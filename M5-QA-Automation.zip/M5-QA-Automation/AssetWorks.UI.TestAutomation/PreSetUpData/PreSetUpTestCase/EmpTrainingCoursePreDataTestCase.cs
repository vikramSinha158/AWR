﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class EmpTrainingCoursePreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/EmpTrainingCoursePreTestData.json", "EmployeeTrainingCourseSetup", true, Description = "M5- Create Employee Training Course Pre Test Data ")]
        public void QA1233_EmployeeTrainingCoursePreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmpCourseSetUpPage();
            List<TrainingCourseSetUp> TrainingCourseObject = CommonUtil.DataObjectForKey("AddTrainingCoursePreSetUp").ToObject<List<TrainingCourseSetUp>>();
            if (TrainingCourseObject != null)
            {
                foreach (TrainingCourseSetUp CourseData in TrainingCourseObject)
                {  
                    int i=0;
                    foreach (string Course in CourseData.CodeList)
                    {
                        CourseData.Code= Course;
                        CourseData .Description= CourseData.DescriptionList[i];
                        CurrentPage.As<EmpCoureSetUpPageActions>().CreateEmployeeTrainingCourse(CourseData);
                        _extendpage.ClickOnRefreshButton();
                        i++;
                    }
                }
            }
            else 
            {
                Assert.Fail("Employee Training Course Pre-Data Not found");
            }
        }
    }
}
