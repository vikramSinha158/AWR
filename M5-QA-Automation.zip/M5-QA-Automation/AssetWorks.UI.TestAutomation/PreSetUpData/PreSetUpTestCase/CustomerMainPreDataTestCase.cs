﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using System.Collections.Generic;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking.CustomerMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class CustomerMainPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/CustomerMainPreTestData.json", "CreateCustomerMain", true, Description = "M5- Create Customer Main Pre Test Data ")]
        public void QA1219_CreateCustomerPreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCustomerMainPage();
            List<CustomerMain> CustomerMainObject = CommonUtil.DataObjectForKey("AddCustomerPreSetUp").ToObject<List<CustomerMain>>();
            if (CustomerMainObject != null)
            {
                foreach (CustomerMain CustomerDetail in CustomerMainObject)
                {
                    int i = 0;                
                    foreach (string CustID in CustomerDetail.CustomerIDList)
                    {
                        CustomerDetail.CustomerID= CustID;
                        CustomerDetail.CustomerDesc= CustomerDetail.CustomerDescList[i];
                        CurrentPage.As<CustomerMainPageActions>().CreateCustomer(CustomerDetail);
                        _extendpage.ClickOnRefreshButton();
                    }
                }
            }
            else 
            {
                Assert.Fail("Customer Main Pre-Data Not found");
            }
        }
    }
}
