﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class PartPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreatePartPreSetUpData", true, Description = "M5-Create Part PreSetUpData ")]
        public void QA1000_CreatePartPreSetUpData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
            List<PartsMainCatalog> PartsMainObject = CommonUtil.DataObjectForKey("PartsMainInfo").ToObject<List<PartsMainCatalog>>();
            if (PartsMainObject != null)
            {
                foreach (PartsMainCatalog partsMainInfo in PartsMainObject)
                {
                    if (partsMainInfo.PartNumberList != null)
                        foreach (string partsNumber in partsMainInfo.PartNumberList)
                        {
                            partsMainInfo.PartNumber = partsNumber;
                            CurrentPage.As<PartMainCatalogPageActions>().CreateNewPart(partsMainInfo);
                            _extendpage.ClickOnRefreshButton();
                        }
                }
            }
            else
            {
                Assert.Fail("Parts Main Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreatePartClassPreSetUpData", true, Description = "M5 - Parts - Part Class Code-Create with Pre-Setup Data")]
        public void QA1310_CreatePartClassCodePreSetupData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartClassCodesPage();
            List<PartsClassCodesObjects> partsClassCodesObjects = CommonUtil.DataObjectForKey("PartsClassCodes").ToObject<List<PartsClassCodesObjects>>();
            if (partsClassCodesObjects != null)
            {
                foreach (PartsClassCodesObjects partsClassCodeObject in partsClassCodesObjects)
                {
                    if (partsClassCodeObject.CodeList != null)
                    {
                        foreach (string code in partsClassCodeObject.CodeList)
                        {
                            partsClassCodeObject.Code = code;
                            CurrentPage.As<PartClassCodesPageActions>().CreateNewPartClassCode(partsClassCodeObject);
                            _extendpage.ClickOnRefreshButton();
                        }
                    }
                }
            }
            else
            {
                Assert.Fail("Parts Class Code Data Not found");
            }
        }
    }
}
