﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class EmployeePreDataTestCase : Hooks
    {      

        [TestCase("PreSetUpTestData/EmployeePreTestData.json", "CreateEmployee", true, Description = "M5-Create Employee PreData Required Fields")]
        public void QA1003_CreateEmployeeRequiredParameters(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CreateEmployeeRequiredParameters DataObject = CommonUtil.DataObjectForKey("CreateEmployeeRequiredData").ToObject<CreateEmployeeRequiredParameters>();
            List<string> EmployeeIDList = DataObject.EmployeeData.EmployeeID;
            if (EmployeeIDList != null)
            {
                foreach (string EmployeeID in EmployeeIDList)
                {
                    CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeRequiredData", EmployeeID);
                }
            }          
        }

        [TestCase("PreSetUpTestData/EmployeePreTestData.json", "CreateEmployee", true, Description = "M5-Create Employee PreData More Fields")]
        public void QA1270_CreateEmployeeMoreParameters(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CreateEmployeeRequiredParameters DataObject = CommonUtil.DataObjectForKey("CreateEmployeeMoreParameters").ToObject<CreateEmployeeRequiredParameters>();
            List<string> EmployeeIDList = DataObject.EmployeeData.EmployeeID;           
            if (EmployeeIDList != null)
            {
                foreach (string EmployeeID in EmployeeIDList)
                {
                    CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeMoreParameters", EmployeeID);
                }
            }
        }
    }
}
