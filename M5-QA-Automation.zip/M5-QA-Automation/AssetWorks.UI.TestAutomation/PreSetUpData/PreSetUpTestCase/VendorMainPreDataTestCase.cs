﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.VendorMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class VendorMainPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/VendorMainPreTestData.json", "CreateVendorMainPreData", true, Description = "M5- Create Vendor Main Pre Test Data ")]
        public void QA1004_CreateVendorPreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToVendorMainPage();
            List<VendorMain> VendorMainObject = CommonUtil.DataObjectForKey("VendorMainData").ToObject<List<VendorMain>>();
            if (VendorMainObject != null)
            {
                foreach (VendorMain VendorDetail in VendorMainObject)
                {                   
                    for (int i=0;i< VendorDetail.VenNumberList.Count;i++)
                    {
                        VendorDetail.VenNumber=VendorDetail.VenNumberList[i];
                        VendorDetail.VenName= VendorDetail.VenNameList[i];
                        CurrentPage.As<VendorMainPageActions>().CreateVendor(VendorDetail);
                        _extendpage.ClickOnRefreshButton();
                    }
                }
            }
            else 
            {
                Assert.Fail("Vendor Main Pre-Data Not found");
            }
        }
    }
}
