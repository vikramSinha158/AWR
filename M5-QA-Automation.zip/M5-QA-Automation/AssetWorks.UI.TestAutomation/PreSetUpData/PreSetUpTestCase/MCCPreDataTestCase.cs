﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class MCCPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/MCCMainPreTestData.json", "MCCMain", true, Description = "M5-Verifying Create MCC Main ")]
        public void QA1001_CreateMCC(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMCCMainPage();
            var MCCCodes = CommonUtil.DataObjectForKey("DataMCCode");
            string[] MCCCodeList = MCCCodes.ToObject<string[]>();
            if (MCCCodeList != null)
            {
                foreach (string MCCCode in MCCCodeList)
                {
                    CurrentPage.As<MCCMainPageActions>().CreateMCCCode("AddDataForMCCMian", MCCCode);
                }
            }
        }
    }
}
