﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Units;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class UnitPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/UnitPreTestData.json", "CreateUnits", true, Description = "M5 Create Unit(s) ")]
        public void QA997_CreateUnit(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            List<UnitMain> DataObject = CommonUtil.DataObjectForKey("Units").ToObject<List<UnitMain>>();
            if (DataObject != null)
            {
                foreach (UnitMain unit in DataObject)
                {
                    CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);
                }
            }
        }

        [TestCase("PreSetUpTestData/UnitPreTestData.json", "CreateUnitRequests", true, Description = "M5 Create Unit Request(s) ")]
        public void QA1093_CreateUnitRequest(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            List<UnitRequest> DataObject = CommonUtil.DataObjectForKey("UnitRequests").ToObject<List<UnitRequest>>();
            if (DataObject != null)
            {
                foreach (UnitRequest unitReq in DataObject)
                {
                    if (unitReq.RequestNoList != null)
                    {
                        List<string> RequestList = unitReq.RequestNoList;
                        foreach (string Request in RequestList)
                        {
                            unitReq.RequestNo = Request;
                            CurrentPage.As<UnitRequestPageActions>().CreateUnitRequest(unitReq);
                            _extendedPage.ClickOnRefreshButton();
                        }
                    }
                    else
                    {
                        CurrentPage.As<UnitRequestPageActions>().CreateUnitRequest(unitReq);
                        _extendedPage.ClickOnRefreshButton();
                    }
                }
            }
            else
                Assert.Fail(" Unit Request Data Not Found ");
        }
        
        [TestCase("PreSetUpTestData/UnitGroupPreTestData.json", "GroupUnitPreData", true, Description = "M5 Create Group Unit")]
        public void QA1095_CreateUnitGroup(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            List<GroupUnit> UnitGroupObject = CommonUtil.DataObjectForKey("GroupUnit").ToObject<List<GroupUnit>>();
            foreach (GroupUnit UnitGroupDetail in UnitGroupObject)
            {
                List<string> UnitGroupNameList = UnitGroupDetail.GroupUnitList;
                foreach (string UnitGroupName in UnitGroupNameList)
                {
                    CurrentPage.As<UnitGroupPageActions>().CreateNewUnitGroup(UnitGroupDetail, UnitGroupName);
                }
            }
        }
    }
}
