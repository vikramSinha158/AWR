﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class BillingPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/BillingPreTestData.json", "Billing", true, Description = "M5-Verifying Create Billing Code ")]
        public void QA996_CreateBillingCode(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            List<AddBillingInformation> BillingObject = CommonUtil.DataObjectForKey("BillingInformation").ToObject<List<AddBillingInformation>>();
            if (BillingObject != null)
            {
                foreach (AddBillingInformation BillingDetail in BillingObject)
                {
                    List<string> BillingList = BillingDetail.BillingCodeList;
                    foreach (string BillingCode in BillingList)
                    {
                        BillingDetail.BillingCode = BillingCode;
                        CurrentPage.As<BillingPageActions>().CreateBillingCode(BillingDetail);
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Billing  Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/BillingFixedChargePreTestData.json", "BillingItem", true, Description = "M5-Verifying Create BillingItem Code ")]
        public void QA1230_CreateBillingItem(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingFixedCharges();
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingItemPreData").ToObject<List<BillingFixedCharge>>();
            if (BillingItemObject != null)
            {
                foreach (BillingFixedCharge BillingItemDetail in BillingItemObject)
                {
                    List<string> BillingItemList = BillingItemDetail.BillingItemList;
                    foreach (string BillingItemCode in BillingItemList)
                    {
                        BillingItemDetail.BillingItem = BillingItemCode;
                        CurrentPage.As<BillingFixedChargePageActions>().AddBillingFixedCharges(BillingItemDetail);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("BillingItem Data Not found");
            }
        }
    }
}
