﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class ResourceTypePreDataTestCase : Hooks
    {      

        [TestCase("PreSetUpTestData/ResourceTypePreTestData.json", "ResourceType", true, Description = "M5-Create Equipment Types Pre Test Data ")]
        public void QA1224_AddResourceTypePreSetUp(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToResourceTypePage();
            List<ResourceType> ResTypeObject = CommonUtil.DataObjectForKey("ResourceTypePreSetUp").ToObject<List<ResourceType>>();
            if (ResTypeObject != null)
            {
                foreach (ResourceType ResTypeData in ResTypeObject)
                {
                    List<string> ResourceList = ResTypeData.ResourceList;
                    int i = 0;
                    foreach (string ResourceNo in ResourceList)
                    {
                        ResTypeData.Resource = ResourceNo;
                        ResTypeData.Description = ResTypeData.DescriptionList[i];
                        CurrentPage.As<ResourceTypePageActions>().AddResourceType(ResTypeData);
                        i++;
                    }
                }
            }
            else {
                Assert.Fail("Resource Type PreStUp Data Not found");
            }
        }
    }
}
