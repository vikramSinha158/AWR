﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class DirectAccountCodesPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/DCAPreTestData.json", "CreateDirectAccountCodes", true,
            TestName = "QA1169_CreateDirectAccountCodes", Description = "M5-Direct Account Codes pre setup data Create Direct Account Codes")]
        public void QA1169_CreateDirectAccountCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDirectAccountCodesPage();
            List<DirectAccountInformation> dcas = CommonUtil.DataObjectForKey("Codes").ToObject<List<DirectAccountInformation>>();
            foreach (DirectAccountInformation dca in dcas)
            {
                if (dca.DirectAccountList != null)
                {
                    foreach (string code in dca.DirectAccountList)
                    {
                        dca.DirectAccount = code;
                        CurrentPage.As<DirectAccountCodesPageActions>().CreateNewDirectAccountCode(dca);
                    }
                }
                else
                    CurrentPage.As<DirectAccountCodesPageActions>().CreateNewDirectAccountCode(dca);
            }
        }


        [TestCase("PreSetUpTestData/DCAPreTestData.json", "CreateIndirectAccountCodes", true,
            TestName = "QA1323_CreateIndirectAccountCodes", Description = "M5-Indirect Account Codes pre setup data Create Indirect Account Codes")]
        public void QA1323_CreateIndirectAccountCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToIndirectAccountCodesPage();
            List<IndirectAccountInfo> codes = CommonUtil.DataObjectForKey("Codes").ToObject<List<IndirectAccountInfo>>();
            foreach (IndirectAccountInfo code in codes)
            {
                if (code.IndirectAccountList != null)
                {
                    foreach (string account in code.IndirectAccountList)
                    {
                        code.AccountNo = account;
                        CurrentPage.As<IndirectAccountCodesPageActions>().CreateIndirectAccountCode(code);
                    }
                }
                else
                    CurrentPage.As<IndirectAccountCodesPageActions>().CreateIndirectAccountCode(code);
            }
        }
    }
}
