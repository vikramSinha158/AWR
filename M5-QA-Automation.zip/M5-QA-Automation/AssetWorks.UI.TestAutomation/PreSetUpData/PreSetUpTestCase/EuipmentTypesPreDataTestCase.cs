﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Equipment;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class EquipmentTypesPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/EquipmentTypesPreTestData.json", "EquipmentType", true, Description = "M5-Create Equipment Types Pre Test Data ")]
        public void QA1005_CreateEquipmentTypes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEquipmentTypesSKUPage();
            List<EquipmentTypeSKU> EquipTypeObject = CommonUtil.DataObjectForKey("CreateEquipmentType").ToObject<List<EquipmentTypeSKU>>();
            if (EquipTypeObject != null)
            {
                foreach (EquipmentTypeSKU EquipTypeData in EquipTypeObject)
                {
                   CurrentPage.As<EquipmentTypesSKUPageActions>().CreateNewEquipmentType(EquipTypeData);                    
                }
            }
            else {
                Assert.Fail("Equipment Types PreStUp Data Not found");
            }
        }
    }
}
