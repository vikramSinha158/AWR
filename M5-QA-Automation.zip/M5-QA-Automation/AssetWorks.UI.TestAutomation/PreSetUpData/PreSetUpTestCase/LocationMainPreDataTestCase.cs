﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class LocationMainPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/LocationMainPreTestData.json", "LocationMain", true, Description = "M5- Create Location Main Pre Test Data ")]
        public void QA1218_CreateLocationMainPreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToLocationMain();
            List<LocationMain> LocationMainObject = CommonUtil.DataObjectForKey("CreateLocationPresetUp").ToObject<List<LocationMain>>();
            if (LocationMainObject != null)
            {
                foreach (LocationMain LocationData in LocationMainObject)
                {
                    int i = 0;
                    foreach (string Location in LocationData.LocationList)
                    {
                        LocationData.Location = Location;
                        LocationData.LocationDesc= LocationData.LocationDescList[i];
                        CurrentPage.As<LocationMainPageActions>().CreateLocation(LocationData);
                        _extendpage.ClickRefresh();
                        i++;
                    }
                }
            }
            else 
            {
                Assert.Fail("Location Main Pre-Data Not found");
            }
        }
    }
}
