using System;

namespace AssetWorks.UI.M5.TestAutomation.Common
{
    public static class ScreensUrl
    {
        public static string WorkOrderMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=WORK ORDER MAIN";

        public static string DepartmentMain = "/PRESENTATION/DEPT/DEFAULT.ASPX";

        public static string UnitMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=UNIT MAIN";

        public static string ComponentMain = "/PRESENTATION/COMPONENT/DEFAULT.ASPX";

        public static string WorkOrderDepartmentRequisitions = "/PRESENTATION/WORKREQUEST/DEPTREQ.ASPX";

        public static string DepartmentNumberChange = "/PRESENTATION/DEPT/DEPTNOCHG.ASPX";

        public static string WorkRequestMain = "/PRESENTATION/WORKREQUEST/DEFAULT.ASPX";

        public static string DepartmentCopy = "/PRESENTATION/DEPT/DUPLICATOR.ASPX";

        public static string UnitDepartmentChange = "/PRESENTATION/UNIT/UNITDEPTCHANGE.ASPX";

        public static string DepartmentGroups = "/PRESENTATION/SECURITY/DEPTGROUPMAINT.ASPX";

        public static string BillingCodes = "/PRESENTATION/BILLCODEMAINT/DEFAULT.ASPX";

        public static string AssetClassCodes = "/PRESENTATION/MISCCODES/CATEGORYCLASS.ASPX";

        public static string SystemStateCountryCodes = "/PRESENTATION/MISCCODES/STATE_COUNTRYCODE.ASPX";

        public static string MCCMain = "/PRESENTATION/MCC/DEFAULT.ASPX";

        public static string DirectAccountCodes = "/PRESENTATION/DIRACCT/DEFAULT.ASPX";

        public static string StandardJobMCC = "/PRESENTATION/STANDJOB/STANDJOBMCC.ASPX";

        public static string SystemCodes = "/PRESENTATION/SYSCOMP/SYSCODES.ASPX";

        public static string PositionCodes = "/PRESENTATION/MISCCODES/POSITIONMAINT.ASPX";

        public static string EmployeeMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=EMPLOYEE MAIN";

        public static string PartListDisposal = "/PRESENTATION/PARTS/PARTDISPOSAL.ASPX";

        public static string PartMainCatalog = "/PRESENTATION/PARTS/DEFAULT.ASPX";

        public static string MotorPoolRentalClass = "/MOTORPOOL/MOTORPOOL/MPRENTALCLASS.ASPX";

        public static string RoleMaintenance = "/PRESENTATION/SECURITY/USERROLE.ASPX";

        public static string VendorMain = "/PRESENTATION/VENDOR/DEFAULT.ASPX";

        public static string VendorCopy = "/PRESENTATION/VENDOR/DUPLICATOR.ASPX";

        public static string VendorNumberChange = "/PRESENTATION/VENDOR/VENDORNOCHG.ASPX";

        public static string CustomerMain = "/EXCUST/FRAMES/DEFAULT.ASPX";

        public static string ApplicationUserMaintenance = "/PRESENTATION/SECURITY/USERAPP.ASPX";

        public static string PartInventoryLocManager = "/PRESENTATION/PARTS/PARTINVLOC.ASPX";

        public static string PartAdjustment = "/PRESENTATION/PARTS/PARTADJINV.ASPX";

        public static string UnitRequest = "/PRESENTATION/UNITACQUISITION/UNITREQUEST.ASPX";

        public static string CustomerTypeCodes = "/EXCUST/FRAMES/CUSTOMERTYPE.ASPX";

        public static string BookingTypeCodes = "/EXCUST/FRAMES/BOOKINGTYPECODES.ASPX";

        public static string ApplicationUserCopy = "/PRESENTATION/SECURITY/DUPLICATOR_USERAPP.ASPX";

        public static string EquipmentProfileTypes = "/PRESENTATION/MISCCODES/EQUIPPROFILETYPE.ASPX";

        public static string EquipmentTypesSKU = "/EQF/EQUIPMENT/EQUIPMENTTYPES.ASPX";

        public static string EquipmentConditions = "/EQF/EQUIPMENT/EQUIPMENTCONDITIONS.ASPX";

        public static string TaxType = "/PRESENTATION/MISCCODES/TAXTYPE.ASPX";

        public static string PartBinPage = "/PRESENTATION/PARTS/BINMAIN.ASPX";

        public static string UnitPurchaseOrders = "/PRESENTATION/UNITACQUISITION/UNITREQPO.ASPX";

        public static string UnitCopy = "/PRESENTATION/UNIT/DUPLICATOR.ASPX";

        public static string PositionCode = "/PRESENTATION/MISCCODES/POSITIONMAINT.ASPX";

        public static string SystemPosition = "/PRESENTATION/SYSCOMP/SYSPOSCODES.ASPX";

        public static string EmployeeTitle = "/PRESENTATION/EMPLOYEES/EMPTITLE.ASPX";

        public static string SystemFlag = "/PRESENTATION/CONTROL/MODMAINT.ASPX";

        public static string NonCompanyUnitMain = "/OPERCTL/OPERATOR/DRIVERNCVEH.ASPX";

        public static string UnitPurchaseRequisitions = "/PRESENTATION/UNITACQUISITION/NEWUNIT.ASPX";

        public static string RoleCopy = "/PRESENTATION/SECURITY/DUPLICATOR.ASPX";

        public static string TaxScheme = "/PRESENTATION/MISCCODES/TAXSCHEME.ASPX";

        public static string BillingFixedCharges = "/PRESENTATION/BILLCODEMAINT/BILLVALIDFIX.ASPX";

        public static string EmployeeTransfer = "/PRESENTATION/EMPLOYEES/EMPTRANSFER.ASPX";

        public static string EmployeeGroup = "/PRESENTATION/EMPLOYEES/EMPGROUPMAINT.ASPX";

        public static string EmployeeShiftAssignment = "/PRESENTATION/EMPLOYEES/EMPSHIFTASSIGN.ASPX";

        public static string CustomerContract = "/EXCUST/FRAMES/CUSTCONTRACT.ASPX";

        public static string CustomerContractCopy= "/EXCUST/FRAMES/CUSTCONTRACTCOPY.ASPX";

        public static string EmployeeCopy = "/PRESENTATION/EMPLOYEES/DUPLICATOR.ASPX";

        public static string PurchaseRequisitions = "/PRESENTATION/PARTS/PREQUISITION.ASPX";

        public static string EquipmentProfile = "/PRESENTATION/MISCCODES/EQUIPPROFILEMAINT.ASPX";

        public static string UnitRequestApprove = "/PRESENTATION/UNITACQUISITION/UNITREQUESTAPPROVE.ASPX";
 
        public static string ItemMasterDefinition = "/PRESENTATION/ITEMMAINT/DEFAULT.ASPX";

        public static string MCCCopy = "/PRESENTATION/MCC/DUPLICATOR.ASPX";

        public static string MarkUpScheme = "/PRESENTATION/MISCCODES/MARKUPSCHEME.ASPX";

        public static string CopyMarkUpScheme = "/PRESENTATION/MISCCODES/MARKUPSCHEMEDUP.ASPX";

        public static string MCCUnitDisplay = "/PRESENTATION/MCC/MCCUNITSCOMP.ASPX";

        public static string MCCQuery= "/PRESENTATION/MCC/MCCDISPLAY.ASPX";

        public static string EmployeeNumberChange = "/PRESENTATION/EMPLOYEES/EMPNOCHG.ASPX";

        public static string AccidentType = "/PRESENTATION/MISCCODES/ACCIDENTTYPES.ASPX";

        public static string AccidentCategory = "/PRESENTATION/ACCIDENT/ACCIDENTCATEGORY.ASPX";
      
        public static string VendorContract = "/PRESENTATION/PARTS/PCONTRACT.ASPX";

        public static string ActiveUserDisplay = "/PRESENTATION/SYSTEM/ACTIVEUSERS.ASPX";

        public static string ComponentCopy = "/PRESENTATION/COMPONENT/DUPLICATOR.ASPX";

        public static string ComponentNumberChange = "/PRESENTATION/COMPONENT/COMPNOCHG.ASPX";

        public static string BillingAdjustment = "/PRESENTATION/BILLCODEMAINT/BILLUNITADJ.ASPX";

        public static string BookingSourceCodes = "/EXCUST/FRAMES/BOOKINGSOURCECODES.ASPX";

        public static string BookingDeclineCancelCodes = "/EXCUST/FRAMES/BOOKINGDECLREASON.ASPX";
      
        public static string BookingAppointment = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=BOOKING APPOINTMENT";

        public static string EmployeeTrainingTranscipt = "/PRESENTATION/EMPLOYEES/EMPTRAINING.ASPX";

        public static string EmpTrainingCourseSetUp = "/PRESENTATION/EMPLOYEES/COURSE.ASPX";

        public static string BillingUnitAccounts = "/PRESENTATION/BILLCODEMAINT/BILLUNITACCT2.ASPX";

        public static string BookingChangeDateReason = "/EXCUST/FRAMES/DATECHANGEREASON.ASPX";
        
        public static string EmpCourseQuery = "/PRESENTATION/EMPLOYEES/COURSEATTENDQRY.ASPX";

        public static string ResourceType = "/PRESENTATION/SHOPPLANNING/RESOURCETYPE.ASPX";

        public static string FuelProducts = "/PRESENTATION/PRODGENMAINT/DEFAULT.ASPX";

        public static string EmployeeItems = "/PRESENTATION/EMPLOYEES/EMPLOYEEITEM.ASPX";
        
        public static string AccidentCause = "/PRESENTATION/MISCCODES/ACCIDENTCAUSE.ASPX";

        public static string WorkRequestCampaignManager = "/PRESENTATION/WORKREQUEST/CAMPAIGN.ASPX";

        public static string LocationMain = "/PRESENTATION/GENLLOC/DEFAULT.ASPX";

        public static string WarrantyTechSpec = "/PRESENTATION/TECHSPEC/TECHSPECWARR.ASPX";

        public static string CompanyDefinition = "/PRESENTATION/CONTROL/DEFAULT.ASPX";

        public static string BillingCodeCopy = "/PRESENTATION/BILLCODEMAINT/BILLCODEDUPLICATOR.ASPX";

        public static string BillingItems = "/PRESENTATION/BILLCODEMAINT/BILLITEM.ASPX";

        public static string BillingItemSource = "/PRESENTATION/BILLCODEMAINT/BILLITEMSOURCE.ASPX";

        public static string AccidentEntry = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=ACCIDENT";

        public static string EmployeePlannedAbsences = "/PRESENTATION/EMPLOYEES/EMPPLANABSENCE.ASPX";

        public static string LaborWedge = "/PRESENTATION/WORKORDER/LABORWEDGE.ASPX";

        public static string EquipmentRequest = "/EQF/EQUIPMENT/EQUIPMENTREQUEST.ASPX";

        public static string MenuMaintenance = "/PRESENTATION/MENUMAINT/DEFAULT.ASPX";

        public static string BillingIndirectItems = "/PRESENTATION/BILLCODEMAINT/BILLINDACCT.ASPX";

        public static string MotorPoolManager = "/MOTORPOOL/MOTORPOOL/DEFAULT.ASPX";

        public static string ProductSetupTanks = "/PRESENTATION/GENLLOC/LOCTANKSETTINGS.ASPX";

        public static string WorkRequestIncident = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=INCIDENT ENTRY";

        public static string DriverStatusCodes = "/PRESENTATION/EMPLOYEES/DRIVERSTATUSCODES.ASPX";

        public static string DriverAllocationReasons = "/OPERCTL/OPERATOR/DRIVERALLOCREASONS.ASPX";
        
        public static string ServiceOrder = "/PRESENTATION/WORKORDER/SERVICEORDER.ASPX";

        public static string BillingDepartmentAccounts = "/PRESENTATION/DEPT/BILLDEPTMAINT.ASPX";

        public static string BillSingleDepartmentAccount = "/PRESENTATION/DEPT/BILLSINGLEDEPTMAINT.ASPX";

        public static string BillSingleUnitAccount = "/PRESENTATION/BILLCODEMAINT/BILLSINGLEUNITACCT2.ASPX";

        public static string DriverTypes = "/PRESENTATION/EMPLOYEES/DRIVERTYPECODES.ASPX";
        
        public static string PartClassCodes = "/PRESENTATION/PARTS/PARTCLASSCODE.ASPX";

        public static string DriverEventClasses = "/OPERCTL/OPERATOR/DRIVEREVENTCLASSES.ASPX";

        public static string DriverEventTypes = "/OPERCTL/OPERATOR/DRIVEREVENTTYPES.ASPX";

        public static string DriverLicenseClasses = "/OPERCTL/OPERATOR/DRIVERLICENCECLASSES.ASPX";

        public static string IndirectAccountCodes = "/PRESENTATION/INDACCT/DEFAULT.ASPX";
        
        public static string EquipRetReasons = "/EQF/EQUIPMENT/EQUIPMENTRETURNREASONS.ASPX";

        public static string DriverEventItem = "/OPERCTL/OPERATOR/DRIVEREVENTITEMS.ASPX";

        public static string ProductOrder = "/PRESENTATION/FUEL/PRODORDER.ASPX";

        public static string ProductReceive = "/PRESENTATION/FUEL/PRODRECEIVE.ASPX";

        public static string DriverMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=DRIVER MAIN";

        public static string ServiceOrderQuery = "/PRESENTATION/WORKORDER/SERVICEPOQUERY.ASPX";

        public static string ServiceOrderReceipt = "/PRESENTATION/WORKORDER/SERVICEORDERRECV.ASPX";

        public static string ProductSetupLocation = "/PRESENTATION/PRODGENMAINT/PRODLOC.ASPX";

        public static string ProductSetUpEmployees = "/PRESENTATION/EMPLOYEES/EMPPROD.ASPX";

    }
}