﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;

namespace AssetWorks.UI.M5.TestAutomation.Config
{
    /// <summary>
    /// Configuration Data
    /// </summary>
    public class ConfigurationData : ConfigReader
    {
        /// <summary>
        /// Set Configuration Data
        /// </summary>
        public static void SetConfigData()
        {
            IntializeConfigSettings();
            if(Settings.Logger == null)
            Settings.Logger = Core.Logs.Logs.Log<Hooks>();
            Settings.Logger.Info($"Settings.Logs: {Settings.Logs}");
            Settings.Logger.Info("------------Setting variables initialization------------");
            Settings.TestPlanSummary = Settings.TData["TestPlanSummary"];
            Settings.Logger.Info($"Settings.TestPlanSummary: {Settings.TestPlanSummary}");
            Settings.ExtentReportPath = Settings.ConfigSettings["ConfigurationData"];
            Settings.Logger.Info($"Settings.ExtentReportPath: {Settings.ExtentReportPath}");
            Settings.ImplicitWait = int.Parse(Settings.ConfigSettings["ImplicitWait"]);
            Settings.Logger.Info($"Settings.ImplicitWait: {Settings.ImplicitWait}");
            Settings.MinExplicitlyWaitTime = int.Parse(Settings.ConfigSettings["MinExplicitlyWaitTime"]);
            Settings.Logger.Info($"Settings.MinExplicitlyWaitTime: {Settings.MinExplicitlyWaitTime}");
            Settings.MaxExplicitlyWaitTime = int.Parse(Settings.ConfigSettings["MidExplicitlyWaitTime"]);
            Settings.Logger.Info($"Settings.MaxExplicitlyWaitTime: {Settings.MaxExplicitlyWaitTime}");
            Settings.ImplicitWait = int.Parse(Settings.ConfigSettings["MaxExplicitlyWaitTime"]);
            Settings.Logger.Info($"Settings.ImplicitWait: {Settings.ImplicitWait}");
            Settings.AUT = TestContext.Parameters["webAppUrl"];
            Settings.Logger.Info($"Settings.AUT: {Settings.AUT}");
            Settings.BrowserName = TestContext.Parameters["browser"];
            Settings.Logger.Info($"Settings.BrowserName: {Settings.BrowserName}");
            Settings.UserName = TestContext.Parameters["webAppUserName"];
            Settings.Logger.Info($"Settings.UserName: {Settings.UserName}");
            Settings.Password = TestContext.Parameters["webAppPassword"];
            Settings.Logger.Info($"Settings.Password: {Settings.Password}");
            Settings.ExtentReport = bool.Parse(Settings.ConfigSettings["ExtentReport"]);
            Settings.Logger.Info($"Settings.ExtentReport: {Settings.ExtentReport}");
            Settings.Logs = bool.Parse(Settings.ConfigSettings["Logs"]);
            Settings.WorkOrderMain = Settings.TData["WorkOrderMain"];
            Settings.Logger.Info($"Settings.WorkOrderMain: {Settings.WorkOrderMain}");
            Settings.Location = TestContext.Parameters["Location"];
            Settings.Logger.Info($"Settings.Location: {Settings.Location}");
            Settings.Department = TestContext.Parameters["Department"];
            Settings.Logger.Info($"Settings.Department: {Settings.Department}");
            Settings.DepartmentMain = Settings.TData["DepartmentMain"];
            Settings.Logger.Info($"Settings.DepartmentMain: {Settings.DepartmentMain}");
            Settings.DepartmentNumber = Settings.TData["DepartmentNumber"];
            Settings.Logger.Info($"Settings.DepartmentNumber: {Settings.DepartmentNumber}");
            Settings.DepartmentStatusFlag = Settings.TData["DepartmentStatusFlag"];
            Settings.Logger.Info($"Settings.DepartmentStatusFlag: {Settings.DepartmentStatusFlag}");
            Settings.WorkOrderDepartmentRequisitions = Settings.TData["WorkOrderDepartmentRequisitions"];
            Settings.Logger.Info($"Settings.WorkOrderDepartmentRequisitions: {Settings.WorkOrderDepartmentRequisitions}");
            Settings.DepartmentRequisitionDesc = Settings.TData["DepartmentRequisitionDesc"];
            Settings.Logger.Info($"Settings.DepartmentRequisitionDesc: {Settings.DepartmentRequisitionDesc}");
            Settings.DepartmentRequisitionDeptNo = Settings.TData["DepartmentRequisitionDeptNo"];
            Settings.Logger.Info($"Settings.DepartmentRequisitionDeptNo: {Settings.DepartmentRequisitionDeptNo}");
            Settings.DepartmentRequisitiondirectAccNo = Settings.TData["DepartmentRequisitiondirectAccNo"];
            Settings.Logger.Info($"Settings.DepartmentRequisitiondirectAccNo: {Settings.DepartmentRequisitiondirectAccNo}");
            Settings.DepartmentNumberChange = Settings.TData["DepartmentNumberChange"];
            Settings.Logger.Info($"Settings.DepartmentNumberChange: {Settings.DepartmentNumberChange}");
            Settings.WorkRequestMain = Settings.TData["WorkRequestMain"];
            Settings.Logger.Info($"Settings.WorkRequestMain: {Settings.WorkRequestMain}");
            Settings.JobCode = Settings.TData["JobCode"];
            Settings.Logger.Info($"Settings.JobCode: {Settings.JobCode}");
            Settings.EmployeeCode = Settings.TData["EmployeeCode"];
            Settings.Logger.Info($"Settings.JobCode: { Settings.EmployeeCode}");
            Settings.EmployeeName = Settings.TData["EmployeeName"];
            Settings.Logger.Info($"Settings.JobCode: {  Settings.EmployeeName}");
            Settings.EmployeePosition = Settings.TData["EmployeePostion"];
            Settings.Logger.Info($"Settings.JobCode: { Settings.EmployeePosition}");
            Settings.TimeType = Settings.TData["TimeType"];
            Settings.Logger.Info($"Settings.JobCode: { Settings.TimeType}");
            Settings.PayClass = Settings.TData["PayClass"];
            Settings.Logger.Info($"Settings.JobCode: { Settings.PayClass}");
            Settings.PayStep = Settings.TData["PayStep"];
            Settings.Logger.Info($"Settings.JobCode: { Settings.PayStep}");
            Settings.DepartmentCopy = Settings.TData["DepartmentCopy"];
            Settings.Logger.Info($"Settings.DepartmentCopy: {Settings.DepartmentCopy}");
            Settings.UnitDepartmentChange = Settings.TData["UnitDepartmentChange"];
            Settings.Logger.Info($"Settings.UnitDepartmentChange: {Settings.UnitDepartmentChange}");
            Settings.DepartmentGroups = Settings.TData["DepartmentGroups"];
            Settings.Logger.Info($"Settings.DepartmentGroups: {Settings.DepartmentGroups}");
            Settings.BillingCodes = Settings.TData["BillingCodes"];
            Settings.Logger.Info($"Settings.BillingCodes: {Settings.BillingCodes}");
            Settings.AssetClassCodes = Settings.TData["AssetClassCodes"];
            Settings.Logger.Info($"Settings.AssetClassCodes: {Settings.AssetClassCodes}");
            Settings.SystemStateCountryCodes = Settings.TData["SystemStateCountryCodes"];
            Settings.Logger.Info($"Settings.SystemStateCountryCodes: {Settings.SystemStateCountryCodes}");
            Settings.MCCMain = Settings.TData["MCCMain"];
            Settings.Logger.Info($"Settings.MCCMain: {Settings.MCCMain}");
            Settings.DBType = TestContext.Parameters["DBType"];
            Settings.Environment = TestContext.Parameters["Environment"];
            if (Settings.Environment.Contains("QA"))
            {
                Settings.OracleConnectionString = TestContext.Parameters["QA_OracleConnectionString"];
                Settings.SQLConnectionString = TestContext.Parameters["QA_SQLConnectionString"];
            }
            else if((Settings.Environment.Contains("STQA")))
            {
                Settings.OracleConnectionString = TestContext.Parameters["UAT_OracleConnectionString"];
                Settings.SQLConnectionString = TestContext.Parameters["UAT_SQLConnectionString"];
            }
        }
    }
}
