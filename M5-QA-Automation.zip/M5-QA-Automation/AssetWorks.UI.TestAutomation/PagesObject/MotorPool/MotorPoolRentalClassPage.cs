﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolRentalClassPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal MotorPoolRentalClassPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _mprClass { get; set; }

        public static string _mprDesc { get; set; }

        public static string _mprPrepDuration { get; set; }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPRentalClassFrame']")]
        internal IWebElement? _frameMPRentalClass = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MotorPoolTable']/tbody")]
        internal IWebElement? _tableMotorPool = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='class$new_0']")]
        internal IWebElement? _inputNewClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='description$new_0']")]
        internal IWebElement? _inputNewDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='prep_duration$new_0']")]
        internal IWebElement? _inputNewPrepDuration = null;
    }
}
