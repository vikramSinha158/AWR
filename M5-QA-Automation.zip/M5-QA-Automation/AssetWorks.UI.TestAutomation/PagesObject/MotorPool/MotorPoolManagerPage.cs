﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolManagerPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorPoolManagerPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='MP_Ticket_No']")]
        internal IWebElement? _inputMPTicketNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newMP']")]
        internal IWebElement? _buttonNewMP = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MPStatus']")]
        internal IWebElement? _inputMPStatus = null;

        //Reservation tab
        [FindsBy(How = How.XPath, Using = "//input[@id='Pickup_Location']")]
        internal IWebElement? _inputPickupLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Pickup_Date_Time']")]
        internal IWebElement? _inputPickupDateTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Return_Location']")]
        internal IWebElement? _inputReturnLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Return_Date_Time']")]
        internal IWebElement? _inputReturnDateTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rental_Class']")]
        internal IWebElement? _inputRentalClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Equip_Unit_No']")]
        internal IWebElement? _inputEquipUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Reserved_For']")]
        internal IWebElement? _inputReservedFor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Dept_No']")]
        internal IWebElement? _inputDepartmentNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Phone_No']")]
        internal IWebElement? _inputPhoneNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Destination']")]
        internal IWebElement? _inputDestination = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Requested_By']")]
        internal IWebElement? _inputRequestedBy = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Reason']")]
        internal IWebElement? _inputReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Account_No']")]
        internal IWebElement? _inputAccountNo = null;

        //Pickup/Return tab
        [FindsBy(How = How.XPath, Using = "//button[@id='CBPickup']")]
        internal IWebElement? _buttonPickup = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Date_Out']")]
        internal IWebElement? _inputDateOut = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Location_Out']")]
        internal IWebElement? _inputLocationOut = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Meter1_Out']")]
        internal IWebElement? _inputMeter1Out = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Meter2_Out']")]
        internal IWebElement? _inputMeter2Out = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='CBReturn']")]
        internal IWebElement? _buttonReturn = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Date_In']")]
        internal IWebElement? _inputDateIn = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Location_In']")]
        internal IWebElement? _inputLocationIn = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Meter1_In']")]
        internal IWebElement? _inputMeter1In = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Meter2_In']")]
        internal IWebElement? _inputMeter2In = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CBMeterInOvr']")]
        internal IWebElement? _checkboxMeterInOvr = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Where_In']")]
        internal IWebElement? _inputWhereIn = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Licperm_No']")]
        internal IWebElement? _inputLicPermNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='State']")]
        internal IWebElement? _inputState = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CityLicense_No']")]
        internal IWebElement? _inputCityLicenseNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Moving_Violations']")]
        internal IWebElement? _checkboxMovingViolations = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Damage']")]
        internal IWebElement? _checkboxDamage = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Returned_By']")]
        internal IWebElement? _inputReturnedBy = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='PRNotes']")]
        internal IWebElement? _inputPRNotes = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Billing_Method']")]
        internal IWebElement? _selectBillingMethod = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='BillWeekends']")]
        internal IWebElement? _checkboxBillWeekends = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='BillHolidays']")]
        internal IWebElement? _checkboxBillHolidays = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Adj_Hours']")]
        internal IWebElement? _inputAdjHours = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Free_Hours']")]
        internal IWebElement? _inputFreeHours = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rate_Hours']")]
        internal IWebElement? _inputRateHours = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Adj_Days']")]
        internal IWebElement? _inputAdjDays = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Free_Days']")]
        internal IWebElement? _inputFreeDays = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rate_Days']")]
        internal IWebElement? _inputRateDays = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Adj_Weeks']")]
        internal IWebElement? _inputAdjWeeks = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Free_Weeks']")]
        internal IWebElement? _inputFreeWeeks = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rate_Weeks']")]
        internal IWebElement? _inputRateWeeks = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Adj_Months']")]
        internal IWebElement? _inputAdjMonths = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Free_Months']")]
        internal IWebElement? _inputFreeMonths = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rate_Months']")]
        internal IWebElement? _inputRateMonths = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rate_Usage']")]
        internal IWebElement? _inputRateUsage = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Quantity_Fuel']")]
        internal IWebElement? _inputQuantityFuel = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rate_Fuel']")]
        internal IWebElement? _inputRateFuel = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MotorPoolFrame']")]
        internal IWebElement? _frameMotorPool = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MotorPoolTable']//tbody")]
        internal IWebElement? _tableMotorPool = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Desc$new_0']")]
        internal IWebElement? _inputNewDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ChargeAmt$new_0']")]
        internal IWebElement? _inputNewChargeAmt = null;
    }
}
