﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Labor
{
    internal class LaborWedgePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal LaborWedgePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmployeeNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NWOUnitNo']")]
        internal readonly IWebElement? _inputNWOUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NWOIndCode']")]
        internal readonly IWebElement? _inputNWOIndCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewJobCode']")]
        internal readonly IWebElement? _inputNewJobCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewPosition']")]
        internal readonly IWebElement? _inputNewPosition = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WoTimeType']")]
        internal readonly IWebElement? _inputWoTimeType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WoPayClass']")]
        internal readonly IWebElement? _inputWoPayClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WoPayStep']")]
        internal readonly IWebElement? _inputWoPayStep = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewPunchTime']")]
        internal readonly IWebElement? _inputNewPunchTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JobStatus']")]
        internal readonly IWebElement? _inputJobStatus = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CurrentLaborFrame']")]
        internal IWebElement? _frameCurrentLabor = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='currTable']/tbody")]
        internal IWebElement? _tableCurrentLabor = null;
    }
}
