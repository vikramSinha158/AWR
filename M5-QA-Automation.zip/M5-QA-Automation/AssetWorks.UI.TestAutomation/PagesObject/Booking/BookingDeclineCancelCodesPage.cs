﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Booking
{
    internal class BookingDeclineCancelCodesPage : BasePage
    {
        internal static string BookingDeclineCanelCodes { get;set;}
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public BookingDeclineCancelCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@name='REASON$new_0']")]
        internal readonly IWebElement? _bookingCode = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BookingDeclReasonFrame']")]
        internal readonly IWebElement? _frameBookingDeclineCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DESCRIPTION$new_0']")]
        internal readonly IWebElement? _bookingDescriptionCode = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BookingDeclReasonTable']")]
        internal readonly IWebElement? _bookingDeclineCodeTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BookingDeclReasonTable']//tbody//tr")]
        internal IList<IWebElement>? _bookingCodeTableRows = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DECLINE_FL$new_0']")]
        internal readonly IWebElement? _bokingCodeDeclinecheckbox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CANCEL_FL$new_0']")]
        internal readonly IWebElement? _bokingCodeCancelcheckbox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DISABLED_FL$new_0']")]
        internal readonly IWebElement? _bokingCodeDisablecheckbox = null;

    }

}
