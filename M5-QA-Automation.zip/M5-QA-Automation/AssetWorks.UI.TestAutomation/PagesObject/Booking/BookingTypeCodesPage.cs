﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BookingTypeCodesPage : BasePage
    {
        public static string BookingTypeCode { get; set; }
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public BookingTypeCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='BOOKING_TYPE$new_0']")]
        internal readonly IWebElement? _bokingTypeCode = null;
    
        [FindsBy(How = How.XPath, Using = "//table[@id='BookingTypeCodesTable']")]
        internal readonly IWebElement? _bookingCodeTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BookingTypeCodesFrame']")]
        internal IWebElement? _frameBookingTypeCodes = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DISABLED_FL$new_0']")]
        internal readonly IWebElement? _bokingTypeDisablecheckbox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='REQ_ADDRESS_FL$new_0']")]
        internal readonly IWebElement? _bokingTypeReqAddcheckbox = null;

    }
}
