﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Booking
{
    internal class BookingSourceCodesPage: BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public BookingSourceCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@name='BOOKING_SOURCE$new_0']")]
        internal readonly IWebElement? _bookingSourcecode = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BookingSourceCodesFrame']")]
        internal readonly IWebElement? _iframebookingecode = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BookingSourceCodesTable']")]
        internal readonly IWebElement? _Tablebookingecode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DISABLED_FL$new_0']")]
        internal readonly IWebElement? _Checkboxbookingecode = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BookingSourceCodesTable']//tbody//tr")]
        internal IList<IWebElement>? _bookingTableRows = null;
    }
}
