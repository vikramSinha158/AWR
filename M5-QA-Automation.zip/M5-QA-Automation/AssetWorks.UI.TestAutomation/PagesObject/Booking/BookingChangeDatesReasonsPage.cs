﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Booking
{
    internal class BookingChangeDatesReasonsPage: BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public BookingChangeDatesReasonsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='Reason_Code$new_0']")]
        internal readonly IWebElement? _bokingDateChangeCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Desc$new_0']")]
        internal readonly IWebElement? _bokingDateChangeCodeDescp = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ReasonCodeFrame']")]
        internal readonly IWebElement? _framebokingDateChangeCode = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='reasonCodeTable']")]
        internal readonly IWebElement? _TablebokingDateChangeCode = null;
    }
}
