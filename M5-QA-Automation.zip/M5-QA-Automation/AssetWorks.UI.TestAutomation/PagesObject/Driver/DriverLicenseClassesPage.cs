﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverLicenseClassesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverLicenseClassesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _headerLicence = "Code";

        internal IWebElement? _disabledCheckBox = null;

        [FindsBy(How = How.Id, Using = "issueAuthCode")]
        internal readonly IWebElement? _issuingAuthorityTxtBox = null;

        [FindsBy(How = How.Id, Using = "licTypeCode")]
        internal readonly IWebElement? _LicenceTypeTxtBox = null;

        [FindsBy(How = How.Name, Using = "DriverLicenceClassesFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverLicenceClassesTable']")]
        internal readonly IWebElement? _driverLicenceClassesTable = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='splNote']")]
        internal IWebElement? _inputNotes = null;

        internal IList<IWebElement>? _verifyLicenceClass(string Code) => Driver.FindElements(By.XPath($"//input[@value='{Code}']"));
    }
}
