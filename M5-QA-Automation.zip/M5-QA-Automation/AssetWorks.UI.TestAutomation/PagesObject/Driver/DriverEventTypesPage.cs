﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverEventTypesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverEventTypesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _headerCode = "Code";

        internal IWebElement? _disabledCheckBox = null;
        internal IWebElement? _expiryCheckBox = null;
        internal IWebElement? _preExpiryCheckBox = null;

        [FindsBy(How = How.Id, Using = "evtClassCode")]
        internal readonly IWebElement? _eventClassTxtBox = null;

        [FindsBy(How = How.Name, Using = "DriverEventTypesFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverEventTypesTable']")]
        internal readonly IWebElement? _driverEventTypesTable = null;
        internal IList<IWebElement>? _tableEventType(string name) => Driver.FindElements(By.XPath($"//input[@value='{name}']"));
    }
}
