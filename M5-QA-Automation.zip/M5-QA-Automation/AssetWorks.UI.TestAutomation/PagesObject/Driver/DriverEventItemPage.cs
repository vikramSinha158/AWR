﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverEventItemPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverEventItemPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _headerEventItem = "Event Item";

        internal IWebElement? _disabledCheckBox = null;

        [FindsBy(How = How.Id, Using = "txtClassCode")]
        internal readonly IWebElement? _eventClassTxtBox = null;

        [FindsBy(How = How.Id, Using = "txtTypeCode")]
        internal readonly IWebElement? _eventTypeTxtBox = null;

        [FindsBy(How = How.Name, Using = "DriverEventItemsFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverEventItemsTable']")]
        internal readonly IWebElement? _driverEventItemTable = null;
        internal IList<IWebElement>? _tableEventItem(string name) => Driver.FindElements(By.XPath($"//input[@value='{name}']"));
    }
}
