﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class TaxTypeMainPage : BasePage
    {
        internal static string TaxClass = String.Empty;
        internal static string TaxDescription = String.Empty;   

        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public TaxTypeMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TaxTypeFrame']")]
        internal readonly IWebElement? _frameTaxType = null;     

        [FindsBy(How = How.XPath, Using = "//table[@id='taxTypeTable']")]
        internal readonly IWebElement? _tableTaxType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='taxClass$new_0']")]
        internal readonly IWebElement? _inputNewTaxClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='desc$new_0']")]
        internal readonly IWebElement? _inputNewTaxDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='disabled$new_0']")]
        internal readonly IWebElement? _ckbNewTaxDisabled = null;
    }
}
