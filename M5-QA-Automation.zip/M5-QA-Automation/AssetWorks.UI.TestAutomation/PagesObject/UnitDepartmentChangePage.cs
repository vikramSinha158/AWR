﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class UnitDepartmentChangePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal static string _unitNumber { get; set; }
        internal static string _deptOwning { get; set; }
        internal static string _deptUsing { get; set; }

        internal UnitDepartmentChangePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal readonly IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OwningDeptNo']")]
        internal readonly IWebElement? _inputOwningDeptNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UsingDeptNo']")]
        internal readonly IWebElement? _inputUsingDeptNo = null;

    }
}
