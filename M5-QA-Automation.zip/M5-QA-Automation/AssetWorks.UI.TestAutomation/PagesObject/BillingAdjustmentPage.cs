﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingAdjustmentPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal string _descriptionHeaderName = "Description";
        internal string _desctd = "desc";
        internal string _amountd = "amount";
        internal string _totalpdsId = "totalpds";
        internal string _totalamtId = "totalamt";
        internal string _firstpdId = "firstpd";
        internal string _locationId = "location";
        internal string _departmentId = "dept";
        internal string _expId = "exp";
        internal string _revId = "rev";

        public BillingAdjustmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='unitdept']")]
        internal readonly IWebElement? _unitdeptInput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillUnitAdjFrame']")]
        internal IWebElement? _billUnitAdjFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillUnitAdjTable']")]
        internal IWebElement? _billUnitAdjTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillUnitAdjTable']//tbody//tr")]
        internal IList<IWebElement>? _billUnitAdjTableRows = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BillItem']")]
        internal readonly IWebElement? _billItemInput = null;
    }
}
