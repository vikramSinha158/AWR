﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillSingleDepartmentAccountPage: BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public BillSingleDepartmentAccountPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptNumber']")]
        internal readonly IWebElement? _departmentNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='use_acct_no']")]
        internal readonly IWebElement? _expenseAccount = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='own_acct_no']")]
        internal readonly IWebElement? _revenueAccount = null;
    }
}
