﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class EmployeeTransfersPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal EmployeeTransfer? DataObject = null;
        internal int _rightEmployeeCount = 0;
        internal int _leftEmployeeCount = 0;

        public EmployeeTransfersPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='Supervisor1']")]
        internal readonly IWebElement? _inputSupervisor1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Supervisor2']")]
        internal readonly IWebElement? _inputSupervisor2 = null; 

        [FindsBy(How = How.XPath, Using = "//select[@name='Choice1Left']")]
        internal IWebElement? _choice1Left = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Choice1Right']")]
        internal IWebElement? _choice1Right = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='Choice1MoveRight']")]
        internal IWebElement? _choice1MoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='Choice1MoveLeft']")]
        internal IWebElement? _choice1MoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EmpFrame']")]
        internal IWebElement? _empFrame = null;
    }
}
