﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class RoleMaintenancePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal string _databaseUserId = string.Empty;
        internal string _pOLineValue = string.Empty;
        internal string _pOLiTotalPOValueneValue = string.Empty;
        internal string _commWOAuthAmountValue = string.Empty;
        internal string _approvalAmountValue = string.Empty;
        internal string _serviceApprovalAmount = string.Empty;
        internal int _leftLocListCnt = 0;
        internal int _rightLocListCnt = 0;
        internal int _leftOperationalListCnt = 0;
        internal int _rightOperationalListCnt = 0;
        internal int _lefMenusListCnt = 0;
        internal int _rightMenusListCnt = 0;
        internal int _leftKpiListCnt = 0;
        internal int _rightKpiListCnt = 0;
        internal int _leftPrivilegesListCnt = 0;
        internal int _rightPrivilegesListCnt = 0;
        internal int _leftPrinterListCnt=0;
        internal int _rightPrinterListCnt = 0;
        internal int _leftReportListCnt = 0;
        internal int _rightReportListCnt = 0;
        internal int _leftAdhocListCnt = 0;
        internal int _rightAdhocListCnt = 0;
        internal int _leftDeptLisCnt = 0;
        internal int _rightDeptLisCnt = 0;
        internal int _leftChatListCnt = 0;
        internal int _rightChatListCnt = 0;
        internal int _leftvGStateListCnt = 0;
        internal static int _rightvGStateListCnt = 0;
        internal int _leftIndAccountsListCnt = 0;
        internal int _rightIndAccountsListCnt = 0;


        public RoleMaintenancePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='UserId']")]
        internal IWebElement? _roleInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Name']")]
        internal IWebElement? _roleDescInput = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='Notes']")]
        internal IWebElement? _roleNoteInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='HomePage']")]
        internal IWebElement? _roleHomePageInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='OutsideUser']")]
        internal IWebElement? _roleOutsideUserCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TwoFactor']")]
        internal IWebElement? _roleTwoFactorCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='dbUID']")]
        internal IWebElement? _roleDbUIDInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MaxPOLineItemCost']")]
        internal IWebElement? _maxPOLineItemCostInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MaxPOTotalCost']")]
        internal IWebElement? _maxPOTotalCostInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MaxCommWOAuthAmt']")]
        internal IWebElement? _maxCommWOAuthAmtInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PartReqApprAmt']")]
        internal IWebElement? _partReqApprAmtInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ServReqApprAmt']")]
        internal IWebElement? _servReqApprAmtInput = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal IWebElement? _locationsOperationalTab = null;

        [FindsBy(How = How.XPath, Using = "//legend[text()='Location Maintenance']")]
        internal IWebElement? _locationMaintenance = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='LocListLeft']")]
        internal IWebElement? _locListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='LocListRight']")]
        internal IWebElement? _locListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='LocListMoveRight']")]
        internal IWebElement? _locListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='LocListMoveLeft']")]
        internal IWebElement? _locListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='LocFrame']")]
        internal IWebElement? _locFrame = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='OperEntityFrame']")]
        internal IWebElement? _operEntityFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='OpEnterLeft']")]
        internal IWebElement? _openterLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='OpEnterRight']")]
        internal IWebElement? _openterRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='OpEnterMoveRight']")]
        internal IWebElement? _openterMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='OpEnterMoveLeft']")]
        internal IWebElement? _openterMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal IWebElement? _menusKPITab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CatFrame']")]
        internal IWebElement? _menusFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatListLeft']")]
        internal IWebElement? _menusListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatListRight']")]
        internal IWebElement? _menusListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatListMoveRight']")]
        internal IWebElement? _menusMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatListMoveLeft']")]
        internal IWebElement? _menusMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='KPIListLeft']")]
        internal IWebElement? _kpiListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='KPIListRight']")]
        internal IWebElement? _kpiListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='KPIListMoveRight']")]
        internal IWebElement? _kpiMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='KPIListMoveLeft']")]
        internal IWebElement? _kpiMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='KpiFrame']")]
        internal IWebElement? _kpiFrame = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab3']")]
        internal IWebElement? _privilegesTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PrivFrame']")]
        internal IWebElement? _privFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PrivListLeft']")]
        internal IWebElement? _privListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PrivListRight']")]
        internal IWebElement? _privListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='PrivListMoveRight']")]
        internal IWebElement? _privListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='PrivListMoveLeft']")]
        internal IWebElement? _privListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab4']")]
        internal IWebElement? _reportingTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PrinterFrame']")]
        internal IWebElement? _printerFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PrinterListLeft']")]
        internal IWebElement? _printerListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PrinterListRight']")]
        internal IWebElement? _printerListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='PrinterListMoveRight']")]
        internal IWebElement? _printerListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='PrinterListMoveLeft']")]
        internal IWebElement? _printerListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ReportFrame']")]
        internal IWebElement? _reportFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='ReportListLeft']")]
        internal IWebElement? _reportListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='ReportListRight']")]
        internal IWebElement?_reportListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='ReportListMoveRight']")]
        internal IWebElement? _reportListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='ReportListMoveLeft']")]
        internal IWebElement? _reportListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DefRptGrp']")]
        internal IWebElement? _defRptGrp = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='AdhocFrame']")]
        internal IWebElement? _adhocFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='AdhocListLeft']")]
        internal IWebElement? _adhocListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='AdhocListRight']")]
        internal IWebElement? _adhocListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='AdhocListMoveRight']")]
        internal IWebElement? _adhocListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='AdhocListMoveLeft']")]
        internal IWebElement? _adhocListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab6']")]
        internal IWebElement? _departmentsChatTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DeptFrame']")]
        internal IWebElement? _deptFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='DeptListLeft']")]
        internal IWebElement? _deptListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='DeptListRight']")]
        internal IWebElement? _deptListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='DeptListMoveRight']")]
        internal IWebElement? _deptListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='DeptListMoveLeft']")]
        internal IWebElement? _deptListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ChatFrame']")]
        internal IWebElement? _chatFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='ChatListLeft']")]
        internal IWebElement? _chatListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='ChatListRight']")]
        internal IWebElement? _chatListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='ChatListMoveRight']")]
        internal IWebElement? _chatListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='ChatListMoveLeft']")]
        internal IWebElement? _chatListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab7']")]
        internal IWebElement? _vendorGatewayTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='VGFrame']")]
        internal IWebElement? _vendorFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='VGStateListLeft']")]
        internal IWebElement? _vGStateListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='VGStateListRight']")]
        internal IWebElement? _vGStateListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='VGStateListMoveRight']")]
        internal IWebElement? _vGStateListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='VGStateListMoveLeft']")]
        internal IWebElement? _vGStateListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab8']")]
        internal IWebElement? _accountsTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='IndAcctFrame']")]
        internal IWebElement? _indAcctFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='IndAcctGroupListLeft']")]
        internal IWebElement? _indAccountsListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='IndAcctGroupListRight']")]
        internal IWebElement? _indAccountsListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='IndAcctGroupListMoveRight']")]
        internal IWebElement? _indAccountsListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='IndAcctGroupListMoveLeft']")]
        internal IWebElement? _indAccountsListMoveLeft = null;

    }
}
