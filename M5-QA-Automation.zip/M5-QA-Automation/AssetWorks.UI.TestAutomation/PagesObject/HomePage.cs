﻿using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    /// <summary>
    /// Page object class for Home
    /// </summary>
    internal class HomePage : BasePage
    {
        internal string locatorHome = "//button[contains(text(),'Home')]//span[@class='mdl-button__ripple-container']";

        public HomePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Home')]//span[@class='mdl-button__ripple-container']")]
        internal IWebElement? _homeTab =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='menuReduce']")]
        internal IWebElement? _mainMain =null;

    }
}
