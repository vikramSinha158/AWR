﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetupTanksPage :BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal string _tankNo = "tTank_no$new_";
        internal string _productNo = "tProd_no$new_";
        internal string _productType = "tTank_Type$new_";
        internal string _adjAccount = "tAdj_Acct$new_";
        internal string _headerTankNo = "Tank No";

        public ProductSetupTanksPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='genloc']")]
        internal readonly IWebElement? _fuelLocation = null;

        [FindsBy(How = How.Id, Using = "Content")]
        internal readonly IWebElement? _iframe = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LocFuelTankTable']")]
        internal readonly IWebElement? _LocFuelTankTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LocFuelTankTable']//tbody//tr")]
        internal IList<IWebElement>? _LocFuelTankTableRows = null;


        internal  IWebElement? _checkBoxEVR(string row) => Driver.FindElement(By.XPath($"//input[@id='EVRII_reqd${row}']")) ;
        internal IList<IWebElement>? _verifyTankNo(string TankNo) => Driver.FindElements(By.XPath($"//input[@value='{TankNo}']"));
    }
}
