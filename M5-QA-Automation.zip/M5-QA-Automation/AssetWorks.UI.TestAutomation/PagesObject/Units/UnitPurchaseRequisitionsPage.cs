﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitPurchaseRequisitionsPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public UnitPurchaseRequisitionsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//button[@id='NewButton']")]
        internal IWebElement? _buttonAddNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewUnitDesc']")]
        internal IWebElement? _inputNewUnitDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Status']")]
        internal IWebElement? _inputStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ReqNo']")]
        internal IWebElement? _inputRequisitionNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='BudYear']")]
        internal IWebElement? _inputBudgetYear = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Requested']")]
        internal IWebElement? _inputRequestedDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExDel']")]
        internal IWebElement? _inputExpectedDelivery = null;

        [FindsBy(How = How.XPath, Using = "//td[@id='TDExDel']/img")]
        internal IWebElement? _calExpectedDelivery = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ReplaceFund']")]
        internal IWebElement? _inputReplacementFund = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OwnerDept']")]
        internal IWebElement? _inputOwnerDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UsingDept']")]
        internal IWebElement? _inputUsingDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DelLoc']")]
        internal IWebElement? _inputDelLoc = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='CUSTOMERNOTES']")]
        internal IWebElement? _inputCustomerNotes = null;

        //PO List tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='MultiplePONumbersFrame']")]
        internal IWebElement? _framePONumbers = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='POTable']/tbody")]
        internal IWebElement? _tablePONumbers = null;

        //Category Options tab
        [FindsBy(How = How.XPath, Using = "//input[@id='CateCode']")]
        internal IWebElement? _inputCategoryCode = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='NewUnitFrame']")]
        internal IWebElement? _frameNewUnit = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CateOpTable']/tbody")]
        internal IWebElement? _tableCategoryOptions = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='sel$0']")]
        internal IWebElement? _checkboxSelected = null;
    }
}
