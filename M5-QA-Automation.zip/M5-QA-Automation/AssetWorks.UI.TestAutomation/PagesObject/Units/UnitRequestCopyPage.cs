﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitRequestCopyPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public UnitRequestCopyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public string _newRequestNo { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='RequestNo']")]
        internal IWebElement? _inputRequestNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Status']")]
        internal IWebElement? _inputStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Ctr']")]
        internal IWebElement? _inputNoOfCopies = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewReqNo']")]
        internal IWebElement? _inputNewReqNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='NewButton']")]
        internal IWebElement? _buttonAddNew = null;

    }
}
