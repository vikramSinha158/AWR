﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class StandardJobTechSpecPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal string _jobHeadeName="Job";
        internal string _dDependentJobId = "dDependentJob";
        internal string _dLocationId = "dLocation";
        internal string _dJobRsnId = "dJobRsn";
        internal string _partNoJobId = "PartNo";
        internal string _qtyPartJobId = "Qty";
        internal string _requiredPartCbId = "requiredFl";
        internal string _partHeadeName = "Part Number";
        internal string _testSuiteHeadeName = "Test Suite";
        internal string _testSuitSelectedId = "Selected";
        internal string _resource = "Resource";
        internal string _resQty = "resQty";
        internal string _primaryFL = "primaryFL";
        internal string _resourceHeadeName = "Resource";
        internal string _effDateDeptFirstRow = string.Empty;
        internal string _effDateDeptSecondRow = string.Empty;


        public StandardJobTechSpecPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='StandJobNo']")]
        internal IWebElement? _standJobNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='StandSpecNo']")]
        internal IWebElement? _standSpecNo = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab3']")]
        internal IWebElement? _dependentJobsTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='StandJobSpecDJFrame']")]
        internal IWebElement? _standJobSpecDJFrame = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='dDependentJob$new_0']")]
        internal IWebElement? _dDependentJob = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='dLocation$0']")]
        internal IWebElement? _dLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='dJobRsn$0']")]
        internal IWebElement? _dJobRsn = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StandJobSpecDJTable']")]
        internal IWebElement? _standJobSpecDJTable = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab0']")]
        internal IWebElement? _detailJobsTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PrefShift']")]
        internal IWebElement? _refShift = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='JobSpan']")]
        internal IWebElement? _jobSpan = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AddToWOFl']")]
        internal IWebElement? _addToWOFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ChangeAssoc']")]
        internal IWebElement? _changeAssocFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ChangeBase']")]
        internal IWebElement? _changeBaseFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='vendorFl']")]
        internal IWebElement? _vendorFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='excludeFl']")]
        internal IWebElement? _excludeFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AddToWOExpFl']")]
        internal IWebElement? _addToWOExpFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FixPriceFl']")]
        internal IWebElement? _fixPriceFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DefJobReason']")]
        internal IWebElement? _defJobReason = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='newId']")]
        internal IWebElement? _newIdBtn = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='Note']")]
        internal IWebElement? _note = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='complaintNote']")]
        internal IWebElement? _complaintNote = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='causeNote']")]
        internal IWebElement? _causeNote = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='correctNote']")]
        internal IWebElement? _correctNote = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal IWebElement? _partJobTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='StandJobSpecFrame']")]
        internal IWebElement? _StandJobSpecPartFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StandJobSpecTable']")]
        internal IWebElement? _standJobSpecPartTable = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal IWebElement? _testSuitesTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='StandJobSpecTSFrame']")]
        internal IWebElement? _standJobSpecTSFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StandJobSpecTSTable']")]
        internal IWebElement? _standJobSpecTSTable = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab4']")]
        internal IWebElement? _estimatesTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='laborSourceFrame']")]
        internal IWebElement? _laborSourceFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LaborResourceTable']")]
        internal IWebElement? _laborResourceTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LaborResourceTable']/tbody/tr")]
        internal IList<IWebElement>? _laborResourceTableRows = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='est_labor_fl']")]
        internal IWebElement? _estlaborfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='est_part_fl']")]
        internal IWebElement? _estpartfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='est_total_fl']")]
        internal IWebElement? _esttotalfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='allow_change_fl']")]
        internal IWebElement? _allowCchangefl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='LaborTime']")]
        internal IWebElement? _laborTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='laborCost']")]
        internal IWebElement? _laborCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ShopTime']")]
        internal IWebElement? _shopTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='partCost']")]
        internal IWebElement? _partCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ContingencyTime']")]
        internal IWebElement? _contingencyTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='commCost']")]
        internal IWebElement? _commCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BookTime']")]
        internal IWebElement? _bookTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EstDo']")]
        internal IWebElement? _estCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='IndStdTime']")]
        internal IWebElement? _indStdTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BookTimeMin']")]
        internal IWebElement? _bookTimeMin = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BookTimeMax']")]
        internal IWebElement? _bookTimeMax = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab5']")]
        internal IWebElement? _deptFixedCostTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='StandJobSpecDeptCostFrame']")]
        internal IWebElement? _standJobSpecDeptCostFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StandJobSpecDeptCostTable']")]
        internal IWebElement? _standJobSpecDeptCostTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StandJobSpecDeptCostTable']//tbody//tr")]
        internal IList<IWebElement>? _standJobSpecDeptCostTableRows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StandJobSpecTable']//tbody//tr")]
        internal IList<IWebElement>? _standJobSpecPartTableRows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StandJobSpecDJTable']//tbody//tr")]
        internal IList<IWebElement>? _standJobSpecDJTableRows = null;
    }
}
