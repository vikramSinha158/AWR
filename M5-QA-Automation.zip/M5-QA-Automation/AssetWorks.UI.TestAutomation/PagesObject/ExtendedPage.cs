﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    public class ExtendedPage : BasePage
    {
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public ExtendedPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//button[@id='savebutton']")]
        internal IWebElement? _buttonSave =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='undobutton']")]
        internal IWebElement? _buttonUndo =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='undoallbutton']")]
        internal IWebElement? _buttonRefresh =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='deletebutton']")]
        internal IWebElement? _buttonDelete =null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Home')]//span[@class='mdl-button__ripple-container']")]
        internal IWebElement? _homeTab =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Action Required']")]
        internal IWebElement? _createDialog =null;

        [FindsBy(How = How.XPath, Using = "//iframe[contains(@id,'Content')]")]
        internal IWebElement? _contentFrame =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Error Messages and Warnings']")]
        internal IWebElement? _errorWarningDisplay =null;
       
        [FindsBy(How = How.XPath, Using = "//span[@class='errorCriticalText']")]
        internal IWebElement? _errorCriticalText =null;

        [FindsBy(How = How.XPath, Using = "//thead[@class='tableFloatingHeaderOriginal']")]
        internal IWebElement? _tableHeaders = null;

        [FindsBy(How = How.XPath, Using = "//nav[@id='mainRelatedMenu']")]
        internal IWebElement? _navRelatedMenu = null;

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]")]
        internal IWebElement? _dialogArea = null;

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]//textarea")]
        internal IWebElement? _txtAreaNotes = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='helpbutton']")]
        internal IWebElement? _helpBtn = null;

        [FindsBy(How = How.XPath, Using = "//div//span[@class='ScreenTitle']")]
        internal readonly IWebElement? _menuBarOptionsHeader = null;

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]//p[1]")]
        internal readonly IWebElement? _dialogTitle = null;
    }
}
