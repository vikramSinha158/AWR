﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class RoleCopyPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public RoleCopyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='UserId']")]
        internal readonly IWebElement? _existingRoleInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewUserId']")]
        internal readonly IWebElement? _newRoleInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewName']")]
        internal readonly IWebElement? _newRoleDesc = null;


    }
}
