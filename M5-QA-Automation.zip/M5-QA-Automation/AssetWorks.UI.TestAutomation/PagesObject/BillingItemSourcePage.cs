﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingItemSourcePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        internal string _billitem = "billitem";
        internal string _deptbill = "deptbill";
        internal string _rev = "rev";
        internal string _exp = "exp";
        internal string _headerBillItem = "Billing Item";

        public BillingItemSourcePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='BillCode']")]
        internal IWebElement? _billingCodeInput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='billitemsourceFrame']")]
        internal IWebElement? _billitemsourceFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='billitemsourceTable']")]
        internal IWebElement? _billitemsourceTable = null;

    }
}
