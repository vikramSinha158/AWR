﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class ComponentItemsPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal string _itemHeaderName = "Item";
        internal string _itemId = "item";
        internal string _valueId = "value";

        public ComponentItemsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='CompNo']")]
        internal IWebElement? _componenNotInput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CompItemFrame']")]
        internal IWebElement? _compItemFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CompItemTable']")]
        internal IWebElement? _compItemTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CompItemTable']//tbody//tr")]
        internal IList<IWebElement>? _compItemTableRows = null;
    }
}
