﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment
{
    internal class EquipmentConditionsPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipmentConditionsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentConditionsFrame']")]
        internal IWebElement? _frameEquipmentConditions = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentConditionsTable']")]
        internal IWebElement? _tableEquipmentConditions = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIPMENT_CONDITION$new_0']")]
        internal IWebElement? _inputNewCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DESCRIPTION$new_0']")]
        internal IWebElement? _inputNewDescription = null;
    }
}
