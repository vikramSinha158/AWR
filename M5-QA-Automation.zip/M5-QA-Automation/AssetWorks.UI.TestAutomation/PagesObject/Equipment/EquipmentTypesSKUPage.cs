﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment
{
    internal class EquipmentTypesSKUPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipmentTypesSKUPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='EquipmentType']")]
        internal IWebElement? _inputEquipmentType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EquipmentTypeDescription']")]
        internal IWebElement? _inputDescription = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentTypesFrame']")]
        internal IWebElement? _frameEquipmentTypes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentTypesTable']")]
        internal IWebElement? _tableEquipmentTypes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SKU$new_0']")]
        internal IWebElement? _inputNewSKU = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SKU_DESCRIPTION$new_0']")]
        internal IWebElement? _inputNewSKUDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SERIAL_NUMBER_REQ_FL$new_0']")]
        internal IWebElement? _checkboxNewSKUSerial = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISABLED_FL$new_0']")]
        internal IWebElement? _checkboxNewSKUDisabled = null;

    }
}
