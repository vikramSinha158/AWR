﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Employee
{
    internal class EmployeeCourseSetUpPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EmployeeCourseSetUpPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='code$new_0']")]
        internal IWebElement? _code = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _codeDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='daysValid$new_0']")]
        internal IWebElement? _daysValid= null;

        [FindsBy(How = How.XPath, Using = "//input[@id='resourceType$new_0']")]
        internal IWebElement? _resourceType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VendorNo$new_0']")]
        internal IWebElement? _VendorNo = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CourseFrame']")]
        internal IWebElement? _courseFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CourseTable']")]
        internal IWebElement? _tableCourse = null;      

        [FindsBy(How = How.XPath, Using = "//input[@id='disabled$new_0']")]
        internal IWebElement? _chbDisabled = null;

    }
}
