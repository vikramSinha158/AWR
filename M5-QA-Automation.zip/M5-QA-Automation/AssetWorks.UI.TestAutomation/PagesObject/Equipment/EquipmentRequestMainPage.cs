﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class EquipmentRequestMainPage : BasePage
    {
        internal static string EuipType = "EQUIPMENT_TYPE";
        internal static string SKU = "SKU";
        internal static string Qty = "QTY";
        internal static string PickUpBy = "CHECKOUT_EMP_ID";
        internal static string EstCheckOut = "EST_CHECKOUT_DT";
        internal static string EstReturn = "EST_RETURN_DT";
        internal static string Status = "STATUS";
        internal static string StatusDate = "STATUS_DT";
        internal static string Notes = "NOTE";
        internal static string New = "$new_";

        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipmentRequestMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='REQUEST_ID']")]
        internal readonly IWebElement? _requestID = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='btnNewEquipmentRequest']")]
        internal readonly IWebElement? _newEquipmentRequest = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='REQUEST_EMP_ID']")]
        internal readonly IWebElement? _requestEmpID = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RequestEmployeeName']")]
        internal readonly IWebElement? _requestEmpName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FROM_LOCATION']")]
        internal readonly IWebElement? _fromLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FromLocationName']")]
        internal readonly IWebElement? _fromLocationName = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='TARGET_TYPE']")]
        internal readonly IWebElement? _targetType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TargetType']")]
        internal readonly IWebElement? _targetTypeValue = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TargetTypeName']")]
        internal readonly IWebElement? _targetTypeName = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentRequestsFrame']")]
        internal readonly IWebElement? _frameEquipRequest = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentRequestsTable']")]
        internal readonly IWebElement? _tableEquipRequest = null;
    }
}
