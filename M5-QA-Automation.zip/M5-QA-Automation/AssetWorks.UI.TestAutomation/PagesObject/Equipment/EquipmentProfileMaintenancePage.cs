﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment
{
    internal class EquipmentProfileMaintenancePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal string _equipProfileDescDetail=String.Empty;
        internal string _equipmentProfileStatus = String.Empty;
        internal List<string> _pAssetCodeList = new List<string>();
        internal List<string> _sAssetCodeList = new List<string>();

        public EquipmentProfileMaintenancePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='equipProfile']")]
        internal IWebElement? _equipProfileInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc']")]
        internal IWebElement? _equipProfileDescInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='status']")]
        internal IWebElement? _selectEquipProfileStatus = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab0']")]
        internal IWebElement? _primaryTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal IWebElement? _secondaryTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EPCLASSFrame']")]
        internal IWebElement? _epPriClassFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatClassListLeft']")]
        internal IWebElement? _pAssetClassListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatClassListRight']")]
        internal IWebElement? _pAssetClassListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatClassListMoveRight']")]
        internal IWebElement? _pAssetClassMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatClassListMoveLeft']")]
        internal IWebElement? _pAssetClassMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EPCATEGORYFrame']")]
        internal IWebElement? _pApCategoryFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CategoryListLeft']")]
        internal IWebElement? _pCategoryListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CategoryListRight']")]
        internal IWebElement? _pCategoryListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CategoryListMoveRight']")]
        internal IWebElement? _pCategoryMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CategoryListMoveLeft']")]
        internal IWebElement? _pCategoryMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatClassList2Left']")]
        internal IWebElement? _sAssetClassListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatClassList2Right']")]
        internal IWebElement? _sAssetClassListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatClassList2MoveRight']")]
        internal IWebElement? _sAsetClassMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatClassList2MoveLeft']")]
        internal IWebElement? _sAssetClassMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CategoryList2Left']")]
        internal IWebElement? _sCategoryListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CategoryList2Right']")]
        internal IWebElement? _sCategoryListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CategoryList2MoveRight']")]
        internal IWebElement? _sCategoryMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CategoryList2MoveLeft']")]
        internal IWebElement? _sCategoryMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EPCLASSSecFrame']")]
        internal IWebElement? _epSecClassFrame = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EPCATEGORYSecFrame']")]
        internal IWebElement? _epSecCategoryFrame = null;

        [FindsBy(How = How.XPath, Using = "//button[text()='Delete']")]
        internal IWebElement? _deleteButton = null;

        [FindsBy(How = How.XPath, Using = "//button[text()='Create']")]
        internal IWebElement? _createButton = null;
    }
}
