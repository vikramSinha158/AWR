﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    public class WorkOrderMainPage : BasePage
    {
        internal string jobNameXpath = "//input[@id='wjJob$r0']";
        internal string canclecbxpath = "//input[@id='showallwo']";
        internal static string? WONumber = null;
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov =>new ListOfValuesPageActions(Driver);
        internal string _enteredInDateTime = string.Empty;
        internal string _enteredOutDateTime = string.Empty;
        internal string _partJobElementId = "wspJob$r";
        internal string _partNumberId = "wspPartNo$r";
        internal string _employeeId = "wspEmpNo$r";
        internal string _qtyId = "wspQty$r";
        internal string _failCodeId = "wspFailCode$r";
        internal string _positionId = "wspJobPosition$r";
        internal string _jobCodeId = "wjJob$r";
        internal string _jobReasonId = "wjJobReason$r";
        internal string _pRONumberId = "wspProNo$r";
        internal string _printTagId = "wspPrintPartTag$r";
        internal string _refNoId = "wspRefNo$r";
        internal string _jobCodename = "wjJob$r";
        internal string _partCodeName = "wspJob$r";
        internal IWebElement? _partJobCode=null;
        internal IWebElement? _partNumber=null;
        internal IWebElement? _partEmpNo = null;
        internal IWebElement? _partQty = null;
        internal IWebElement? _failCode = null;
        internal IWebElement? _refNo = null;
        internal IWebElement?  _empPosition = null;
        internal IWebElement?  _pRONumber = null;
        internal string _jobstockPCode = String.Empty;
        internal string _wnspJoBCode = "wnspJob$r";  
        internal string _wnspPartNumber = "wnspPartNo$r";
        internal string _wnspEffDate = "wnspEffDate$r";
        internal string _wnspVendor = "wnspVendor$r";
        internal string _wnspEmpNo = "wnspEmpNo$r";
        internal string _wnspQty = "wnspQty$r";
        internal string _wnspPrintPartTag = "wnspPrintPartTag$r";
        internal string _wnspFailCode = "wnspFailCode$r";
        internal string _wnspRefNo = "wnspRefNo$r";
        internal string _wnspProNo = "wnspProNo$r";
        internal string _wnspJobPosition = "wnspJobPosition$r";
        internal IWebElement? _wnsPartJobCode = null;
        internal IWebElement? _wnsPartNumber = null;
        internal IWebElement? _wnsPartEmpNo = null;
        internal IWebElement? _wnsPartVendor = null;
        internal IWebElement? _wnsPartQty = null;
        internal IWebElement? _wnsPartFailCode = null;
        internal IWebElement? _wnsPartRefNo = null;
        internal IWebElement? _wnsPartEmpPosition = null;
        internal IWebElement? _wnsPartPRONumber = null;
        internal string _wcJobCode = "wcJob$r";
        internal string _wcvendor = "wcvendor$r";
        internal string _wcinvno = "wcinvno$r";
        internal string _wclaborcost = "wclaborcost$r";
        internal string _wcpartcost = "wcpartcost$r";
        internal string _wcmisccost = "wcmisccost$r";
        internal string _wctax = "wctax$r";
        internal string _wctotal = "wctot$r";
        internal string _wcposition = "wcposition$r";
        internal IWebElement? _commJobCode = null;
        internal IWebElement? _commvendorr = null;
        internal IWebElement? _commInvno = null;
        internal IWebElement? _commlaborcost = null;
        internal IWebElement? _commPartcost = null;
        internal IWebElement? _commMisccost = null;
        internal IWebElement? _commTax = null;
        internal IWebElement? _commTotal = null;
        internal IWebElement? _commPosition = null;
        internal string _invnoValue = String.Empty;
        internal string _wclaborcostvalue = string.Empty;
        internal string _wcpartcostValue = string.Empty;
        internal string _wcmisccostValue = string.Empty;
        internal string _wctaxValue = string.Empty;
        internal string _wfJobCode = "wfJob$r";
        internal string _wfHose = "wfHose$r";
        internal string _wfProd = "wfProd$r"; 
        internal string _wfQty = "wfQty$r";
        internal string _wfUnitCost = "wfUnitCost$r";
        internal string _wfEmpNo = "wfEmpNo$r";
        internal IWebElement? _fluidJobCode = null;
        internal IWebElement? _fluidHose = null;
        internal IWebElement? _fluidQty = null;
        internal IWebElement? _fluidEmpNo = null;
        string _wctotalValue = string.Empty;
        internal string _jobStatusId = "wjStatus$r";

        public WorkOrderMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }       

        [FindsBy(How = How.XPath, Using = "//span[@class='ScreenTitle']")]
        internal IWebElement? _workOrderTitle =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='objNumber']")]
        internal IWebElement? _inputWorkOrderNo =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Work Order']")]
        internal IWebElement? _searchLinkWorkOrderNo =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wonumber']")]
        internal IWebElement? _workOrderNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='woStatus']")]
        internal IWebElement? _workOrderStatus =null;

        [FindsBy(How = How.XPath, Using = "//div[@id='dialog-area0']//span[contains(text(),'Unit')]")]
        internal IWebElement? _searchLinkUnitNo =null;
      
        [FindsBy(How = How.XPath, Using = "//input[@id='buildbutton']")]
        internal IWebElement? _buildButton =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='visitReq']")]
        internal IWebElement? _visitReq =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal IWebElement? _unitNo =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Component']")]
        internal IWebElement? _searchLinkComponent =null;
      
        [FindsBy(How = How.XPath, Using = "//span[text()='Action Required']")]
        internal IWebElement? _alterPop =null;
      
        [FindsBy(How = How.XPath, Using = "//button[text()='Continue']")]
        internal IWebElement? _alterPopContinueBtn =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='downtime']")]
        internal IWebElement? _datetimeWOField =null;
      
        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab1']")]
        internal IWebElement? _jobTab =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wjJob$r0']")]
        internal IWebElement? _jobCode =null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Job Information')]")]
        internal IWebElement? _jobInformation =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='List of Job Codes']")]
        internal IWebElement? _jobClistLink =null;
     
        [FindsBy(How = How.XPath, Using = "//input[@id='wjJobReason$r0']")]
        internal IWebElement? _jobReason = null;
        
        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame14']")]
        internal IWebElement? _jobFormFrame =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wjStatus$r0']")]
        internal IWebElement? _jobStatus =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Job Information (Loaded 0 records)']")]
        internal IWebElement? _jobDeletedMsg =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Job Information (Loaded 1 records)']")]
        internal IWebElement? _jobLoadedMsg =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='showallwo']")]
        internal IWebElement? _showcloseordercheckbox =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wo_no$0']")]
        internal IWebElement? _canWOnumber =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='status$0']")]
        internal IWebElement? _woStatus =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='open$0']")]
        internal IWebElement? _woOpenDate =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='closed$0']")]
        internal IWebElement? _woCloseDate =null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='WOListFrame']")]
        internal IWebElement? _wolistframe =null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'Work Order Filter')]")]
        internal IWebElement? _workOrderFilter =null;

        [FindsBy(How = How.XPath, Using = "//iframe[@id='Content']")]
        internal IWebElement? _contentFrame =null;

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Work Request List')]")]
        internal IWebElement? _workRequestList =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Work Request List (Loaded 1 Records)']")]
        internal IWebElement? _workRequestDialog =null;

        [FindsBy(How = How.XPath, Using = "//table[@id='wrTable']//tr")]
        internal IList<IWebElement>? _workRequesRows =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='addjob$0']")]
        internal IWebElement? _addWorkRequest =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='wrSaveBtn']")]
        internal IWebElement? _saveWRBtn =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='woopen']")]
        internal IWebElement? _woVisitInfoOpenDate =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wocomplete']")]
        internal IWebElement? _woVisitInfoCompleteDate =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='woclose']")]
        internal IWebElement? _woVisitInfoCloseDate =null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab2']")]
        internal IWebElement? _laborTab =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wlJob$r0']")]
        internal IWebElement? _laborJobCode =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wlEmpNo$r0']")]
        internal IWebElement? _employeeCode =null;
       
        [FindsBy(How = How.XPath, Using = "//input[@id='wlPosition$r0']")]
        internal IWebElement? _employeePosition =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wlTimeIn$r0']")]
        internal IWebElement? _inDateTime =null;
       
        [FindsBy(How = How.XPath, Using = "//input[@id='wlTimeOut$r0']")]
        internal IWebElement? _outDateTime =null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame17']")]
        internal IWebElement? _woLaborframe =null;
       
        [FindsBy(How = How.XPath, Using = "//input[@id='wlEmpName$r0']")]
        internal IWebElement? _employeeName =null;
        
        [FindsBy(How = How.XPath, Using = "//input[@id='wlTimeType$r0']")]
        internal IWebElement? _timeType =null;
        
        [FindsBy(How = How.XPath, Using = "//input[@id='wlPayClass$r0']")]
        internal IWebElement? _payClass =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wlPayStep$r0']")]
        internal IWebElement? _payStep =null;
      
        [FindsBy(How = How.XPath, Using = "//span[text()='Labor Charge Information (Loaded 0 records)']")]
        internal IWebElement? _LaborChargeDeletetInfo =null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab3']")]
        internal IWebElement? _partab =null;
       
        [FindsBy(How = How.XPath, Using = "//input[@id='wspEffDate$r0']")]
        internal IWebElement? _partEffDate =null;
       
        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame19']")]
        internal IWebElement? _partInfoframe =null;
      
        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable19']//tbody//tr")]
        internal IList<IWebElement>? _stockPartRecords =null;
       
        [FindsBy(How = How.XPath, Using = "//span[text()='Stock Part Charge Information (Loaded 0 records)']")]
        internal IWebElement? _stockPartDeletetInfo =null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNoDesc']")]
        internal IWebElement? _woDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='woLocation']")]
        internal IWebElement? _woLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='udcStatus']")]
        internal IWebElement? _deptSatatus = null;
      
        [FindsBy(How = How.XPath, Using = "//input[@name='vinSerialReqNo']")]
        internal IWebElement? _reqN = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame20']")]
        internal IWebElement? _nonStockPartframe = null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Non-Stock Part Charge Information (Loaded 0 records)']")]
        internal IWebElement? _nonStockPartDeletetInfo = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab4']")]
        internal IWebElement? _commTab = null;
       
        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame22']")]
        internal IWebElement? _commframe = null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Commercial Charge Information (Loaded 0 records)']")]
        internal IWebElement? _commChargetDeletetInfo = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab5']")]
        internal IWebElement? _fluidtab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame24']")]
        internal IWebElement? _fluidframe = null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Fluid Charge Information (Loaded 0 records)']")]
        internal IWebElement? _fluidDeletetInfo = null;
    }
}
