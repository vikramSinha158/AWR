﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.Core.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PurchaseRequisitionsPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal string _lineNo = "line$new_";
        internal string _prPartNoName = "PartNo$new_";
        internal string _prQty = "qty$new_";
        internal string _prUnitCost = "cpunitcost$new_";
        internal string _prNeededBy = "needby$new_";
        internal string _prReserveCode = "chargeCodeI$new_";
        internal string _prResvRefNo = "typeNumI$new_";
        internal string _refNo = "lineRefNo$new_";
        internal string _contract = "contract$new_";
        internal string _rejApproval = "approval_fl$new_";
        internal string _prRejReason = "RejReason$new_";
        internal string _prNoteBtn = "noteBtn$new_";
        internal string _prQuoted = "Quoted$new_";
        internal string _headerResvRefNo = "Resv Ref No";
        internal IWebElement? _noteForPR = null;
        internal IWebElement? _approvalCheckbox = null;
        public static string UnitReserveRefNO=String.Empty;
        internal IWebElement? _tQuotedCheckBox = null;

        public PurchaseRequisitionsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='reqno']")]
        internal readonly IWebElement? _reqNoInput = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='newReq']")]
        internal readonly IWebElement? _newReqButton = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='hvendor']")]
        internal readonly IWebElement? _hvendorInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='chargeCode']")]
        internal readonly IWebElement? _hresvCodeSelect= null;

        [FindsBy(How = How.XPath, Using = "//input[@name='hQuoted']")]
        internal readonly IWebElement? _hQuotedCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='vendor_fl']")]
        internal readonly IWebElement? _hvendorCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PRequisitionFrame']")]
        internal readonly IWebElement? _pRequisitionFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']")]
        internal readonly IWebElement? _prPartTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']//tbody//tr")]
        internal IList<IWebElement>? _prPartTableRows = null;

    }
}
