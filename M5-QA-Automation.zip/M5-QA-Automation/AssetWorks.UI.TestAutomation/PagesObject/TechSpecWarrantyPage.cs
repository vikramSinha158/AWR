﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class TechSpecWarrantyPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public TechSpecWarrantyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab0']")]
        internal IWebElement? _wholeUnitTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='tech_spec']")]
        internal IWebElement? _warrantyTechSpecInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='VENDOR_NO']")]
        internal  IWebElement? _vendorNoInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Usage']")]
        internal  IWebElement? _usageInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Usage_UM']")]
        internal IWebElement? _meterType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Elapsed_Time']")]
        internal  IWebElement? _elapsedTimeInput = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal IWebElement? _warrantyPartTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='SpecPartWarrFrame']")]
        internal IWebElement? _specPartWarrFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='SpecPartWarrTable']")]
        internal IWebElement? _specPartWarrTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='SpecWarrTable']")]
        internal IWebElement? _specWarrTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='SpecWarrFrame']")]
        internal IWebElement? _specWarrFrame = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal IWebElement? _warrantySubUnitTab = null;
    }

}
