﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class StandardJobMCCPage : BasePage
    {
        internal  string _mCCJOobCodeValue = String.Empty;
        internal string _recurringIntervalDaysValue = String.Empty;
        internal string _schedulingBasisValue = String.Empty;
        internal string _seasonalRestrictionValue = String.Empty;
        internal string _visitReasonValue = String.Empty;
        internal string _priorityValue = String.Empty;
        internal string _overduePriorityValue=String.Empty;
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);


        public StandardJobMCCPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='StandJobNo']")]
        internal readonly IWebElement? _standardJobNoInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='StandMccNo']")]
        internal readonly IWebElement? _standardMccNoInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Time']")]
        internal readonly IWebElement? _recurringIntervaTimelInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EarliestDate']")]
        internal readonly IWebElement? _earliestDateTimeInput = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal readonly IWebElement? _forecasterTab = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='AbsoRel']")]
        internal readonly IWebElement? _schedulingBasic = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RecurJob']")]
        internal readonly IWebElement? _recurringJobCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='SeasonFlag']")]
        internal readonly IWebElement? _seasonFlag = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='LocCode']")]
        internal readonly IWebElement? _locCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='VR']")]
        internal readonly IWebElement? _visitReason = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Priority']")]
        internal readonly IWebElement? _priority = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Overdue_Priority']")]
        internal readonly IWebElement? _overduePriority = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Calibration']")]
        internal readonly IWebElement? _calibration = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal readonly IWebElement? _locationOverrideTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='unitloc$new_0']")]
        internal readonly IWebElement? _maintenanceloc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='jobloc$new_0']")]
        internal readonly IWebElement? _overrideloc = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='StandJobMccLocFrame']")]
        internal readonly IWebElement? _standJobMccLocFramec = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='unitloc$0']")]
        internal readonly IWebElement? _maintenancelocValue = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='jobloc$0']")]
        internal readonly IWebElement? _overridelocValue= null;
    }
}
