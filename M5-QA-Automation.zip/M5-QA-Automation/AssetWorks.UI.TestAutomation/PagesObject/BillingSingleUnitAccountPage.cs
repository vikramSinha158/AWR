﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingSingleUnitAccountPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal string _expensiveHeaderName = "Expense Account";
        internal string _expenseEffectiveDate = string.Empty;
        internal static List<string> ExpenseEffectiveDates = new List<string>();
        internal string _revenueEffectiveDate = string.Empty;

        public BillingSingleUnitAccountPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal readonly IWebElement? _billSingleunit = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillAcctExpTable']")]
        internal readonly IWebElement? _tablebillSingleunit = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillSingleAcctExpFrame']")]
        internal readonly IWebElement? _framebillSingleunit = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='SpreadAlloc$0']")]
        internal readonly IWebElement? _Allocationpercent = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpAllocAcct$new_0']")]
        internal readonly IWebElement? _expenseAccount = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpAlloc$new_0']")]
        internal readonly IWebElement? _expenseAllocAccount = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillExpAllocFrame']")]
        internal readonly IWebElement? _frameexpenseAllocAccount = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillExpAllocTable']")]
        internal readonly IWebElement? _TableframeexpenseAllocAccount = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@id='Content2']")]
        internal IWebElement? _content2Frame = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpAllocAcct$new_1']")]
        internal readonly IWebElement? _expenseAccount1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpAlloc$new_1']")]
        internal readonly IWebElement? _expenseAllocAccount1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpAllocAcct$new_2']")]
        internal readonly IWebElement? _expenseAccount2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpAlloc$new_2']")]
        internal readonly IWebElement? _expenseAllocAccount2 = null;

        [FindsBy(How = How.XPath, Using = "//*[@id='closeC2Btn']")]
        internal readonly IWebElement? _closebutton = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpAcct$0']")]
        internal readonly IWebElement? _ExpAcct = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='tblBillAcctRev']")]
        internal readonly IWebElement? _tableBillAcctRev = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillSingleAcctRevFrame']")]
        internal readonly IWebElement? _billSingleAcctRevFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillAcctExpTable']//tbody//tr")]
        internal readonly IList<IWebElement>? _tablebillSingleunitRows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='tblBillAcctRev']//tbody//tr")]
        internal readonly IList<IWebElement>? _tableBillAcctRevRows = null;

    }
}
