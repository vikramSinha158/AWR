﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Accidents
{
    internal class AccidentEntryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public AccidentEntryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='AccidentNo']")]
        internal readonly IWebElement? _accidentNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='NewButton']")]
        internal readonly IWebElement? _addAccident = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNo']")]
        internal readonly IWebElement? _unitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Operator']")]
        internal readonly IWebElement? _accidentEntryOperator = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Operator_name']")]
        internal readonly IWebElement? _accidentEntryOperatorName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DriverLic']")]
        internal readonly IWebElement? _accidentEntryDrivingLicense = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DriverCountry']")]
        internal readonly IWebElement? _accidentEntryDriverCountry = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DriverState']")]
        internal readonly IWebElement? _accidentEntryDriverState = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Driver_phone']")]
        internal readonly IWebElement? _accidentEntryDriverPhone = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Driver_email']")]
        internal readonly IWebElement? _accidentEntryDriverEmail = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='supervisor']")]
        internal readonly IWebElement? _accidentEntrySupervisor = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='InsCompany']")]
        internal readonly IWebElement? _accidentEntryInsuranceCompany = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Policy_no']")]
        internal readonly IWebElement? _accidentEntryPolicyNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Exp_date']")]
        internal readonly IWebElement? _accidentEntryExpiryDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Ins_Phone']")]
        internal readonly IWebElement? _accidentEntryInsurancePhone = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Trip_orig']")]
        internal readonly IWebElement? _accidentEntryTripOrig = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Trip_dest']")]
        internal readonly IWebElement? _accidentEntryTripDest = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='start_time']")]
        internal readonly IWebElement? _accidentEntryStartTime = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='purpose']")]
        internal readonly IWebElement? _accidentEntryPurpose = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='AccidentNo']")]
        internal readonly IWebElement? _accidentEntryAccidentNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='scope']")]
        internal readonly IWebElement? _accidentEntryScope = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='route']")]
        internal readonly IWebElement? _accidentEntryRoute = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Activity']")]
        internal readonly IWebElement? _accidentActivity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='work_hours']")]
        internal readonly IWebElement? _accidentEntryWorkHours = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='onDuty']")]
        internal readonly IWebElement? _accidentEntryOnDuty = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='vendorNo$new_0']")]
        internal readonly IWebElement? _vendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RefNo$new_0']")]
        internal readonly IWebElement? _refNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Est_date$new_0']")]
        internal readonly IWebElement? _estimatedDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Labor_hrs$new_0']")]
        internal readonly IWebElement? _laborHours = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Labor_do$new_0']")]
        internal readonly IWebElement? _laborCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='part_do$new_0']")]
        internal readonly IWebElement? _partCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='comm_do$new_0']")]
        internal readonly IWebElement? _commCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Misc_do$new_0']")]
        internal readonly IWebElement? _miscCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='tax_do$new_0']")]
        internal readonly IWebElement? _tax = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Total_do$new_0']")]
        internal readonly IWebElement? _total = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EstimateFrame']")]
        internal readonly IWebElement? _vendorTabFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EstimateTable']")]
        internal readonly IWebElement? _vendorTable = null;       

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ReqListFrame']")]
        internal readonly IWebElement? _workRequestFrame = null;
        
        [FindsBy(How = How.XPath, Using = "//table[@id='reqTable']")]
        internal readonly IWebElement? _workRequestTable = null;

        [FindsBy(How = How.XPath, Using = "//div[@id='flink']")]
        internal readonly IWebElement? _workRequests = null;
 
        [FindsBy(How = How.XPath, Using = "//button[@id='newWr']")]
        internal readonly IWebElement? _newWorkRequests = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='JobReason']")]
        internal readonly IWebElement? _jobReason = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='JobCode']")]
        internal readonly IWebElement? _jobCode = null;
     
        [FindsBy(How = How.XPath, Using = "//input[@name='PrefShift']")]
        internal readonly IWebElement? _scheduleShift = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='MaintLoc']")]
        internal readonly IWebElement? _mainLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WrNo']")]
        internal readonly IWebElement? _number = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@id='Content2']")]
        internal readonly IWebElement? _contentFrame = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='EarlDate']")]
        internal readonly IWebElement? _earliestDate = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='PreferDate']")]
        internal readonly IWebElement? _dueDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='LatestDate']")]
        internal readonly IWebElement? _latestDate = null;

        //Insurance Claims tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame21']")]
        internal readonly IWebElement? _frameInsuranceClaims = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable21']/tbody")]
        internal IWebElement? _tableInsuranceClaims = null;

        //Payments tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame22']")]
        internal readonly IWebElement? _framePayments = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable22']/tbody")]
        internal IWebElement? _tablePayments = null;

        //Accident Detail Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='Accident_date']")]
        internal readonly IWebElement? _inputAccidentDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Address1']")]
        internal readonly IWebElement? _inputAddress1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='City']")]
        internal readonly IWebElement? _inputCity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LocCountry']")]
        internal readonly IWebElement? _inputCountry = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='State']")]
        internal readonly IWebElement? _inputState = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Zip']")]
        internal readonly IWebElement? _inputZip = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Accident_type']")]
        internal readonly IWebElement? _inputAccidentType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Accident_cause']")]
        internal readonly IWebElement? _inputAccidentCause = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Weather']")]
        internal readonly IWebElement? _inputWeatherCondition = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RoadCond']")]
        internal readonly IWebElement? _inputRoadCondition = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='visibility']")]
        internal readonly IWebElement? _inputVisibility = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='seatBelt']")]
        internal readonly IWebElement? _checkboxSeatBeltUsed = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Injury']")]
        internal readonly IWebElement? _checkboxPersonalInjury = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Fatality']")]
        internal readonly IWebElement? _checkboxFatalities = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='reportFlag']")]
        internal readonly IWebElement? _checkboxPoliceReport = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ReportNo']")]
        internal readonly IWebElement? _inputReportNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PlcDept']")]
        internal readonly IWebElement? _inputPoliceDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OfficerName']")]
        internal readonly IWebElement? _inputOfficerName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PlcAddress']")]
        internal readonly IWebElement? _inputPoliceAddress = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PlcCity']")]
        internal readonly IWebElement? _inputPoliceCity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PlcState']")]
        internal readonly IWebElement? _inputPoliceState = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PlcZip']")]
        internal readonly IWebElement? _inputPoliceZip = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PlcCountry']")]
        internal readonly IWebElement? _inputPoliceCountry = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DrugFlag']")]
        internal readonly IWebElement? _checkboxDrugFlag = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Sobriety']")]
        internal readonly IWebElement? _selectSobriety = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Clear_date']")]
        internal readonly IWebElement? _inputDateCleared = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame14']")]
        internal readonly IWebElement? _frameWitness = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable14']//tbody")]
        internal readonly IWebElement? _tableWitness = null;

        //Unit Damage Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='ClaimNo']")]
        internal readonly IWebElement? _inputClaimNo = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='claim_status']")]
        internal readonly IWebElement? _selectClaimStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Est_repair']")]
        internal readonly IWebElement? _inputEstimateRepair = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Other_act']")]
        internal readonly IWebElement? _inputOtherPartyActual = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='WriteOff']")]
        internal readonly IWebElement? _selectWriteOff = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='buyBackAmt']")]
        internal readonly IWebElement? _inputBuyBackAmt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Sub_amount']")]
        internal readonly IWebElement? _inputSubrogationAmount = null;
    }
}
