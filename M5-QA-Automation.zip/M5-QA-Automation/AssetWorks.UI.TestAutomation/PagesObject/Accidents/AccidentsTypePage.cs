﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Accidents
{
    internal class AccidentsTypePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public AccidentsTypePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='AccidentTypesFrame']")]
        internal readonly IWebElement? _accidenttypeframe = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='AccidentTypesTable']")]
        internal readonly IWebElement? _accidenttypetable = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='type_no$new_0']")]
        internal readonly IWebElement? _accidenttypeinput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='desc$new_0']")]
        internal readonly IWebElement? _accidenttypeDescp = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='disabled$new_0']")]
        internal readonly IWebElement? _checkboxDisabled = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='authPw']")]
        internal readonly IWebElement? _inputPassword = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='authContBtn']")]
        internal readonly IWebElement? _btnContinue = null;

    }
}
