﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Accidents
{
    internal class AccidentCategoryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public AccidentCategoryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='AcciCategoryFrame']")]
        internal readonly IWebElement? _accidentCategoryFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='accicategoryTable']")]
        internal readonly IWebElement? _accidentCategoryTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='code$new_0']")]
        internal readonly IWebElement? _categoryCode = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='desc$new_0']")]
        internal readonly IWebElement? _categoryDescription = null;
    }
}
