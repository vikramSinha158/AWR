﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class MCCUnitDisplayPage : BasePage
    {
        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal string _unitMoHeader = "Unit No.";
        internal string _componentNoHeader = "Component No.";

        public MCCUnitDisplayPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='MCCKey']")]
        internal IWebElement? _mCCKeyinput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='UnitsFrame']")]
        internal IWebElement? _unitsFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='unitsTable']")]
        internal IWebElement? _unitsTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ComponentsFrame']")]
        internal IWebElement? _componentsFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='componentsTable']")]
        internal IWebElement? _componentsTable = null;
    }
}
