﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingIndirectItemsPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public BillingIndirectItemsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='BillCode']")]
        internal readonly IWebElement? _billingCodeInput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillIndAcctFrame']")]
        internal IWebElement? _billIndAcctFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillIndAcctTable']")]
        internal IWebElement? _billIndAcctTable = null;
    }
}
