﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class TechSpecMainPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal string _techSpecProduct= "product_no$new_";
        internal string _techSpecCapacity = "Capacity$new_";
        internal string _techSpecMaxDailyFueling = "max_daily_fuelings$new_";
        internal string _techSpecMaxDailyQty = "max_daily_qty$new_";
        internal string _techSpecPri = "pri$new_";
        internal string _techSpecSec = "sec$new_";
        internal IWebElement? _product_no = null;
        internal IWebElement? _capacity = null;
        internal IWebElement? _maxDailyFuelings = null;
        internal IWebElement? _maxDailyQty = null;
        internal IWebElement? _priCheckbpx = null;
        internal IWebElement? _secCheckbox = null;
        public static string _trimValue = String.Empty;
        public static string _referenceValue = String.Empty;
        internal string _replacementValue = String.Empty;
        internal string _gVWValue = String.Empty;
        internal string _offHwyPctValue = String.Empty;
        internal string _techSpacNoteValue = String.Empty;
        internal string _techSpecWONoteValue = String.Empty;
        public static string _uPQCityValue = String.Empty;
        public static string _uPQHighwayValue = String.Empty;
        public static string _uPQCombinedValue = String.Empty;
        internal string _reasoncodeName = "reasoncode$new_";
        internal string _estPromptName = "EstPrompt$new_";
        internal string _jobMaxCostName = "JobMaxCost$new_";
        internal string _sysJobMaxHrsName = "JobMaxHrs$new_";
        internal string _lTDMaxCostName = "LTDMaxCost$new_";
        internal IWebElement? _reasoncode = null;
        internal IWebElement? _estPrompt = null;
        internal IWebElement? _jobMaxCost = null;
        internal IWebElement? _sysJobMaxHrs = null;
        internal IWebElement? _lTDMaxCost = null;
        internal string _systemcodeName = "system_code$new_";
        internal string _sysEstPromptName = "SysEstPrompt$new_";
        internal string _sysJobMaxCostName = "SysJobMaxCost$new_";
        internal string _sysJobMaxHrName = "SysJobMaxHrs$new_";
        internal string _sysLTDMaxCostName = "SysLTDMaxCost$new_";
        internal IWebElement? _systemcode = null;
        internal IWebElement? _sysEstPrompt = null;
        internal IWebElement? _sysJobMaxCost = null;
        internal IWebElement? _sysJobMaxHr = null;
        internal IWebElement? _sysLTDMaxCost = null;
        internal string _assocSpecNo = "assocSpecNo$new_";
        internal string _maxNoAssocName = "maxNoAssoc$new_";
        internal string _maxNoAssocPosnName = "maxNoAssocPosn$new_";
        internal string _minNoAssocName = "minNoAssoc$new_";
        internal string _assocJobName = "assocJob$new_";
        internal string _minNoAssocSaleName = "minNoAssocSale$new_";
        internal IWebElement? _assocSpec = null;
        internal IWebElement? _maxNoAssoc = null;
        internal IWebElement? _maxNoAssocPosn = null;
        internal IWebElement? _minNoAssoc = null;
        internal IWebElement? _assocJob = null; 
        internal IWebElement? _minNoAssocSale = null;
        internal string _docTypeName = "DOC_TYPE$new_";
        internal string _expDateCheckboxName = "EXPDATE_FL$new_";
        internal string _attachFileCheckboxName = "ATTACH_FL$new_";
        internal IWebElement? _docType = null;
        internal IWebElement? _expDateCheckbox = null;
        internal IWebElement? _attachFileCheckbox = null;

        public TechSpecMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='TechSpecNo']")]
        internal readonly IWebElement? _techSpecNoInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TechSpecDesc']")]
        internal readonly IWebElement? _techSpecDesc = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab0']")]
        internal IWebElement? _detailTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Year']")]
        internal readonly IWebElement? _yearInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MFG']")]
        internal readonly IWebElement? _mfgInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Make']")]
        internal readonly IWebElement? _makeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Model']")]
        internal readonly IWebElement? _modelInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Trim']")]
        internal readonly IWebElement? _trimInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Reference']")]
        internal readonly IWebElement? _referenceInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='licClassCode']")]
        internal readonly IWebElement? _licClassCodeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Category']")]
        internal readonly IWebElement? _categoryInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Replacement']")]
        internal readonly IWebElement? _replacementInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='GVW']")]
        internal readonly IWebElement? _gVWInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='OffHwyPct']")]
        internal readonly IWebElement? _offHwyPctInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TestSuiteName']")]
        internal readonly IWebElement? _testSuiteNameInput = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='Note']")]
        internal readonly IWebElement? _techSpacNote = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='SpecWONote']")]
        internal readonly IWebElement? _techSpecWONote = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal IWebElement? _productTab = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='VehType']")]
        internal IWebElement? _vehType = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='FuelClass']")]
        internal IWebElement? _fuelClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UPQCity']")]
        internal readonly IWebElement? _uPQCity = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UPQHighway']")]
        internal readonly IWebElement? _uPQHighway = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UPQCombined']")]
        internal readonly IWebElement? _uPQCombined = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TechSpecProdFrame']")]
        internal IWebElement? _techSpecProdFrame = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal IWebElement? _exceptionsTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TotalWOCost']")]
        internal readonly IWebElement? _totalWOCostInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AnnTotMaintCosts']")]
        internal readonly IWebElement? _maintCostsInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='LTDTotMaintCosts']")]
        internal readonly IWebElement? _lTDTotMaintCostsInput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TechSpecReasonFrame']")]
        internal IWebElement? _techSpecReasonFrame = null;
        
        [FindsBy(How = How.XPath, Using = "//iframe[@name='TechSpecSysFrame']")]
        internal IWebElement? _techSpecSysFrame = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab4']")]
        internal IWebElement? _assocTechSpecTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='AssocTechSpecFrame']")]
        internal IWebElement? _assocTechSpecFrame = null;

        [FindsBy(How = How.XPath, Using= "//a[@href='#divTab6']")]
        internal IWebElement? _documentTypesTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DocTypesFrame']")]
        internal IWebElement? _docTypesFrame = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab7']")]
        internal IWebElement? _zonesTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='emisRate']")]
        internal readonly IWebElement? _emisRateInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='maxRange']")]
        internal readonly IWebElement? _maxRangeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='batRange']")]
        internal readonly IWebElement? _batRangeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='batDensity']")]
        internal readonly IWebElement? _batDensityInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='zlicClass']")]
        internal readonly IWebElement? _zoneslicClassInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='starRate']")]
        internal readonly IWebElement? _starRateInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='dvPermFl']")]
        internal readonly IWebElement? _dvPermitCheckbox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='cameraFl']")]
        internal readonly IWebElement? _cameraCheckbox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='camDetail']")]
        internal readonly IWebElement? _cammentDetailInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='compYear']")]
        internal readonly IWebElement? _compYearInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CO']")]
        internal readonly IWebElement? _coInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CO2']")]
        internal readonly IWebElement? _co2Input = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CO2A']")]
        internal readonly IWebElement? _coaInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='HC']")]
        internal readonly IWebElement? _hcInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NOX']")]
        internal readonly IWebElement? _noxInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='zPM']")]
        internal readonly IWebElement? _pmInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PM10']")]
        internal readonly IWebElement? _pm10Input = null;
    }
}
