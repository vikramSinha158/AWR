﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.ProductOrder
{
    internal class ProductLocationReceivePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public ProductLocationReceivePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "fpono")]
        internal IWebElement? _productOrder = null;
        
        [FindsBy(How = How.Id, Using = "RefNo")]
        internal IWebElement? _referenceNumber = null;

        [FindsBy(How = How.Id, Using = "venInvdt3")]
        internal IWebElement? _vendorInvDate = null;

        [FindsBy(How = How.Name, Using = "FuelFrame")]
        internal IWebElement? _fuelFrame = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@Name,'receivedqty$')]")]
        internal IList<IWebElement>? _receivedQuantity = null;
        
        [FindsBy(How = How.XPath, Using = "//input[contains(@Name,'completeLine$')]")]
        internal IList<IWebElement>? _completeLineCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@Name,'totalDo$')]")]
        internal IList<IWebElement>? _totalCost = null;

        [FindsBy(How = How.Name, Using = "totalinvoicecost")]
        internal IWebElement? _totalInvoiceCost = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'prod$')]")]
        internal IList<IWebElement>? _prod = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'tank$')]")]
        internal IList<IWebElement>? _prodTank = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'unitcost$')]")]
        internal IList<IWebElement>? _prodUnitCost = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'orderqty$')]")]
        internal IList<IWebElement>? _prodQuantity = null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Display?']/following-sibling::input")]
        internal IWebElement? _displayClosedItems = null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Reopen?']/following-sibling::input")]
        internal IWebElement? _reOpenClosedItems = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'receiveddate$')]")]
        internal IList<IWebElement>? _receivedDate = null;
    }
}
