﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.ProductOrder
{
    internal class ProductOrderPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public ProductOrderPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }          

        [FindsBy(How = How.Id, Using = "fpono")]
        internal IWebElement? _poNumber = null;

        [FindsBy(How = How.Id, Using = "newPo")]
        internal IWebElement? _newPOButton = null;

        [FindsBy(How = How.XPath, Using = "//button[text()='Create']")]
        internal IWebElement? _createButton = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='vennumber']")]
        internal IWebElement? _vendorNumber = null;

        [FindsBy(How = How.Id, Using = "contractNo")]
        internal IWebElement? _contractNumber = null;

        [FindsBy(How = How.Id, Using = "prod$new_0")]
        internal IWebElement? _prodInput = null;

        [FindsBy(How = How.Id, Using = "tank$new_0")]
        internal IWebElement? _prodTankInput = null;

        [FindsBy(How = How.Id, Using = "unitcost$new_0")]
        internal IWebElement? _prodUnitCostInput = null;

        [FindsBy(How = How.Id, Using = "orderqty$new_0")]
        internal IWebElement? _prodQuantityInput = null;

        [FindsBy(How = How.Id, Using = "receivedqty$0")]
        internal IWebElement? _receivedQuantityInput = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'prod$')]")]
        internal IList<IWebElement>? _prod = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'tank$')]")]
        internal IList<IWebElement>? _prodTank = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'unitcost$')]")]
        internal IList<IWebElement>? _prodUnitCost = null;
        
        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'orderqty$')]")]
        internal IList<IWebElement>? _prodQuantity = null;

        [FindsBy(How = How.XPath, Using = "//button[text()='Accept?']")]
        internal IWebElement? _acceptButton = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='FuelFrame']")]
        internal IWebElement? _fuelFrame = null;

        [FindsBy(How = How.Id, Using = "prod$0")]
        internal IList<IWebElement>? _prodInputs = null;
    }
}
