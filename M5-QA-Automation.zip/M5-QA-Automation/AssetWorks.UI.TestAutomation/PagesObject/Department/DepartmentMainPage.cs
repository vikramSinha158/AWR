﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Department
{
    /// <summary>
    /// Page object class for Department Main
    /// </summary>
    internal class DepartmentMainPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal DepartmentMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//span[@class='ScreenTitle']")]
        internal readonly IWebElement? _departmentTitle = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptNumber']")]
        internal readonly IWebElement? _inputDeptNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptDesc']")]
        internal readonly IWebElement? _inputDeptDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='STATUS']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='savebutton']")]
        internal readonly IWebElement? _buttonSave = null;

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]//p[1]")]
        internal readonly IWebElement? _dialogTitle = null;

        // General Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='BILLING_CODE']")]
        internal readonly IWebElement? _inputDeptBillingCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='BILLING_DESC']")]
        internal readonly IWebElement? _inputDeptBillingDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Contact']")]
        internal readonly IWebElement? _inputDeptContact = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Phone']")]
        internal readonly IWebElement? _inputDeptPhone = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PhoneEx']")]
        internal readonly IWebElement? _inputDeptPhoneEx = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Email']")]
        internal readonly IWebElement? _inputDeptEmail = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MCC']")]
        internal readonly IWebElement? _inputDeptMCC = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SpecNo']")]
        internal readonly IWebElement? _inputDeptSpecNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DeliveryLoc']")]
        internal readonly IWebElement? _inputDeptDeliveryLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MaintLoc']")]
        internal readonly IWebElement? _inputDeptMaintLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='invLoc']")]
        internal readonly IWebElement? _inputDeptInvLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EX_CUSTNO']")]
        internal readonly IWebElement? _inputDeptExCustNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Prioritykick']")]
        internal readonly IWebElement? _inputDeptPriorityKick = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MaxWO']")]
        internal readonly IWebElement? _inputDeptMaxWO = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MarkupScheme']")]
        internal readonly IWebElement? _inputDeptMarkupScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TaxExempt']")]
        internal readonly IWebElement? _inputDeptTaxExempt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='AlterFlatTax']")]
        internal readonly IWebElement? _inputDeptAlterFlatTax = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Outside']")]
        internal readonly IWebElement? _inputDeptOutsideOrg = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='WONOTES']")]
        internal readonly IWebElement? _inputDeptWONotes = null;


        //Org Hierarchy Tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='DeptOrgHierFrame']")]
        internal IWebElement? _frameDeptOrgHier = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DeptOrgHierTable']/tbody")]
        internal IWebElement? _tableDeptOrgHier = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Label$0']")]
        internal readonly IWebElement? _inputDeptOrgH1122 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Label$1']")]
        internal readonly IWebElement? _inputDeptOrgHDepartment = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Label$2']")]
        internal readonly IWebElement? _inputDeptOrgHSection = null;


        //Quote Rules Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='Approval1Title']")]
        internal readonly IWebElement? _inputDeptApproval1Title = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Approval2Title']")]
        internal readonly IWebElement? _inputDeptApproval2Title = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DeptQuoteFrame']")]
        internal IWebElement? _frameDeptQuote = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DeptQuoteTable']/tbody")]
        internal IWebElement? _tableDeptQuote = null;


        //Motor Pool Tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPApproverFrame']")]
        internal IWebElement? _frameDeptMPApprover = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='approverTable']/tbody")]
        internal IWebElement? _tableDeptApprover = null;

    }
}
