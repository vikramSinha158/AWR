﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Department
{
    internal class DepartmentGroupsPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal static List<string> DeptInGroup { get; set; }

        internal DepartmentGroupsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptGroup']")]
        internal readonly IWebElement? _inputDeptGroup =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='rbNumber']")]
        internal readonly IWebElement? _radioNumber =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='rbName']")]
        internal readonly IWebElement? _radioName =null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Departments']")]
        internal readonly IWebElement? _tabDepartments =null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DeptGroupMaintFrame']")]
        internal readonly IWebElement? _frameDeptGroup =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DeptListLeft']")]
        internal readonly IWebElement? _selectDeptListLeft =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DeptListRight']")]
        internal readonly IWebElement? _selectDeptListRight =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='DeptListMoveRight']")]
        internal readonly IWebElement? _buttonDeptListMoveRight =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='DeptListMoveLeft']")]
        internal readonly IWebElement? _buttonDeptListMoveLeft =null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Roles']")]
        internal readonly IWebElement? _tabRoles =null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DeptGroupMaintUserFrame']")]
        internal readonly IWebElement? _frameDeptGroupUser =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='userID$new_0']")]
        internal readonly IWebElement? _inputNewRole =null;
        
    }
}
