﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Department
{
    internal class DepartmentNumberChangePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal static string NCDepartmentNumber { get; set; }

        internal static string NCDepartmentDescription { get; set; }

        internal static string NCDepartmentStatus { get; set; }

        internal DepartmentNumberChangePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptNumber']")]
        internal readonly IWebElement? _inputDepartmentNumber =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtdepartmentDesc']")]
        internal readonly IWebElement? _txtDepartmentDescription =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='STATUS']")]
        internal readonly IWebElement? _txtDepartmentStatus =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewDeptNumber']")]
        internal readonly IWebElement? _inputNewDepartmentNumber =null;
       
    }
}
