﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class CompanyDefinitionPage :BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public CompanyDefinitionPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal IWebElement? _accountTemplateTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='useDirAcct']")]
        internal readonly IWebElement? _useDirAcctCheckbox = null;
    }
}
