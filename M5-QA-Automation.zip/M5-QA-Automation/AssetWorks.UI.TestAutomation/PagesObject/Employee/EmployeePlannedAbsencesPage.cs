﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Labor
{
    internal class EmployeePlannedAbsencesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal EmployeePlannedAbsencesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal readonly By LocatorTableHeader = By.XPath("//span[contains(text(),'Loaded')]");

        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmployeeNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeName']")]
        internal readonly IWebElement? _inputEmployeeName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='STATUS']")]
        internal readonly IWebElement? _inputEmployeeStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ShiftCode']")]
        internal readonly IWebElement? _inputShiftCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ShiftDesc']")]
        internal readonly IWebElement? _inputShiftCodeDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FiscalPd']")]
        internal readonly IWebElement? _inputStartingPeriod = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='AbsenceFrame']")]
        internal IWebElement? _frameAbsence = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='planabsenceTable']/tbody")]
        internal IWebElement? _tablePlanAbsence = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='planabsenceTable']/tbody/tr")]
        internal IList<IWebElement>? _tablePlanAbsenceTotalRows = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Loaded')]")]
        internal IList<IWebElement>? _tablePlanAbsenceHeader = null;

        internal IWebElement? _inputNewIndirectAccount(string rowId) => Driver.FindElement(By.XPath($"//input[@id='IndAcct$new_{rowId}']"));
        internal IWebElement? _inputIndirectAccount(string rowId) => Driver.FindElement(By.XPath($"//input[@id='IndAcct${rowId}']"));
        internal IWebElement? _inputNewStartDate(string rowId) => Driver.FindElement(By.XPath($"//input[@id='Start_Date$new_{rowId}']"));
        internal IWebElement? _inputNewStartTime(string rowId) => Driver.FindElement(By.XPath($"//input[@id='Start_Time$new_{rowId}']"));
        internal IWebElement? _inputNewEndDate(string rowId) => Driver.FindElement(By.XPath($"//input[@id='End_Date$new_{rowId}']"));
        internal IWebElement? _inputNewEndTime(string rowId) => Driver.FindElement(By.XPath($"//input[@id='End_Time$new_{rowId}']"));
        internal IWebElement? _inputNewDescription(string rowId) => Driver.FindElement(By.XPath($"//input[@id='HolidayDesc$new_{rowId}']"));
        internal IWebElement? _inputNewTimeType(string rowId) => Driver.FindElement(By.XPath($"//input[@id='TimeType$new_{rowId}']"));
        internal IWebElement? _inputNewUnion(string rowId) => Driver.FindElement(By.XPath($"//input[@id='Union$new_{rowId}']"));
        internal IWebElement? _inputNewPayClass(string rowId) => Driver.FindElement(By.XPath($"//input[@id='PayClass$new_{rowId}']"));
        internal IWebElement? _inputNewPayStep(string rowId) => Driver.FindElement(By.XPath($"//input[@id='PayStep$new_{rowId}']"));
        internal IWebElement? _checkboxNewIgnoreSubtraction(string rowId) => Driver.FindElement(By.XPath($"//input[@id='IgnoreSubtraction$new_{rowId}']"));

    }
}
