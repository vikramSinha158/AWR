﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class EmployeeTitlePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal EmployeeTitlePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EmpTitleFrame']")]
        internal IWebElement? _frameEmpTitle = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EmpTitleTable']/tbody")]
        internal IWebElement? _tableEmpTitles = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JOB_TITLE$new_0']")]
        internal IWebElement? _inputTitle = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PROD_PCENT$new_0']")]
        internal IWebElement? _inputProductivity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISABLED_FL$new_0']")]
        internal IWebElement? _chbDisabled = null;      
    }
}
