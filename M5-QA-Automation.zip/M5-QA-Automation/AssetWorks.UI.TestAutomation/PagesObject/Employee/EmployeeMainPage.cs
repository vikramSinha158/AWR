﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
/// <summary>
/// Page object class for Employee Main
/// </summary>
internal class EmployeeMainPage : BasePage
{
        public static string EmpID { get; set; }
        public static string EmpName { get; set; }
        public static string TripCardPin { get; set; }
        public static string DriverNO { get; set; }
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal EmployeeMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }      

        //General Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmpID =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtEmployeeName']")]
        internal readonly IWebElement? _inputName =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='STATUS']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JOB_TITLE']")]
        internal readonly IWebElement? _jobTitle = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SKILL_LEVEL']")]
        internal readonly IWebElement? _skillLevel = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SHIFT_CODE']")]
        internal readonly IWebElement? _inputShiftCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SHIFT_DESC']")]
        internal readonly IWebElement? _ShiftCodeDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Shift_Eff_Dt']")]
        internal readonly IWebElement? _effectiveDate = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='CHG_TIME_WO_FL']")]
        internal readonly IWebElement? _AuthChargeTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UsePayroll']")]
        internal readonly IWebElement? _usePayrollRates = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MarkupScheme']")]
        internal readonly IWebElement? _markupScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='issueToUnit']")]
        internal readonly IWebElement? _Unit = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='issueToWO']")]
        internal readonly IWebElement? _WorkOrder = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='issueToIA']")]
        internal readonly IWebElement? _IndirectAcct = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='issueToDA']")]
        internal readonly IWebElement? _DirectAccount = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='issueToDE']")]
        internal readonly IWebElement? _Department = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TRIPCARD_PIN']")]
        internal readonly IWebElement? _tripCard = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='START_DT']")]
        internal readonly IWebElement? _startDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TERM_DT']")]
        internal readonly IWebElement? _terminationDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PHONE']")]
        internal readonly IWebElement? _telephone = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PHONE_EXT']")]
        internal readonly IWebElement? _phoneExt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EMAIL_ADDRESS']")]
        internal readonly IWebElement? _email = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PIN']")]
        internal readonly IWebElement? _pin = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='SUPERV_FL']")]
        internal readonly IWebElement? _supervisor = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='CONTRACTOR_FL']")]
        internal readonly IWebElement? _contractor = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DEPT_CONTACT_FL']")]
        internal readonly IWebElement? _dptContact = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='EXEMPT_FL']")]
        internal readonly IWebElement? _exempt = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DRIVER_FL']")]
        internal readonly IWebElement? _driver = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='TECHNICIAN_FL']")]
        internal readonly IWebElement? _technician = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='ADD_NEW_JOB_FL']")]
        internal readonly IWebElement? _addJobOnLabor = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='TIMEKEEP_FL']")]
        internal readonly IWebElement? _timeKeeper = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='MP_APPROVAL_FL']")]
        internal readonly IWebElement? _mpAppr = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='INV_FL']")]
        internal readonly IWebElement? _invEmp = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='tempEmployee']")]
        internal readonly IWebElement? _tempEmp = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='empNotes']")]
        internal readonly IWebElement? _empNotes = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab0']")]
        internal IWebElement? _generalTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab1']")]
        internal IWebElement? _assignmentTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab3']")]
        internal IWebElement? _subordinatesTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab4']")]
        internal IWebElement? _resourceTypeTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab5']")]
        internal IWebElement? _driverInfoTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab6']")]
        internal IWebElement? _motorPoolTab = null;

        //Asignment Tab        
        [FindsBy(How = How.XPath, Using = "//input[@id='SUPER_ID']")]
        internal readonly IWebElement? _supervisorID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='HOMELOC']")]
        internal readonly IWebElement? _inputHomeLOcation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LOC_DESC']")]
        internal readonly IWebElement? _HomeLocationDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DEPT_NO']")]
        internal readonly IWebElement? _deptNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DEPT_DESC']")]
        internal readonly IWebElement? _deptNoDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VENDOR_NO']")]
        internal readonly IWebElement? _vendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VENDOR_DESC']")]
        internal readonly IWebElement? _vendorNoDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UNION_NO']")]
        internal readonly IWebElement? _unionNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UNION_DESC']")]
        internal readonly IWebElement? _unionNoDesc = null;
        //PayrollTab
        [FindsBy(How = How.XPath, Using = "//a[@href='#ctlTab2']")]
        internal IWebElement? _payrollTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_CLASS']")]
        internal readonly IWebElement? _primaryPayClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_STEP']")]
        internal readonly IWebElement? _primaryPayStep = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_STEP_DESC']")]
        internal readonly IWebElement? _primaryPayDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_CLASS2']")]
        internal readonly IWebElement? _secondaryPayClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_STEP2']")]
        internal readonly IWebElement? _secondaryPayStep = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_STEP2_DESC']")]
        internal readonly IWebElement? _secondaryPayDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_CLASS3']")]
        internal readonly IWebElement? _tertiaryPayClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_STEP3']")]
        internal readonly IWebElement? _tertiaryPayStep = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAY_STEP3_DESC']")]
        internal readonly IWebElement? _tertiaryPayDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TIME_TYPE']")]
        internal readonly IWebElement? _timeType = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame21']")]
        internal readonly IWebElement? _frameResouceType= null;     

        [FindsBy(How = How.XPath, Using = "//input[@id='ertResourceType$r0']")]
        internal IWebElement? _inputResourceType = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@id='ertExpireDt$r0']")]
        internal IWebElement? _inputExpiryDate = null;
        
        [FindsBy(How = How.XPath, Using = "//span[@id='LTmrDataFrame20']")]
        internal IWebElement? _frameText = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='LTmrDataFrame21']")]
        internal IWebElement? _frameTextResourcePool = null;

        //Driver Info Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='OPERATOR_ID']")]
        internal IWebElement? _inputDriverNO = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='TAX_FORM_ONFILE_FL']")]
        internal IWebElement? _taxformOnFile = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LICENSENO']")]
        internal IWebElement? _inputLicenceNO = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LICEXP_DT']")]
        internal IWebElement? _icenceExpiry = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtDriverStatus']")]
        internal IWebElement? _txtDriverStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtDvrStatusDesc']")]
        internal IWebElement? _driverStatusDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtDriverType']")]
        internal IWebElement? _txtDriverType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtDvrTypeDesc']")]
        internal IWebElement? _driverTypeDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtDriverClass']")]
        internal IWebElement? _txtDriverClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtDvrClassDesc']")]
        internal IWebElement? _driverClassDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ADDRESS1']")]
        internal IWebElement? _address1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ADDRESS2']")]
        internal IWebElement? _address2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CITY']")]
        internal IWebElement? _city = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='STATE']")]
        internal IWebElement? _state = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ZIPCODE']")]
        internal IWebElement? _zipCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='REGION']")]
        internal IWebElement? _region = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MUNICIPALITY']")]
        internal IWebElement? _municipality = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='COUNTY']")]
        internal IWebElement? _country = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MOBILE']")]
        internal IWebElement? _mobile = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MONTHLYUSG']")]
        internal IWebElement? _monthlyUsage = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MONTHLYBSNUSG']")]
        internal IWebElement? _monthlyBisUsage = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='restMPReservation']")]
        internal IWebElement? _restMPReservation = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='empClass$r0']")]
        internal IWebElement? _motorpoolClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='empdescription$r0']")]
        internal IWebElement? _motorpoolClassDesc = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='LTmrDataFrame30']")]
        internal IWebElement? _frameTextMotorPool = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame30']")]
        internal IWebElement? _frameMotorPoolTable = null;

        //Employee Copy
        [FindsBy(How = How.XPath, Using = "//input[@id='NewEmployeeNo']")]
        internal readonly IWebElement? _inputNewEmpID = null;

    }
}
