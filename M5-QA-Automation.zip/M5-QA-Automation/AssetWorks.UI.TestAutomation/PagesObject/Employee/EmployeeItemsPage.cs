﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Employee
{
    internal class EmployeeItemsPage : BasePage
    {
        internal EmployeeItemsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmployeeId = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EmployeeItemFrame']")]
        internal IWebElement? _employeeItemFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EmployeeitemTable']")]
        internal IWebElement? _employeeItemTable = null;

        internal IWebElement? _inputEmployeeItem(string rowId) => Driver.FindElement(By.XPath($"//input[@id='item$new_{rowId}']"));
        internal IWebElement? _inputValueField(string rowId) => Driver.FindElement(By.XPath($"//input[@id='value$new_{rowId}']"));

    }
}
