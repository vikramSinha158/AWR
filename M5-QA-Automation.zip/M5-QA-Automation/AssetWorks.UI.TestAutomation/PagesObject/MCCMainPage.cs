﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class MCCMainPage : BasePage
    {
        internal string FirstType = String.Empty;
        internal string FirstMin = String.Empty;
        internal string FirstMax = String.Empty;
        internal string FirstLength = String.Empty;
        internal string SecondType = String.Empty;
        internal string SecondMin = String.Empty;
        internal string SecondMax = String.Empty;
        internal string SecondLength = String.Empty;
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal string _mccErrorMessge = "Cannot delete MCC";

        public MCCMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='MCCKey']")]
        internal readonly IWebElement? _mccMainInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MCCDesc']")]
        internal readonly IWebElement? _mccMainDescInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='cbofirstType']")]
        internal readonly IWebElement? _meuFirstType = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='cbosecondType']")]
        internal readonly IWebElement? _meuSecondType = null;
    
        [FindsBy(How = How.XPath, Using = "//input[@name='txtfirstMin']")]
        internal readonly IWebElement? _txtFirstMin = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='txtfirstMax']")]
        internal readonly IWebElement? _txtFirstMax = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='txtfirstLength']")]
        internal readonly IWebElement? _txtFirstLength = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='txtsecondMin']")]
        internal readonly IWebElement? _txtSecondMin = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='txtsecondMax']")]
        internal readonly IWebElement? _txtSecondMax = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='txtsecondLength']")]
        internal readonly IWebElement? _txtSecondLength = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='seasonCode']")]
        internal readonly IWebElement? _txtSeasonCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='seasonDesc']")]
        internal readonly IWebElement? _seasonDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='SeasonStart']")]
        internal readonly IWebElement? _seasonStart = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='SeasonEnd']")]
        internal readonly IWebElement? _seasonEnd = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Disabled']")]
        internal readonly IWebElement? _mccMainDisabledField = null;
    }
}
