﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.BasicUserFunctionality
{
    internal class MenuMaintenancePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public MenuMaintenancePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='search']")]
        internal IWebElement? _inputSearchFilter = null;

        internal IWebElement? _treeExpander(string title) => Driver.FindElement(
            By.XPath($"//span[text()='{title}']/preceding-sibling::span[@class='fancytree-expander']"));

        internal IWebElement? _checkboxReauthenticate(string title) => Driver.FindElement(
            By.XPath($"//span[text()='{title}']//parent::span//parent::td//parent::tr//input[@type='checkbox']"));

    }
}
