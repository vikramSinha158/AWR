﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class AppUserMaintenanceMainPage : BasePage
    {

        public static string ApplicationUser { get; set; }
        public static string Name { get; set; }
        public static string UserRole { get; set; }
        public static string NewUserID { get; set; }
        public static string NewUserName { get; set; }


        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);


        public AppUserMaintenanceMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='UserApp']")]
        internal readonly IWebElement? _appUser = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AllowWeb']")]
        internal readonly IWebElement? _allowWebAccessChb = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AppPass']")]
        internal readonly IWebElement? _appPassword = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AllowMobile']")]
        internal readonly IWebElement? _allowMobileAccessChb = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MobilePass']")]
        internal readonly IWebElement? _mobilePassword = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UserID']")]
        internal readonly IWebElement? _userRole = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UniqueId']")]
        internal readonly IWebElement? _uniqueID = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UserDesc']")]
        internal readonly IWebElement? _userName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewUserId']")]
        internal readonly IWebElement? _newUserId = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewName']")]
        internal readonly IWebElement? _newUserName = null;
    }
}
