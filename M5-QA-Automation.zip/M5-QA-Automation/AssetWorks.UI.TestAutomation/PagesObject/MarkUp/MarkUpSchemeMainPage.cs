﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MarkUp
{
    internal class MarkUpSchemeMainPage : BasePage
    {
        internal static string MarkUpSchemeID = string.Empty;
        internal static string EffectiveDate = string.Empty;
        internal static string NewSchemeID = string.Empty;
        internal static string NewEffectiveDate = string.Empty;

        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public MarkUpSchemeMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='markupscheme']")]
        internal readonly IWebElement? _inputScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='SchemeDesc']")]
        internal readonly IWebElement? _inputSchemeDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Disabled']")]
        internal readonly IWebElement? _disableScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EffDate']")]
        internal readonly IWebElement? _effectiveDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Reason']")]
        internal readonly IWebElement? _jobReason = null;       

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MarkupPartFrame']")]
        internal readonly IWebElement? _markupPartFrame = null;     

        [FindsBy(How = How.XPath, Using = "//table[@id='MarkupSchemeTable']")]
        internal readonly IWebElement? _markupSchemeTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MarkupLaborFrame']")]
        internal readonly IWebElement? _markupLaborFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MarkupLaborTable']")]
        internal readonly IWebElement? _markupLaborTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MarkupCommFrame']")]
        internal readonly IWebElement? _markupCommFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MarkupCommTable']")]
        internal readonly IWebElement? _markupCommTable = null;

        //Copy MarkUp Scheme
        [FindsBy(How = How.XPath, Using = "//input[@name='AllDate']")]
        internal readonly IWebElement? _copyAllDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AllReason']")]
        internal readonly IWebElement? _copyAllReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='newscheme']")]
        internal readonly IWebElement? _newScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewSchemeDesc']")]
        internal readonly IWebElement? _newSchemeDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='newReason']")]
        internal readonly IWebElement? _newReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewDate']")]
        internal readonly IWebElement? _newDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='newEffDate']")]
        internal readonly IWebElement? _newEffDate = null;

    }
}
