﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingItemsPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal string _billItemHeader= "Bill Item";
        internal string _billchargesId = "billcharges";

        public BillingItemsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillItemFrame']")]
        internal IWebElement? _billItemFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillItemTable']")]
        internal IWebElement? _billItemTable = null;

    }
}
