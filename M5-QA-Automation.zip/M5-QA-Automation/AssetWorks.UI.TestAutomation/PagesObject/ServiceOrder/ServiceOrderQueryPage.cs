﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.ServiceOrder
{
    internal class ServiceOrderQueryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ServiceOrderQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='qloc']")]
        internal readonly IWebElement? _inputLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='qvendor']")]
        internal readonly IWebElement? _inputVendor = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='status']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='serviceNo']")]
        internal readonly IWebElement? _inputServiceOrder = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='servCode']")]
        internal readonly IWebElement? _inputServiceCode = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='resvCode']")]
        internal readonly IWebElement? _selectResvCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='poFromDt']")]
        internal readonly IWebElement? _inputPoFromDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='poToDt']")]
        internal readonly IWebElement? _inputPoToDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RetrieveBtn']")]
        internal readonly IWebElement? _buttonRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ClearBtn']")]
        internal readonly IWebElement? _buttonClear = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ServicePOQryFrame']")]
        internal IWebElement? _frameServicePOQry = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='POListTable']/tbody")]
        internal IWebElement? _tablePOList = null;
    }
}
