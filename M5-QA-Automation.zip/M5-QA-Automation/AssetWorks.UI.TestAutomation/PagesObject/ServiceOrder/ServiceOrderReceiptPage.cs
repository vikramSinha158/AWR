﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.ServiceOrder
{
    internal class ServiceOrderReceiptPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ServiceOrderReceiptPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='servloc']")]
        internal readonly IWebElement? _inputLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='pono1']")]
        internal readonly IWebElement? _inputOrderNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='vennumber1']")]
        internal readonly IWebElement? _inputVendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='invno1']")]
        internal readonly IWebElement? _inputInvoiceNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='effdt']")]
        internal readonly IWebElement? _inputEffectiveDate = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='recvAll']")]
        internal readonly IWebElement? _buttonReceiveAll = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ServiceRecvFrame']")]
        internal IWebElement? _frameServices = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ServiceRcvTable']/tbody")]
        internal IWebElement? _tableServices = null;
    }
}
