﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public BillingPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }


        [FindsBy(How = How.XPath, Using = "//input[@name='BillingCode']")]
        internal readonly IWebElement? _billingCodeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BillingDesc']")]
        internal readonly IWebElement? _billingDescInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EffectiveDate']")]
        internal readonly IWebElement? _effectiveDate = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='BillingType']")]
        internal readonly IWebElement? _billingType = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab0']")]
        internal readonly IWebElement? _billingDetailTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='LeaseRate']")]
        internal readonly IWebElement? _leaseRateInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='LeaseRatePer']")]
        internal readonly IWebElement? _leaseRatePer = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Shift']")]
        internal readonly IWebElement? _shift = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Season']")]
        internal readonly IWebElement? _season = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TaxableFl']")]
        internal readonly IWebElement? _taxableFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='taxScheme']")]
        internal readonly IWebElement? _taxScheme = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='FixedBids']")]
        internal readonly IWebElement? _fixedBids = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='billItem']")]
        internal readonly IWebElement? _billItem = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='LaborBilling']")]
        internal readonly IWebElement?_laborBilling = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PartBilling']")]
        internal readonly IWebElement? _partBilling = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CommBilling']")]
        internal readonly IWebElement? _commBilling = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FlatPerPeriod']")]
        internal readonly IWebElement? _flatPerPeriod = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ChargePerUsage']")]
        internal readonly IWebElement? _chargePerUsage = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='HowToCharge']")]
        internal readonly IWebElement? _howToCharge = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='RecordingMethod']")]
        internal readonly IWebElement? _recordingMethod = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='IFuelProducts']")]
        internal readonly IWebElement? _iFuelProducts = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='OFuelProducts']")]
        internal readonly IWebElement? _oFuelProducts = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ChargePerGal']")]
        internal readonly IWebElement? _chargePerGal = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal readonly IWebElement? _motorPoolTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FuelCharge']")]
        internal readonly IWebElement? _fuelCharge = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TimeType']")]
        internal readonly IWebElement? _timeType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EmpTime']")]
        internal readonly IWebElement? _empTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Overtime']")]
        internal readonly IWebElement? _overtime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Doubletime']")]
        internal readonly IWebElement? _doubletime = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='BillingMethod']")]
        internal readonly IWebElement? _billingMethod = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BillWeekends']")]
        internal readonly IWebElement? _billWeekends = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BillHolidays']")]
        internal readonly IWebElement? _billHolidays = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='HourlyRate']")]
        internal readonly IWebElement? _hourlyRate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='HourlyUsage']")]
        internal readonly IWebElement? _hourlyUsage = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DailyRate']")]
        internal readonly IWebElement? _dailyRate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DailyUsage']")]
        internal readonly IWebElement? _dailyUsage = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='WeeklyRate']")]
        internal readonly IWebElement? _weeklyRate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='WeeklyUsage']")]
        internal readonly IWebElement? _weeklyUsage = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MonthlyRate']")]
        internal readonly IWebElement? _monthlyRate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MonthlyUsage']")]
        internal readonly IWebElement? _monthlyUsage = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab3']")]
        internal readonly IWebElement? _fixedlTab = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='FixedFrame']")]
        internal IWebElement? _fixedFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='FixedTable']")]
        internal IWebElement? _fixedTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewEffDt']")]
        internal readonly IWebElement? _newEffDate = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='FixedTable']//tbody//tr")]
        internal IList<IWebElement>? _fixedTableRows = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Disabled']")]
        internal readonly IWebElement? _billingState = null;
    }
}
