﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class ListOfValuesPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        internal string parentWindow;

        public ListOfValuesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }     

        [FindsBy(How = How.Id, Using = "searchBtn")]
        internal IWebElement? _buttonSearch =null;

        [FindsBy(How = How.Id, Using = "clrBtn")]
        internal IWebElement? _buttonClear =null;

        [FindsBy(How = How.Id, Using = "md0")]
        internal IWebElement? _firstInputBox =null;

        [FindsBy(How = How.XPath, Using = "//table[@id='lovBodyTable']/tbody/tr/td/span")]
        internal IWebElement? _firstListItem =null;
       
        [FindsBy(How = How.XPath, Using = "//input[@name='srchField']")]
        internal IWebElement? _serachField =null;

        [FindsBy(How = How.XPath, Using = "//table[@id='lovBodyTable']/tbody/tr[9]/td[1]/span")]
        internal IWebElement? _componentItem =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='wac']")]
        internal IWebElement? _selectwac =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='sys2']")]
        internal IWebElement? _sysCode =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='comp2']")]
        internal IWebElement? _componentCode =null;

        [FindsBy(How = How.XPath, Using = "//input[@value='OK']")]
        internal IWebElement? _okBtn =null;

        [FindsBy(How = How.XPath, Using = "//table[@id='lovBodyTable']/tbody/tr[2]/td[1]/span")]
        internal IWebElement? _codeList =null;

        [FindsBy(How = How.XPath, Using = "//select[@name='srchField']")]
        internal IWebElement? _selectsataus =null;

        [FindsBy(How = How.XPath, Using = "//input[@type='search']")]        
        internal IWebElement? _searchtext =null;

        [FindsBy(How = How.XPath, Using = "//table[@class='topspacer']")]
        internal IWebElement? _table =null;        

        [FindsBy(How = How.XPath, Using = "//div[@id='lovBodyTable_info']")]
        internal IWebElement? _searchCountText = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='wac']")]
        internal IWebElement? _selectWA = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='sys2']")]
        internal IWebElement? _selectSystem = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='comp2']")]
        internal IWebElement? _selectComponent = null;
    }
}
