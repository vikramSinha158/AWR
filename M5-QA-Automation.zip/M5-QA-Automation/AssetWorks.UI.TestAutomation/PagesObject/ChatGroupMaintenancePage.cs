﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class ChatGroupMaintenancePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal string _chatGroupName="chatGroup$new_";
        internal List<string> _chatGroups = new List<string>();
        internal IWebElement? _chatGroupElement = null;
        internal int _chatCountBeforeDeletion = 0;
        internal string _groupChatHeader = "Chat Group";
        internal string _groupChatId = "chatGroup";

        public ChatGroupMaintenancePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//table[@id='chatGroupTable']//tbody//tr")]
        internal IList<IWebElement>? _chatGroupRows = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ChatGroupMaintFrame']")]
        internal IWebElement? _chatGroupMaintFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='chatGroupTable']")]
        internal IWebElement? _chatGroupTable = null;
    }
}
