﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class MCCQueryPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal string _jobCodeHeader = "Job Code";
        internal string _mccComponentNoHeader = "Component No.";
        internal string _mccUnitNoHeader = "Unit No.";
        internal string _mccDepartmentNoHeader = "Department No.";

        public MCCQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='MCCKey']")]
        internal IWebElement? _mCCQueryKeynput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='JobDisplayFrame']")]
        internal IWebElement? _jobDisplayFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='jobdisplayTable']")]
        internal IWebElement? _jobdisplayTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='UnitsFrame']")]
        internal IWebElement? _unitFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='unitsTable']")]
        internal IWebElement? _unitsTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='componentsTable']")]
        internal IWebElement? _componentsTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ComponentsFrame']")]
        internal IWebElement? _componentsFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DepartmentsTable']")]
        internal IWebElement? _departmentsTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DepartmentsFrame']")]
        internal IWebElement? _departmentsFrame = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal IWebElement? _unitTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal IWebElement? _componentsTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab3']")]
        internal IWebElement? _departmentsTab = null;
    }
}
