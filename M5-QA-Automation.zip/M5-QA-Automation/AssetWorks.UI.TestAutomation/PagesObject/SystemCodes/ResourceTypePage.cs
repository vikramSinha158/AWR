﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class ResourceTypePage : BasePage
    {
        internal string Resource = "resource";
        internal string Description = "desc";
        internal string MarkUpScheme = "markup";
        internal string Disabled = "disable";        

        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public ResourceTypePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ResourceTypeFrame']")]
        internal readonly IWebElement? _resourceTypeFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ResourceTable']")]
        internal readonly IWebElement? _resourceTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='resource$new_0']")]
        internal readonly IWebElement? _resource = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='desc$new_0']")]
        internal readonly IWebElement? _desc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='markup$new_0']")]
        internal readonly IWebElement? _markUpScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='disabled$new_0']")]
        internal readonly IWebElement? _disabled = null;

    }
}
    