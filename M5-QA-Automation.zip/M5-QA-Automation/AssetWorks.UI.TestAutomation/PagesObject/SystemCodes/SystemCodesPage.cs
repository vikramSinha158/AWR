﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class SystemCodesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal SystemCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _sysCode { get; set; }

        public static string _sysDesc { get; set; }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='SysCodesFrame']")]
        internal IWebElement? _frameSystemCodes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='syscodesTable']/tbody")]
        internal IWebElement? _tableSystemCodes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='code$new_0']")]
        internal IWebElement? _inputNewCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _inputNewDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='xref_no$new_0']")]
        internal IWebElement? _inputNewCrossRef = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='part_charge$new_0']")]
        internal IWebElement? _inputNewPartCharge = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='priority$new_0']")]
        internal IWebElement? _inputNewPriority = null;
    }
}
