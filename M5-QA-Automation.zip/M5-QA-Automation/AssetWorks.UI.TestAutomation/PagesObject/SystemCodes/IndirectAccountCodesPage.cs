﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class IndirectAccountCodesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal IndirectAccountCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='IndKey']")]
        internal IWebElement? _inputAccountNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='IndDesc']")]
        internal IWebElement? _inputDescription = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Disabled']")]
        internal IWebElement? _selectDisabled = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='comm_fl']")]
        internal IWebElement? _checkboxCommercialChargesAllowed = null;
    }
}
