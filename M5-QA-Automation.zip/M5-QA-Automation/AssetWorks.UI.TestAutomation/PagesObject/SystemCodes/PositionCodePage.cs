﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class PositionCodePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal PositionCodePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PosCodesFrame']")]
        internal IWebElement? _framePositionCodes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PosCodesTable']/tbody")]
        internal IWebElement? _tablePositionCodes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='poscodes$new_0']")]
        internal IWebElement? _inputPositionCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _inputPositionCodeDesc = null;

    }
}
