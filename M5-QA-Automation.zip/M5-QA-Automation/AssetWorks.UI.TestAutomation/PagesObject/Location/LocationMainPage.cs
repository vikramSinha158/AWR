﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class LocationMainPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);       

        public LocationMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='genloc']")]
        internal readonly IWebElement? _genloc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='locdesc']")]
        internal readonly IWebElement? _locDesc = null;   

        [FindsBy(How = How.XPath, Using = "//select[@name='Disabled']")]
        internal readonly IWebElement? _disabledChk = null;
 
        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab0']")]
        internal IWebElement? _generalTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='state']")]
        internal readonly IWebElement? _state = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='country']")]
        internal readonly IWebElement? _country = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='timezone']")]
        internal readonly IWebElement? _timeZone = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal IWebElement? _configurationTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='fuellocfl']")]
        internal readonly IWebElement? _fuellocfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='deliverylocfl']")]
        internal readonly IWebElement? _deliverylocfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='parklocfl']")]
        internal readonly IWebElement? _parklocfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='motorpoolfl']")]
        internal readonly IWebElement? _motorpoolfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='replusagefactor']")]
        internal readonly IWebElement? _replusagefactor = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RES_DURATION']")]
        internal readonly IWebElement? _resDURATION = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal IWebElement? _hierarchyTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='deptno']")]
        internal readonly IWebElement? _deptNo = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab3']")]
        internal IWebElement? _InventoryTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='invlocfl']")]
        internal readonly IWebElement? _invlocfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='OverheadCost']")]
        internal readonly IWebElement? _overheadCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CarryingCost']")]
        internal readonly IWebElement? _carryingCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AutoReqApproval']")]
        internal readonly IWebElement? _autoReqApproval = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ReqApproval']")]
        internal readonly IWebElement? _reqApproval = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='SUPER_NO']")]
        internal readonly IWebElement? _supervisor = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab4']")]
        internal IWebElement? _MaintenanceTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='maintlocfl']")]
        internal readonly IWebElement? _maintlocfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='jobspanfl']")]
        internal readonly IWebElement? _jobspanfl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='includenote']")]
        internal readonly IWebElement? _includeNote = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='notifypm']")]
        internal readonly IWebElement? _notifyTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='dtstatus']")]
        internal readonly IWebElement? _downtimeStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='sendWONotifyFl']")]
        internal readonly IWebElement? _sendWONotify = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='sendJobAttachFl']")]
        internal readonly IWebElement? _sendJobAttach = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='TimeReporting']")]
        internal readonly IWebElement? _timeReporting = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='TimeRounding']")]
        internal readonly IWebElement? _timeRounding = null;

    }
}
