﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest
{
    internal class WorkRequestMainPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public WorkRequestMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@id='udcsel']")]
        internal IWebElement? _selectWRType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal IWebElement? _inputWRUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WrNo']")]
        internal IWebElement? _inputWorkRequestNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Occurance']")]
        internal IWebElement? _inputWROccurance = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newWr']")]
        internal IWebElement? _buttonNewWR = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JobCode']")]
        internal IWebElement? _inputWRJobCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JobCodeDesc']")]
        internal IWebElement? _inputWRJobCodeDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JobReason']")]
        internal IWebElement? _inputWRJobReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JobReasonDesc']")]
        internal IWebElement? _inputWRJobReasonDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PrefShift']")]
        internal IWebElement? _inputWRShift = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PrefShiftDesc']")]
        internal IWebElement? _inputWRShiftDesc = null;

        //General Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='ReportedBy']")]
        internal IWebElement? _inputWRReportedBy = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Contact']")]
        internal IWebElement? _inputWRContact = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Phone']")]
        internal IWebElement? _contactPhone = null;

        [FindsBy(How = How.Id, Using = "ReqRef")]
        internal IWebElement? _reqRef = null;

        [FindsBy(How = How.Id, Using = "DirAcct")]
        internal IWebElement? _dirAcct = null;

        [FindsBy(How = How.Id, Using = "MaintLoc")]
        internal IWebElement? _maintLoc = null;

        [FindsBy(How = How.Id, Using = "Notes")]
        internal IWebElement? _notes = null;

        [FindsBy(How = How.Id, Using = "correctNote")]
        internal IWebElement? _correctNote = null;

        [FindsBy(How = How.Id, Using = "EarlDate")]
        internal IWebElement? _earlDate = null;

        [FindsBy(How = How.Id, Using = "PreferDate")]
        internal IWebElement? _preferDate = null;

        [FindsBy(How = How.Id, Using = "LatestDate")]
        internal IWebElement? _latestDate = null;

        [FindsBy(How = How.Id, Using = "EmpCrew")]
        internal IWebElement? _employee = null;

        [FindsBy(How = How.Id, Using = "vendor_no")]
        internal IWebElement? _vendorNo = null;

        [FindsBy(How = How.Id, Using = "Source")]
        internal IWebElement? _source = null;

        [FindsBy(How = How.Id, Using = "Symptom")]
        internal IWebElement? _symptom = null;

        [FindsBy(How = How.Name, Using = "WRPartsFrame")]
        internal IWebElement? _wrPartsTableFrame = null;

        [FindsBy(How = How.Id, Using = "partsTable")]
        internal IWebElement? _wrPartsTable = null;

        internal string _partsNumberColHeader = "Part Number";
      
        internal string _partsNo = "PartNo";

        internal string _descriptionColHeadere = "Description";
        
        internal string _partsDesc = "pDesc";

        internal string _partsQuantityColHeadere = "Quantity";
        
        internal string _qty = "qty";

        internal string _unitInventoryColHeader = "Unit Inventory";
        
        internal string _unitInventory = "unitInventory";

        internal string _unitCostColHeader = "Unit Price";
        
        internal string _unitCost = "unitCost";

        internal string _totalQtyColHeader = "Total Qty";
        
        internal string _totalQty = "total";

        internal string _totalCostColHeader = "Total Cost";
        
        internal string _totalCost = "totalCost";
    }
}
