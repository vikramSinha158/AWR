﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest
{
    public class WorkRequestIncidentPage: BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public WorkRequestIncidentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "udcsel")]
        internal IWebElement? _selectWRType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal IWebElement? _inputWRUnitNo = null;

        [FindsBy(How = How.Id, Using = "cbNew")]
        internal IWebElement? _newIncidentBtn = null;

        [FindsBy(How = How.Id, Using = "IncidentNumber")]
        internal IWebElement? _incidentNo = null;

        [FindsBy(How = How.Id, Using = "Note")]
        internal IWebElement? _note = null;

        [FindsBy(How = How.Id, Using = "Status")]
        internal IWebElement? _status = null;

        [FindsBy(How = How.Id, Using = "failState")]
        internal IWebElement? _failState = null;

        [FindsBy(How = How.Id, Using = "ReportedBy")]
        internal IWebElement? _reportedBy = null;

        [FindsBy(How = How.Id, Using = "Phone")]
        internal IWebElement? _phone = null;

        [FindsBy(How = How.Id, Using = "Source")]
        internal IWebElement? _source = null;

        [FindsBy(How = How.Id, Using = "Symptom")]
        internal IWebElement? _symptom = null;

        [FindsBy(How = How.Id, Using = "Priority")]
        internal IWebElement? _priority = null;

        [FindsBy(How = How.Id, Using = "Zone")]
        internal IWebElement? _zone = null;

        [FindsBy(How = How.Id, Using = "Component")]
        internal IWebElement? _compoment = null;

        [FindsBy(How = How.Id, Using = "Condition")]
        internal IWebElement? _condition = null;

        [FindsBy(How = How.Id, Using = "Run")]
        internal IWebElement? _run = null;

        [FindsBy(How = How.Id, Using = "Block")]
        internal IWebElement? _block = null;

        [FindsBy(How = How.Id, Using = "ServiceDate")]
        internal IWebElement? _serviceDate = null;

        [FindsBy(How = How.Id, Using = "Parkloc")]
        internal IWebElement? _parkingLoction = null;

        [FindsBy(How = How.Id, Using = "MaintLoc")]
        internal IWebElement? _mainLocation = null;

        [FindsBy(How = How.Id, Using = "DateTime")]
        internal IWebElement? _openDateTime = null;

        [FindsBy(How = How.Id, Using = "StatusChange")]
        internal IWebElement? _lastStatusChange = null;

        [FindsBy(How = How.Id, Using = "IncStatusChange")]
        internal IWebElement? _lastIncidentStatusChange = null;

        [FindsBy(How = How.Id, Using = "wrtextno")]
        internal IWebElement? _wrTextNo = null;

        internal IWebElement? _dailogText(string campaignNo) => Driver.FindElement(By.XPath($"//p[text()='Campaign Number {campaignNo} does not exist?']"));
    }
}
