﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartInventoryPage : BasePage
    {
        public PartInventoryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal IWebElement? _inputPartNumber = null;     

        [FindsBy(How = How.XPath, Using = "//select[@id='snc']")]
        internal IWebElement? _stockType = null;
        
        [FindsBy(How = How.XPath, Using = "//select[@id='sStatus']")]
        internal IWebElement? _reorderAllowed = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='PIssDept']")]
        internal IWebElement? _issueToDepartment = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='PIssAcct']")]
        internal IWebElement? _issueToAccount = null;

        
        [FindsBy(How = How.XPath, Using = "//input[@name='CoreDo']")]
        internal IWebElement? _coreCharge= null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ChgCode']")]
        internal IWebElement? _chargeCode = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='core_fl']")]
        internal IWebElement? _coreTracking = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Unit_Do']")]
        internal IWebElement? _standard = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='primaryLoc']")]
        internal IWebElement? _binPrimaryLoc = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='vendPartNo']")]
        internal IWebElement? _vendorPartNo = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='maxinvlevel1']")]
        internal IWebElement? _maxInvQty = null;
       
        [FindsBy(How = How.XPath, Using = "//input[@name='mininvlevel1']")]
        internal IWebElement? _minInvQty = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MarkupScheme']")]
        internal IWebElement? _markupScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='COST_CAT_CODE']")]
        internal IWebElement? _costCategory = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='QtyOnHand']")]
        internal IWebElement? _QtyOnHand = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='onHandQty']")]
        internal IWebElement? _onHandQuantity = null;
    }
}
