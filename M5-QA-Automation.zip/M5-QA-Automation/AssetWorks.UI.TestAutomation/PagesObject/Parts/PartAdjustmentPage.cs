﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartAdjustmentPage:BasePage
    {
        public PartAdjustmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal IWebElement? _inputPartNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Reason']")]
        internal IWebElement? _ReasonCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EmpNo']")]
        internal IWebElement? _EmployeeNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AdjQtyOnHand']")]
        internal IWebElement? _AdjustmentQty = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='AdjPrice']")]
        internal IWebElement? _AdjustmentPrice = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='Notes']")]
        internal IWebElement? _Notes = null;
      
        [FindsBy(How = How.XPath, Using = "//input[@name='QtyOnHand']")]
        internal IWebElement? _QtyOnHand = null;
    }
}
