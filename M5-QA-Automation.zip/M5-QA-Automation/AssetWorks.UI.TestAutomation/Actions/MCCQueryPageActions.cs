﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class MCCQueryPageActions : MCCQueryPage
    {
        public MCCQueryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify MCC Query
        /// </summary>
        /// <param name="MCCKey"></param>
        /// <param name="JobCode"></param>
        /// <param name="UnitNo"></param>
        /// <param name="ComponentNo"></param>
        /// <param name="Department"></param>
        public void VerifyMCCQuery(string MCCKey, string JobCode, string UnitNo, String ComponentNo, string Department)
        {
            _extendpage.SwitchToContentFrame();
            _mCCQueryKeynput.SetText(MCCKey, "MCCKey for MCCQuery ");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_jobDisplayFrame, "jobDisplayFrame");
            _extendpage.VerifyTableColumnContainValue(_jobdisplayTable, _jobCodeHeader, JobCode);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _unitTab.ClickElement("Unit No", Driver);
            Driver.SwitchToFrame(_unitFrame, "unitFrame");
            _extendpage.VerifyTableColumnContainValue(_unitsTable, _mccUnitNoHeader, UnitNo);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _componentsTab.ClickElement("componentsTab", Driver);
            Driver.SwitchToFrame(_componentsFrame, "componentsFrame");
            _extendpage.VerifyTableColumnContainValue(_componentsTable, _mccComponentNoHeader, ComponentNo);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _departmentsTab.ClickElement("Department", Driver);
            Driver.SwitchToFrame(_departmentsFrame, "departmentsFrame");
            _extendpage.VerifyTableColumnContainValue(_departmentsTable, _mccDepartmentNoHeader, Department);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified MCC Query");
        }

    }
}
