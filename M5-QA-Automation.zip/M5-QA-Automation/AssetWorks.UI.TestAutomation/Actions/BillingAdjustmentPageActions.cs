﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingAdjustmentPageActions : BillingAdjustmentPage
    {
        public BillingAdjustmentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Billing Adjustment
        /// </summary>
        /// <param name="DataObject"></param>
        public void AddAndUpdateBillingAdjustment(BillingAdjustment DataObject)
        {
            Settings.Logger.Info(" Creating Billing Adjustment ");
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            _unitdeptInput.SetText(DataObject.UnitDeptNo, " UnitDeptNo ");
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_billItemInput, DataObject.BillItem, DataObject.BillItemLOV);
            FillBillingAdjustmentItems(DataObject);
        }

        /// <summary>
        /// Fill AdjustmentI temsn1
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillBillingAdjustmentItems(BillingAdjustment DataObject)
        {
            Settings.Logger.Info(" Adding  Billing Adjustment Items ");
            Driver.SwitchToFrame(_billUnitAdjFrame, "compItemFrame");
            if (DataObject.AdjustmentItems.CheckBillingAdjustmentTable &&_billUnitAdjTableRows.Count > 1) { _extendpage.DeleteTableRowsUsingColumnName(_billUnitAdjTable, _descriptionHeaderName, _desctd, _billUnitAdjFrame);}
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName,"", _desctd).SetText(DataObject.AdjustmentItems.Description, "Description");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _amountd).SetText(DataObject.AdjustmentItems.Amount, "Amount");
            Driver.WaitForReady();
            IWebElement TotalpdsId =_extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _totalpdsId);
            _extendpage.SelectAllAndClearField(TotalpdsId);
            TotalpdsId.SetText(DataObject.AdjustmentItems.TotalPeriods, "TotalPeriods");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _firstpdId).SetText(DataObject.AdjustmentItems.FirstPeriod, "FirstPeriod");
            Driver.WaitForReady();
            IWebElement Location = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _locationId);
            Driver.WaitForReady();
            _extendpage.SelectAllAndClearField(Location);
            Driver.WaitForReady();
            Location.SetText(DataObject.AdjustmentItems.Location, "locationId");
            Driver.WaitForReady();
            if(DataObject.AdjustmentItems.Department!=null) _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _departmentId).SetText(DataObject.AdjustmentItems.Department, "Department");
            Driver.WaitForReady();
            IWebElement ExpUsing= _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _expId);
            _lov.SearchAndSelectLOVData(ExpUsing, DataObject.AdjustmentItems.ExpUsing);
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_billUnitAdjFrame, "compItemFrame");
            IWebElement RevOwning = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _revId);
            _lov.SearchAndSelectLOVData(RevOwning,DataObject.AdjustmentItems.RevOwning);
            _extendpage.ClicKSave();
        }

        /// <summary>
        /// VerifyBillingAdjustment
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBillingAdjustment(BillingAdjustment DataObject)
        {
            Settings.Logger.Info(" Verifying Billing Adjustment Fields  ");
            _extendpage.RefreshAndSetText(_unitdeptInput, DataObject.UnitDeptNo, " UnitDeptNo ");
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_billItemInput, DataObject.BillItem,false);
            CommonUtil.VerifyElementValue(_unitdeptInput, "UnitdeptInput", DataObject.UnitDeptNo, false, "value");
            CommonUtil.VerifyElementValue(_billItemInput, "BillItemInput", DataObject.BillItem, false, "value");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_billUnitAdjFrame, "compItemFrame");
            IWebElement Desc = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _desctd);
            CommonUtil.VerifyElementValue(Desc, "Description", DataObject.AdjustmentItems.Description,false, "value");
            IWebElement Aamount = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _amountd);
            CommonUtil.VerifyElementValue(Aamount, "Amount", DataObject.AdjustmentItems.Amount, false, "value");
            IWebElement TotalpdsId = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _totalpdsId);
            CommonUtil.VerifyElementValue(TotalpdsId, "Total Period", DataObject.AdjustmentItems.TotalPeriods, false, "value");
            IWebElement TotalAmount = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _totalamtId);
            CommonUtil.VerifyElementValue(TotalAmount, "Total Amount ", DataObject.AdjustmentItems.TotalAmount, false, "value");
            IWebElement Firstpd = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _firstpdId);
            CommonUtil.VerifyElementValue(Firstpd, "FirstPeriod", DataObject.AdjustmentItems.FirstPeriod, false, "value");
            IWebElement Location = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _locationId);
            CommonUtil.VerifyElementValue(Location, "Location", DataObject.AdjustmentItems.Location, false, "value");
            IWebElement ExpUsing = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _expId);
            CommonUtil.VerifyElementValue(ExpUsing, "ExpUsing", DataObject.AdjustmentItems.ExpUsing, false, "value");
            IWebElement RevOwning = _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _revId);
            CommonUtil.VerifyElementValue(RevOwning, "RevOwning", DataObject.AdjustmentItems.RevOwning, false, "value");
            Settings.Logger.Info(" Successfully Verified Billing Adjustment Items");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary> 
        /// Verify Billing Adjustment Deletion
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBillingAdjustmentDeletion(BillingAdjustment DataObject)
        {
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_billUnitAdjTable, _descriptionHeaderName, DataObject.AdjustmentItems.Description, _desctd).Click();
            _extendpage.DeleteAndVerifySingleTableRowDeletion(_unitdeptInput, DataObject.UnitDeptNo, _billUnitAdjFrame, _billUnitAdjTableRows);
            Settings.Logger.Info(" Successfully Verified deletion Billing Adjustment Item");
        }

        /// <summary>
        /// Delete Billing Adjustmen tTable
        /// </summary>
        /// <param name="UnitdeptNo"></param>
        public void DeleteBillingAdjustmentTable(string UnitdeptNo)
        {
            _extendpage.RefreshAndSetText(_unitdeptInput, UnitdeptNo, " UnitDeptNo ");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_billUnitAdjFrame, "compItemFrame");
            _extendpage.DeleteTableRowsUsingColumnName(_billUnitAdjTable, _descriptionHeaderName, _desctd, _billUnitAdjFrame);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Deleted Billing Adjustment Fields  ");
        }

        /// <summary>
        /// Verify Delete Billing AdjustmentTable
        /// </summary>
        /// <param name="UnitdeptNo"></param>
        public void VerifyDeleteBillingAdjustmentTable(string UnitdeptNo)
        {
            _extendpage.RefreshAndSetText(_unitdeptInput, UnitdeptNo, " UnitDeptNo ");
            Driver.WaitForReady();
            _extendpage.VerifyTableRowDeletion(_billUnitAdjFrame, _billUnitAdjTableRows, "BillUnitAdjTableRows");
        }
    }
}
