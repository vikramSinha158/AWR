﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ComponentCopyActions : ComponentCopyPage
    {
        public ComponentCopyActions(IWebDriver Driver) : base(Driver) { }


        /// <summary>
        /// Copy Existing Component
        /// </summary>
        /// <param name="ExistingComponentName"></param>
        /// <param name="NoOFCopies"></param>
        /// <param name="CreateType"></param>
        /// <returns></returns>
        public string CopyExistingComponent(string ExistingComponentName,string NoOFCopies,bool IsCreateTypeSave=true)
        {
            string NewComponentNo=String.Empty;
            _extendpage.SwitchToContentFrame();
            Settings.Logger.Info(" Copy Existing Component ");
            _existingComponentInput.SetText(ExistingComponentName, "Old Component");
            Driver.WaitForReady();
            _noOfCopiesInput.SetText(NoOFCopies, "No Of Coponent Copies ");
            if (IsCreateTypeSave)
            {
                Driver.WaitForReady();
                _newCompNoInput.SetText(CommonUtil.GetRandomStringWithSpecialChars(6), "No Of Coponent Copies ");
                _extendpage.Save();
                _extendpage.SwitchToContentFrame();
            }
            else
            {
                Driver.WaitForReady();
                _newCompNoInput.SendKeys(Keys.Tab);
                _addNewComponent.ClickElement("New Component ", Driver);
            }
            Driver.WaitForReady();
            NewComponentNo = new ComponentMainPageActions(Driver).GetComponentNumber();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($" New  Component { NewComponentNo}");
            return NewComponentNo;
        }
    }
}
