﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MarkUp;
using NUnit.Framework;
using OpenQA.Selenium;
using System;


namespace AssetWorks.UI.M5.TestAutomation.Actions.MarkUp
    {
    internal class MarkUpSchemePageActions : MarkUpSchemeMainPage    {

        public MarkUpSchemePageActions(IWebDriver Driver) : base(Driver) { }       

        /// <summary>
        /// Create New MarkUp Scheme 
        /// </summary>
        /// <param name="Datakey"></param>       
        public string CreateMarkUpScheme(string DataObjectKey)
        {
            Settings.Logger.Info(" Create MarkUp Scheme");
            CreateMarkUpScheme createMarupObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CreateMarkUpScheme>();
            EnterSchemeId(createMarupObjectValues.Scheme);
            if (createMarupObjectValues.FilltMarkUpMainData.ToLower()=="yes")
            {
                FillSchemeMainInfo(createMarupObjectValues);
            }
            if (createMarupObjectValues.FillPartMarkUp.ToLower() == "yes")
            {                
                FillPartData(createMarupObjectValues);
            }
            if (createMarupObjectValues.FIllLaborMarkUp.ToLower() == "yes")
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _extendPage.GetTabLinkByText("Labor Markup/Rate").ClickElement("Labor Markup/Rate Tab", Driver);
                FillLaborData(createMarupObjectValues); 
            }
            if (createMarupObjectValues.FIllCommercialMarkUp.ToLower() == "yes")
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _extendPage.GetTabLinkByText("Commercial Markup").ClickElement("Commercial Markup Tab", Driver);
                FillCommercialData(createMarupObjectValues);
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();
            _extendPage.ClickOnRefreshButton();
            return MarkUpSchemeID;

        }

        /// <summary>
        /// Enter Scheme ID
        /// </summary>
        /// <param name="schemeID"></param>
        /// <param name="NewScheme"></param>
        public void EnterSchemeId(string schemeID, bool NewScheme = true)
        {
            _extendPage.SwitchToContentFrame();
            Driver.WaitForReady();
            MarkUpSchemeID = schemeID == "random" ? CommonUtil.GetRandomStringWithSpecialChars(8) : schemeID;
            _inputScheme.SetText(MarkUpSchemeID, "MarkUP Scheme ID");
            Driver.WaitForReady();
            if (NewScheme)
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.ActionRequiredWindow("Create");
                _extendPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Fill MarkUpScheme Data -Desc,Diaable,EffectiveDate,Job Reason
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void FillSchemeMainInfo(CreateMarkUpScheme createMarupObjectValues)
        {
            _inputSchemeDesc.SetText(createMarupObjectValues.SchemeDesc, "Scheme Description");           
            _disableScheme.SelectFilterValueHavingEqualValue(createMarupObjectValues.DisableScheme);
            if (!string.IsNullOrEmpty(createMarupObjectValues.EffectiveDate))
            {
                EffectiveDate = createMarupObjectValues.EffectiveDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(createMarupObjectValues.EffectiveDate)).ToString("MM/dd/yyyy");
                _effectiveDate.SetText(EffectiveDate, "EffectiveDate");
            }
            _jobReason.SetText(createMarupObjectValues.JobReason, "Job Reason");
        }        

        /// <summary>
        /// Fill Part MarkUp Tab Data
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void FillPartData(CreateMarkUpScheme createMarupObjectValues)
        {
          
            Driver.SwitchToFrame(_markupPartFrame, "Part frame");
            for (int i = 0; i < createMarupObjectValues.PartMarkUp.Count; i++)
            {
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable,
               "Kind of Transaction", createMarupObjectValues.PartMarkUp[i].KindOfTransaction, "pmarkupPC").SetText(createMarupObjectValues.PartMarkUp[i].MarkUpPercent, "Markup Percent");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable,
             "Kind of Transaction", createMarupObjectValues.PartMarkUp[i].KindOfTransaction, "pLimit").SetText(createMarupObjectValues.PartMarkUp[i].MarkUpLimit, "Markup Limit");
            }   
        }

        /// <summary>
        /// Fill Labor MarkUpTab Data
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void FillLaborData(CreateMarkUpScheme createMarupObjectValues)
        {          
            Driver.SwitchToFrame(_markupLaborFrame, "Labor frame");
            for (int i = 0; i < createMarupObjectValues.LaborMarkUp.Count; i++)
            {
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable,
               "Kind of Transaction", createMarupObjectValues.LaborMarkUp[i].KindOfTransaction, "lmarkupPC").SetText(createMarupObjectValues.LaborMarkUp[i].MarkUpPercent, "Markup Percent");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable,
              "Kind of Transaction", createMarupObjectValues.LaborMarkUp[i].KindOfTransaction, "lLaborRate").SetText(createMarupObjectValues.LaborMarkUp[i].LaborRate, "Labor Rate");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable,
             "Kind of Transaction", createMarupObjectValues.LaborMarkUp[i].KindOfTransaction, "lLimit").SetText(createMarupObjectValues.LaborMarkUp[i].MarkUpLimit, "Markup Limit");
            }
        }

        /// <summary>
        /// Fill Commercial MarkUP Tab Data
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void FillCommercialData(CreateMarkUpScheme createMarupObjectValues)
        {           
            Driver.SwitchToFrame(_markupCommFrame, "Commercial frame");
            for (int i = 0; i < createMarupObjectValues.CommercialMarkUp.Count; i++)
            {
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable,
               "Kind of Transaction", createMarupObjectValues.CommercialMarkUp[i].KindOfTransaction, "cmarkupPC").SetText(createMarupObjectValues.CommercialMarkUp[i].MarkUpPercent, "Markup Percent");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable,
             "Kind of Transaction", createMarupObjectValues.CommercialMarkUp[i].KindOfTransaction, "cLimit").SetText(createMarupObjectValues.CommercialMarkUp[i].MarkUpLimit, "Markup Limit");

            }
        }

        /// <summary>
        /// Edit MarkUp Scheme
        /// </summary>
        /// <param name="SchemeID"></param>
        /// <param name="DataObjectKey"></param>
        public void EditMarkUpScheme(string SchemeID, string DataObjectKey)
        {
            Settings.Logger.Info(" Edit MarkUp Scheme Data");
            CreateMarkUpScheme createMarupObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CreateMarkUpScheme>();         
            EnterSchemeId(SchemeID, false);          
            if (createMarupObjectValues.FilltMarkUpMainData.ToLower() == "yes")
            {
                FillSchemeMainInfo(createMarupObjectValues);
            }            
            if (createMarupObjectValues.FillPartMarkUp.ToLower() == "yes")
            {
                Driver.WaitForReady();
                FillPartData(createMarupObjectValues);
            }
            if (createMarupObjectValues.FIllLaborMarkUp.ToLower() == "yes")
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _extendPage.GetTabLinkByText("Labor Markup/Rate").ClickElement("Labor Markup/Rate Tab", Driver);
                FillLaborData(createMarupObjectValues);
            }
            if (createMarupObjectValues.FIllCommercialMarkUp.ToLower() == "yes")
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _extendPage.GetTabLinkByText("Commercial Markup").ClickElement("Commercial Markup Tab", Driver);
                FillCommercialData(createMarupObjectValues);
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();
            _extendPage.ClickOnRefreshButton();
        }

        /// <summary>
        /// Verify MarkUp Scheme Data
        /// </summary>
        /// <param name="schemeID"></param>
        /// <param name="DataObjectKey"></param>
        public void VerifyMarkupScheme(string schemeID,string DataObjectKey, string NewSchemeDesc = "false")
        {
            Settings.Logger.Info(" Verify MarkUp Scheme Data");
            CreateMarkUpScheme createMarupObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CreateMarkUpScheme>();           
            EnterSchemeId(schemeID,false);          
            if (createMarupObjectValues.FilltMarkUpMainData.ToLower() == "yes")
            {
                Driver.WaitForReady();
                VerifyMarkUpMainInfo(createMarupObjectValues, NewSchemeDesc);
            }
            if (createMarupObjectValues.FillPartMarkUp.ToLower() == "yes")
            {
                Driver.WaitForReady();
                VerifyPartMarkUp(createMarupObjectValues);
            }
            if (createMarupObjectValues.FIllLaborMarkUp.ToLower() == "yes")
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _extendPage.GetTabLinkByText("Labor Markup/Rate").ClickElement("Labor Markup/Rate Tab", Driver);
                VerifyLaborMarkUp(createMarupObjectValues);
            }
            if (createMarupObjectValues.FIllCommercialMarkUp.ToLower() == "yes")
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _extendPage.GetTabLinkByText("Commercial Markup").ClickElement("Commercial Markup Tab", Driver);
                VerifyCommercialMarkUp(createMarupObjectValues);
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnRefreshButton();
            Driver.WaitForReady();

        }

        /// <summary>
        /// Verify MarkUpScheme Data -Desc,Diaable,EffectiveDate,Job Reason
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void VerifyMarkUpMainInfo(CreateMarkUpScheme createMarupObjectValues, string NewSchemeDesc)
        {
            if (NewSchemeDesc == "false")
            {
                CommonUtil.VerifyElementValue(_inputSchemeDesc, "Scheme Description", createMarupObjectValues.SchemeDesc);
            }    
            else
            {
                CommonUtil.VerifyElementValue(_inputSchemeDesc, "Scheme Description", NewSchemeDesc);
            }
            CommonUtil.VerifyElementValue(_disableScheme, "Disable Full Tax Scheme", createMarupObjectValues.DisableScheme, true);
            CommonUtil.VerifyElementValue(_effectiveDate, "Effective Date", EffectiveDate);
            CommonUtil.VerifyElementValue(_jobReason, "Effective Date", createMarupObjectValues.JobReason);
        }

        /// <summary>
        /// Verify Part MarkUp Tab Data
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void VerifyPartMarkUp(CreateMarkUpScheme createMarupObjectValues)
        {
            Driver.SwitchToFrame(_markupPartFrame, "Part frame");
            for (int i = 0; i < createMarupObjectValues.PartMarkUp.Count; i++)
            {
               string PartMarkupPercent= _extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable,  "Kind of Transaction", createMarupObjectValues.PartMarkUp[i].KindOfTransaction, "pmarkupPC").GetAttribute("value");
                CommonUtil.AssertTrue<string>(createMarupObjectValues.PartMarkUp[i].MarkUpPercent, PartMarkupPercent);
                string PartMarkupLimit=_extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable,  "Kind of Transaction", createMarupObjectValues.PartMarkUp[i].KindOfTransaction, "pLimit").GetAttribute("value");
                CommonUtil.AssertTrue<string>(createMarupObjectValues.PartMarkUp[i].MarkUpLimit, PartMarkupLimit);
            }
        }

        /// <summary>
        ///  Verify Labor MarkUp Tab Data
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void VerifyLaborMarkUp(CreateMarkUpScheme createMarupObjectValues)
        {
            Driver.SwitchToFrame(_markupLaborFrame, "Labor frame");
            for (int i = 0; i < createMarupObjectValues.LaborMarkUp.Count; i++)
            {
                string LaborMarkupPercent = _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, "Kind of Transaction", createMarupObjectValues.LaborMarkUp[i].KindOfTransaction, "lmarkupPC").GetAttribute("value");
                CommonUtil.AssertTrue<string>(createMarupObjectValues.LaborMarkUp[i].MarkUpPercent, LaborMarkupPercent);
                string LaborRate = _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, "Kind of Transaction", createMarupObjectValues.LaborMarkUp[i].KindOfTransaction, "lLaborRate").GetAttribute("value");
                CommonUtil.AssertTrue<string>(createMarupObjectValues.LaborMarkUp[i].LaborRate, LaborRate);
                string LaborMarkupLimit = _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, "Kind of Transaction", createMarupObjectValues.LaborMarkUp[i].KindOfTransaction, "lLimit").GetAttribute("value");
                CommonUtil.AssertTrue<string>(createMarupObjectValues.LaborMarkUp[i].MarkUpLimit, LaborMarkupLimit);
            }
        }

        /// <summary>
        /// Verify Commercial MarkUP Tab Data
        /// </summary>
        /// <param name="createMarupObjectValues"></param>
        public void VerifyCommercialMarkUp(CreateMarkUpScheme createMarupObjectValues)
        {
            Driver.SwitchToFrame(_markupCommFrame, "Commercial frame");
            for (int i = 0; i < createMarupObjectValues.CommercialMarkUp.Count; i++)
            {
                string CommMarkupPercent = _extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable, "Kind of Transaction", createMarupObjectValues.CommercialMarkUp[i].KindOfTransaction, "cmarkupPC").GetAttribute("value");
                CommonUtil.AssertTrue<string>(createMarupObjectValues.CommercialMarkUp[i].MarkUpPercent, CommMarkupPercent);
                string CommMarkupLimit = _extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable ,"Kind of Transaction", createMarupObjectValues.CommercialMarkUp[i].KindOfTransaction, "cLimit").GetAttribute("value");
                CommonUtil.AssertTrue<string>(createMarupObjectValues.CommercialMarkUp[i].MarkUpLimit, CommMarkupLimit);
            }
        }

        /// <summary>
        /// Delete MarkUp scheme       
        /// </summary>
        /// <param name="SchemeID"></param>
        public void DeleteMarkUpScheme(string SchemeID)
        {
            Settings.Logger.Info(" Delete MarkUp Scheme ");            
            _extendPage.SwitchToContentFrame();
            _inputScheme.SetText(SchemeID, "MarkUp Scheme ID");
            Driver.WaitForReady();
            _inputScheme.ClickElement("Scheme ID",Driver);   
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnDeleteButton();
            _extendPage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify MarkUp Scheme Deletion
        /// </summary>
        /// <param name="SchemeID"></param>
        public void VerifyMarkUpSchemeDeletion(string SchemeID)
        {
            Settings.Logger.Info(" Verify MarkUp Scheme Deletion");
            _extendPage.RefreshAndSetText(_inputScheme, SchemeID, "MarkUp scheme ID");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Assert.IsTrue(_extendPage._createDialog.VerifyElementDisplay(" Action Required Dialog "));
            _extendPage.ActionRequiredWindow("Cancel");
            Settings.Logger.Info("  Verified MarkUp Scheme Deletion");
        }

        public string CopyMarkUpScheme(string existingScheme, string DataobjectKey)
        {
            CopyMarkUpScheme copyMarupObjectValues = CommonUtil.DataObjectForKey(DataobjectKey).ToObject<CopyMarkUpScheme>();
            _extendPage.SwitchToContentFrame();
            _inputScheme.SetText(existingScheme, "");
             Driver.WaitForReady();
            _copyAllDate.SelectCheckBox("CheckBox Copy All date", copyMarupObjectValues.CopyAllDate);
            if (!string.IsNullOrEmpty(copyMarupObjectValues.EffectiveDate))
            {
                EffectiveDate = copyMarupObjectValues.EffectiveDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(copyMarupObjectValues.EffectiveDate)).ToString("MM/dd/yyyy");
                _effectiveDate.SetText(EffectiveDate, "EffectiveDate");
            }
            _copyAllReason.SelectCheckBox("CheckBox Copy All Reason", copyMarupObjectValues.CopyAllReasons);
            _jobReason.SetText(copyMarupObjectValues.JobReason, "Job Reason");
            NewSchemeID = copyMarupObjectValues.NewScheme == "random" ? CommonUtil.GetRandomStringWithSpecialChars(8) : copyMarupObjectValues.NewScheme;
            _newScheme.SetText(NewSchemeID, "New Scheme ID");
             Driver.WaitForReady();
            _newSchemeDesc.SetText(copyMarupObjectValues.NewSchemeDesc, "New Scheme Description");
            Driver.WaitForReady();
            _newReason.SetText(copyMarupObjectValues.NewJobReason, "New Job Reason");
            _newDate.SelectCheckBox("", copyMarupObjectValues.NewDate);
            if (!string.IsNullOrEmpty(copyMarupObjectValues.NewEffectiveDate))
            {
                NewEffectiveDate = copyMarupObjectValues.NewEffectiveDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(copyMarupObjectValues.NewEffectiveDate)).ToString("MM/dd/yyyy");
                _newEffDate.SetText(NewEffectiveDate, "New Effective Date");
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();
            _extendPage.ClickOnRefreshButton();
            return NewSchemeID;
        }

    }
    }   
