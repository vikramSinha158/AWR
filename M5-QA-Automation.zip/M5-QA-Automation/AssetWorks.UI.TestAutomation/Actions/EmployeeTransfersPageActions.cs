﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using System.Threading.Tasks;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Common;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmployeeTransfersPageActions : EmployeeTransfersPage
    {
        public EmployeeTransfersPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Set Supervisor Information
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void SetSupervisorInformation(string ObjectKey)
        {
            DataObject = null;
             DataObject = CommonUtil.DataObjectForKey(ObjectKey).ToObject<EmployeeTransfer>();
            _extendpage.SwitchToContentFrame();
            _inputSupervisor1.SetText(DataObject.SupervisorInformation.Supervisor1, "Supervisor1");
             Driver.WaitForReady();
            _inputSupervisor2.SetText(DataObject.SupervisorInformation.Supervisor2, "Supervisor2");
        }

        /// <summary>
        /// Verify Retrieve Employees Dispaly
        /// </summary>
        public void VerifyRetrieveEmployeesDispaly()
        {
            Driver.SwitchToFrame(_empFrame, "Group List Frame");
           _choice1Left.ClickElement("List", Driver);
            List<string> ExpectedChoice1Left = DataObject.SupervisorInformation.Supervisor1EmpID;
            _extendpage.VerifyGroupListItem(_choice1Left, ExpectedChoice1Left);
            List<string> Expectedhoice1Right = DataObject.SupervisorInformation.Supervisor2EmpID;
            _extendpage.VerifyGroupListItem(_choice1Right, Expectedhoice1Right);
            Settings.Logger.Info(" Successfully Verified Retrieve Employees assigned to First and Second Supervisors");
        }

        /// <summary>
        /// Transfer All Employees From Left To Right
        /// </summary>
        public void TransferAllEmployeesFromLeftToRight()
        {
            _rightEmployeeCount = 0;
            _leftEmployeeCount = 0;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _leftEmployeeCount = _extendpage.SelectAllGroupList(_empFrame, _choice1Left, _choice1MoveRight, _choice1Right, ref _rightEmployeeCount);
            _rightEmployeeCount = _rightEmployeeCount + _leftEmployeeCount;
            _extendpage.Save();
            Settings.Logger.Info(" Transfer All Employees from First Supervisors to Second Supervisors");
        }

        /// <summary>
        /// Verify Employees Tranfer Left To Right
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public List<string> VerifyEmployeesTranferLeftToRight(string ObjectKey)
        {
            SetSupervisorInformation(ObjectKey);
            //Verifying Right Column Employee COunt After Transfer
            _extendpage.verifyGroupListCount(_empFrame, _choice1Right, _rightEmployeeCount);
            int ActualLeftListCount = _choice1Left.GetDropdownListTotalCount();
            //Verifying Left Column Employee empty
            CommonUtil.AssertTrue<int>(0, ActualLeftListCount);
            _extendpage.ClickRefresh();
            Settings.Logger.Info(" Successfully Verified Employees Tranfer First Supervisor To Second Supervisor");
            return DataObject.SupervisorInformation.Supervisor1EmpID;
           
        }

        /// <summary>
        /// Reset First Supervisor Employee
        /// </summary>
        public void ResetFirstSupervisorEmployee()
        {
            TransferSupervisorEmployeeList(_choice1Right, _choice1MoveLeft, DataObject.SupervisorInformation.Supervisor1EmpID);
            Settings.Logger.Info(" Reset the First Supervisor Employee after Transfer ");
        }

        /// <summary>
        /// Transfer All Employees From Right To Left
        /// </summary>
        public void TransferAllEmployeesFromRightToLeft()
        {
            _rightEmployeeCount = 0;
            _leftEmployeeCount = 0;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _rightEmployeeCount = _extendpage.SelectAllGroupList(_empFrame, _choice1Right, _choice1MoveLeft, _choice1Left, ref _leftEmployeeCount);
            _leftEmployeeCount = _rightEmployeeCount + _leftEmployeeCount;
            _extendpage.Save();
            Settings.Logger.Info(" Transfer All Employees from second  Supervisors to first Supervisors");
        }

        /// <summary>
        /// Verify Employees Transfer Right To Left
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public List<string> VerifyEmployeesTransferRightToLeft(string ObjectKey)
        {
            SetSupervisorInformation(ObjectKey);
            //Verifying Left Column Employee COunt After Transfer
            _extendpage.verifyGroupListCount(_empFrame, _choice1Left, _leftEmployeeCount);
            int ActualLeftListCount = _choice1Right.GetDropdownListTotalCount();
            //Verifying Right Column Employee empty
            CommonUtil.AssertTrue<int>(0, ActualLeftListCount);
            _extendpage.ClickRefresh();
            Settings.Logger.Info(" Successfully Verified Employees Tranfer Second Supervisor To First Supervisor");
            return DataObject.SupervisorInformation.Supervisor2EmpID;
        }

        /// <summary>
        /// Reset Second Supervisor Employee
        /// </summary>
        public void ResetSecondSupervisorEmployee()
        {
            TransferSupervisorEmployeeList(_choice1Left, _choice1MoveRight, DataObject.SupervisorInformation.Supervisor2EmpID);
            Settings.Logger.Info(" Reset the Second Supervisor Employee after Transfer ");
        }

        /// <summary>
        /// Tranfer One Employee Fromr Left To Right
        /// </summary>
        public void TranferOneEmployeeFromrLeftToRight()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            TransferSupervisorEmployeeList(_choice1Left, _choice1MoveRight, DataObject.SupervisorInformation.Supervisor1OneEmpID);
            Settings.Logger.Info(" Tranfer One Employee Fromr first supervisor To second supervisor ");
        }

        /// <summary>
        /// Verify Tranfer One Employee Frome Left To Right
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public List<string> VerifyTranferOneEmployeeFromeLeftToRight(string ObjectKey)
        {
            VerifyOneEmployeeTRansfer(ObjectKey, _choice1Right, DataObject.SupervisorInformation.Supervisor1OneEmpID[0]);
            Settings.Logger.Info(" Successfully Verified Tranfer One Employee from first supervisor To second supervisor");
            return DataObject.SupervisorInformation.Supervisor1OneEmpID;          
        }

        /// <summary>
        /// Reset First Supervisor One Employee
        /// </summary>
        public void ResetFirstSupervisorOneEmployee()
        {
            TransferSupervisorEmployeeList(_choice1Right, _choice1MoveLeft, DataObject.SupervisorInformation.Supervisor1OneEmpID);
            Settings.Logger.Info(" Reset the First Supervisor Employee after one employe  Transfer ");
        }

        /// <summary>
        /// Tranfer One Employee Fromr Right To Left
        /// </summary>
        public void TranferOneEmployeeFromrRightToLeft()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            TransferSupervisorEmployeeList(_choice1Right, _choice1MoveLeft, DataObject.SupervisorInformation.Supervisor2OneEmpID);
            Settings.Logger.Info(" Tranfer One Employee Fromr second  supervisor To first supervisor ");
        }

        /// <summary>
        /// Verify Tranfer One Employee Frome Right To Left
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public List<string> VerifyTranferOneEmployeeFromeRightToLeft(string ObjectKey)
        {
            VerifyOneEmployeeTRansfer(ObjectKey, _choice1Left, DataObject.SupervisorInformation.Supervisor2OneEmpID[0]);
            Settings.Logger.Info(" Successfully Verified Tranfer One Employee from second supervisor To first supervisor");
            return DataObject.SupervisorInformation.Supervisor2OneEmpID;
        }

        /// <summary>
        /// Reset Second Supervisor One Employee
        /// </summary>
        public void ResetSecondSupervisorOneEmployee()
        {
            TransferSupervisorEmployeeList(_choice1Left, _choice1MoveRight, DataObject.SupervisorInformation.Supervisor2OneEmpID);
            Settings.Logger.Info(" Reset the second Supervisor Employee after one employeeTransfer ");
        }

        /// <summary>
        /// Transfer Supervisor Employee List
        /// </summary>
        /// <param name="EmployeeList"></param>
        /// <param name="MoveListElement"></param>
        /// <param name="ExpectedGroupList"></param>
        public void TransferSupervisorEmployeeList(IWebElement EmployeeList, IWebElement MoveListElement, List<string> ExpectedGroupList)
        {
            Driver.SwitchToFrame(_empFrame, "Group List Frame");
            EmployeeList.ClickElement("List", Driver);
            Driver.WaitForReady();
            _extendpage.SelectMultipleItemFromList(EmployeeList, MoveListElement, ExpectedGroupList);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
        }

        /// <summary>
        /// Verify One Employee TRansfer
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="EmployeeList"></param>
        /// <param name="EmployeeName"></param>
        public void VerifyOneEmployeeTRansfer(string ObjectKey, IWebElement EmployeeList,string EmployeeName)
        {
            SetSupervisorInformation(ObjectKey);
            Driver.SwitchToFrame(_empFrame, "Group List Frame");
            EmployeeList.ClickElement("List", Driver);
            CommonUtil.AssertTrue<bool>(true, EmployeeList.ClickDropDownValuebyContainingText(EmployeeName));
            _extendpage.ClickRefresh();
        }

        /// <summary>
        /// Tranfer One Employee Left To Right By Double Click
        /// </summary>
        public void TranferOneEmployeeLeftToRightByDoubleClick()
        {
            TranferOneEmployeeByDoubleClick(_choice1Left, DataObject.SupervisorInformation.Supervisor1OneEmpID[0]);
            Settings.Logger.Info(" Tranfer One Employee Fromr first supervisor To second supervisor By Double Click ");
        }

        /// <summary>
        /// Tranfer One Employee Right To Left By DoubleClick
        /// </summary>
        public void TranferOneEmployeeRightToLeftByDoubleClick()
        {
            TranferOneEmployeeByDoubleClick(_choice1Right, DataObject.SupervisorInformation.Supervisor2OneEmpID[0]);
            Settings.Logger.Info(" Tranfer One Employee Fromr first supervisor To second supervisor By Double Click ");
        }

        /// <summary>
        /// Tranfer One Employee By Double Click
        /// </summary>
        /// <param name="GroupList"></param>
        /// <param name="ClickText"></param>
        public void TranferOneEmployeeByDoubleClick(IWebElement GroupList, string ClickText)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_empFrame, "Group List Frame");
            _extendpage.SelectElementInListUsingDoubleClick(GroupList, ClickText);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
        }

        /// <summary>
        /// Check And Reset Supervisor List
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void CheckAndResetSupervisorList(string ObjectKey)
        {
            EmployeeTransfer? EmployeeListData = null;
            EmployeeListData = CommonUtil.DataObjectForKey(ObjectKey).ToObject<EmployeeTransfer>();
            Driver.SwitchToFrame(_empFrame, "Group List Frame");
            _choice1Left.ClickElement("List", Driver);
            Driver.WaitForReady();
            List<string> ActualListValues = _choice1Left.GetDropdownValueList();
            if (ActualListValues!=null)
            {
                if (!CommonUtil.CompareList<string>(EmployeeListData.SupervisorInformation.Supervisor1ActEmpID, ActualListValues))
                {
                    _choice1Left.SendKeys(Keys.Control + "a");
                    _choice1MoveRight.ClickElement("Move Element ", Driver);
                    _extendpage.Save();
                    _extendpage.SwitchToContentFrame();
                    TransferSupervisorEmployeeList(_choice1Right, _choice1MoveLeft, EmployeeListData.SupervisorInformation.Supervisor1ActEmpID);
                }
            }
            if (ActualListValues == null)
            {
                Driver.SwitchTo().DefaultContent();
                _extendpage.SwitchToContentFrame();
                TransferSupervisorEmployeeList(_choice1Right, _choice1MoveLeft, EmployeeListData.SupervisorInformation.Supervisor1ActEmpID);
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Settings.Logger.Info(" Checked and Reset supervisor  List ");
        }
    }
}
