﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.M5.TestAutomation.Common;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class StandardJobMCCActions : StandardJobMCCPage
    {
        public StandardJobMCCActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Standard Jobs MCC
        /// </summary>
        /// <param name="StandardJobMCCKey"></param>
        /// <returns></returns>
        public List<string> CreateStandardJobsMCC(string StandardJobMCCKey,string MCCCode)
        {
            Settings.Logger.Info(" Creating  standard Job MCC ");
            List<string> StandardMCCJobs = new List<string>();
            var DataObject = CommonUtil.DataObjectForKey(StandardJobMCCKey);
            _extendpage.SwitchToContentFrame();
            _mCCJOobCodeValue = CommonUtil.DataForKey(StandardJobMCCObjects.MCCJOobCode, DataObject).ToString().Trim();
            _standardJobNoInput.SetText(_mCCJOobCodeValue, "Standard Job No Input");
            Driver.WaitForReady();
            _standardMccNoInput.SetText(MCCCode, " MCC Code ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            _extendpage.SwitchToContentFrame();
            _recurringIntervalDaysValue = CommonUtil.DataForKey(StandardJobMCCObjects.RecurringIntervalDays, DataObject).ToString().Trim();
            _recurringIntervaTimelInput.SetText(_recurringIntervalDaysValue, "Recurring Interval");
            _earliestDateTimeInput.SetText(CommonUtil.GenerateRandomDateString(-1), "Earliest Date Time Input");
            if (DataObject != null)
            {
                FillForecasterTab(DataObject);
            }
            else { Assert.Fail("Json Objext found nul for Forecaster Tab data"); }
            FillOverrideLocation();
            _extendpage.VerifyCreatedActionNumber(_standardMccNoInput, MCCCode);
            StandardMCCJobs.Add(_mCCJOobCodeValue);
            StandardMCCJobs.Add(MCCCode);
            Settings.Logger.Info($" Cobinationn of standard Job MCC {StandardMCCJobs[0].ToString()} and {StandardMCCJobs[1].ToString()}");
            return StandardMCCJobs;
        }

        /// <summary>
        /// Fill Forecaster Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillForecasterTab(dynamic DataObject)
        {
            _forecasterTab.ClickElement("forecasterTa", Driver);
            _schedulingBasisValue = CommonUtil.DataForKey(StandardJobMCCObjects.SchedulingBasis, DataObject).ToString().Trim();
            _schedulingBasic.SelectFilterValueHavingEqualValue(_schedulingBasisValue);
            _recurringJobCheckBox.SelectCheckBox("Recurring Job CheckBox");
            _seasonalRestrictionValue = CommonUtil.DataForKey(StandardJobMCCObjects.SeasonalRestriction, DataObject).ToString().Trim();
            _seasonFlag.SelectFilterValueHavingEqualValue(_seasonalRestrictionValue);
            _locCode.SetText(Settings.Location, "Location code");
            _visitReasonValue = CommonUtil.DataForKey(StandardJobMCCObjects.VisitReason, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _visitReason.SetText(_visitReasonValue, "Visit Reason");
            _priorityValue = CommonUtil.DataForKey(StandardJobMCCObjects.Priority, DataObject).ToString();
            _priority.ClickDropDownValuebyContainingText(_priorityValue);
            _overduePriorityValue = CommonUtil.DataForKey(StandardJobMCCObjects.OverduePriority, DataObject).ToString();
            _overduePriority.ClickDropDownValuebyContainingText(_overduePriorityValue);
            _calibration.SelectCheckBox("Calibration");
        }

        /// <summary>
        /// Fill Override Location
        /// </summary>
        public void FillOverrideLocation()
        {
            ClickOnLocOverrideTab();
            Driver.SwitchToFrame(_standJobMccLocFramec, "stand Job Mcc Loc Framec");
            _maintenanceloc.SetText(Settings.Location,"Maintenance location ");          
            Driver.WaitForReady();
            Driver.DoubleClick(_overrideloc, " override location ");
            _lov.SelectCode();
        }

        /// <summary>
        /// VerifyStandardJobMCCInfo
        /// </summary>
        public void VerifyStandardJobMCCInfo()
        {
            Settings.Logger.Info(" Verifying  standard Job MCC ");
            _extendpage.RefreshAndSetText(_standardJobNoInput, _mCCJOobCodeValue, " standard Job No Input ");
            Driver.WaitForReady();
            _standardMccNoInput.SetText(StandardJobMCCObjects.StandardMCCCode, " MCC Code ");
            Driver.WaitForReady();
            string ActualrecurringIntervalValue = _recurringIntervaTimelInput.GetElementValueByAttribute("ovalue");          
            CommonUtil.AssertTrue<string>(_recurringIntervalDaysValue, ActualrecurringIntervalValue);
            _forecasterTab.ClickElement("forecasterTa", Driver);
            string ActualSchedulingBasicValue = _schedulingBasic.GetVisibleText();
            CommonUtil.AssertTrue<string>(_schedulingBasisValue, ActualSchedulingBasicValue);
            string ActualSeasonalRestrictionValue = _seasonFlag.GetVisibleText();
            CommonUtil.AssertTrue<string>(_seasonalRestrictionValue, ActualSeasonalRestrictionValue);
            string ActualLocationValue=_locCode.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(Settings.Location, ActualLocationValue);
            Driver.WaitForReady();
            string ActualvisitReasonValue=_visitReason.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(_visitReasonValue, ActualvisitReasonValue);
            string ActualPriorityValue = _priority.GetVisibleText();
            CommonUtil.AssertTrue<string>(_priorityValue.Trim(), ActualPriorityValue);
            string ActualOverduePriorityValue=_overduePriority.GetVisibleText(); ;
            CommonUtil.AssertTrue<string>(_overduePriorityValue.Trim(), ActualOverduePriorityValue);
            ClickOnLocOverrideTab();
            Driver.SwitchToFrame(_standJobMccLocFramec, "stand Job Mcc Loc Framec");
            Driver.WaitForReady();
            string ActualMaintLoc= _maintenancelocValue.GetElementValueByAttribute("value");
            CommonUtil.AssertTrue<string>(Settings.Location, ActualMaintLoc);
            Driver.WaitForReady();
            string ActualOverrideLocationValue= _overridelocValue.GetElementValueByAttribute("value");
            Assert.False(String.IsNullOrEmpty(ActualOverrideLocationValue), "Override location value Null");
            Settings.Logger.Info(" Successfully Verified standard Job MCC  Information");
        }

        /// <summary>
        /// Edit And Verify Standard JobMCCInfo
        /// </summary>
        /// <param name="EditStandardJobMCCKey"></param>
        public void EditAndVerifyStandardJobMCCInfo(string EditStandardJobMCCKey)
        {
            Settings.Logger.Info(" Editing  standard Job MCC ");
            var DataObject = CommonUtil.DataObjectForKey(EditStandardJobMCCKey);
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_standardJobNoInput, _mCCJOobCodeValue, " standard Job No Input ");
            Driver.WaitForReady();
            _standardMccNoInput.SetText(StandardJobMCCObjects.StandardMCCCode, " MCC Code ");
            Driver.WaitForReady();
            if (DataObject != null)
            {
                FillForecasterTab(DataObject);
            }
            else { Assert.Fail("Json Objext found nul for Forecaster Tab data"); }
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            VerifyStandardJobMCCInfo();
        }

        /// <summary>
        /// Click On Loc Override Tab
        /// </summary>
        public void ClickOnLocOverrideTab()
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _locationOverrideTab.ClickElement("location Override Tab", Driver);
        }
    }
}
