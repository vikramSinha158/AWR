﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingItemSourcePageActions : BillingItemSourcePage
    {
        public BillingItemSourcePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Billing Item Source
        /// </summary>
        /// <param name="DataObject"></param>
        public void AddBillingItemSource(BillingItemSourceDetail DataObject)
        {
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _billingCodeInput.SetText(DataObject.BillingCodeSource, "BillingCodeSource");
            Driver.SwitchToFrame(_billitemsourceFrame, "billitemsourceFrame");
            int RowNum = 0;
            foreach (BillingItemSource BillingItemSource in DataObject.BillingItemSource)
            {
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_billitemsourceTable, _headerBillItem, DataObject.BillingItemSourceList[RowNum], _deptbill).SelectFilterValueHavingEqualValue(BillingItemSource.DepartmentBill);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_billitemsourceTable, _headerBillItem, DataObject.BillingItemSourceList[RowNum], _rev).SelectFilterValueHavingEqualValue(BillingItemSource.RevenueAccountsSource);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_billitemsourceTable, _headerBillItem, DataObject.BillingItemSourceList[RowNum], _exp).SelectFilterValueHavingEqualValue(BillingItemSource.ExpenseAccountSource);
                RowNum++;
            }
            _extendpage.Save();
            Settings.Logger.Info(" Added Billing Item Source Detail ");
        }

        /// <summary>
        /// Verify Billing Item Source
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBillingItemSource(BillingItemSourceDetail DataObject)
        {
            RefreshAndMoveToBillingItemSource(DataObject.BillingCodeSource);
            int RowNum = 0;
            foreach (BillingItemSource BillingItemSource in DataObject.BillingItemSource)
            {
                Driver.WaitForReady();
                string ActualDeptbill= _extendpage.GetTableActionElementByRelatedColumnValue(_billitemsourceTable, _headerBillItem, DataObject.BillingItemSourceList[RowNum], _deptbill).GetVisibleText();
                CommonUtil.AssertTrue<string>(BillingItemSource.DepartmentBill, ActualDeptbill);
                string ActualRevenue=_extendpage.GetTableActionElementByRelatedColumnValue(_billitemsourceTable, _headerBillItem, DataObject.BillingItemSourceList[RowNum], _rev).GetVisibleText();
                CommonUtil.AssertTrue<string>(BillingItemSource.RevenueAccountsSource, ActualRevenue);
                string ActualExpense =_extendpage.GetTableActionElementByRelatedColumnValue(_billitemsourceTable, _headerBillItem, DataObject.BillingItemSourceList[RowNum], _exp).GetVisibleText();
                CommonUtil.AssertTrue<string>(BillingItemSource.ExpenseAccountSource, ActualExpense);
                RowNum++;
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Billing Item Source Detail ");
        }

        /// <summary>
        /// Refresh And Move To Billing Item Source
        /// </summary>
        /// <param name="BiilingCode"></param>
        private void RefreshAndMoveToBillingItemSource(string BiilingCode)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            _billingCodeInput.SetText(BiilingCode, "BillingCodeSource");
            Driver.SwitchToFrame(_billitemsourceFrame, "billitemsourceFrame");
            Settings.Logger.Info(" Refresh Billing Item Source  ");
        }
    }
}
