﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillSingleDepartmentAccountPageActions : BillSingleDepartmentAccountPage
    {
        public BillSingleDepartmentAccountPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Fill Department Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillDepartmentInformation(SingleDepartmentDetails DataObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _departmentNumber.SetText(DataObject.Department, "Department Number");
            Driver.WaitForReady();
            _expenseAccount.SetText(DataObject.ExpenseAccount, "Expense Account");
            Driver.WaitForReady();
            _extendedPage.SetTextWithLovOption(_revenueAccount, DataObject.RevenueAccount, DataObject.SingleDepartmentLOV);
            _extendedPage.Save();
            Settings.Logger.Info("Department Information Details Filled Successfully");
        }

        /// <summary>
        /// Verify Department Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDepartmentInformation(SingleDepartmentDetails DataObject)
        {
            _extendedPage.RefreshAndSetText(_departmentNumber, DataObject.Department, " Department Number");
            CommonUtil.VerifyElementValue(_departmentNumber, "Department Number", DataObject.Department);
            CommonUtil.VerifyElementValue(_expenseAccount, "Expense Account", DataObject.ExpenseAccount);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Department Information Details Verified Successfully");
        }

        /// <summary>
        /// Verify Single Department Account Deletion
        /// </summary>
        /// <param name="DepartmentNo"></param>
        public void VerifySingleDepartmentAccountDeletion(string DepartmentNo)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.VerifyCodeDeletion(_departmentNumber, DepartmentNo, "Department No");
        }
    }
}
