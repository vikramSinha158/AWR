﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.BasicUserFunctionality;

namespace AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality
{
    internal class MenuMaintenancePageActions : MenuMaintenancePage
    {
        public MenuMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Update Reauthenticate On Save
        /// </summary>
        /// <param name="settings"></param>
        public void UpdateReauthenticateOnSave(MenuMaintenanceSetting settings)
        {
            bool _checked = false;
            Settings.Logger.Info(" Update Reauthenticate On Save setting ");
            _extendedPage.SwitchToContentFrame();
            _inputSearchFilter.SetText(settings.FlagName, "search text");
            Driver.WaitForReady();
            if (settings.FilePath != null)
            {
                bool scroll = true;
                IWebElement expander;
                foreach (var file in settings.FilePath)
                {
                    expander = _treeExpander(file);
                    if (scroll)
                    {
                        Driver.ScrollInView(expander);
                        scroll = false;
                    }
                    Driver.WaitForClickable(expander, file);
                    Driver.ClickOnElement(expander, file);
                    Driver.WaitForReady();
                }
            }
            Driver.WaitForSomeTime();
            _checkboxReauthenticate(settings.FlagName).VerifyElementDisplay(settings.FlagName);
            string state = _checkboxReauthenticate(settings.FlagName).GetAttribute("checked");
            if (state != null)
                _checked = true;
            if (settings.IsEnabled != _checked)
                Driver.ClickOnElement(_checkboxReauthenticate(settings.FlagName), settings.FlagName);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
        }
    }
}
