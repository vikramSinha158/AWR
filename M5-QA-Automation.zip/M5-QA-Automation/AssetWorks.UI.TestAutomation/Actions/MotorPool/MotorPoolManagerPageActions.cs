﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolManagerPageActions : MotorPoolManagerPage
    {
        public MotorPoolManagerPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Motor Pool Manager Ticket
        /// </summary>
        /// <param name="managerTicket"></param>
        /// <returns>TicketNo</returns>
        public string CreateMotorPoolManagerTicket(ManagerTicket managerTicket)
        {
            Settings.Logger.Info("Creating Motor Pool Manager Ticket");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _buttonNewMP.ClickElement("new Ticket", Driver);
            Driver.WaitForReady();
            if (managerTicket.reservationTab != null)
                FillReservationTabInfo(managerTicket.reservationTab);
            if (managerTicket.pickupReturnTab != null)
                FillPickupReturnTabInfo(managerTicket.pickupReturnTab);
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForSomeTime();
            _extendedPage.SwitchToContentFrame();
            managerTicket.TicketNo = _inputMPTicketNo.GetElementValueByAttribute("ovalue");
            Settings.Logger.Info($"Created Motor Pool Manager Ticket - {managerTicket.TicketNo}");
            Driver.SwitchTo().DefaultContent();
            return managerTicket.TicketNo;
        }

        /// <summary>
        /// Update Motor Pool Manager Ticket Info
        /// </summary>
        /// <param name="managerTicket"></param>
        public void UpdateMotorPoolManagerTicket(ManagerTicket managerTicket)
        {
            Settings.Logger.Info("Update Motor Pool Manager Ticket Info");
            _extendedPage.RefreshAndSetText(_inputMPTicketNo, managerTicket.TicketNo, "Ticket No");
            Driver.WaitForReady();
            if (managerTicket.reservationTab != null)
                FillReservationTabInfo(managerTicket.reservationTab);
            if (managerTicket.pickupReturnTab != null)
                FillPickupReturnTabInfo(managerTicket.pickupReturnTab);
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Fill Reservation Tab Info
        /// </summary>
        /// <param name="reservation"></param>
        public void FillReservationTabInfo(ReservationTab reservation)
        {
            Settings.Logger.Info("Fill Reservation Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Reservation"), "Reservation Tab");
            Driver.WaitForReady();
            _inputPickupLocation.SetText(reservation.PickupLocation, "Pickup Location");
            Driver.WaitForReady();
            _inputPickupDateTime.SetText(reservation.PickupDateTime, "Pickup Date Time");
            Driver.WaitForReady();
            _inputReturnLocation.SetText(reservation.ReturnLocation, "Return Location");
            Driver.WaitForReady();
            _inputReturnDateTime.SetText(reservation.ReturnDateTime, "Return Date Time");
            Driver.WaitForReady();
            _inputRentalClass.SetText(reservation.RentalClass, "Rental Class");
            Driver.WaitForReady();
            _inputEquipUnitNo.SetText(reservation.EquipUnitNo, "Equip Unit No");
            Driver.WaitForReady();
            _inputReservedFor.SetText(reservation.ReservedFor, "Reserved For");
            Driver.WaitForReady();
            _inputDepartmentNo.SetText(reservation.DepartmentNo, "Department No");
            Driver.WaitForReady();
            _inputPhoneNo.SetText(reservation.PhoneNo, "Phone No");
            Driver.WaitForReady();
            _inputDestination.SetText(reservation.Destination, "Destination");
            Driver.WaitForReady();
            _inputRequestedBy.SetText(reservation.RequestedBy, "Requested By");
            Driver.WaitForReady();
            _inputReason.SetText(reservation.Reason, "Reason");
            Driver.WaitForReady();
            _inputAccountNo.SetText(reservation.AccountNo, "Account No");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Pickup Return Tab Info
        /// </summary>
        /// <param name="pickupReturn"></param>
        public void FillPickupReturnTabInfo(PickupReturnTab pickupReturn)
        {
            Settings.Logger.Info("Fill Pickup Return Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Pickup/Return"), "Pickup Return Tab");
            Driver.WaitForReady();
            if (pickupReturn.IsPickup)
                _buttonPickup.ClickElement("Pickup", Driver);
            _inputLocationOut.SetText(pickupReturn.LocationOut, "Location Out");
            Driver.WaitForReady();
            if (pickupReturn.Meter1Out != null)
            {
                _extendedPage.SelectAllAndClearField(_inputMeter1Out);
                _inputMeter1Out.SetText(pickupReturn.Meter1Out, "Meter1 Out");
                Driver.WaitForReady();
            }
            _inputMeter2Out.SetText(pickupReturn.Meter2Out, "Meter2 Out");
            Driver.WaitForReady();
            if (pickupReturn.IsReturn)
                _buttonReturn.ClickElement("Return", Driver);
            Driver.WaitForReady();
            _inputLocationIn.SetText(pickupReturn.LocationIn, "Location In");
            Driver.WaitForReady();
            if (pickupReturn.Meter1In != null)
            {
                _extendedPage.SelectAllAndClearField(_inputMeter1In);
                _inputMeter1In.SetText(pickupReturn.Meter1In, "Meter1 In");
                Driver.WaitForReady();
            }
            _inputMeter2In.SetText(pickupReturn.Meter2In, "Meter2 In");
            Driver.WaitForReady();
            if (pickupReturn.MeterInOvr)
                _checkboxMeterInOvr.SelectCheckBox("Meter In Ovr");
            else
                _checkboxMeterInOvr.DeSelectCheckBox("Meter In Ovr");
            Driver.WaitForReady();
            _inputWhereIn.SetText(pickupReturn.WhereIn, "Where In");
            Driver.WaitForReady();
            _inputLicPermNo.SetText(pickupReturn.LicPermNo, "License Permit No");
            Driver.WaitForReady();
            _inputState.SetText(pickupReturn.State, "State");
            Driver.WaitForReady();
            _inputCityLicenseNo.SetText(pickupReturn.CityLicenseNo, "City License No");
            Driver.WaitForReady();
            if (pickupReturn.MovingViolations)
                _checkboxMovingViolations.SelectCheckBox("Moving Violations");
            else
                _checkboxMovingViolations.DeSelectCheckBox("Meter In Ovr");
            Driver.WaitForReady();
            if (pickupReturn.Damage)
                _checkboxDamage.SelectCheckBox("Damage");
            else
                _checkboxDamage.DeSelectCheckBox("Damage");
            Driver.WaitForReady();
            _inputReturnedBy.SetText(pickupReturn.ReturnedBy, "Returned By");
            Driver.WaitForReady();
            _inputPRNotes.SetText(pickupReturn.PRNotes, "PR Notes");
            Driver.WaitForReady();
            _selectBillingMethod.SelectFilterValueHavingEqualValue(pickupReturn.BillingMethod);
            Driver.WaitForReady();
            _inputAdjHours.SetText(pickupReturn.AdjHours, "Adj Hours");
            Driver.WaitForReady();
            _inputFreeHours.SetText(pickupReturn.FreeHours, "Free Hours");
            Driver.WaitForReady();
            _inputRateHours.SetText(pickupReturn.RateHours, "Rate Hours");
            Driver.WaitForReady();
            _inputAdjDays.SetText(pickupReturn.AdjDays, "Adj Days");
            Driver.WaitForReady();
            _inputFreeDays.SetText(pickupReturn.FreeDays, "Free Days");
            Driver.WaitForReady();
            _inputRateDays.SetText(pickupReturn.RateDays, "Rate Days");
            Driver.WaitForReady();
            _inputAdjWeeks.SetText(pickupReturn.AdjWeeks, "Adj Weeks");
            Driver.WaitForReady();
            _inputFreeWeeks.SetText(pickupReturn.FreeWeeks, "Free Weeks");
            Driver.WaitForReady();
            _inputRateWeeks.SetText(pickupReturn.RateWeeks, "Rate Weeks");
            Driver.WaitForReady();
            _inputAdjMonths.SetText(pickupReturn.AdjMonths, "Adj Months");
            Driver.WaitForReady();
            _inputFreeMonths.SetText(pickupReturn.FreeMonths, "Free Months");
            Driver.WaitForReady();
            _inputRateMonths.SetText(pickupReturn.RateMonths, "Rate Months");
            Driver.WaitForReady();
            _inputRateUsage.SetText(pickupReturn.RateUsage, "RateUsage");
            Driver.WaitForReady();
            _inputQuantityFuel.SetText(pickupReturn.QuantityFuel, "Quantity Fuel");
            Driver.WaitForReady();
            _inputRateFuel.SetText(pickupReturn.RateFuel, "Rate Fuel");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameMotorPool, "Motor Pool frame");
            _inputNewDescription.SetText(pickupReturn.ChargeDesc, "Charge Desc");
            Driver.WaitForReady();
            _inputNewChargeAmt.SetText(pickupReturn.ChargeAmt, "Charge Amt");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Motor Pool Manager Ticket Info
        /// </summary>
        /// <param name="managerTicket"></param>
        public void VerifyMotorPoolManagerTicket(ManagerTicket managerTicket)
        {
            Settings.Logger.Info("Verify Motor Pool Manager Ticket Info");
            _extendedPage.RefreshAndSetText(_inputMPTicketNo, managerTicket.TicketNo, "Ticket No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputMPStatus, "Status", managerTicket.MPStatus);
            if (managerTicket.reservationTab != null)
                VerifyReservationTabInfo(managerTicket.reservationTab);
            if (managerTicket.pickupReturnTab != null)
                VerifyPickupReturnTabInfo(managerTicket.pickupReturnTab);
            Settings.Logger.Info("Successfully Verified Motor Pool Manager Ticket Info");
        }

        /// <summary>
        /// Verify Reservation Tab Info
        /// </summary>
        /// <param name="reservation"></param>
        public void VerifyReservationTabInfo(ReservationTab reservation)
        {
            Settings.Logger.Info("Verify Reservation Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Reservation"), "Reservation Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputPickupLocation, "Pickup Location", reservation.PickupLocation);
            CommonUtil.VerifyElementValue(_inputReturnLocation, "Return Location", reservation.ReturnLocation);
            CommonUtil.VerifyElementValue(_inputRentalClass, "Rental Class", reservation.RentalClass);
            CommonUtil.VerifyElementValue(_inputEquipUnitNo, "Equip Unit No", reservation.EquipUnitNo);
            CommonUtil.VerifyElementValue(_inputReservedFor, "Reserved For", reservation.ReservedFor);
            CommonUtil.VerifyElementValue(_inputDepartmentNo, "Department No", reservation.DepartmentNo);
            CommonUtil.VerifyElementValue(_inputPhoneNo, "Phone No", reservation.PhoneNo);
            CommonUtil.VerifyElementValue(_inputDestination, "Destination", reservation.Destination);
            CommonUtil.VerifyElementValue(_inputRequestedBy, "Requested By", reservation.RequestedBy);
            CommonUtil.VerifyElementValue(_inputReason, "Reason", reservation.Reason);
            CommonUtil.VerifyElementValue(_inputAccountNo, "Account No", reservation.AccountNo);
            Settings.Logger.Info("Successfully Verified Reservation Tab Info");
        }

        /// <summary>
        /// Verify Pickup Return Tab Info
        /// </summary>
        /// <param name="pickupReturn"></param>
        public void VerifyPickupReturnTabInfo(PickupReturnTab pickupReturn)
        {
            Settings.Logger.Info("Verify Pickup Return Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Pickup/Return"), "Pickup Return Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputLocationOut, "Location Out", pickupReturn.LocationOut);
            CommonUtil.VerifyElementValue(_inputMeter1Out, "Meter1 Out", pickupReturn.Meter1Out);
            CommonUtil.VerifyElementValue(_inputMeter2Out, "Meter2 Out", pickupReturn.Meter2Out);
            CommonUtil.VerifyElementValue(_inputLocationIn, "Location In", pickupReturn.LocationIn);
            CommonUtil.VerifyElementValue(_inputMeter1In, "Meter1 In", pickupReturn.Meter1In);
            CommonUtil.VerifyElementValue(_inputMeter2In, "Meter2 In", pickupReturn.Meter2In);
            CommonUtil.VerifyElementValue(_inputWhereIn, "Where In", pickupReturn.WhereIn);
            CommonUtil.VerifyElementValue(_inputLicPermNo, "License Permit No", pickupReturn.LicPermNo);
            CommonUtil.VerifyElementValue(_inputState, "State", pickupReturn.State);
            CommonUtil.VerifyElementValue(_inputCityLicenseNo, "City License No", pickupReturn.CityLicenseNo);
            CommonUtil.VerifyCheckboxState(_checkboxMovingViolations, "Moving Violations", pickupReturn.MovingViolations);
            CommonUtil.VerifyCheckboxState(_checkboxDamage, "Damage", pickupReturn.Damage);
            CommonUtil.VerifyElementValue(_inputReturnedBy, "Returned By", pickupReturn.ReturnedBy);
            CommonUtil.VerifyElementValue(_inputPRNotes, "PR Notes", pickupReturn.PRNotes);
            CommonUtil.VerifyElementValue(_selectBillingMethod, "Billing Method", pickupReturn.BillingMethod, true);
            CommonUtil.VerifyElementValue(_inputAdjHours, "Adj Hours", pickupReturn.AdjHours);
            CommonUtil.VerifyElementValue(_inputFreeHours, "Free Hours", pickupReturn.FreeHours);
            CommonUtil.VerifyElementValue(_inputRateHours, "Rate Hours", pickupReturn.RateHours);
            CommonUtil.VerifyElementValue(_inputAdjDays, "Adj Days", pickupReturn.AdjDays);
            CommonUtil.VerifyElementValue(_inputFreeDays, "Free Days", pickupReturn.FreeDays);
            CommonUtil.VerifyElementValue(_inputRateDays, "Rate Days", pickupReturn.RateDays);
            CommonUtil.VerifyElementValue(_inputAdjWeeks, "Adj Weeks", pickupReturn.AdjWeeks);
            CommonUtil.VerifyElementValue(_inputFreeWeeks, "Free Weeks", pickupReturn.FreeWeeks);
            CommonUtil.VerifyElementValue(_inputRateWeeks, "Rate Weeks", pickupReturn.RateWeeks);
            CommonUtil.VerifyElementValue(_inputAdjMonths, "Adj Months", pickupReturn.AdjMonths);
            CommonUtil.VerifyElementValue(_inputFreeMonths, "Free Months", pickupReturn.FreeMonths);
            CommonUtil.VerifyElementValue(_inputRateMonths, "Rate Months", pickupReturn.RateMonths);
            CommonUtil.VerifyElementValue(_inputRateUsage, "Rate Usage", pickupReturn.RateUsage);
            CommonUtil.VerifyElementValue(_inputQuantityFuel, "Quantity Fuel", pickupReturn.QuantityFuel);
            CommonUtil.VerifyElementValue(_inputRateFuel, "Rate Fuel", pickupReturn.RateFuel);
            if (pickupReturn.ChargeDesc != null && pickupReturn.ChargeAmt != null)
            {
                Driver.SwitchToFrame(_frameMotorPool, "Motor Pool frame");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool,
                    "Description", pickupReturn.ChargeDesc, "ChargeAmt"), "Charge Amt", pickupReturn.ChargeAmt, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Successfully Verified Pickup Return Tab Info");
        }
    }
}
