﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolRentalClassPageActions : MotorPoolRentalClassPage
    {
        public MotorPoolRentalClassPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Motor Pool Rental Class
        /// </summary>
        /// <returns>mprClass</returns>
        public string CreateNewMotorPoolRentalClass()
        {
            Settings.Logger.Info("Create Motor Pool Rental Class");
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _mprClass = CommonUtil.GetRandomStringWithSpecialChars(6);
            _mprDesc = CommonUtil.GetRandomStringWithSpecialChars(8) + " " + _mprClass;
            _mprPrepDuration = CommonUtil.GenerateRandomIntValue(1, 99).ToString();
            _inputNewClass.SetText(_mprClass, "New Class");
            Driver.WaitForReady();
            _inputNewDesc.SetText(_mprDesc, "New Description");
            _inputNewPrepDuration.SetText(_mprPrepDuration, "New Prep Duration");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            return _mprClass;
        }

        /// <summary>
        /// Verify Table Updated With Class
        /// </summary>
        /// <param name="Class"></param>
        /// <param name="Column"></param>
        /// <param name="Value"></param>
        public void VerifyTableUpdatedWithClass(string Class, string Column, string Value)
        {
            Settings.Logger.Info($"Verify Motor Pool Rental Class '{Column}' for : " + Class);
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            string cellVal = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableMotorPool, "Class", Class, Column, "value", "div").GetAttribute("value");
            CommonUtil.AssertTrue(Value, cellVal);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Motor Pool Rental Class
        /// </summary>
        /// <param name="Class"></param>
        /// <param name="Column"></param>
        /// <param name="Value"></param>
        public void UpdateMotorPoolRentalClass(string Class, string Column, string Value)
        {
            Settings.Logger.Info($"Update Motor Pool Rental Class '{Column}' for : " + Class);
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableMotorPool, "Class", Class, Column, "value", "div").SetText(Value, Column);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Motor Pool Rental Class
        /// </summary>
        /// <param name="Class"></param>
        public void DeleteMotorPoolRentalClass(string Class)
        {
            Settings.Logger.Info($"Deleting Motor Pool Rental Class for : " + Class);
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableMotorPool, "Class", Class, "description", "value", "div").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableMotorPool, "Class", Class, "value", "div");
            Driver.SwitchTo().DefaultContent();
        }
    }
}
