﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class AppUserMaintenancePageActions : AppUserMaintenanceMainPage
    {
        public AppUserMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Application User
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public string CreateApplicationUser(string DataObjectKey)
        {

            Settings.Logger.Info(" Creating Application User   ");
            string User = CommonUtil.GetRandomStringWithSpecialChars(8);
            _extendPage.SwitchToContentFrame();
            _appUser.SetText(User, " Application User ");
            Driver.SwitchTo().DefaultContent();
            _extendPage.ActionRequiredWindow("Create");
            _extendPage.SwitchToContentFrame();
            FillApplicationUserMaintenanceDetail(DataObjectKey, User);
            _extendPage.VerifyCreatedActionNumber(_appUser, User);
            AppUserMaintenanceMainPage.ApplicationUser = User;
            AppUserMaintenanceMainPage.Name = Name;
            return User;
        }


        /// <summary>
        /// Fill User Details
        /// </summary>
        /// <param name="AppUser"></param>
        public void FillApplicationUserMaintenanceDetail(string DataObjectKey, string User)
        {
            AddApplicationUser DataObject = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<AddApplicationUser>();
            _allowWebAccessChb.SelectCheckBox(" Allow Web Access ");
            Driver.WaitForReady();
            _appPassword.SetText(DataObject.Password, "Application Password");
            Driver.WaitForReady();
            _allowMobileAccessChb.SelectCheckBox(" Allow Mobile Access ");
            Driver.WaitForReady();
            _mobilePassword.SetText(DataObject.Password, "Application Password");
            Driver.WaitForReady();
            UserRole = DataObject.UserRole;
            _userRole.SetText(UserRole, "User Role");
            Name = "User " + User;
            Driver.WaitForReady();
            _userName.SetText(Name, "Name");
            Driver.ClickOnElement(_uniqueID, " Unique ID");
            _uniqueID.SendKeys(Keys.Tab);
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
        }


        /// <summary>
        /// Verify Application User Data
        /// </summary>
        /// <param name="AppUser"></param>
        public void VerifyApplicationUserMaintenanceDetail(string AppUser)
        {
            Settings.Logger.Info(" Verifying Application User Maintenance Data ");
            _extendPage.SwitchToContentFrame();
            //_extendPage.RefreshAndSetText(_appUser, AppUser, " Application User ");
            Driver.WaitForReady();
            string ActualAppUserValue = _appUser.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(AppUser, ActualAppUserValue);
            Driver.WaitForReady();
            CommonUtil.AssertTrue<bool>(true, _allowWebAccessChb.Selected);
            string ActualAppPasswordValue = _appPassword.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(ActualAppPasswordValue), "Password is Null");
            Driver.WaitForReady();
            CommonUtil.AssertTrue<bool>(true, _allowMobileAccessChb.Selected);
            string ActualMobilePasswordValue = _mobilePassword.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(ActualMobilePasswordValue), "Mobile Password is Null");
            Driver.WaitForReady();
            string ActualUserRoleValue = _userRole.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(UserRole, ActualUserRoleValue);
            string ActualNameValue = _userName.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(Name, ActualNameValue);
            Driver.WaitForReady();
            string ActualUniqueIDValue = _uniqueID.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(AppUser, ActualUniqueIDValue);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Open Application User
        /// </summary>
        /// <param name="AppUser"></param>
        public void VerifyApplicationUserDeletion(string AppUser)
        {
            Driver.SwitchTo().DefaultContent();
            _extendPage.VerifyCodeDeletion(_appUser, AppUser, "Application User");
        }

        /// <summary>
        /// Edit Application User Maintenance Detail
        /// </summary>
        /// <param name="DataObjectKey"></param>
        public void EditApplicationUserDetail(string DataObjectKey, string User)
        {
            Settings.Logger.Info(" Edit User Details ");
            string NameNew = "New" + User;
            _extendPage.RefreshAndSetText(_appUser, User, " Application User ");
            FillApplicationUserMaintenanceDetail(DataObjectKey, NameNew);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClicKSave();
        }


    }
}
