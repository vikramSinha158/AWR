﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions
    {
            internal class AppUserCopyPageActions : AppUserMaintenanceMainPage
    {
                public AppUserCopyPageActions(IWebDriver Driver) : base(Driver) { }



        /// <summary>
        /// Create Application User
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public AppUserMaintenancePageActions CopyApplicationUser(string DataObjectKey, string ExistingUserID)
        {
            CopyApplicationUser DataObject = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CopyApplicationUser>();
            Settings.Logger.Info(" Filling Application User Copy Details  ");
            _extendPage.SwitchToContentFrame();
            _appUser.SetText(ExistingUserID, " Existing User ID ");
            string NewUserID = CommonUtil.GetRandomStringWithSpecialChars(8);
            Driver.WaitForReady();
            _newUserId.SetText(NewUserID, "New User ID");
            Driver.WaitForReady();
            _appPassword.SetText(DataObject.Password, "New User Password");
            NewUserName = "User" + NewUserID;
            _newUserName.SetText(NewUserName, "New User Name");
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClicKSave();
            AppUserMaintenanceMainPage.NewUserID = NewUserID;
            AppUserMaintenanceMainPage.Name = NewUserName;
            return new AppUserMaintenancePageActions(Driver);
        }
     }
    }   
