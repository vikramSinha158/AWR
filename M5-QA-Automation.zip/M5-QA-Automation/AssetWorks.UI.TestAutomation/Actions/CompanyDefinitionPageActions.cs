﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class CompanyDefinitionPageActions : CompanyDefinitionPage
    {
        public CompanyDefinitionPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Fill Account Template Tab
        /// </summary>
        /// <param name="useDirAcctCheckbox"></param>
        public void FillAccountTemplateTab(bool useDirAcctCheckbox)
        {
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            _accountTemplateTab.ClickElement("accountTemplateTab", Driver);
            if (useDirAcctCheckbox) { _useDirAcctCheckbox.SelectCheckBox("useDirAcctCheckbox", useDirAcctCheckbox); }
            else { _useDirAcctCheckbox.DeSelectCheckBox("useDirAcctCheckbox"); }          
            _extendpage.Save();
            Settings.Logger.Info(" created Company Definition With Account Template Tab");
        }

        /// <summary>
        /// Verify Account Template Tab
        /// </summary>
        /// <param name="useDirAcctCheckbox"></param>
        public void VerifyAccountTemplateTab(bool useDirAcctCheckbox)
        {
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            _accountTemplateTab.ClickElement("accountTemplateTab", Driver);
            CommonUtil.VerifyCheckboxState(_useDirAcctCheckbox, "", useDirAcctCheckbox);
            _extendpage.Save();
            Settings.Logger.Info(" Successfully Verified  Company Definition With Account Template Tab");
        }
    }
}
