﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Utils;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using System.Runtime.CompilerServices;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ExtendedPageActions : ExtendedPage
    {
        public ExtendedPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Clic on save button
        /// </summary>
        public void ClicKSave()
        {
            Driver.WaitForReady();
            Driver.MouseHover(_buttonSave, " save button ");
            Driver.ClickElementUsingAction(_buttonSave, " save button ");
            CheckkWarningMessage();
        }

        /// <summary>
        /// Hendle the pop to select the action
        /// </summary>
        /// <param name="Elementname"></param>
        public void ActionRequiredWindow(string Elementname)
        {
            Settings.Logger.Info(" Performing action on required window ");
            Driver.WaitForReady();
            if (_createDialog.VerifyElementDisplay(" Action Required Dialog "))
            {
                string element = $"//button[text()='{Elementname}']";
                Driver.FindElement(By.XPath(element)).Click();
            }
        }

        /// <summary>
        /// Enter description for th action
        /// </summary>
        /// <param name="InputElement"></param>
        public string EnterDescription(IWebElement InputElement)
        {
            Settings.Logger.Info(" Providing an description  ");
            string DescriptionContent = $"{CommonUtils.RandomString(5, false)} {" "} {CommonUtils.RandomString(10, false)}";
            InputElement.SetText(DescriptionContent, $"Description text field : { DescriptionContent} ");
            return DescriptionContent;
        }

        /// <summary>
        /// Switch to content frame
        /// </summary>
        public void SwitchToContentFrame()
        {            
            Driver.SwitchToFrame(_contentFrame, "content frame");
        }     


        /// <summary>
        /// Refresh And Switch To Table Frame
        /// </summary>
        public void RefreshAndSwitchToTable(IWebElement IframeElement, string IFrameName)
        {
            ClickOnRefreshButton();
            SwitchToContentFrame();
            Driver.SwitchToFrame(IframeElement, IFrameName);
        }
        /// <summary>
        /// Verifying action number after saving the action
        /// </summary>
        /// <param name="ActionElement"></param>
        /// <param name="CreatedActioNumber"></param>
        public void VerifyCreatedActionNumber(IWebElement ActionElement, string CreatedActioNumber)
        {
            Settings.Logger.Info(" Verifying created action number  ");
            ClicKSave();
            Driver.WaitForReady();
            SwitchToContentFrame();
            string ActualActionNo = ActionElement.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(CreatedActioNumber, ActualActionNo);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// verifying the unit work order creation
        /// </summary>
        /// <returns></returns>
        public WorkOrderMainPageActions VerifyCreatedUnitWorkOrder()
        {
            Settings.Logger.Info(" Verifying created unit number  ");
            CurrentPage = new HomePageActions(Driver).NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().SearchForUnitNo();
            _lov.EnterSearchField(Settings.UnitNumber);
            Settings.Logger.Info($"Searched for {Settings.UnitNumber} in LOV ");
            CurrentPage.As<WorkOrderMainPageActions>().CreateAndVerifyWorkOrder();
            return new WorkOrderMainPageActions(Driver);
        }

        /// <summary>
        /// Click on save button
        /// </summary>
        public void ClickOnSaveButton()
        {
            _buttonSave.VerifyElementDisplay(" save button ");
            _buttonSave.Click();
            Settings.Logger.Info(" Click on save button.");
            _buttonUndo.GetElementValueByAttribute("disabled");
        }

        /// <summary>
        /// Click on refresh button
        /// </summary>
        public void ClickOnRefreshButton()
        {
            _buttonRefresh.VerifyElementDisplay(" Refresh button ");
            _buttonRefresh.Click();
            Settings.Logger.Info(" Click on refresh button.");
           _buttonUndo.GetElementValueByAttribute("disabled");
        }

        /// <summary>	
        /// Click on delete button	
        /// </summary>	
        public void ClickOnDeleteButton()
        {
            Driver.WaitForReady();
            Driver.MouseHover(_buttonDelete, " Delete button ");
            Driver.WaitForClickable(_buttonDelete, " Delete button ");
            Driver.ClickOnElement(_buttonDelete, "Delete button");
        }

        /// <summary>
        /// Verify object date with system today date.
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="EleName"></param>
        public void VerifySystemDateContainAppdate(IWebElement WebElement, string EleName)
        {
            Settings.Logger.Info(" Verifying Date with in application for " + EleName);
            WebElement.Click();
            string reqDate = WebElement.GetElementValueByAttribute("ovalue");
            string actualDate = CommonUtil.RemoveTimeFromDate(reqDate);
            string currentDate = DateTime.Today.ToShortDateString();
            Assert.IsTrue(actualDate.Contains(currentDate), EleName + " date does not match with today's date");
            Settings.Logger.Info($" Verified application date {actualDate} and current date as {currentDate} ");
        }

        /// <summary>
        /// Common method to asset
        /// </summary>
        /// <param name="ActualValue"></param>
        /// <param name="ExpectedValue"></param>
        public void AssetTrue(string ActualValue, string ExpectedValue)
        {
            try
            {
                Assert.True(ActualValue.Equals(ExpectedValue, StringComparison.OrdinalIgnoreCase), $"{ActualValue} actual value not matched with expected value {ExpectedValue}");
                Settings.Logger.Info($"Actual value : {ActualValue} and expacted value : {ExpectedValue} ");
            }
            catch (Exception ex)
            {
                Settings.Logger.Info($"Actual value : {ActualValue} not matched with expacted value : {ExpectedValue} ");
                Assert.Fail($"{ActualValue} actual value not matched with expected value {ExpectedValue } Exception message : {ex}");
            }
        }


        /// <summary>
        /// Checking Warnibg Message
        /// </summary>
        /// <returns></returns>
        public void CheckkWarningMessage()
        {
            if (_errorWarningDisplay.VerifyElementDisplay("Error Messages and Warnings"))
            {
                string ErrorMessage = _errorCriticalText.GetText("Error Message");
                Settings.Logger.Info($"Test case fail getting an error {ErrorMessage} ");
                Assert.Fail(ErrorMessage);
            }
        }
        /// <summary>
        /// Get Error Message
        /// </summary>
        /// <returns></returns>
        public string GetErrorMessage()
        {
            string ErrorMessage = string.Empty; 
            if (_errorWarningDisplay.VerifyElementDisplay("Error Messages and Warnings"))
            {
                ErrorMessage = _errorCriticalText.GetText("Error Message");              

            }
            return ErrorMessage;
        }
        /// <summary>
        /// Change the hour in date time formate
        /// </summary>
        /// <param name="Date"></param>
        /// <param name="hour"></param>
        /// <returns></returns>
        public string ChangeHourInDateTime(string Date, int Hour)
        {
            DateTime givenDate = Convert.ToDateTime(Date);
            var value = givenDate.AddHours(Hour).ToString("MM/dd/yyyy hh:mm:ss");
            Settings.Logger.Info($"Getting random date string '{value}'");
            return value;
        }

        /// <summary>
        /// Return IWebElement for Input Tag
        /// </summary>
        /// <param name="elementIdentity"></param>
        /// <param name="SearchType"></param>
        /// <returns></returns>
        public IWebElement GetElementForInput(string ElementIdentity, string SearchType = "id",string ElementType="input")
        {
            IWebElement Element = null;
            string Locator = $"//{ElementType}[@{SearchType}='{ElementIdentity}']";
            Driver.WaitForVisibility(By.XPath(Locator), ElementIdentity);            
            //Driver.WaitForReady();
            Element = Driver.FindElement(By.XPath(Locator));
            return Element;
        }

        /// <summary>
        /// Get Table Element
        /// </summary>
        /// <param name="ElementIdentity"></param>
        /// <param name="ElementType"></param>
        /// <param name="SearchType"></param>
        /// <returns></returns>
        public IWebElement GetElementFromTable(string ElementIdentity, string ElementType = "input", string SearchType = "id")
        {
            IWebElement Element = null;
            string Locator = $"//{ElementType}[@{SearchType}='{ElementIdentity}']";
            Driver.WaitForVisibility(By.XPath(Locator), ElementIdentity);
            Element = Driver.FindElement(By.XPath(Locator));
            return Element;
        }

        /// <summary>
        /// Get IWebElement Input Element And Set Value
        /// </summary>
        /// <param name="elementIdentity"></param>
        /// <param name="value"></param>
        /// <param name="searchType"></param>
        /// <returns></returns>
        public IWebElement GetInputElementAndSetValue(string ElementIdentity, string Value, string SearchType = "id")
        {
            IWebElement Element = null;
            Element = GetElementForInput(ElementIdentity, SearchType);
            Driver.WaitForReady();
             Element.SetText(Value, ElementIdentity);
            return Element;
        }

        /// <summary>
        /// Get IWebElement Input Element And Attribute Value
        /// </summary>
        /// <param name="elementIdentity"></param>
        /// <param name="searchType"></param>
        /// <returns></returns>
        public string GetAttributeValueForInput(string ElementIdentity, string SearchType = "id",string AttributeValue= "ovalue")
        {
            IWebElement Element = null;
            Element = GetElementForInput(ElementIdentity, SearchType);
            Driver.WaitForReady();
            return Element.GetElementValueByAttribute(AttributeValue);
        }

        /// <summary>
        /// Get IWebElement Input Element And Click Element
        /// </summary>
        /// <param name="elementIdentity"></param>
        /// <param name="searchType"></param>
        /// <returns></returns>
        public IWebElement GetAndClickElement(string ElementIdentity, string SearchType = "id")
        {
            IWebElement Element = null;
            Element = GetElementForInput(ElementIdentity, SearchType);
            Element.ClickElement(ElementIdentity, Driver);
            return Element;
        }

        /// <summary>
        /// Get IWebElement Input Element And Double Click
        /// </summary>
        /// <param name="elementIdentity"></param>
        /// <param name="searchType"></param>
        /// <returns></returns>
        public IWebElement GetAndDoubleClickElement(string ElementIdentity, string SearchType = "id")
        {
            IWebElement Element = null;
            Element = GetElementForInput(ElementIdentity, SearchType);
            Driver.DoubleClick(Element, " Job reason ");
            return Element;
        }

        /// <summary>
        /// Save ,refresh and reload the workorder
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="WorkOrderNo"></param>
        public void SaveAndReloadActionCode(IWebElement Element, string WorkOrderNo)
        {
            Settings.Logger.Info($"Open the Code page  '{WorkOrderNo}'");
            ClicKSave();
            CheckkWarningMessage();
            ClickOnRefreshButton();
            Driver.PageScrollUp();
            SwitchToContentFrame();
            Driver.WaitForReady();
            Element.SetText(WorkOrderNo, "workOrderNumber");
        }

        /// <summary>
        /// Get Tab Link By Text eg., 'Org Hierarchy'
        /// </summary>
        /// <param name="LinkText"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public IWebElement GetTabLinkByText(string LinkText)
        {
            if (LinkText == null)
                throw new Exception("Search text can not be null.");
            string path = $"//a[text()='{LinkText}']";
            return Driver.FindElement(By.XPath(path));
        }

        /// <summary>
        /// Get Column Id By Header
        /// </summary>
        /// <param name="Header"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public string GetColumnIdByHeader(string Header)
        {
            string? colId = null;
            try
            {
                if (_tableHeaders.VerifyElementDisplay(Header))
                {
                    IList<IWebElement> _headerList = _tableHeaders.FindElements(By.XPath("//th"));
                    foreach (IWebElement header in _headerList)
                    {
                        var a = header.Text;
                        if (header.Text.Equals(Header))
                        {
                            colId = header.GetElementValueByAttribute("col");
                            break;
                        }
                    }
                }
                else
                    throw new Exception("Table Headers not found.!");
                if (colId == null)
                    throw new Exception("Column Header not found.!");
                return colId;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Generate Related Path For Action Element
        /// </summary>
        /// <param name="ColId"></param>
        /// <param name="EleType"></param>
        /// <returns></returns>
        public string GenerateRelatedPathForActionElement(string ColId, string EleType)
        {
            string relPath;
            if (EleType == "button")
                relPath = $"//td[@col='{ColId}']/button";
            else if (EleType == "div")
                relPath = $"//td[@col='{ColId}']/div";
            else
                relPath = $"//td[@col='{ColId}']/input";
            return relPath;
        }

        /// <summary>
        /// Get Table Action Element By Related Column Value
        /// </summary>
        /// <param name="_table"></param>
        /// <param name="ColHeader"></param>
        /// <param name="ColValue"></param>
        /// <param name="ColAction"></param>
        /// <param name="Attribute"></param>
        /// <param name="EleType"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public IWebElement GetTableActionElementByRelatedColumnValue(IWebElement _table, string ColHeader, string ColValue, string ColAction, string Attribute = "value", string EleType = "input")
        {
            string txtFilter, cellId;
            string? rowNo = null;
            try
            {
                string relPath = GenerateRelatedPathForActionElement(GetColumnIdByHeader(ColHeader), EleType);
                IList<IWebElement> filterList = _table.FindElements(By.XPath(relPath));
                foreach (IWebElement filter in filterList)
                {
                    txtFilter = filter.GetAttribute(Attribute);
                    if (string.IsNullOrEmpty(txtFilter) && ColValue == "")
                    {
                        rowNo = filter.GetElementValueByAttribute("id").Split('$')[1];
                        break;
                    }
                    else if (txtFilter.Equals(ColValue))
                    {
                        try {
                            rowNo = filter.GetElementValueByAttribute("id").Split('$')[1];
                            break;
                        }
                        catch {
                            rowNo = filter.GetElementValueByAttribute("name").Split('$')[1];
                            break;
                        }
                    }
                }
                if (rowNo != null)
                    cellId = ColAction + '$' + rowNo;
                else
                    throw new Exception("Column value not found.!");
                return _table.FindElement(By.Id(cellId));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Verify Table Column Does Not Contain Value
        /// </summary>
        /// <param name="_table"></param>
        /// <param name="ColHeader"></param>
        /// <param name="ColValue"></param>
        /// <param name="Attribute"></param>
        /// <param name="EleType"></param>
        /// <exception cref="Exception"></exception>
        public void VerifyTableColumnDoesNotContainValue(IWebElement _table, string ColHeader, string ColValue, string Attribute = "value", string EleType = "input")
        {
            try
            {
                bool flag = true;
                string txtFilter;
                string relPath = GenerateRelatedPathForActionElement(GetColumnIdByHeader(ColHeader), EleType);
                IList<IWebElement> filterList = _table.FindElements(By.XPath(relPath));
                foreach (IWebElement filter in filterList)
                {
                    txtFilter = filter.GetAttribute(Attribute);
                    if (txtFilter.Equals(ColValue))
                    {
                        flag = false;
                        break;
                    }
                }
                Assert.IsTrue(flag, $"Table column '{ColHeader}' does contains : '{ColValue}'");
                Settings.Logger.Info($"Table column '{ColHeader}' does not contains : '{ColValue}'");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Switch To Table Frame
        /// </summary>
        public void SwitchToTableFrame(IWebElement TableFrame)
        {
            SwitchToContentFrame();
            Driver.SwitchToFrame(TableFrame, "Table frame");
        }

        /// Verify Delete Action
        /// </summary>
        /// <param name="CodeElement"></param>
        /// <param name="CodeValue"></param>
        /// <param name="ElementName"></param>
        public void VerifyCodeDeletion(IWebElement CodeElement, string CodeValue, string ElementName)
        {
            Settings.Logger.Info($" Deleting {ElementName}  ");
            RefreshAndSetText(CodeElement, CodeValue, ElementName);
            Driver.WaitForReady();
            CodeElement.ClickElement(CodeValue,Driver);
            Driver.SwitchTo().DefaultContent();
            ClickOnDeleteButton();
            ActionRequiredWindow("Delete");
            SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.WaitForInvisibility(By.XPath(Settings.ActionDialog), "Deletion dialog ");
            string ValueAfterDeletion = CodeElement.GetAttribute("ovalue");
            Assert.True(String.IsNullOrEmpty(ValueAfterDeletion), $"{ElementName} not deleted, found value { ValueAfterDeletion}");
            Settings.Logger.Info($"{ElementName }-{CodeValue} Deleted successfully  ");
        }

        /// <summary>
        /// Refresh And Set Text
        /// </summary>
        /// <param name="CodeElement"></param>
        /// <param name="TextValue"></param>
        /// <param name="ElementName"></param>
        public void RefreshAndSetText(IWebElement CodeElement, string TextValue, string ElementName)
        {
            Settings.Logger.Info($" Refresh and set Text {ElementName}  ");
            ClickOnRefreshButton();
            SwitchToContentFrame();
            Driver.WaitForReady();
            CodeElement.SetText(TextValue, ElementName);
        }

        /// <summary>
        /// Click Delete And Verify Deletion Message
        /// </summary>
        /// <param name="DeleteMessageElement"></param>
        public void ClickDeleteAndVerifyDeletionMessage(IWebElement DeleteMessageElement)
        {
            DeleteAndSave();
            Assert.True(DeleteMessageElement.VerifyElementDisplay("Job deleted message "), "Information not deleted");
            Settings.Logger.Info(" Successfully Deleted  Commercial Charge Information");
        }

        /// <summary>
        /// Delete And Save
        /// </summary>
        public void DeleteAndSave()
        {
            Driver.SwitchTo().DefaultContent();
            ClickOnDeleteButton();
            ClicKSave();
            SwitchToContentFrame();
        }

        /// <summary>
        /// Save And Chack Warning
        /// </summary>
        public void SaveAndChackWarning()
        {
            Driver.SwitchTo().DefaultContent();
            ClicKSave();
            CheckkWarningMessage();
        }

        /// <summary>
        /// Navigate To Related Menu Page
        /// </summary>
        /// <param name="MenuOption"></param>
        /// <exception cref="Exception"></exception>
        public void NavigateToRelatedMenuPage(string MenuOption)
        {
            bool flag = true;
            string optionTxt;
            _navRelatedMenu.VerifyElementDisplay(" Related Menu ");
            _navRelatedMenu.Click();
            Settings.Logger.Info($" Click on related menu {MenuOption} option ");
            string optionlist = $"//nav[@id='mainRelatedMenu']/ul/li/ul/li";
            IList<IWebElement> optionList = Driver.FindElements(By.XPath(optionlist));
            foreach (IWebElement option in optionList)
            {
                optionTxt = option.Text;
                if (optionTxt == MenuOption)
                {
                    option.Click();
                    Driver.WaitForReady();
                    flag = false;
                    break;
                }
            }
            if (flag)
                throw new Exception($"Menu Option not found in list : {MenuOption}");
        }

        /// <summary>
        /// Add Notes
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="Notes"></param>
        /// <param name="Lenght"></param>
        public void AddNotes(IWebElement Element, string Notes = "random", int Lenght = 30)
        {
            if (Notes == "random")
                Notes = CommonUtil.GetRandomStringWithSpecialChars(Lenght);
            Element.Click();
            Driver.SwitchTo().DefaultContent();
            _txtAreaNotes.VerifyElementDisplay(" Notes Textarea ");
            _txtAreaNotes.SetText(Notes, " Notes Textarea ");
            ClickOnDialogBoxButton("OK");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Click On Dialog Box Button
        /// </summary>
        /// <param name="Option"></param>
        /// <exception cref="Exception"></exception>
        public void ClickOnDialogBoxButton(string Option)
        {
            Driver.WaitForReady();
            string dialogOption = $"//button[contains(text(),'{Option}')]";
            IWebElement btnOption = _dialogArea.FindElement(By.XPath(dialogOption));
            btnOption.VerifyElementDisplay($" {Option} button ");
            btnOption.Click();
            Settings.Logger.Info($" Clicked on '{Option}' button  ");
        }

        /// <summary>
        /// Select Group List
        /// </summary>
        /// <param name="SourcrtGroupList"></param>
        /// <param name="MoveListElement"></param>
        /// <returns></returns>
        public int SelectAllGroupList(IWebElement FrameName,IWebElement SourcrtGroupList,IWebElement MoveListElement,IWebElement DestGroupList,ref int DestCntBeforeMove)
        {
            int SourceGroupListItemCOunt = 0;
            int DestGropListItemCOunt = 0;
            Driver.SwitchToFrame(FrameName, " Group List Frame ");
            DestGroupList.ClickElement("List", Driver);
            DestGropListItemCOunt = DestGroupList.GetDropdownListTotalCount();
            DestCntBeforeMove = DestGropListItemCOunt;
            SourcrtGroupList.ClickElement("List", Driver);
            SourceGroupListItemCOunt = SourcrtGroupList.GetDropdownListTotalCount();
            if (SourceGroupListItemCOunt > 0)
            {
                SourcrtGroupList.SendKeys(Keys.Control + "a");
                MoveListElement.ClickElement("Move Element ", Driver);
            }           
            return SourceGroupListItemCOunt;
        }

        /// <summary>
        /// verify Group List Count
        /// </summary>
        /// <param name="Frame"></param>
        /// <param name="DestGroupListCount"></param>
        /// <param name="ExpactedListCount"></param>
        public void verifyGroupListCount(IWebElement Frame, IWebElement DestGroupListCount, int ExpectedListCount)
        {
            Driver.SwitchToFrame(Frame, "Group List Frame");
            DestGroupListCount.ClickElement("List", Driver);
            int ActualListCount = DestGroupListCount.GetDropdownListTotalCount();
            CommonUtil.AssertTrue<int>(ExpectedListCount, ActualListCount);
        }

        /// <summary>
        /// Select All And MoveGroup List Elements
        /// </summary>
        /// <param name="FrameName"></param>
        /// <param name="SourcrtGroupList"></param>
        /// <param name="MoveListElement"></param>
        public void SelectAllAndMoveGroupListElements(IWebElement FrameName, IWebElement SourcrtGroupList, IWebElement MoveListElement)
        {
            int LeftListItemCOunt = 0;
            Driver.SwitchToFrame(FrameName, " Group List Frame ");
            LeftListItemCOunt = SourcrtGroupList.GetDropdownListTotalCount();
            if (LeftListItemCOunt > 0)
            {
                SourcrtGroupList.SendKeys(Keys.Control + "a");
                MoveListElement.ClickElement("Move Element ", Driver);
            }
        }
        /// <summary>
        /// Select one List Item and Move to Destination
        /// </summary>
        /// <param name="FrameName"></param>
        /// <param name="SourceValue"></param>
        /// <param name="MoveButton"></param>
        public void SelectValueAndMoveToDestination(IWebElement SourceValue, IWebElement MoveButton)
        {         
           SourceValue.ClickElement("List Element", Driver);
            MoveButton.ClickElement("Move Element ", Driver);            
        }

        /// <summary>
        /// Verify Element
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="ExpectedValue"></param>
        /// <param name="DropDown"></param>
        /// <param name="AttributeValue"></param>
        public void VerifyElement(IWebElement Element,string ExpectedValue,bool DropDown=false,string AttributeValue = "ovalue")
        {
            string ActualValue = String.Empty;
            if (!String.IsNullOrEmpty(ExpectedValue))
            {
                if (DropDown)
                {
                    ActualValue = Element.GetVisibleText();
                }
                else
                {
                    //Driver.WaitForReady();
                    ActualValue = Element.GetElementValueByAttribute(AttributeValue);
                }
                CommonUtil.AssertTrue<string>(ExpectedValue, ActualValue);
            }
        }

        /// <summary>
        /// Check Data Existence And Get Action Code
        /// </summary>
        /// <param name="RequiredActionCode"></param>
        /// <param name="ActionCodeValue"></param>
        /// <returns></returns>
        public bool CheckDataExistenceAndGetActionCode(string RequiredActionCode, ref string ActionCodeValue, string QuerryKey, int Length=8)
        {
            bool DataExits = false;
            if (string.IsNullOrEmpty(RequiredActionCode) || RequiredActionCode.ToLower().Equals("random"))
            {                 
                ActionCodeValue = CommonUtil.GetRandomStringWithSpecialChars(Length).ToUpper();
                Settings.Logger.Info($" RequiredActionCode equals to random, Random Data : {ActionCodeValue}, Generated ");               
            }   
            else
            {
                if (Settings.connection!= null && CommonUtil.CheckDataExist(Settings.connection, QuerryKey, RequiredActionCode, Settings.DBType))
                {                
                    DataExits = true;
                    ActionCodeValue = RequiredActionCode;
                    Settings.Logger.Info($" Data : {RequiredActionCode} , Exits ");
                }
                else
                {                  
                    ActionCodeValue = RequiredActionCode;
                    Settings.Logger.Info($" Data : {RequiredActionCode} , Not Exits ");
                }
            }
            return DataExits;
        }

        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        {
            Driver.SwitchTo().DefaultContent();
            Driver.MouseHover(_buttonSave, " save button ");
            Driver.ClickElementUsingAction(_buttonSave, " save button ");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Delete ActionCode
        /// </summary>
        /// <param name="CodeElement"></param>
        /// <param name="CodeValue"></param>
        /// <param name="ElementName"></param>
        public string? DeleteActionCode(IWebElement CodeElement, string CodeValue, string ElementName)
        {
            string ErrorMessage = null;
            RefreshAndSetText(CodeElement, CodeValue, ElementName);
            Driver.WaitForReady();
            CodeElement.ClickElement("Click on input text ", Driver);
            Driver.SwitchTo().DefaultContent();
            ClickOnDeleteButton();
            ActionRequiredWindow("Delete");
            Driver.WaitForReady();
            if (_errorWarningDisplay.VerifyElementDisplay("Error Messages and Warnings"))
            {
                ErrorMessage = _errorCriticalText.GetText("Error Message");
                Settings.Logger.Info($"Test case -- getting an error {ErrorMessage} ");
            }
            Settings.Logger.Info($" Deleted {ElementName}  ");
            return ErrorMessage;
        }

        /// <summary>
        /// Refresh And Leave Page
        /// </summary>
        public void RefreshAndLeavePage()
        {
            ClickRefresh();
            Driver.AcceptAlert();
            Driver.WaitForReady();
            ActionRequiredWindow("Leave");
            Driver.WaitForReady();
        }


        /// <summary>
        /// Click Refresh
        /// </summary>
        public void ClickRefresh()
        {
             Driver.SwitchTo().DefaultContent();
            _buttonRefresh.VerifyElementDisplay(" Refresh button ");
            _buttonRefresh.Click();
            Settings.Logger.Info(" Click on refresh button.");
        }

        /// <summary>
        /// Verify Group List Item
        /// </summary>
        /// <param name="Grouplist"></param>
        /// <param name="ExpectedGroupList"></param>
        public void VerifyGroupListItem(IWebElement Grouplist, List<string> ExpectedGroupList)
        {
            Driver.WaitForReady();
            List<string> ActualListValues = Grouplist.GetDropdownValueList();
            int ExpectedlistCount = ExpectedGroupList.Count;
            if (ActualListValues.Count == ExpectedlistCount)
            {
                for (int i = 0; i < ExpectedlistCount; i++)
                {
                    CommonUtil.AssertTrue<bool>(true, ActualListValues[i].Contains(ExpectedGroupList[i]));
                }
            }
            else {
                Assert.Fail($"Gropulist Count ={ActualListValues.Count } not matched with Expacted Employee list count ={ExpectedlistCount} ");
            }
        }

        /// <summary>
        /// Verify Group List Item As Null
        /// </summary>
        /// <param name="Grouplist"></param>
        /// <param name="ExpectedGroupList"></param>
        public void VerifyGroupListIsNull(IWebElement Grouplist)
        {
            Driver.WaitForReady();
            List<string> ActualListValues = Grouplist.GetDropdownValueList();                       
           Assert.IsNull(ActualListValues);               
        }

        /// <summary>
        /// Save And Perform Action Required
        /// </summary>
        /// <param name="ActionRequired"></param>
        public void SaveAndPerformActionRequired(string ActionRequired)
        {
            Driver.SwitchTo().DefaultContent();
            ClicKSave();
            ActionRequiredWindow(ActionRequired);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Select Multiple Item From List
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="MoveListElement"></param>
        /// <param name="ExpectedGroupList"></param>
        public void SelectMultipleItemFromList(IWebElement WebElement, IWebElement MoveListElement, List<string> ExpectedGroupList)
        {
            SelectElement element = new SelectElement(WebElement);
            int index = 0;
            foreach (IWebElement option in element.Options)
            {               
                if (index < ExpectedGroupList.Count)
                {                 
                    if (option.Text.Trim().Contains(ExpectedGroupList[index]))
                    {
                        Driver.WaitForReady();
                        OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Driver);
                        builder.KeyDown(Keys.Control).Click(option).KeyUp(Keys.Control).Build().Perform(); ;
                        index++;
                    }
                }
            }
            Driver.WaitForReady();
            MoveListElement.ClickElement("Nove selected list", Driver);
        }

        /// <summary>
        /// Select Element In List Using Double Click
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="ExpectedGroupList"></param>
        public void SelectElementInListUsingDoubleClick(IWebElement GroupList,string ClickText)
        {
            SelectElement element = new SelectElement(GroupList);
            foreach (IWebElement option in element.Options)
            {
                Driver.WaitForReady();
                if (option.Text.Trim().Contains(ClickText))
                {
                    Driver.DoubleClick(option, "ClickText");
                    break;
                }
            }
        }

        /// <summary>
        /// Get Select Element And Select Value
        /// </summary>
        /// <param name="ElementIdentity"></param>
        /// <param name="Value"></param>
        /// <param name="SearchType"></param>
        /// <returns></returns>
        public IWebElement GetSelectElementAndSelectValue(string ElementIdentity, string Value, string SearchType = "id")
        {
            IWebElement Element = null;
            Element = GetSelectElement(ElementIdentity, SearchType);
            Driver.WaitForReady();
            Element.SelectFilterValueHavingEqualValue(Value);
            return Element;
        }

        /// <summary>
        /// Get Select Element
        /// </summary>
        /// <param name="ElementIdentity"></param>
        /// <param name="SearchType"></param>
        /// <returns></returns>
        public IWebElement GetSelectElement(string ElementIdentity, string SearchType = "id")
        {
            IWebElement Element = null;
            string Locator = $"//select[@{SearchType}='{ElementIdentity}']";
            Driver.WaitForVisibility(By.XPath(Locator), ElementIdentity);
            Driver.WaitForReady();
            Element = Driver.FindElement(By.XPath(Locator));
            return Element;
        }

        /// <summary>
        /// Get Button Element And Click Element
        /// </summary>
        /// <param name="ElementIdentity"></param>
        /// <param name="SearchType"></param>
        /// <returns></returns>
        public IWebElement GetButtonElementAndClickElement(string ElementIdentity, string SearchType = "id")
        {
            IWebElement Element = null;
            Element = GetButtonElement(ElementIdentity, SearchType);
            Element.ClickElement(ElementIdentity, Driver);
            return Element;
        }

        /// <summary>
        /// Get Button Element
        /// </summary>
        /// <param name="ElementIdentity"></param>
        /// <param name="SearchType"></param>
        /// <returns></returns>
        public IWebElement GetButtonElement(string ElementIdentity, string SearchType = "id")
        {
            IWebElement Element = null;
            string Locator = $"//button[@{SearchType}='{ElementIdentity}']";
            Driver.WaitForVisibility(By.XPath(Locator), ElementIdentity);
            Driver.WaitForReady();
            Element = Driver.FindElement(By.XPath(Locator));
            return Element;
        }

        /// <summary>
        /// Verify Added Notes
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="ExpectedNotes"></param>
        public void VerifyAddedNotes(IWebElement Element, string ExpectedNotes )
        {
            Element.Click();
            Driver.SwitchTo().DefaultContent();
            _txtAreaNotes.VerifyElementDisplay(" Notes Textarea ");
            string ActualNotes=_txtAreaNotes.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(ExpectedNotes.Trim(), ActualNotes.Trim());
            ClickOnDialogBoxButton("OK");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Menu Bar Headers
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="ExpectedHeaders"></param>
        public void VerifyMenuBarHeaders(string ExpectedHeader)
        {
            Driver.WaitForReady();
            SwitchToContentFrame();
            string ActualHeader = _menuBarOptionsHeader.GetText("Application User Maintenance");
            CommonUtil.AssertTrue<string>(ExpectedHeader.Trim(), ActualHeader.Trim());
            Driver.WaitForReady();
        }

        /// Select One Item From List
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="MoveListElement"></param>
        /// <param name="ExpectedItem"></param>
        public void SelectOneItemFromList(IWebElement WebElement, IWebElement MoveListElement, string ExpectedItem)
        {
            SelectElement element = new SelectElement(WebElement);
            foreach (IWebElement option in element.Options)
            {
                    if(option.Text.Trim().Contains(ExpectedItem))
                    {
                        Driver.WaitForReady();
                        WebElement.ClickDropDownValuebyContainingText(ExpectedItem);
                        break;
                    }
            }
            Driver.WaitForReady();
            MoveListElement.ClickElement("Nove selected list", Driver);
        }

        /// <summary>
        /// Verify Table Column Contain Value
        /// </summary>
        /// <param name="_table"></param>
        /// <param name="ColHeader"></param>
        /// <param name="ColValue"></param>
        /// <param name="Attribute"></param>
        /// <param name="EleType"></param>
        /// <exception cref="Exception"></exception>
        public void VerifyTableColumnContainValue(IWebElement _table, string ColHeader, string ColValue, string Attribute = "value", string EleType = "input")
        {
            try
            {
                bool flag = false;
                string txtFilter;
                string relPath = GenerateRelatedPathForActionElement(GetColumnIdByHeader(ColHeader), EleType);
                IList<IWebElement> filterList = _table.FindElements(By.XPath(relPath));
                foreach (IWebElement filter in filterList)
                {
                    txtFilter = filter.GetAttribute(Attribute);
                    if (txtFilter.Equals(ColValue))
                    {
                        flag = true;
                        break;
                    }
                }
                Assert.IsTrue(flag, $"Table column '{ColHeader}' does not contains : '{ColValue}'");
                Settings.Logger.Info($"Table column '{ColHeader}' contains : '{ColValue}'");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Open Close help
        /// </summary>
        /// <param name="close"></param>
        public void OpenAndCloseHelp(bool close = false)
        {
            Settings.Logger.Info(" Open and close help window ");
            _helpBtn.Click();
            Driver.WaitForReady();
            Driver.SwitchToNewWBrowserTab(1);
            if (close)
            {
                Driver.Close();
                Driver.SwitchToNewWBrowserTab(0);
            }
        }

        /// <summary>
        /// Verify screen url
        /// </summary>
        /// <param name="webElement"></param>
        /// <param name="screenUrl"></param>
        public void VerifyScreenUrl(IWebElement webElement, string screenUrl)
        {
            Driver.WaitForReady();
            Driver.WaitForSomeTime();
            string actualResult = webElement.GetAttribute("title");
            Driver.MouseHover(webElement, " Screen URL ");
            Assert.True(actualResult.Contains(screenUrl));
        }

        /// <summary>
        /// Get Date In Application TimeZOne
        /// </summary>
        /// <param name="DaysOffset"></param>
        /// <returns></returns>
        public string GetDateInAppTimeZOne(string DaysOffset)
        {
            DateTime currentTime = TimeZoneInfo.ConvertTime(DateTime.Now.AddDays(Convert.ToDouble(DaysOffset)), TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
            return currentTime.ToString("MM/dd/yyyy");
        }
        
        /// Verify Associated Code Not Deleted
        /// </summary>
        /// <param name="CodeInputElement"></param>
        /// <param name="CodeNo"></param>
        /// <param name="ExpactedMessage"></param>
        public void VerifyAssociatedCodeNotDeleted(IWebElement CodeInputElement, string CodeNo,string ExpactedMessage)
        {
            string ErrorMessage = DeleteActionCode(CodeInputElement, CodeNo, CodeNo);
            if (!String.IsNullOrEmpty(ErrorMessage))
            {
                CommonUtil.AssertTrue<bool>(true,ErrorMessage.Contains(ExpactedMessage));
            }
            else
            {
                Assert.Fail($" Code { CodeNo }  Deleted ");
            }
        }

        /// <summary>
        /// Delete And Verify Single Table Row
        /// </summary>
        /// <param name="CodeInputElement"></param>
        /// <param name="TableFrame"></param>
        /// <param name="CodeNo"></param>
        /// <param name="TableRows"></param>
        public void DeleteAndVerifySingleTableRowDeletion(IWebElement CodeInputElement, string CodeNo, IWebElement TableFrame, IList<IWebElement>? TableRows)
        {
            Driver.WaitForReady();
            DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Deleted and saved Item  ");
            RefreshAndSetText(CodeInputElement, CodeNo, "Code No");
            Driver.SwitchToFrame(TableFrame, "TableFrameName");
            Driver.WaitForReady();
            int ActualCount = TableRows.Count - 1;
            CommonUtil.AssertTrue<int>(0, ActualCount);
        }

        /// <summary>
        /// Select AndClearTextBox
        /// </summary>
        /// <param name="Element"></param>
        public void SelectAllAndClearField(IWebElement Element)
        {
            Element.Click();
            Driver.WaitForReady();
            Element.SendKeys(Keys.Control + "a");
            Element.SendKeys(Keys.Backspace);
        }      

        /// <summary>
        /// Switch To Frame After Tab Click
        /// </summary>
        /// <param name="TabElement"></param>
        /// <param name="FrameName"></param>
        public void SwitchToFrameAfterTabClick(IWebElement TabElement,IWebElement FrameName)
        {
            SwitchToContentFrameAndTabClick(TabElement);
            Driver.SwitchToFrame(FrameName, "Switch to Child Frame");
        }

        /// <summary>
        /// Switch To Content Frame Tab Click
        /// </summary>
        /// <param name="TabElement"></param>
        public void SwitchToContentFrameAndTabClick(IWebElement TabElement)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            SwitchToContentFrame();
            TabElement.ClickElement("Click On Tab", Driver);
        }

        /// <summary>
        /// Add Records In Table
        /// </summary>
        /// <param name="Table"></param>
        /// <param name="TableFrame"></param>
        /// <param name="TableKey"></param>
        public void AddRecordsInTable(IWebElement Table, IWebElement TableFrame,string TableKey)
        {
            TableData TableData = CommonUtil.DataObjectForKey(TableKey).ToObject<TableData>();
            if (TableData != null)
            {
                Driver.SwitchToFrame(TableFrame, "Switch to Child Frame");
                List<TableRowsList> TableRowsList = TableData.Table.TableRowsList;
                foreach (TableRowsList TableItems in TableRowsList)
                {
                    List<TableItemsList> TableItemsList = TableItems.TableItemsList;
                    foreach (TableItemsList TableRowsItem in TableItemsList)
                    {
                        Driver.WaitForReady();
                        IWebElement ActionElement = null;
                        if (TableRowsItem.LOV)
                        {
                            ActionElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, TableRowsItem.Attribute);
                            SelectAllAndClearField(ActionElement);
                            _lov.SearchAndSelectLOVData(ActionElement, TableRowsItem.ItemValue);
                            SwitchToContentFrame();
                            Driver.SwitchToFrame(TableFrame, "Frame");
                        }
                        else if (TableRowsItem.SetText)
                        {
                            ActionElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, TableRowsItem.Attribute);
                            SelectAllAndClearField(ActionElement);
                            Driver.WaitForReady();
                            ActionElement.SetText(TableRowsItem.ItemValue, TableRowsItem.ItemName);
                        }
                        else if (TableRowsItem.SetCheckBox)
                        {
                            ActionElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, TableRowsItem.Attribute);
                            Driver.WaitForReady();
                            SetCheckBox(ActionElement, TableRowsItem.ItemName, TableRowsItem.SelectCheckBox);
                        }
                        else if (TableRowsItem.DropDown)
                        {
                            ActionElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, TableRowsItem.Attribute);
                            SelectAllAndClearField(ActionElement);
                            Driver.WaitForReady();
                            ActionElement.ClickDropDownValuebyContainingText(TableRowsItem.ItemValue);
                        }
                        else if (TableRowsItem.DateField)
                        {
                            ActionElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, TableRowsItem.Attribute);
                            SelectAllAndClearField(ActionElement);
                            Driver.WaitForReady();
                            if (!String.IsNullOrEmpty(TableRowsItem.ItemValue))
                            {ActionElement.SetText(TableRowsItem.ItemValue, "ItemValue");}
                            else {
                                string DateValue = CommonUtil.GenerateRandomDateString(Convert.ToInt32(TableRowsItem.NoOfDaysForDate));
                                ActionElement.SetText(DateValue, TableRowsItem.ItemName);
                            }
                        }
                    }
                }
            }
            else { Assert.Fail($"Table data for { TableKey } not found" );}      
        }

        /// <summary>
        /// Verify Records In Table
        /// </summary>
        /// <param name="Table"></param>
        /// <param name="TableFrame"></param>
        /// <param name="TableKey"></param>
        /// <param name="Attribute"></param>
        public void VerifyRecordsInTable(IWebElement Table, IWebElement TableFrame, string TableKey,string Attribute= "value")
        {
            TableData TableData = CommonUtil.DataObjectForKey(TableKey).ToObject<TableData>();
            if (TableData != null)
            {               
                Driver.SwitchToFrame(TableFrame, "Switch to Child Frame");
                List<TableRowsList> TableRowsList = TableData.Table.TableRowsList;
                foreach (TableRowsList TableItems in TableRowsList)
                {
                    int ItemNo = 1;
                    List<TableItemsList> TableItemsList = TableItems.TableItemsList;
                    foreach (TableItemsList TableRowsItem in TableItemsList)
                    {
                        IWebElement ActualElement = null;
                        if (ItemNo == 1) { ActualElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.ItemValue, TableRowsItem.ItemName, Attribute); }
                        else { ActualElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, Attribute); }
                        if (TableRowsItem.LOV || TableRowsItem.SetText || TableRowsItem.VeriFyDescription)
                            CommonUtil.VerifyElementValue(ActualElement, $"{ TableRowsItem.ItemName } -- { TableRowsItem.ItemValue}", TableRowsItem.ItemValue, false, Attribute);
                        else if (TableRowsItem.SetCheckBox)
                            CommonUtil.VerifyCheckboxState(ActualElement, $"{ TableRowsItem.ItemName } -- { TableRowsItem.SelectCheckBox} ", TableRowsItem.SelectCheckBox);
                        else if (TableRowsItem.DropDown)
                        {
                            IWebElement SelectElement = GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, Attribute, "select");
                            CommonUtil.VerifyElementValue(SelectElement, $"{ TableRowsItem.ItemName } -- { TableRowsItem.ItemValue}", TableRowsItem.ItemValue, true, Attribute);
                        }
                        ItemNo++;
                    }
                }
            }
            else { Assert.Fail($"Table data for { TableKey } not found"); }
        }

        /// <summary>
        /// Delete Record sFrom Table
        /// </summary>
        /// <param name="Table"></param>
        /// <param name="TableFrame"></param>
        /// <param name="TableKey"></param>
        /// <param name="Attribute"></param>
        public void DeleteRecordsFromTable(IWebElement Table, IWebElement TableFrame, string TableKey, string Attribute = "value",int ActiveColForNo=1)
        {          
            TableData TableData = CommonUtil.DataObjectForKey(TableKey).ToObject<TableData>();
            if (TableData != null)
            {              
                Driver.SwitchToFrame(TableFrame, "Switch to Child Frame");
                List<TableRowsList> TableRowsList = TableData.Table.TableRowsList;
                foreach (TableRowsList TableItems in TableRowsList)
                {
                    int ColNo = 1;
                    List<TableItemsList> TableItemsList = TableItems.TableItemsList;                    
                    foreach (TableItemsList TableRowsItem in TableItemsList)
                    {
                        if (ColNo == ActiveColForNo)
                        {
                            Driver.WaitForReady();
                            if (ColNo == 1) { GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.ItemValue, TableRowsItem.ItemName, Attribute).Click(); }
                            else { GetTableActionElementByRelatedColumnValue(Table, TableRowsItem.HeaderName, TableRowsItem.SearchValue, TableRowsItem.ItemName, Attribute).Click(); }
                            DeleteAndSave();
                            Driver.SwitchToFrame(TableFrame, "TableFrame");
                            break;
                        }
                        ColNo++;
                    }
                }
            }
            else { Assert.Fail($"Table data for { TableKey } not found"); }
        }

        /// <summary>
        /// Verify Record Deletion From Table
        /// </summary>
        /// <param name="Table"></param>
        /// <param name="TableFrame"></param>
        /// <param name="TableKey"></param>
        /// <param name="Attribute"></param>
        public void VerifyRecordDeletionFromTable(IWebElement Table, IWebElement TableFrame, string TableKey, string Attribute = "value")
        {
            TableData TableData = CommonUtil.DataObjectForKey(TableKey).ToObject<TableData>();
            Driver.SwitchToFrame(TableFrame, "Switch to Child Frame");
            if (TableData != null)
            {            
                List<TableRowsList> TableRowsList = TableData.Table.TableRowsList;
                foreach (TableRowsList TableItems in TableRowsList)
                {
                    List<TableItemsList> TableItemsList = TableItems.TableItemsList;
                    foreach (TableItemsList TableRowsItem in TableItemsList)
                    {
                        VerifyTableColumnDoesNotContainValue(Table, TableRowsItem.HeaderName, TableRowsItem.ItemValue, Attribute);
                        break;
                    }
                }
            }
            else { Assert.Fail($"Table data for { TableKey } not found"); }
        }

        /// <summary>
        /// Set Text With Lov Option
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="TextValue"></param>
        /// <param name="LOv"></param>
        public void SetTextWithLovOption(IWebElement Element,string TextValue,bool LOv=false,IWebElement? FrameElement=null)
        {
            if (!String.IsNullOrEmpty(TextValue))
            {
                SelectAllAndClearField(Element);
                Driver.WaitForReady();
                if (LOv) {
                    _lov.SearchAndSelectLOVData(Element, TextValue);
                    SwitchToContentFrame();
                    if (FrameElement != null) { Driver.SwitchToFrame(FrameElement, "Frame"); }
                }
                else { Element.SetText(TextValue, TextValue); }
            }
        }

        /// <summary>
        /// Set Check Box
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="ElementName"></param>
        /// <param name="CheckBoxStatus"></param>
        public void SetCheckBox(IWebElement Element,string ElementName,bool CheckBoxStatus=true)
        {
            if (CheckBoxStatus) { Element.SelectCheckBox(ElementName, CheckBoxStatus); }
            else { Element.DeSelectCheckBox(ElementName); }
        }

        /// <summary>
        /// Verify Record Created Successfully
        /// </summary>
        /// <param name="ActionElement"></param>
        /// <param name="UpdatedElement"></param>
        /// <param name="RecordNumber"></param>
        /// <param name="ElementName"></param>
        public void VerifyRecordCreatedSuccess(IWebElement ActionElement, IWebElement UpdatedElement, string RecordNumber, string ElementName)
        {
            Driver.SwitchTo().DefaultContent();
            ClickOnSaveButton();
            Driver.WaitForReady();
            RefreshAndSetText(ActionElement, RecordNumber, ElementName);
            Driver.WaitForReady();
            Assert.IsTrue(!String.IsNullOrEmpty(UpdatedElement.GetAttribute("ovalue")));
            Driver.SwitchTo().DefaultContent();
        }

        /// Verify Code Does Not Exist
        /// </summary>
        /// <param name="CodeElement"></param>
        /// <param name="CodeValue"></param>
        /// <param name="ElementName"></param>
        public void VerifyCodeDoesNotExist(IWebElement CodeElement, string CodeValue, string ElementName)
        {
            Settings.Logger.Info($"Verifying {ElementName} - {CodeValue} Does Not Exist ");
            RefreshAndSetText(CodeElement, CodeValue, ElementName);
            Driver.SwitchTo().DefaultContent();
            _dialogTitle.VerifyElementDisplay(" Dialog title ");
            string txt = _dialogTitle.Text;
            Assert.IsTrue(txt.Contains(CodeValue.ToUpper()));
            ClickOnDialogBoxButton("Cancel");
        }

        /// <summary>
        /// SaveWithRequiredAction
        /// </summary>
        /// <param name="RequiredAction"></param>
        public void SaveWithRequiredAction(string RequiredAction)
        {
            Save();
            ActionRequiredWindow(RequiredAction);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Table Row Deletion
        /// </summary>
        /// <param name="TableFrame"></param>
        /// <param name="TableRows"></param>
        /// <param name="TableName"></param>
        public void VerifyTableRowDeletion(IWebElement TableFrame, IList<IWebElement>? TableRows,string TableName)
        {
            Driver.SwitchToFrame(TableFrame, TableName);
            Driver.WaitForReady();
            int ActualCount = TableRows.Count - 1;
            CommonUtil.AssertTrue<int>(0, ActualCount);
            Settings.Logger.Info($"Successfully Verified Table deletion '{TableName}'");
        }

        /// Get Total Table Records
        /// </summary>
        /// <param name="TableID"></param>
        /// <returns></returns>
        public int GetTotalTableRecords(IWebElement TableID)
        {
            return TableID.FindElements(By.XPath("//tbody/tr")).Count;
        }

        /// <summary>
        /// Delete Table Rows Using ColumnName
        /// </summary>
        /// <param name="_table"></param>
        /// <param name="ColHeader"></param>
        /// <param name="ColAction"></param>
        /// <param name="FrameElement"></param>
        /// <param name="Attribute"></param>
        /// <param name="EleType"></param>
        /// <exception cref="Exception"></exception>
        public void DeleteTableRowsUsingColumnName(IWebElement _table, string ColHeader,string ColAction, IWebElement? FrameElement = null,bool CheckActionRequired=false, string Attribute = "value")
        {
            string txtFilter=string.Empty;
            List<string> TableRows = new List<string>(); ;
            try
            {
                string relPath = GenerateRelatedPathForActionElement(GetColumnIdByHeader(ColHeader), "input");
                IList<IWebElement> filterList = _table.FindElements(By.XPath(relPath));
                foreach (IWebElement filter in filterList)
                {
                    txtFilter = filter.GetAttribute(Attribute);
                    if (!String.IsNullOrEmpty(txtFilter)) { TableRows.Add(txtFilter); }        
                }
                if (TableRows.Count > 0) {
                    foreach (string TableRowsItem in TableRows)
                    {
                        Driver.WaitForReady();
                        GetTableActionElementByRelatedColumnValue(_table, ColHeader, TableRowsItem, ColAction, Attribute).Click();
                        DeleteAndSave();
                        if (CheckActionRequired)
                        {
                            Driver.SwitchTo().DefaultContent();
                            ActionRequiredWindow("Continue");
                            SwitchToContentFrame();
                        }
                        if (FrameElement != null) { Driver.SwitchToFrame(FrameElement, "Frame"); }
                        Settings.Logger.Info($"Table column '{ColHeader}' deleted having row item : '{txtFilter}'");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Verify Button State
        /// </summary>
        /// <param name="uiElement"></param>
        /// <param name="webElementName"></param>
        /// <param name="isEnabled"></param>
        public void VerifyFieldState(IWebElement Element,bool IsEnabled,string ElementName)
        {
            bool ActualState = Element.Enabled;
            CommonUtil.AssertTrue(IsEnabled, ActualState);
            Settings.Logger.Info($"Successfully verified { ElementName } state.");
        }

        /// <summary>
        /// Verify ReadOnly Field
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="IsEnabled"></param>
        /// <param name="ElementName"></param>
        public void VerifyReadOnlyField(IWebElement Element, bool IsEnabled, string ElementName)
        {
            bool ActualState = Element.GetAttribute("readOnly").Equals("true");
            CommonUtil.AssertTrue(IsEnabled, ActualState);
            Settings.Logger.Info($"Successfully verified { ElementName } state.");
        }

        /// <summary>
        /// Verify Empty Field
        /// </summary>
        /// <param name="CodeElement"></param>
        /// <param name="ElementName"></param>
        /// <param name="Attributr"></param>
        public void VerifyEmptyField(IWebElement CodeElement,string ElementName,string Attributr= "ovalue")
        {
            string ValueAfterDeletion = CodeElement.GetAttribute("ovalue");
            Assert.True(String.IsNullOrEmpty(ValueAfterDeletion), $"{ElementName} not deleted, found value { ValueAfterDeletion}");
            Settings.Logger.Info($"Successfully verified { ElementName } is empty .");
        }

    }
}
