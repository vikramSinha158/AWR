﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Microsoft.Extensions.Logging;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Security.Principal;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingUnitAccountsPageActions : BillingUnitAccountsPage
    {
        public BillingUnitAccountsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Update EffectiveDate And ExpenseAccount
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void AddEffectiveDateExpenseAccountRevenueAccount(BillingUnitAccountDetail UnitAccount)
        {
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.WaitForReady();
            _billDropdown.SelectDropdownUsingValue("Bill Item", UnitAccount.BillItem);
            if (UnitAccount.EffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
               "Effective Date", "", "ExpEffDate").SetText(UnitAccount.EffectiveDate, "Expense Date");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
               "Effective Date", UnitAccount.EffectiveDate, "ExpAcct").SetText(UnitAccount.ExpenseAccount, "Expense Account");
            }
            if (UnitAccount.RevenueEffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameRevenueAccount, "RevenueAccount Frame");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableRevenueAccount,
               "Effective Date", "", "EffDt").SetText(UnitAccount.RevenueEffectiveDate, "Revenue Date");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableRevenueAccount,
               "Effective Date", UnitAccount.RevenueEffectiveDate, "RevAcct").SetText(UnitAccount.RevenueAccount, "Expense Account");
            }
            Driver.WaitForReady();
            _extendedPage.Save();
            Settings.Logger.Info("Add Details of Bill Item in Unit Account is Completed Successfully!");
        }

        /// <summary>
        /// Verify Update EffectiveDate And ExpenseAccount
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void VerifyEffectiveDateExpenseAccountRevenueAccount(BillingUnitAccountDetail UnitAccount)
        {
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.WaitForReady();
            _billDropdown.SelectDropdownUsingValue("Bill Item", UnitAccount.BillItem);
            if (UnitAccount.EffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
               "Effective Date", UnitAccount.EffectiveDate, "ExpEffDate"), "Effective Date", UnitAccount.EffectiveDate, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
               "Effective Date", UnitAccount.EffectiveDate, "ExpAcct"), "Expense Account", UnitAccount.ExpenseAccount, false, "value");
            }
            if (UnitAccount.RevenueEffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameRevenueAccount, "RevenueAccount Frame");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableRevenueAccount,
               "Effective Date", UnitAccount.RevenueEffectiveDate, "EffDt"), "Revenue Date", UnitAccount.RevenueEffectiveDate, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableRevenueAccount,
               "Effective Date", UnitAccount.RevenueEffectiveDate, "RevAcct"), "Revenue Account", UnitAccount.RevenueAccount, false, "value");
            }
            Settings.Logger.Info(" Verification for Update the Details of Bill Item in Unit Account is Completed Successfully!");
        }

        /// <summary>
        /// Delete Updated Expense Account
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void DeleteEffectiveDateExpenseAccountRevenueAccount(BillingUnitAccountDetail UnitAccount)
        {
            _extendedPage.RefreshAndLeavePage();
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.WaitForReady();
            _billDropdown.SelectDropdownUsingValue("Bill Item", UnitAccount.BillItem);
            if (UnitAccount.EffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                "Effective Date", UnitAccount.EffectiveDate, "ExpAcct").Click();
            }
            if (UnitAccount.RevenueEffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameRevenueAccount, "RevenueAccount Frame");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableRevenueAccount,
                "Effective Date", UnitAccount.RevenueEffectiveDate, "RevAcct").Click();
            }
            _extendedPage.DeleteAndSave();
            Settings.Logger.Info(" Deletion for Update the Details of Bill Item in Unit Account is Completed Successfully!");
        }

        /// <summary>
        /// Verify Delete Updated Expense Account
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void VerifyDeleteEffectiveDateExpenseAccountRevenueAccount(BillingUnitAccountDetail UnitAccount)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.WaitForReady();
            _billDropdown.SelectDropdownUsingValue("Bill Item", UnitAccount.BillItem);
            if (UnitAccount.EffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                _extendedPage.VerifyTableColumnDoesNotContainValue(_tableExpenseAccount,
                    "Effective Date", UnitAccount.ExpenseAccount);
            }
            if (UnitAccount.RevenueEffectiveDate != null)
            {
                Driver.SwitchToFrame(_frameRevenueAccount, "ExpenseAccount Frame");
                _extendedPage.VerifyTableColumnDoesNotContainValue(_tableRevenueAccount,
                    "Effective Date", UnitAccount.RevenueAccount);
            }
            _extendedPage.RefreshAndLeavePage();
            Settings.Logger.Info("Verify after Deletion Bill Item in Unit Account is Completed Successfully!");
        }
        /// <summary>
        /// Add Expense Account To BillItems
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void AddExpenseAccountBillItemsWithAllCurrent(UnitAccountDetails UnitAccount)
        {
            int RowNum = 0;
            if (UnitAccount.UnitAccountExpenseTable != null) 
            {
                _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
                Driver.WaitForReady();
                foreach (UnitAccountExpenseTable UnitAccountExpenseTable in UnitAccount.UnitAccountExpenseTable)
                {
                    Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                   "Bill Item", "", "ExpBillItem").SetText(UnitAccount.BillingItemList[RowNum], "Bill Item");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                   "Bill Item", UnitAccount.BillingItemList[RowNum], "ExpAcct").SetText(UnitAccountExpenseTable.ExpenseAccount, "Expense Account");
                    Driver.WaitForReady();
                    RowNum++;
                    _extendedPage.Save();
                    _extendedPage.SwitchToContentFrame();
                }
            } else
            {
                AddExpenseAllocationBillItem(UnitAccount);
            }
            
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Add Expense Account to BillItem  Completed Successfully!");
        }

        /// <summary>
        /// Verify Expense Account of BillItems
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void VerifyExpenseAccountBillItemsWithAllCurrent(UnitAccountDetails UnitAccount)
        {
            int RowNum = 0;
            if (UnitAccount.UnitAccountExpenseTable != null)
            {
                _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
                Driver.WaitForReady();
                Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                foreach (UnitAccountExpenseTable UnitAccountExpenseTable in UnitAccount.UnitAccountExpenseTable)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                      "Bill Item", UnitAccount.BillingItemList[RowNum], "ExpBillItem"), "Bill Item", UnitAccount.BillingItemList[RowNum], false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                   "Bill Item", UnitAccount.BillingItemList[RowNum], "ExpAcct"), "Expense Account", UnitAccountExpenseTable.ExpenseAccount, false, "value");
                    RowNum++;
                }
                Driver.SwitchTo().DefaultContent();
            }
            else
            {
                VerifyExpenseAllocationBillItem(UnitAccount);
            }
            Settings.Logger.Info("Verify Expense Account to BillItem  Completed Successfully!");
        }

        /// <summary>
        /// Delete ExpenseAccount BillItems With AllCurrent
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void DeleteExpenseAccountBillItemsWithAllCurrent(UnitAccountDetails UnitAccount)
        {
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.WaitForReady();
            int RowNum = 0;
            if (UnitAccount.UnitAccountExpenseTable != null)
            {
                foreach (UnitAccountExpenseTable UnitAccountExpenseTable in UnitAccount.UnitAccountExpenseTable)
                {
                    Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                   "Bill Item", UnitAccount.BillingItemList[RowNum], "ExpAcct").Click();
                    Driver.WaitForReady();
                    RowNum++;
                    _extendedPage.DeleteAndSave();
                }
            }
            else {
                Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
               "Bill Item", UnitAccount.BillItem, "ExpAcct").Click();
                Driver.WaitForReady();
                _extendedPage.DeleteAndSave();
            }
           
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Delete Expense Account to BillItem  Completed Successfully!");
        }

        /// <summary>
        /// Verify Delete ExpenseAccount BillItems With AllCurrent
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void VerifyDeleteExpenseAccountBillItemsWithAllCurrent(UnitAccountDetails UnitAccount)
        {
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
            int RowNum = 0;
            if (UnitAccount.UnitAccountExpenseTable != null)
            {
                foreach (UnitAccountExpenseTable UnitAccountExpenseTable in UnitAccount.UnitAccountExpenseTable)
                {
                    string afterDelection= _extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                   "Bill Item", UnitAccount.BillingItemList[RowNum], "ExpAcct").GetAttribute("value");
                    Assert.IsTrue(afterDelection.Equals(""));
                    Driver.WaitForReady();
                    RowNum++;  
                }
            }
            else
            {
                string afterDelection=_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
              "Bill Item", UnitAccount.BillItem, "ExpAcct").GetAttribute("value");
                Assert.IsTrue(afterDelection.Equals(""));
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verify Deleted Expense Account to BillItem  Completed Successfully!");
        }

        /// <summary>
        /// Add Expense Allocation BillItem
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void AddExpenseAllocationBillItem(UnitAccountDetails UnitAccount)
        {
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.SwitchToFrame(_frameExpenseaccount, "ExpenseAccount Frame");
            Driver.WaitForSomeTime();
            Driver.ClickOnElement(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
               "Bill Item", UnitAccount.BillItem, "SpreadAlloc"), "Percentage");
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(_iframeContent2ExpenseAllocation, "content frame");
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_iframeExpenseAllocationAccount, "Table Frame");
            int RowNum = 0;
            foreach (ExpenseAccountAllocationTable list in UnitAccount.ExpenseAccountAllocationTable)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(
                        _tableExpenseAllocationAccount, "Expense Account", "", "ExpAllocAcct").SetText(list.ExpenseAccount, "Direct Account Number");
                Driver.WaitForReady();
                _extendedPage.SelectAllAndClearField(_extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableExpenseAllocationAccount, "Expense Account", list.ExpenseAccount, "ExpAlloc"));
                _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableExpenseAllocationAccount, "Expense Account", list.ExpenseAccount, "ExpAlloc").
                    SetText(list.Allocation, "Expense Account Number");
                RowNum++;
            }
            Driver.WaitForReady();
            _extendedPage.Save();
            Driver.ClickOnElement(_Content2closebutton, "Close Button");
            Settings.Logger.Info("Add Expense Allocation Account to BillItem  Completed Successfully!");
        }

        /// <summary>
        /// Verify Expense Allocation BillItem
        /// </summary>
        /// <param name="UnitAccount"></param>
        public void VerifyExpenseAllocationBillItem(UnitAccountDetails UnitAccount)
        {
            _extendedPage.RefreshAndSetText(_UnitNumber, UnitAccount.UnitNo, "Unit Number");
            Driver.SwitchToFrame(_frameExpenseaccount, "Table Frame");
            Driver.WaitForSomeTime();
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
                   "Bill Item", UnitAccount.BillItem, "ExpAcct"),"Expense Account",UnitAccount.ExpenseAcct,false,"value");
            Driver.ClickOnElement(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableExpenseAccount,
               "Bill Item", UnitAccount.BillItem, "SpreadAlloc"), "Percentage");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_iframeContent2ExpenseAllocation, "content frame");
            Driver.SwitchToFrame(_iframeExpenseAllocationAccount, "Table Frame");
            int RowNum = 0;
            foreach (ExpenseAccountAllocationTable list in UnitAccount.ExpenseAccountAllocationTable)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableExpenseAllocationAccount, "Expense Account", list.ExpenseAccount, "ExpAllocAcct"),
                "Expense Acct", list.ExpenseAccount, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableExpenseAllocationAccount, "Expense Account", list.ExpenseAccount, "ExpAlloc"),
                "Expense Number", list.Allocation, false, "value");
                RowNum++;
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verify Expense Allocation Account to BillItem  Completed Successfully!");
        }
    }
}
