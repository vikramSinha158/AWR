﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Booking;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingChangeDatesReasonsObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Booking
{
    internal class BookingChangeDatesReasonsPageActions:BookingChangeDatesReasonsPage
    {
        public BookingChangeDatesReasonsPageActions(IWebDriver Driver) : base(Driver) { }
        /// <summary>
        /// Create Booking Date Change Reason Code
        /// </summary>
        /// <param name="BookingDateChange"></param>
        /// <returns></returns>
        public string CreateBookingDateChangeReasonCode(BookingChangeDateDetails BookingDateChange)
        {
            if(BookingDateChange.BookingDateCode == "Random")
            {
                BookingDateChange.BookingDateCode = CommonUtil.GetRandomStringWithSpecialChars(2);
            }
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_framebokingDateChangeCode, "Table frame");
            _bokingDateChangeCode.SetText(BookingDateChange.BookingDateCode, "New Booking Date Change Code");
            _bokingDateChangeCodeDescp.SetText(BookingDateChange.BookingDateDescription, "New Booking  Date Change Description Code");
            _extendedPage.Save();
            Settings.Logger.Info("Created Booking  Date Change Reasons Code Successfully");
            return BookingDateChange.BookingDateCode;
        }
        /// <summary>
        /// Edit into Booking Date Change Reason
        /// </summary>
        /// <param name="BookingDateChange"></param>
        public void EditBookingDateChangeReason(BookingChangeDateDetails BookingDateChange)
        {
           Settings.Logger.Info("Update Booking Change Date Reason for : " + BookingDateChange.BookingDateCode);
          if (!BookingDateChange.BookingDateDisable)
                _extendedPage.GetTableActionElementByRelatedColumnValue(
         _TablebokingDateChangeCode, "Code", BookingDateChange.BookingDateCode, "Disable_Fl").DeSelectCheckBox("Disabled");
         _extendedPage.GetTableActionElementByRelatedColumnValue(
         _TablebokingDateChangeCode, "Code", BookingDateChange.BookingDateCode, "Disable_Fl").SelectCheckBox("Disabled", BookingDateChange.BookingDateDisable);
            _extendedPage.Save();
          Settings.Logger.Info("Edited Booking Date Change Reason Code");
        }
        /// <summary>
        /// Verify Booking Date Change
        /// </summary>
        /// <param name="BookingDateChange"></param>
        public void VerifyBookingDateChange(BookingChangeDateDetails BookingDateChange)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_framebokingDateChangeCode, "Table frame");
            IWebElement Code = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _TablebokingDateChangeCode, "Code", BookingDateChange.BookingDateCode, "Reason_Code");
            CommonUtil.VerifyElementValue(Code, "Booking Code", BookingDateChange.BookingDateCode, false, "value");
            IWebElement Description = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _TablebokingDateChangeCode, "Description", BookingDateChange.BookingDateDescription.ToUpper(), "Desc");
            CommonUtil.VerifyElementValue(Description, "Booking Description", BookingDateChange.BookingDateDescription.ToUpper(), false, "value");
            Settings.Logger.Info("Verified Created Booking Date Change Reasons Code Successfully");
        }

        /// Delete Booking DateChange
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteBookingDateChange(string CodeVal)
        {
            Settings.Logger.Info("Delete Booking Date Change: " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _TablebokingDateChangeCode, "Code", CodeVal, "Reason_Code").Click();
            Driver.WaitForReady();
            _extendedPage.DeleteAndSave();
            Settings.Logger.Info("Delete Booking Date Change");
        }
        /// <summary>
        /// Verify After Deletion of Booking Date Change
        /// </summary>
        public void VerifyAfterDeletionBookingDateChange(string CauseVal)
        {
            Driver.SwitchToFrame(_framebokingDateChangeCode, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_TablebokingDateChangeCode, "Code", CauseVal);
        }
    }
}
