﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking.CustomerMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Booking
{
    internal class CustomerContractCopyPageActions : CustomerContractPage
    {
        public CustomerContractCopyPageActions(IWebDriver Driver) : base(Driver) { }
        string ContractNumber = string.Empty;
        string StartDate = string.Empty;
        string AwardDate = string.Empty;
        /// <summary>
        /// Create Customer Contract
        /// </summary>
        /// <param name="CustNo"></param>
        /// <param name="DataObjectKey"></param>
        /// <returns></returns>
        public string CreateCustomerContractCopy(CreateCustomerContractCopy createCutomerContractCopy)
        {
            Settings.Logger.Info(" Creating New Customer Contract");
            _extendpage.SwitchToContentFrame();
            _contractNo.SetText(createCutomerContractCopy.contract, "Contract");
            Driver.WaitForReady();
            _newCustNumber.SetText(createCutomerContractCopy.CustomerNumber, "Customer");
            Driver.WaitForReady();
            _startDateContract.SetText(DateTime.Now.ToString(), "Current Date");
            Driver.WaitForReady();
            FillContractCopyInfo(createCutomerContractCopy.CustomerNumber);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            ContractNumber = _contractNo.GetAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return ContractNumber;
        }

        /// <summary>
        /// Fill Contract Info
        /// </summary>
        /// <param name="createCustContractObjectValues"></param>
        public void FillContractCopyInfo(string customerNumber)
        {
            Settings.Logger.Info("Edit Customer Contract Copy");
            _newCustNumber.SetText(customerNumber, "Customer Number");           
             Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Job Tab Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        public void FillJObTab(JobsTabData DataObjectValue)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Jobs"), "Jobs");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameJob, "Job Table");
            _newJob.SetText(DataObjectValue.Job, "Job");
            Driver.WaitForReady();
            _newFixedPrice.SetText(DataObjectValue.FixedPrice, "Fixed Price");
        }

        /// <summary>
        /// Verify Customer Contract
        /// </summary>
        /// <param name="ContractNo"></param>
        /// <param name="CustNo"></param>
        /// <param name="CustDesc"></param>
        /// <param name="DataObjectKey"></param>
        public void VerifyCustomerContract(string ContractNo, string CustNo, string CustDesc, string DataObjectKey)
        {
            CreateCustomerContract verifyCustContractObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CreateCustomerContract>();
            _extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            CommonUtil.VerifyElementValue(_custNumber, "Customer Number", CustNo);
            CommonUtil.VerifyElementValue(_custDescription, "Customer Description", CustDesc);
            CommonUtil.VerifyElementValue(_status, "Status", verifyCustContractObjectValues.Status, true);
            CommonUtil.VerifyElementValue(_startDate, "Start Date", StartDate);
            if (verifyCustContractObjectValues.JobsTab != null)
            {
                for (int i = 0; i < verifyCustContractObjectValues.JobsTab.Count; i++)
                {
                    VerifyJobTabData(verifyCustContractObjectValues.JobsTab[i], i);
                }
            }
        }

        /// <summary>
        /// Verify Job Tab Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyJobTabData(JobsTabData DataObjectValue, int RowNO)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Jobs"), "Jobs");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameJob, "Job Table");
            string jobDesc = _extendpage.GetTableActionElementByRelatedColumnValue(
                _tableJob, "Job", DataObjectValue.Job, "Job_Desc").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.JobDescription, jobDesc);
            string fixedPrice = _extendpage.GetTableActionElementByRelatedColumnValue(
               _tableJob, "Job", DataObjectValue.Job, "Fixed_Price").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.FixedPrice, fixedPrice);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Contract
        /// </summary>
        /// <param name="ContractNo"></param>
        public void DeleteContract(string ContractNo)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            _extendpage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
            Settings.Logger.Info($" Deleted Contract:{ContractNo}  ");
        }

        /// <summary>
        /// Verify Contract Deletion
        /// </summary>
        /// <param name="ContractNo"></param>
        public void VeriftContractDeletion(string ContractNo)
        {
            _extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            Driver.WaitForSomeTime();
            IAlert Alert = Driver.SwitchTo().Alert();
            Alert.Accept();
            Settings.Logger.Info($" Verified Contract: {ContractNo} Deleted Successfully ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Edit Contract
        /// </summary>
        /// <param name="ContractNo"></param>
        /// <param name="DataKey"></param>
        public string EditContractCopy(CreateCustomerContractCopy editContractObjectValues)
        {
            editContractObjectValues.NewCustomerNumber = editContractObjectValues.CustomerNumber;
            _extendpage.SwitchToContentFrame();
            FillContractCopyInfo(editContractObjectValues.NewCustomerNumber);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            ContractNumber = _contractNo.GetAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return ContractNumber;
        }      
    }
}
