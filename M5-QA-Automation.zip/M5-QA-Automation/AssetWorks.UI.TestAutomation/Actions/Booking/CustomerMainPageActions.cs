using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using NUnit.Framework;
using OpenQA.Selenium;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking.CustomerMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class CustomerMainPageActions : CustomerMainPage
    {
        public CustomerMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Customer Main
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <returns></returns>
        public string CreateCustomer(CustomerMain DataObject)
        {        
            string CustNo = string.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DataObject.CustomerID, ref CustNo, "CustomerMainQuery"))
            {
                Settings.Logger.Info(" Creating New Customer ");
                DataObject.CustomerID = CustNo;
                _extendpage.SwitchToContentFrame();
                _customerMainNumber.SetText(DataObject.CustomerID, "Customer Number ");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                Driver.WaitForReady();
                _customerMainDescription.SetText(DataObject.CustomerDesc, " Description ");
                _customerStatus.SelectFilterValueHavingEqualValue(DataObject.CustomerStatus);
                if (DataObject.GeneralTab != null)
                    FillGeneralTab(DataObject.GeneralTab);
                Driver.SwitchTo().DefaultContent();
                _extendpage.ClickOnSaveButton();
            }
            return DataObject.CustomerID;
        }

        /// <summary>
        /// Fill Customer Details
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillGeneralTab(GeneralTab DataObject)
        {          
            _customerAddress1.SetText(DataObject.Address1, " Address Line 1 ");           
            Driver.WaitForReady();
            _customerCity.SetText(DataObject.City, " City ");           
            Driver.WaitForReady();
            _customerZip.SetText(DataObject.Zip, " Zip ");          
            Driver.WaitForReady();
            _customerState.Click();
            Driver.WaitForReady();
            _customerState.SetText(DataObject.State, " State ");
            Driver.WaitForReady();
            _email.Click();
            _email.SendKeys(Keys.Tab);
            Driver.WaitForReady();          
            _owningDeptNo.SetText(DataObject.OwningDepartment, " Owning Department  ");         
            Driver.WaitForReady();
            _jobStatus.SetText(DataObject.InitialJobStatus, " Initial Job Status  ");            
            _billingFrequency.SelectFilterValueHavingEqualValue(DataObject.BillingFrequency);           
            Driver.WaitForReady();
            _customerType.SetText(DataObject.CustomerType, " Customer Type  ");           
        }

        /// <summary>
        /// Verify Customer Data
        /// </summary>
        /// <param name="CustomerNumber"></param>
        public void VerifyCustomerData(CustomerMain DataObject)
        {
            Settings.Logger.Info(" Verifying Customer Main Details ");
            _extendpage.RefreshAndSetText(_customerMainNumber, DataObject.CustomerID, "Customer Number ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_customerMainNumber,"", DataObject.CustomerID);                   
            CommonUtil.VerifyElementValue( _customerMainDescription,"", DataObject.CustomerDesc);
            CommonUtil.VerifyElementValue(_customerStatus, "", DataObject.CustomerStatus,true);
            if(DataObject.CheckLOVstatus==true)
            {
                VerifyLOVCustomerStatus(DataObject.CustomerID, DataObject.CustomerStatus);
            }
            GeneralTab DataObjectGeneralTab = DataObject.GeneralTab;
            if (DataObjectGeneralTab != null)            
            { 
                CommonUtil.VerifyElementValue(_customerAddress1,"", DataObjectGeneralTab.Address1);            
                CommonUtil.VerifyElementValue(_customerCity,"", DataObjectGeneralTab.City);           
                CommonUtil.VerifyElementValue(_customerState,"", DataObjectGeneralTab.State);             
                CommonUtil.VerifyElementValue(_customerZip,"", DataObjectGeneralTab.Zip);
                CommonUtil.VerifyElementValue(_customerCountry,"", DataObjectGeneralTab.Country);               
                CommonUtil.VerifyElementValue( _owningDeptNo,"", DataObjectGeneralTab.OwningDepartment);               
                CommonUtil.VerifyElementValue(_jobStatus,"", DataObjectGeneralTab.InitialJobStatus);           
                CommonUtil.VerifyElementValue(_billingFrequency,"", DataObjectGeneralTab.BillingFrequency,true);          
                CommonUtil.VerifyElementValue(_customerType,"", DataObjectGeneralTab.CustomerType);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete employee and Verify deletion       
        /// </summary>
        /// <param name="EmployeeID"></param>
        public void DeleteCustomerAndVerify(string CustNo)
        {           
            Settings.Logger.Info($" Deleting {CustNo}  ");          
            _extendpage.VerifyCodeDeletion(_customerMainNumber, CustNo, "Employee ID");           
            Settings.Logger.Info($"Customer: {CustNo} Deleted successfully  ");
        }

        /// <summary>
        /// Edit Customer Status Details      
        /// </summary>
        /// <param name="CustomerStatus"></param>
        public void EditCustomer(CustomerMain DataObject)

        {
            Settings.Logger.Info(" Edit Customer Main Details ");
            _extendpage.RefreshAndSetText(_customerMainNumber, DataObject.CustomerID, "Customer Number ");
            Driver.WaitForReady();
            _customerMainDescription.SetText(DataObject.CustomerDesc, " Description ");
            _customerStatus.SelectFilterValueHavingEqualValue(DataObject.CustomerStatus);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify LOV Customer Status       
        /// </summary>
        /// <param name="CustNo"></param>
        public void VerifyLOVCustomerStatus(string CustNo, string status)
        {
            Settings.Logger.Info($"Verifying Customer is {status} ");
            Driver.WaitForReady();
            Driver.DoubleClick(_customerMainNumber, "Customer Number");
            Driver.WaitForReady();
            string parentWindow = Driver.SwitchToNewWindow();
            Driver.WaitForReady();
            _filterDropdown.SelectFilterValueHavingEqualValue(status);
            _lov.ClickOnSearchButton();
            Driver.WaitForReady();
            _searchtext.SendKeys(CustNo);
            string searchResult = _customerSearchResult.Text.ToString();
            Assert.AreEqual(CustNo,searchResult);
            Driver.SwitchTo().Window(parentWindow);
        }
    }
}   
