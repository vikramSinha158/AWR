﻿using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.ServiceOrder;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ServiceOrder
{
    internal class ServiceOrderReceiptPageActions : ServiceOrderReceiptPage
    {
        internal ServiceOrderReceiptPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Service Order Receipt
        /// </summary>
        /// <param name="receipt"></param>
        public void CreateServiceOrderReceipt(ServiceOrderReceiptDetail receipt)
        {
            Settings.Logger.Info(" Creating Service Order Receipt ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputOrderNumber.SetText(receipt.OrderNo, "Order No");
            Driver.WaitForReady();
            _inputInvoiceNo.SetText(receipt.InvoiceNo, "Invoice No");
            Driver.WaitForReady();
            _inputEffectiveDate.SetText(receipt.EffectiveDate, "Effective Date");
            Driver.WaitForReady();
            _buttonReceiveAll.ClickElement("Receive All", Driver);
            Driver.WaitForReady();
            if (receipt.ServicesDetail != null)
                VerifyAndUpdateServicesDetail(receipt.ServicesDetail);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify And Update Services Detail
        /// </summary>
        /// <param name="services"></param>
        public void VerifyAndUpdateServicesDetail(IList<ServicesDetail> services)
        {
            Settings.Logger.Info(" Verify And Update Services Detail ");
            Driver.SwitchToFrame(_frameServices, "Services frame");
            Driver.WaitForReady();
            foreach (ServicesDetail item in services)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableServices, "Service", item.Service, "RcvCost"), "Rcv Cost", item.POCost, false, "value");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServices, "Service",
                    item.Service, "chargeCode").SelectFilterValueHavingEqualValue(item.ResvCode);
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServices, "Service",
                    item.Service, "typeNum").SetText(item.ResvRefNo, "Resv Ref No");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServices, "Service",
                    item.Service, "job").SetText(item.Job, "Job");
                if (item.CompCheck)
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServices, "Service",
                        item.Service, "completed").SelectCheckBox("Completed");
                else
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServices, "Service",
                        item.Service, "completed").DeSelectCheckBox("Completed");
            }
        }

        /// <summary>
        /// Verify Service Order Message
        /// </summary>
        /// <param name="orderNo"></param>
        public void VerifyServiceOrderMessage(string orderNo)
        {
            Settings.Logger.Info(" Verify Service Order Message ");
            _extendedPage.RefreshAndSetText(_inputOrderNumber, orderNo, "Order Number");
            Driver.WaitForSomeTime();
            string message = Driver.GetAlertText();
            CommonUtil.AssertTrue("The service order is closed or canceled.", message);
            Driver.AcceptAlert();
            Settings.Logger.Info(" Susseccfully Verified Service Order Message ");
        }
    }
}
