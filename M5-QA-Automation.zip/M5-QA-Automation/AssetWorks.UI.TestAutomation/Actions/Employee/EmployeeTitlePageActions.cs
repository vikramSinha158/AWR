﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Employee
{
    internal class EmployeeTitlePageActions : EmployeeTitlePage
    {
        public EmployeeTitlePageActions(IWebDriver Driver) : base(Driver) { }

        string Title = string.Empty;
        int Productivity = 0; 
        
        /// <summary>
        /// Create Employee Title Data
        /// </summary>
        /// <param name="TitleVal"></param>
        /// <param name="ProductivityVal"></param>
        /// <returns></returns>
        public string CreateEmployeeTitle(string TitleVal, int ProductivityVal, bool CheckDisabledCheckBox)
        {
            Settings.Logger.Info("Create Employee Title");
            _extendedPage.SwitchToTableFrame(_frameEmpTitle);
            Title = TitleVal == "random" ? CommonUtil.GetRandomStringWithSpecialChars(12, true, false).ToUpper() : TitleVal;
            Productivity = ProductivityVal;
            _inputTitle.SetText(Title, "Title");
            _inputProductivity.SetText(Productivity.ToString(), "Productivity");
            _chbDisabled.SelectCheckBox("Disabled CheckBox", CheckDisabledCheckBox);
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            return Title;
        }

       /// <summary>
       /// Verify Employee Title Data
       /// </summary>
       /// <param name="TitleVal"></param>
       /// <param name="ProductivityVal"></param>
        public void VerifyEmployeeTitleData(string TitleVal, int ProductivityVal, bool checkBoxToVerify)
        {
            string cellprod = string.Empty; 
            bool chkActaulValue;  
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameEmpTitle, "Table frame");
            Settings.Logger.Info("Verify Employee Title data for : " + TitleVal);
            if (!string.IsNullOrEmpty(TitleVal) && !string.IsNullOrEmpty(ProductivityVal.ToString()))
            {
                 cellprod = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEmpTitles, "Title", TitleVal, "PROD_PCENT").GetAttribute("value");                
            }
            CommonUtil.AssertTrue(cellprod, ProductivityVal.ToString());          
            chkActaulValue = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEmpTitles, "Title", TitleVal, "DISABLED_FL").GetAttribute("value") == "Y" ? true : false;
            CommonUtil.AssertTrue<bool>(checkBoxToVerify, chkActaulValue);                     
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
        }

        /// <summary>
        /// Update and Verify Employee Title Data
        /// </summary>
        /// <param name="TitleVal"></param>
        /// <param name="ProductivityVal"></param>
        public void UpdateAndVerifyEmployeeTitleData(string TitleVal, int ProductivityVal,bool DisabledCkhState)
        {            
            Settings.Logger.Info("Update Employee Title :");
            _extendedPage.SwitchToTableFrame(_frameEmpTitle);
            if (!string.IsNullOrEmpty(TitleVal) && !string.IsNullOrEmpty(ProductivityVal.ToString()))
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEmpTitles, "Title", TitleVal, "PROD_PCENT").SetText(ProductivityVal.ToString(), "Productivity");
                if (DisabledCkhState)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEmpTitles, "Title", TitleVal, "DISABLED_FL").Click();
                }
            }
            else
            {
                Assert.Fail("Data to Update Employee Title Record is Null");
            }
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            VerifyEmployeeTitleData(TitleVal, ProductivityVal, DisabledCkhState);        
        }

        /// <summary>
        /// Delete Employee Title
        /// </summary>
        /// <param name="TitleVal"></param>
        public void DeleteEmployeeTitle(string TitleVal)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameEmpTitle, "Table frame");
            Settings.Logger.Info("Deleting Employee Title : " + TitleVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEmpTitles, "Title", TitleVal, "JOB_TITLE").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Deleted Employee Title
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedEmployeeTitle(string TitleVal)
        {         
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameEmpTitle, "Table frame");
            Settings.Logger.Info("Verify Employee Title Data is Deleted for : " + TitleVal);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableEmpTitles, "Title", TitleVal);
            Driver.SwitchTo().DefaultContent();
        }
    }
    }

