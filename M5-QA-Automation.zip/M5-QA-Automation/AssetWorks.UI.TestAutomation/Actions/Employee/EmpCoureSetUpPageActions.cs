﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Employee;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Employee
    {
    internal class EmpCoureSetUpPageActions : EmployeeCourseSetUpPage
    {

        public EmpCoureSetUpPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Employee Training Course
        /// </summary>
        /// <param name="CourseObject"></param>
        /// <returns></returns>
        public string CreateEmployeeTrainingCourse(TrainingCourseSetUp CourseObject)
        {               
            if (CourseObject.Code == null)
            {
                CourseObject.Code = "random";
            }
            string CourseCode=string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(CourseObject.Code, ref CourseCode, "CourseQuery",6))
            {
                CourseObject.Code = CourseCode;
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_courseFrame, "Couse Table frame");
                Settings.Logger.Info($"Creating Training Course :-{ CourseObject.Code}");
                _code.SetText(CourseObject.Code, "New code");
                _codeDescription.SetText(CourseObject.Description, "New code desc");
                _daysValid.SetText(CourseObject.DaysValid, "DaysValid");
                Driver.WaitForReady();
                _resourceType.SetText(CourseObject.ResourceType, "ResourceType");
                Driver.WaitForReady();
                _VendorNo.SetText(CourseObject.VendorNo, "VendorNo");
                _chbDisabled.SelectCheckBox("Disabled", CourseObject.Disabled);
                _extendedPage.SaveAndChackWarning();
                Settings.Logger.Info($"Completed Creating Training Course :-{ CourseObject.Code}");
            }
            return CourseObject.Code;
        }       

        /// <summary>
        /// Verify Employee Training Course
        /// </summary>
        /// <param name="CourseObject"></param>
        public void VerifyEmployeeTrainingCourse(TrainingCourseSetUp CourseObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_courseFrame, "Course frame");
            Settings.Logger.Info($"Verifying Training Course :-{ CourseObject.Code}");      
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "desc"), "Course Description", CourseObject.Description,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "daysValid"), "Days Valid", CourseObject.DaysValid, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "resourceType"), "Resource Type", CourseObject.ResourceType, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "VendorNo"), "Vendor No", CourseObject.VendorNo, false, "value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "disabled"), "Disabled CheckBox", CourseObject.Disabled);
            Settings.Logger.Info($" Training Course :-{ CourseObject.Code} verified Successfully");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Edit Employee Training Course
        /// </summary>
        /// <param name="CourseObject"></param>
        public void EditEmployeeTrainingCourse(TrainingCourseSetUp CourseObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_courseFrame, "Course frame");
            Settings.Logger.Info($"Editing Training Course :-{ CourseObject.Code}");
            Driver.WaitForReady();
            if (CourseObject.Disabled)
            {  _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "disabled").SelectCheckBox("Select Disabled CheckBox", CourseObject.Disabled); }
            else
            { _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "disabled").DeSelectCheckBox("Uncheck Disabled CheckBox");}
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "desc").SetText(CourseObject.Description, "Course Description");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "daysValid").SetText(CourseObject.DaysValid, "Days Valid");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "resourceType").SetText( CourseObject.ResourceType, "Resource Type");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "VendorNo").SetText( CourseObject.VendorNo, "Vendor No");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCourse, "Code", CourseObject.Code, "disabled").SelectCheckBox("Select Disabled CheckBox", CourseObject.Disabled);
             _extendedPage.Save();
            Settings.Logger.Info($"Completed Editing Training Course :-{ CourseObject.Code}");
        }

        /// <summary>
        /// Delete Training Course
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteTrainingCourse(string CodeVal)
        {            
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_courseFrame, "Course frame");
            Settings.Logger.Info("Deleting Training Course : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
           _tableCourse, "Code", CodeVal, "desc").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
        }


        /// <summary>
        /// Verify Training Course Deletion
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedTrainingCourse(string CodeVal)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_courseFrame, "Course frame");
            Settings.Logger.Info("Verify Training Course Deletion : " + CodeVal);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableCourse, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
        }

    }
    }   
