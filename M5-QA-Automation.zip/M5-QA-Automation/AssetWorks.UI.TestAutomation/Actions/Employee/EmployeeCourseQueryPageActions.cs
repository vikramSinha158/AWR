using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmployeeCourseQueryPageActions : EmployeeCourseQueryPage
    {
        public EmployeeCourseQueryPageActions(IWebDriver Driver) : base(Driver) { }   

        /// <summary>
        /// Enter COurse Query Data
        /// </summary>
        /// <param name="QueryDataObject"></param>
        public void EnterCourseQueryData(EmployeeCourseQueryData QueryDataObject)
        {
            Settings.Logger.Info($" Entering Query Data Fields");
            _extendpage.SwitchToContentFrame();
            _clearBtn.ClickElement("Clear Button",Driver);
            Driver.WaitForReady();
            _course.SetText(QueryDataObject.Course, "Course");
            Driver.WaitForReady();
            _location.SetText(QueryDataObject.Location, "Location");
            Driver.WaitForReady();
            _employee.SetText(QueryDataObject.Employee, "Employee");
            Driver.WaitForReady();
            _resourceType.SetText(QueryDataObject.ResourseType, "ResourseType");
            Driver.WaitForReady();
            _attPlanNext.SelectFilterValueHavingEqualValue(QueryDataObject.AttPlanNext);
            Driver.WaitForReady();
            _vendorNo.SetText(QueryDataObject.VendorNo, "VendorNo");
            Driver.WaitForReady();
            _fromDate.SetText(QueryDataObject.FromDate, "FromDate");
            Driver.WaitForReady();
            _toDate.SetText(QueryDataObject.ToDate, "ToDate");
            Driver.WaitForReady();
            _retrieveBtn.ClickElement("Retrieve Btn", Driver);
            Driver.WaitForReady();           
        }


        /// <summary>
        /// Verify Employee Training Transcipt
        /// </summary>
        /// <param name="EmpTTObject"></param>
        public void VerifyCourseAttendQueryHistory(List<VerifyQueryResult> VerifyQueryResult, int TotalCourseAttended)
        {
            Settings.Logger.Info("Verify Retrieved Course Attend Query History ");
            Driver.SwitchToFrame(_courseAttendQryFrame, "CourseAttendQuery Frame");           
            CommonUtil.AssertTrue<int>(TotalCourseAttended, _extendpage.GetTotalTableRecords(_courseAttendQryTable));
            for (int i = 0; i < VerifyQueryResult.Count; i++)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, Location), "Location", VerifyQueryResult[i].Location, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, Employee), "Employee", VerifyQueryResult[i].Employee, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, ResourceType), "Resource Type", VerifyQueryResult[i].ResourseType, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, VendorNo), "Vendor No", VerifyQueryResult[i].VendorNo, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, DatePlanned), "Date Planned", VerifyQueryResult[i].DatePlanned, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, DateAttended), "Date Attended", VerifyQueryResult[i].DateAttended, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, NextDate), "Next Date", VerifyQueryResult[i].NextDate, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, Mark), "Mark", VerifyQueryResult[i].Mark, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, Result), "Result", VerifyQueryResult[i].Result, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_courseAttendQryTable, "Course", VerifyQueryResult[i].Course, Certificate), "Certificate", VerifyQueryResult[i].Certificate, false, "value");
            }
            Settings.Logger.Info("Retrieved Course Attend Query History Verified Successfully");        
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Get Updated Verify Query Result Object
        /// </summary>
        /// <param name="empObject"></param>
        /// <param name="CourseCode"></param>
        /// <param name="verifyQueryResultsObj"></param>
        /// <returns></returns>
        public List<VerifyQueryResult> GetUpdatedVerifyQueryResultObject(EmpTrainingTranscipt empObject,string? CourseCode, List<VerifyQueryResult> verifyQueryResultsObj)
        {            
            for (int i = 0; i < verifyQueryResultsObj.Count; i++)
            {
                verifyQueryResultsObj[i].DatePlanned = empObject.TrainingCourseData[i].Planned;
                verifyQueryResultsObj[i].DateAttended = empObject.TrainingCourseData[i].Attended;
                verifyQueryResultsObj[i].NextDate = empObject.TrainingCourseData[i].ValidUntil;
                if(!string.IsNullOrEmpty(CourseCode))
                verifyQueryResultsObj[i].Course = CourseCode;
            }
            return verifyQueryResultsObj;
        }

      
    }
}


