﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Employee;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Employee
{
    internal class EmployeeItemsPageActions : EmployeeItemsPage
    {
        public EmployeeItemsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Assign Items To Employee
        /// </summary>
        /// <param name="Items"></param>
        public void AssignItemsToEmployee(EmployeeItems Items)
        {
            Settings.Logger.Info(" Assign Items To Employee ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeId.SetText(Items.EmployeeID, "Employee ID");
            Driver.WaitForReady();
            if (Items.ItemInformation != null)
            {
                int rowId = 0;
                Driver.SwitchToFrame(_employeeItemFrame, "Employee Item Frame");
                foreach(ItemInformation itemD in Items.ItemInformation)
                {
                    _inputEmployeeItem(rowId.ToString()).SetText(itemD.Item, "Item");
                    Driver.WaitForReady();
                    _inputValueField(rowId.ToString()).SetText(itemD.Value, "Value");
                    rowId++;
                }

            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Assigned Items To Employee
        /// </summary>
        /// <param name="Items"></param>
        public void VerifyAssignedItemsToEmployee(EmployeeItems Items)
        {
            Settings.Logger.Info(" Verify Assigned Items To Employee ");
            _extendedPage.RefreshAndSetText(_inputEmployeeId, Items.EmployeeID, "Employee ID");
            Driver.WaitForSomeTime();
            if (Items.ItemInformation != null)
            {
                Driver.SwitchToFrame(_employeeItemFrame, "Employee Item Frame");
                foreach (ItemInformation itemD in Items.ItemInformation)
                {
                    _extendedPage.VerifyTableColumnContainValue(_employeeItemTable, "Item", itemD.Item);
                    if (itemD.Value != null)
                    {
                        string value = _extendedPage.GetTableActionElementByRelatedColumnValue(_employeeItemTable, "Item", 
                            itemD.Item, "value").GetAttribute("value");
                        CommonUtil.AssertTrue(value, itemD.Value);
                    }
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Remove Assigned Items To Employee
        /// </summary>
        /// <param name="Items"></param>
        public void RemoveAssignedItemsToEmployee(EmployeeItems Items)
        {
            Settings.Logger.Info(" Remove Assigned Items To Employee ");
            _extendedPage.RefreshAndSetText(_inputEmployeeId, Items.EmployeeID, "Employee ID");
            Driver.WaitForSomeTime();
            if (Items.ItemInformation != null)
            {
                Driver.SwitchToFrame(_employeeItemFrame, "Employee Item Frame");
                foreach (ItemInformation itemD in Items.ItemInformation)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_employeeItemTable, "Item", itemD.Item, "value").Click();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnDeleteButton();
                    _extendedPage.SwitchToTableFrame(_employeeItemFrame);
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Update Assigned Items To Employee
        /// </summary>
        /// <param name="Items"></param>
        public void UpdateAssignedItemsToEmployee(EmployeeItems Items)
        {
            Settings.Logger.Info(" Update Assigned Items To Employee ");
            _extendedPage.RefreshAndSetText(_inputEmployeeId, Items.EmployeeID, "Employee ID");
            Driver.WaitForSomeTime();
            if (Items.ItemInformation != null)
            {
                Driver.SwitchToFrame(_employeeItemFrame, "Employee Item Frame");
                foreach (ItemInformation itemD in Items.ItemInformation)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_employeeItemTable, "Item", 
                        itemD.Item, "value").SetText(itemD.Value, "Value");
                    Driver.WaitForReady();
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Assigned Items Deleted From Employee
        /// </summary>
        /// <param name="Items"></param>
        public void VerifyAssignedItemsDeletedFromEmployee(EmployeeItems Items)
        {
            Settings.Logger.Info(" Verify Assigned Items Deleted From Employee ");
            _extendedPage.RefreshAndSetText(_inputEmployeeId, Items.EmployeeID, "Employee ID");
            Driver.WaitForSomeTime();
            if (Items.ItemInformation != null)
            {
                Driver.SwitchToFrame(_employeeItemFrame, "Employee Item Frame");
                foreach (ItemInformation itemD in Items.ItemInformation)
                {
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_employeeItemTable, "Item", itemD.Item);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
