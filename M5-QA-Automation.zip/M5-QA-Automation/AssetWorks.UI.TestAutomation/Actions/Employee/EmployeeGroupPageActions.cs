﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Employee;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Employee
{
    internal class EmployeeGroupPageActions : EmployeeGroupPage
    {
        internal EmployeeGroupPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Employee Group
        /// </summary>
        /// <param name="Location"></param>
        /// <param name="Group"></param>
        /// <returns></returns>
        public string CreateEmployeeGroup(string Location, string Group = "random")
        {
            string GroupCode;
            Settings.Logger.Info(" Create a new Employee Group ");
            if (Group.ToLower().Equals("random"))
                GroupCode = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
            else
                GroupCode = Group.ToUpper();
            _extendedPage.SwitchToContentFrame();
            _inputEmpLocation.SetText(Location, "Location");
            Driver.WaitForReady();
            _inputEmpGroup.SetText(GroupCode, "Group Code");
            Driver.SwitchTo().DefaultContent();
            if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                _extendedPage.ClickOnDialogBoxButton("Create");
            _extendedPage.VerifyCreatedActionNumber(_inputEmpGroup, GroupCode);
            return GroupCode;
        }

        /// <summary>
        /// Retrieve Employee Group
        /// </summary>
        /// <param name="Location"></param>
        /// <param name="GroupCode"></param>
        public void RetrieveEmployeeGroup(string Location, string GroupCode)
        {
            Settings.Logger.Info(" Retrieve Employee Group Information");
            _extendedPage.RefreshAndSetText(_inputEmpLocation, Location, "Location");
            Driver.WaitForReady();
            Driver.DoubleClick(_inputEmpGroup, "Group Code");
            _lov.SearchAndClickElement(GroupCode);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Assigned Employee In Group
        /// </summary>
        /// <param name="EmployeeName"></param>
        /// <param name="EmployeeTitle"></param>
        public void VerifyAssignedEmployeeInGroup(string EmployeeName, string EmployeeTitle)
        {
            Settings.Logger.Info(" Verify Assigned Employee In Group");
            _extendedPage.SwitchToTableFrame(_frameGroupView);
            string cellVal = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableEmpGroup, "Employee Name", EmployeeName, "jobtitle").GetAttribute("value");
            CommonUtil.AssertTrue(EmployeeTitle, cellVal);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Include Assigned Employee In Group
        /// </summary>
        /// <param name="EmployeeName"></param>
        public void IncludeAssignedEmployeeInGroup(string EmployeeName)
        {
            Settings.Logger.Info(" Include Assigned Employee In Group");
            _extendedPage.SwitchToTableFrame(_frameGroupView);
            IWebElement disabled = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableEmpGroup, "Employee Name", EmployeeName, "disabled");
            if (disabled.GetAttribute("value") == "N")
            {
                disabled.Click();
                Settings.Logger.Info($" Included In Group");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
            }
            else
                Settings.Logger.Info($"{EmployeeName} - Already Included In Group");
        }

        /// <summary>
        /// Verify Employee Link
        /// </summary>
        /// <param name="Employee"></param>
        /// <param name="EmployeeName"></param>
        public void VerifyEmployeeLink(string Employee, string EmployeeName)
        {
            Settings.Logger.Info(" Verify Assigned Employee In Group");
            _extendedPage.SwitchToTableFrame(_frameGroupView);
            GetEmpLinkByText(Employee).Click();
            string parentWindow = Driver.SwitchToNewWindow();
            EmployeeMainPageActions Emp = new EmployeeMainPageActions(Driver);
            Emp.VerifyEmployeeInfo(Employee, EmployeeName);
            Driver.SwitchTo().Window(parentWindow);
        }


        /// <summary>
        /// Delete Employee Group
        /// </summary>
        /// <param name="Location"></param>
        /// <param name="GroupCode"></param>
        public void DeleteEmployeeGroup(string Location, string GroupCode)
        {
            Settings.Logger.Info(" Retrieve Employee Group Information");
            RetrieveEmployeeGroup(Location, GroupCode);
            _extendedPage.SwitchToContentFrame();
            _inputEmpGroup.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            string ValueAfterDeletion = _inputEmpGroup.GetAttribute("ovalue");
            Assert.True(String.IsNullOrEmpty(ValueAfterDeletion), $"Group Code not deleted, found value {ValueAfterDeletion}");
            Settings.Logger.Info($"Group Code-{GroupCode} Deleted successfully  ");
        }
    }
}
