﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmployeeShiftAssignPageActions : EmployeeShiftAssignmentPage
    {
        public EmployeeShiftAssignPageActions(IWebDriver Driver) : base(Driver) { }
        string EffectiveDate;
        /// <summary>
        /// Assign Shift Code
        /// </summary>
        /// <param name="EmployeeNo"></param>
        /// <param name="DataObjectKey"></param>
        /// <returns></returns>
        public string AssignShifts(string EmployeeNo, string DataObjectKey)
        {
            string CurrentAssignedShift=string.Empty;
            EmployeeShiftAssign createEmpObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<EmployeeShiftAssign>();
            _extendedPage.SwitchToContentFrame();
            _inputEmpID.SetText(EmployeeNo, "Employee No");
            Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            for (int i = 0; i < createEmpObjectValues.ShiftData.Count; i++)
            {
                _shiftCode.SetText(createEmpObjectValues.ShiftData[i].ShiftCode, "Shift Code");
                
                if (!string.IsNullOrEmpty(createEmpObjectValues.ShiftData[i].EffectiveDate))
                {
                    EffectiveDate=CommonUtil.GenerateRandomDateString(Convert.ToInt32(createEmpObjectValues.ShiftData[i].EffectiveDate));               
                    Driver.WaitForReady();
                    _effDt.SetText(EffectiveDate, "EffectiveDate");
                    if (createEmpObjectValues.ShiftData[i].EffectiveDate == "0") { CurrentAssignedShift = createEmpObjectValues.ShiftData[i].ShiftCode; }
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            }
            return CurrentAssignedShift;
        }
        /// <summary>
        /// Verify Assign Shift
        /// </summary>
        /// <param name="EmployeeNo"></param>
        /// <param name="DataObjectKey"></param>
        public void VerifyAssignShifts(string EmployeeNo, string DataObjectKey)
        {
            EmployeeShiftAssign createEmpObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<EmployeeShiftAssign>();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputEmpID, EmployeeNo, "EmployeeNo");
            Driver.WaitForReady();
            Settings.Logger.Info("Verify Employee Shift Assignment");
            Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            for (int i = 0; i < createEmpObjectValues.ShiftData.Count; i++)
            {
                if (!string.IsNullOrEmpty(createEmpObjectValues.ShiftData[i].EffectiveDate))
                {
                    EffectiveDate = CommonUtil.GenerateRandomDateString(Convert.ToInt32(createEmpObjectValues.ShiftData[i].EffectiveDate));
                }
                Driver.WaitForReady();
                string cellEffDAte = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _shiftAssignTable, "Shift", createEmpObjectValues.ShiftData[i].ShiftCode, "effDt").GetAttribute("value");
                CommonUtil.AssertTrue(EffectiveDate, cellEffDAte);
               
            }
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Delete Employee Shift Code
        /// </summary>
        /// <param name="EmployeeNo"></param>
        /// <param name="DataObjectKey"></param>
        public void DeleteAssignShifts(string EmployeeNo, string DataObjectKey)
        {
            EmployeeShiftAssign createEmpObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<EmployeeShiftAssign>();          
            _extendedPage.RefreshAndSetText(_inputEmpID, EmployeeNo, "EmployeeNo");
            Driver.WaitForReady();
            Settings.Logger.Info("Delete Shift Assignment");
            Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            for (int i = 0; i < createEmpObjectValues.ShiftData.Count; i++)
            {         
              if (!(createEmpObjectValues.ShiftData[i].EffectiveDate == "0"))
                {
                     _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _shiftAssignTable, "Shift", createEmpObjectValues.ShiftData[i].ShiftCode, "effDt").ClickElement("Effective Date", Driver);
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnDeleteButton();
                    _extendedPage.ClickOnSaveButton();
                    _extendedPage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
                }
            }
           
        }
        /// <summary>
        /// Verify Deleted Shift Code
        /// </summary>
        /// <param name="EmployeeNo"></param>
        /// <param name="DataObjectKey"></param>
        public void VerifyDeletedAssignShifts(string EmployeeNo, string DataObjectKey)
        {
            EmployeeShiftAssign createEmpObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<EmployeeShiftAssign>();
             Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputEmpID, EmployeeNo, "EmployeeNo");
            Driver.WaitForReady();
            Settings.Logger.Info("Verify Deleted Shift Assignment");
            Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            for (int i = 0; i < createEmpObjectValues.ShiftData.Count; i++)
            {
                Driver.WaitForReady();
                if (!(createEmpObjectValues.ShiftData[i].EffectiveDate == "0"))
                {
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_shiftAssignTable, "Shift", createEmpObjectValues.ShiftData[i].ShiftCode);                    
                }
            }
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
        }
    }    
}

