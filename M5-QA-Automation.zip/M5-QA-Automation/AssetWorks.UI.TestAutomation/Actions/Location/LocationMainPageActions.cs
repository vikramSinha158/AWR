﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class LocationMainPageActions : LocationMainPage
    {
        public LocationMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Location Main
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public string CreateLocation(LocationMain DataObject)
        {
            string LocationName = String.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DataObject.Location, ref LocationName, "LocationMainQuery", 6))
            {
                DataObject.Location = LocationName;
                Settings.Logger.Info($" Creating Location: {LocationName}");
                _extendpage.SwitchToContentFrame();
                _genloc.SetText(DataObject.Location, "Location Name");
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                _locDesc.SetText(DataObject.LocationDesc, "Location Description");
                _disabledChk.SelectFilterValueHavingEqualValue(DataObject.Disabled);
                if (DataObject.GeneralTab != null)
                {
                    FillGeneralTab(DataObject.GeneralTab);
                }
                if (DataObject.ConfigurationTab != null)
                {
                    FillConfigurationTab(DataObject.ConfigurationTab);
                }
                if (DataObject.HierarchyTab != null)
                {
                    FillHierarchyTab(DataObject.HierarchyTab);
                }
                if (DataObject.InventoryTab != null)
                {
                    FillInventoryTab(DataObject.InventoryTab);
                }
                if (DataObject.MaintenanceTab != null)
                {
                    FillMaintenanceTab(DataObject.MaintenanceTab);
                }
                Driver.SwitchTo().DefaultContent();
                _extendpage.ClicKSave();
                _extendpage.RefreshAndSetText(_genloc, DataObject.Location, "Location");
                Driver.PageScrollUp();
            }
            return DataObject.Location;
        }

        /// <summary>
        /// Fill General Information Tab data
        /// </summary>
        /// <param name="GeneralInfoTabObj"></param>
        public void FillGeneralTab(GeneralInfoTab GeneralInfoTabObj)
        {
            Settings.Logger.Info(" Filling General Tab Data ");
            _state.SetText(GeneralInfoTabObj.State, "State");
            Driver.WaitForReady();
            _country.SetText(GeneralInfoTabObj.Country, " Country ");
            Driver.WaitForReady();
            _timeZone.SetText(GeneralInfoTabObj.TimeZone, " TimeZone ");
        }

        /// <summary>
        /// Fill Configuration Tab Data
        /// </summary>
        /// <param name="ConfigurationTabObject"></param>
        public void FillConfigurationTab(ConfigurationTab ConfigurationTabObject)
        {
            Settings.Logger.Info(" Filling Configuration Tab");
            ScrollUpAndSelectTab(_configurationTab, "Configuration Tab");
            Driver.WaitForReady();
            _fuellocfl.SelectCheckBox("FuelLocation", ConfigurationTabObject.FuelLocation);
            _deliverylocfl.SelectCheckBox("DeliveryLocation", ConfigurationTabObject.DeliveryLocation);
            _parklocfl.SelectCheckBox("ParkingLocation", ConfigurationTabObject.ParkingLocation);
            _motorpoolfl.SelectCheckBox("MotorPoolLocation", ConfigurationTabObject.MotorPoolLocation);
            _replusagefactor.SetText(ConfigurationTabObject.LTDUsageFactor, "Replacement LTD Usage Factor");
            Driver.WaitForReady();
            _resDURATION.SetText(ConfigurationTabObject.ReservationDuration, "Reservation Duration");
        }

        /// <summary>
        /// Fill Hierarchry Tab Data
        /// </summary>
        /// <param name="HierarchyTabObject"></param>
        public void FillHierarchyTab(HierarchyTab HierarchyTabObject)
        {
            Settings.Logger.Info(" Filling Hierarchy Tab ");
            ScrollUpAndSelectTab(_hierarchyTab, "Hierarchy Tab");
            Driver.WaitForReady();
            _deptNo.SetText(HierarchyTabObject.Department, "Department");
        }

        /// <summary>
        /// Fill Inventory Tab Data
        /// </summary>
        /// <param name="InventoryTabObject"></param>
        public void FillInventoryTab(InventoryTab InventoryTabObject)
        {
            Settings.Logger.Info(" Filling Inventory Tab ");
            ScrollUpAndSelectTab(_InventoryTab, "Inventory Tab");
            Driver.WaitForReady();
            _invlocfl.SelectCheckBox("Inventory Location");
            Driver.WaitForReady();         
            _overheadCost.SetText(InventoryTabObject.OverheadCost, "OverheadCost");
            Driver.WaitForReady();
            _carryingCost.SetText(InventoryTabObject.CarryingCost, "CarryingCost");
            Driver.WaitForReady();
            _reqApproval.SelectCheckBox("Req Approval", InventoryTabObject.ManualReq);
            _autoReqApproval.SelectCheckBox("Auto Req Approval", InventoryTabObject.AutoReq);
            _supervisor.SetText(InventoryTabObject.Supervisor, "Supervisor");
        }

        /// <summary>
        /// Fill Maintenance Tab Data
        /// </summary>
        /// <param name="MaintenanceTabObject"></param>
        public void FillMaintenanceTab(MaintenanceTab MaintenanceTabObject)
        {
            Settings.Logger.Info(" Filling Maintenance Tab ");
            ScrollUpAndSelectTab(_MaintenanceTab, "Maintenance Tab");
            Driver.WaitForReady();
            _maintlocfl.SelectCheckBox("Maintenance Location Checkbox", MaintenanceTabObject.MaintLocation);
            Driver.WaitForReady();
            _jobspanfl.SelectCheckBox("Jobs Span Shifts", MaintenanceTabObject.JobsSpanShifts);
            _includeNote.SelectCheckBox("Include Notes", MaintenanceTabObject.IncludeNotes);
            _notifyTime.SetText(MaintenanceTabObject.NotifyTime, "NotifyTime");
            Driver.WaitForReady();
            _downtimeStatus.SetText(MaintenanceTabObject.DowntimeStatus, "Downtime Status");
            Driver.WaitForReady();
            _sendWONotify.SelectCheckBox("Send WO Notify", MaintenanceTabObject.SendWONotify);
            _sendJobAttach.SelectCheckBox("Send Job Attach", MaintenanceTabObject.SendJobAttach);
            _timeReporting.SelectFilterValueHavingEqualValue(MaintenanceTabObject.TimeReporting);
            Driver.WaitForReady();
            _timeRounding.SelectFilterValueHavingEqualValue(MaintenanceTabObject.TimeRounding);
        }

        /// <summary>
        /// Scroll Up the Page and Select Tab
        /// </summary>
        /// <param name="TabLocator"></param>
        /// <param name="TabName"></param>
        public void ScrollUpAndSelectTab(IWebElement TabLocator, string TabName)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            TabLocator.ClickElement(TabName, Driver);
        }

        /// <summary>
        /// Verify Location Main Data
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyLocationMain(LocationMain DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_genloc, DataObject.Location, "Location");
            Settings.Logger.Info($" Verifying Location Main: {DataObject.Location}");        
            CommonUtil.VerifyElementValue(_genloc, "Location", DataObject.Location);
            CommonUtil.VerifyElementValue(_locDesc, "LocationDesc", DataObject.LocationDesc);
            CommonUtil.VerifyElementValue(_disabledChk, "Disabled", DataObject.Disabled,true);      
            if (DataObject.GeneralTab != null)
            {
                VerifyGeneralTab(DataObject.GeneralTab);
            }
            if (DataObject.ConfigurationTab != null)
            {
                VerifyConfigurationTab(DataObject.ConfigurationTab);
            }
            if (DataObject.HierarchyTab != null)
            {
                VerifyHierarchyTab(DataObject.HierarchyTab);
            }
            if (DataObject.InventoryTab != null)
            {
                VerifyInventoryTab(DataObject.InventoryTab);
            }
            if (DataObject.MaintenanceTab != null)
            {
                VerifyMaintenanceTab(DataObject.MaintenanceTab);
            }
            Settings.Logger.Info($" Successfully Verified Location Main: {DataObject.Location}");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify General Tab Data
        /// </summary>
        /// <param name="GeneralInfoTabObj"></param>
        public void VerifyGeneralTab(GeneralInfoTab GeneralInfoTabObj)
        {
            CommonUtil.VerifyElementValue(_state, "State", GeneralInfoTabObj.State);
            CommonUtil.VerifyElementValue(_country, "Country", GeneralInfoTabObj.Country);
            CommonUtil.VerifyElementValue(_timeZone, "TimeZone", GeneralInfoTabObj.TimeZone);
        }

        /// <summary>
        /// Verify configuration Tab Data
        /// </summary>
        /// <param name="ConfigurationTabObj"></param>
        public void VerifyConfigurationTab(ConfigurationTab ConfigurationTabObj)
        {
            ScrollUpAndSelectTab(_configurationTab, "Configuration Tab");
            CommonUtil.VerifyCheckboxState(_fuellocfl, "FuelLocation", ConfigurationTabObj.FuelLocation);
            CommonUtil.VerifyCheckboxState(_deliverylocfl, "DeliveryLocation", ConfigurationTabObj.DeliveryLocation);
            CommonUtil.VerifyCheckboxState(_parklocfl, "ParkingLocation", ConfigurationTabObj.ParkingLocation);
            CommonUtil.VerifyCheckboxState(_motorpoolfl, "MotorPoolLocation", ConfigurationTabObj.MotorPoolLocation);
        }

        /// <summary>
        /// Verify Hierarchy tab
        /// </summary>
        /// <param name="HierarchyTabObj"></param>
        public void VerifyHierarchyTab(HierarchyTab HierarchyTabObj)
        {
            ScrollUpAndSelectTab(_hierarchyTab, "Hierarchy Tab");
            CommonUtil.VerifyElementValue(_deptNo, "Department", HierarchyTabObj.Department);
        }

        /// <summary>
        /// Verify Inventory Tab
        /// </summary>
        /// <param name="InventoryTabObj"></param>
        public void VerifyInventoryTab(InventoryTab InventoryTabObj)
        {
            ScrollUpAndSelectTab(_InventoryTab, "Inventory Tab");
            CommonUtil.VerifyCheckboxState(_invlocfl, "Inventory Location", InventoryTabObj.InventoryLocation);
            CommonUtil.VerifyElementValue(_overheadCost, "OverheadCost", InventoryTabObj.OverheadCost);
            CommonUtil.VerifyElementValue(_carryingCost, "CarryingCost", InventoryTabObj.CarryingCost);
        }

        /// <summary>
        /// Verify Maintenance Tab
        /// </summary>
        /// <param name="MaintenanceTabObj"></param>
        public void VerifyMaintenanceTab(MaintenanceTab MaintenanceTabObj)
        {
            ScrollUpAndSelectTab(_MaintenanceTab, "Maintenance Tab");
            CommonUtil.VerifyCheckboxState(_maintlocfl, "Maintenance Location", MaintenanceTabObj.MaintLocation);
            CommonUtil.VerifyElementValue(_timeReporting, "TimeReporting", MaintenanceTabObj.TimeReporting,true);
            CommonUtil.VerifyElementValue(_timeRounding, "TimeRounding", MaintenanceTabObj.TimeRounding,true);
        }

        /// <summary>
        /// Delete Location Main
        /// </summary>
        /// <param name="LocationName"></param>
        public void DeleteLocationMain(string LocationName)
        {
            Settings.Logger.Info($" Deleting Location: {LocationName} ");
            Driver.SwitchTo().DefaultContent();          
            _extendpage.RefreshAndSetText(_genloc, LocationName, "Location");          
            _locDesc.ClickElement("Location Description",Driver);                
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            _extendpage.ActionRequiredWindow("Delete");          
        }

        /// <summary>
        /// Verify Location Deletion
        /// </summary>
        /// <param name="LocationName"></param>
        public void VerifyLocationDeletion(string LocationName)
        {             
            _extendpage.RefreshAndSetText(_genloc, LocationName, "Location");           
            Driver.SwitchTo().DefaultContent();
            CommonUtil.AssertTrue(true, _extendpage._createDialog.VerifyElementDisplay(" Action Required Dialog "));       
            _extendpage.ActionRequiredWindow("Cancel");
            Settings.Logger.Info($" Verified Location Main {LocationName} Deletion");
        }
    }
    }
