﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingCodeCopyPageActions : BillingCodeCopyPage
    {
        public BillingCodeCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Copy Existing Billing Code
        /// </summary>
        /// <param name="BillingCodeCopy"></param>
        /// <returns></returns>
        public string CopyExistingBillingCode(AddBillingInformation BillingCodeCopy)
        {
            string NewBillingCode = String.Empty;
            _extendpage.SwitchToContentFrame();
            _existBillCodeInput.SetText(BillingCodeCopy.ExistingBillingCode, "ExistingBillingCode");
            NewBillingCode = CommonUtil.GetRandomStringWithSpecialChars(6);
            Driver.WaitForReady();
            _newBillCodeInput.SetText(NewBillingCode, "NewBillingCode");
            Driver.WaitForReady();
            _newDescriptionInput.SetText(BillingCodeCopy.Description, "NewDescriptionInput");
            BillingObjects.EffectiveDate = BillingCodeCopy.BillingEffectiveDate;
            _extendpage.Save();
            Settings.Logger.Info($" Created Copying Billing Code { NewBillingCode }");
            return NewBillingCode;
        }
    }
}
