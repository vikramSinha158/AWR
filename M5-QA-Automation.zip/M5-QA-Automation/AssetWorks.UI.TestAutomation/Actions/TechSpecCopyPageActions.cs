﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class TechSpecCopyPageActions : TechSpecCopyPage
    {
        public TechSpecCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Copy Existing TechSpec
        /// </summary>
        /// <param name="OldTechSpec"></param>
        /// <returns></returns>
        public string CopyExistingTechSpec(string OldTechSpec)
        {
            Settings.Logger.Info(" Copy Tech existing Tech spec ");
            _extendpage.SwitchToContentFrame();
            _oldTechSpecNo.SetText(OldTechSpec, "Old TechS pec no");
            string TechSpecNo = CommonUtil.GetRandomStringWithSpecialChars();
            Driver.WaitForReady();
            _newTechSpecNoInput.SetText(TechSpecNo, "TechSpec No");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            Settings.Logger.Info($"Successfully creted the Copy Tech existing Tech spec {TechSpecNo}");
            return TechSpecNo;
        }
    }
}
