﻿using OpenQA.Selenium;
using Newtonsoft.Json.Linq;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ItemMasterDefinitionPageActions : ItemMasterDefinitionPage
    {
        public ItemMasterDefinitionPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Item Master Definition
        /// </summary>
        /// <param name="item"></param>
        /// <returns>ItemNo</returns>
        public string AddItemMasterDefinition(Item item)
        {
            Settings.Logger.Info("Add Item Master Definition");
            _extendedPage.SwitchToContentFrame();
            _selectTarget.SelectFilterValueHavingEqualValue(item.Target);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameItemMain, "Item Main frame");
            item.ItemNo = (CommonUtil.GetRandomStringWithSpecialChars(4) + item.ItemNo).ToUpper();
            _inputNewItem.SetText(item.ItemNo, "Item No");
            Driver.WaitForReady();
            _selectNewType.SelectFilterValueHavingEqualValue(item.ItemType);
            if (item.MandatoryItem == "Y")
                _inputNewMandatory.Click();
            if (item.ValidateValue == "Y")
                _inputNewValidated.Click();
            _inputNewDefaultValue.SetText(item.DefaultValue, "Default Value");
            if (item.Disable == "Y")
                _inputNewDisabled.Click();
            if (item.Value != null)
                AddItemValue(item.Value);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            VerifyItemInformation(item);
            return item.ItemNo;
        }

        /// <summary>
        /// Add Item Value
        /// </summary>
        /// <param name="Value"></param>
        public void AddItemValue(string Value)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToTableFrame(_frameItemValue);
            _inputNewItemValue.SetText(Value, "Item Value");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Update Item Information
        /// </summary>
        /// <param name="item"></param>
        public void UpdateItemInformation(Item item)
        {
            Settings.Logger.Info("Update Item Information");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _selectTarget.SelectFilterValueHavingEqualValue(item.Target);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameItemMain, "Item Main frame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableItemMain, "Item",
                item.ItemNo, "item").Click();
            if (item.MandatoryItem == "Y")
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableItemMain, "Item", 
                    item.ItemNo, "mandatory_fl").Click();
            if (item.ValidateValue == "Y")
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableItemMain, "Item",
                    item.ItemNo, "validate_fl").Click();
            if (item.DefaultValue != null)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableItemMain, 
                    "Item", item.ItemNo, "defaultval").SetText(item.DefaultValue, "Default value");
            if (item.Disable == "Y")
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableItemMain, "Item",
                    item.ItemNo, "disabled").Click();
            if (item.Value != null)
                AddItemValue(item.Value);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Item Information
        /// </summary>
        /// <param name="item"></param>
        public void VerifyItemInformation(Item item)
        {
            Settings.Logger.Info("Verify Item Information");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _selectTarget.SelectFilterValueHavingEqualValue(item.Target);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameItemMain, "Item Main frame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableItemMain, "Item", 
                item.ItemNo, "item").Click();
            if (item.ItemType != null)
            {
                string _itemType = _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableItemMain, "Item", item.ItemNo, "field_type").GetAttribute("value");
                CommonUtil.AssertTrue(item.ItemType.Substring(0, 1), _itemType);
            }
            if (item.MandatoryItem != null)
            {
                string _mandatoryItem = _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableItemMain, "Item", item.ItemNo, "mandatory_fl").GetAttribute("value");
                CommonUtil.AssertTrue(item.MandatoryItem, _mandatoryItem);
            }
            if (item.ValidateValue != null)
            {
                string _validateValue = _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableItemMain, "Item", item.ItemNo, "validate_fl").GetAttribute("value");
                CommonUtil.AssertTrue(item.ValidateValue, _validateValue);
            }
            if (item.DefaultValue != null)
            {
                if (item.DefaultValue == "now" && item.ItemType == "Date")
                {
                    _extendedPage.VerifySystemDateContainAppdate(
                        _extendedPage.GetTableActionElementByRelatedColumnValue(
                            _tableItemMain, "Item", item.ItemNo, "defaultval"), "");
                }
                else
                {
                    string _defaultValue = _extendedPage.GetTableActionElementByRelatedColumnValue(
                        _tableItemMain, "Item", item.ItemNo, "defaultval").GetAttribute("value");
                    CommonUtil.AssertTrue(item.DefaultValue, _defaultValue);
                }
            }
            if (item.Disable != null)
            {
                string _disabled = _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableItemMain, "Item", item.ItemNo, "disabled").GetAttribute("value");
                CommonUtil.AssertTrue(item.Disable, _disabled);
            }
            if (item.Value != null)
                VerifyItemValue(item.Value);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Item Value
        /// </summary>
        /// <param name="Value"></param>
        public void VerifyItemValue(string Value)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToTableFrame(_frameItemValue);
            string _value = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableItemValue, "Value", Value, "itemValue").GetAttribute("value");
            CommonUtil.AssertTrue(Value, _value);
        }

        /// <summary>
        /// Delete Item Definition
        /// </summary>
        /// <param name="Target"></param>
        /// <param name="ItemNo"></param>
        public void DeleteItemDefinition(string Target, string ItemNo)
        {
            Settings.Logger.Info("Verify Item Information");
            _extendedPage.SwitchToContentFrame();
            _selectTarget.SelectFilterValueHavingEqualValue(Target);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameItemMain, "Item Main frame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableItemMain, "Item", ItemNo, "item").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.AcceptAlert();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameItemMain, "Item Main frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableItemMain, "Item", ItemNo);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
        }
    }
}