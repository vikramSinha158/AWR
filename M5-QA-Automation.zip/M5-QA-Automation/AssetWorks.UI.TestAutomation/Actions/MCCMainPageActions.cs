﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class MCCMainPageActions : MCCMainPage
    {
        public MCCMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create MCC Code
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public string CreateMCCCode(string DataObjectKey, string MCCCodeNo = "random")
        {
            string MCCCode=string.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(MCCCodeNo, ref MCCCode, "MCCCodeQuery"))
            {
                Settings.Logger.Info(" Creating MCC Code   ");
                _extendpage.SwitchToContentFrame();
                _mccMainInput.SetText(MCCCode, " MCC Code ");
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                MCCMainObjects.MCCCodeDesCription = _extendpage.EnterDescription(_mccMainDescInput);
                FillMonthlyExpectedUsage(DataObjectKey);
                AddSeasonCode();
                Driver.SwitchTo().DefaultContent();
                Driver.WaitForReady();
                _extendpage.VerifyCreatedActionNumber(_mccMainInput, MCCCode);              
            }
            return MCCCode;
        }

        /// <summary>
        /// Fill Monthly Expected Usage
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillMonthlyExpectedUsage(string DataObjectKey)
        {
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            FirstType = CommonUtil.DataForKey(MCCMainObjects.MEUFirstType, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _meuFirstType.SelectFilterValueHavingEqualValue(FirstType);
            FirstMin = CommonUtil.DataForKey(MCCMainObjects.MEUFirstMin, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _txtFirstMin.SetText(FirstMin, " First Min Value");
            FirstMax = CommonUtil.DataForKey(MCCMainObjects.MEUFirstMax, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _txtFirstMax.SetText(FirstMax, " First Max value ");
            FirstLength = CommonUtil.DataForKey(MCCMainObjects.MEUFirstLength, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _txtFirstLength.SetText(FirstLength, " First Length value ");
            SecondType = CommonUtil.DataForKey(MCCMainObjects.MEUSecondType, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _meuSecondType.SelectFilterValueHavingEqualValue(SecondType);
            SecondMin = CommonUtil.DataForKey(MCCMainObjects.MEUSecondMin, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _txtSecondMin.SetText(SecondMin, " Second Min Value");
            SecondMax = CommonUtil.DataForKey(MCCMainObjects.MEUSecondMax, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _txtSecondMax.SetText(SecondMax, " Second Max value ");
            SecondLength = CommonUtil.DataForKey(MCCMainObjects.MEUSecondLength, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _txtSecondLength.SetText(SecondLength, " Second Length value ");          
        }

        /// <summary>
        /// Add Season Code
        /// </summary>
        public void AddSeasonCode()
        {
            _txtSeasonCode.SetText("ONE", "Season code ");
        }

        /// <summary>
        /// Verify MCC Main Info
        /// </summary>
        public void VerifyMCCMainInfo(string DataObjectKey,string MCCCode)
        {
            Settings.Logger.Info(" Verifying  MCC Main   ");
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            _extendpage.RefreshAndSetText(_mccMainInput, MCCCode, "MCC Code ");
            Driver.WaitForReady();
            string ActualMCCCodeValue = _mccMainInput.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(MCCCode, ActualMCCCodeValue);
            FirstType = CommonUtil.DataForKey(MCCMainObjects.MEUFirstType, DataObject).ToString().Trim();
            string ActualFirstType=_meuFirstType.GetVisibleText();
            CommonUtil.AssertTrue<string>(FirstType, ActualFirstType);
            FirstMin = CommonUtil.DataForKey(MCCMainObjects.MEUFirstMin, DataObject).ToString().Trim();
            string ActualFirstMin=_txtFirstMin.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(FirstMin, ActualFirstMin);
            FirstMax = CommonUtil.DataForKey(MCCMainObjects.MEUFirstMax, DataObject).ToString().Trim();
            string ActualFirstMax=_txtFirstMax.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(FirstMax, ActualFirstMax);
            FirstLength = CommonUtil.DataForKey(MCCMainObjects.MEUFirstLength, DataObject).ToString().Trim();
            string ActualFirstLength=_txtFirstLength.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(FirstLength, ActualFirstLength);
            SecondType = CommonUtil.DataForKey(MCCMainObjects.MEUSecondType, DataObject).ToString().Trim();
            string ActualSecondType=_meuSecondType.GetVisibleText();
            CommonUtil.AssertTrue<string>(SecondType, ActualSecondType);
            SecondMin = CommonUtil.DataForKey(MCCMainObjects.MEUSecondMin, DataObject).ToString().Trim();
            string ActualSecondMin=_txtSecondMin.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(SecondMin, ActualSecondMin);
            SecondMax = CommonUtil.DataForKey(MCCMainObjects.MEUSecondMax, DataObject).ToString().Trim();
            string ActualSecondMax=_txtSecondMax.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(SecondMax, ActualSecondMax);
            SecondLength = CommonUtil.DataForKey(MCCMainObjects.MEUSecondLength, DataObject).ToString().Trim();
            string ActualSecondLength=_txtSecondLength.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(SecondLength, ActualSecondLength);
            string ActualSeasonCode = _txtSeasonCode.GetElementValueByAttribute("ovalue");
            Assert.False(String.IsNullOrEmpty(ActualSeasonCode), "Season Code value  found null ");
            string ActualSeasonDesc = _seasonDesc.GetElementValueByAttribute("ovalue");
            Assert.False(String.IsNullOrEmpty(ActualSeasonDesc), "Season Desc value found null ");
            string ActualSeasonStart = _seasonStart.GetElementValueByAttribute("ovalue");
            Assert.False(String.IsNullOrEmpty(ActualSeasonStart), "Season start value  found null ");
            string ActualSeasonEnd = _seasonEnd.GetElementValueByAttribute("ovalue");
            Assert.False(String.IsNullOrEmpty(ActualSeasonEnd), "Season End value   found null ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Edit And Verify MCC Main
        /// </summary>
        /// <param name="DataObject"></param>
        public void EditAndVerifyMCCMain(string DataObjectKey)
        {
            Settings.Logger.Info(" Edit and Verifying  MCC Main   ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_mccMainInput, MCCMainObjects.MCCCode, "MCC Code ");
            Driver.WaitForReady();
            FillMonthlyExpectedUsage(DataObjectKey);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            VerifyMCCMainInfo(DataObjectKey, MCCMainObjects.MCCCode);
        }

        /// <summary>
        /// Verify MCC Disable
        /// </summary>
        /// <param name="DisabledStatus"></param>
        public void VerifyMCCDisable(string DisabledStatus) 
        {
            Settings.Logger.Info(" Checking Disabled field for MCC Main  ");
            _extendpage.SwitchToContentFrame();
            _mccMainDisabledField.SelectFilterValueHavingEqualValue(DisabledStatus);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            Driver.WaitForReady();
            _extendpage.RefreshAndSetText(_mccMainInput, MCCMainObjects.MCCCode,"MCC Code ");
            Driver.WaitForReady();
            CommonUtil.AssertTrue<string>("true", _meuFirstType.GetAttribute("disabled"));
            CommonUtil.AssertTrue<string>("true", _txtFirstMin.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _txtFirstMax.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _txtFirstLength.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _meuSecondType.GetAttribute("disabled"));
            CommonUtil.AssertTrue<string>("true", _txtSecondMin.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _txtSecondMax.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _txtSecondLength.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _txtSeasonCode.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _seasonDesc.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _seasonStart.GetAttribute("readonly"));
            CommonUtil.AssertTrue<string>("true", _seasonEnd.GetAttribute("readonly"));
        }

        /// <summary>
        /// Verify MCC Main Deletion
        /// </summary>
        public void VerifyMCCMainDeletion(string MCCCode)
        {
            _mccMainDisabledField.SelectFilterValueHavingEqualValue("No");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            _extendpage.VerifyCodeDeletion(_mccMainInput, MCCCode, "MCC Main");
        }

        /// <summary>
        /// Verify Associated MCC Not Deleted
        /// </summary>
        /// <param name="MCCNO"></param>
        public void VerifyAssociatedMCCNotDeleted(string MCCNO)
        {
            string ErrorMessage=_extendpage.DeleteActionCode(_mccMainInput, MCCNO, "MCC Main");
            if (!String.IsNullOrEmpty(ErrorMessage))
            {
                CommonUtil.AssertTrue<bool>(true, ErrorMessage.Contains(_mccErrorMessge));              
                _extendpage.RefreshAndLeavePage();
            }
            else { 
                Assert.Fail("MCC Deleted ");
            }
        }

        /// <summary>
        /// MCC Main Deletion
        /// </summary>
        /// <param name="MCCCode"></param>
        public void MCCMainDeletion(string MCCCode)
        {
            _extendpage.VerifyCodeDeletion(_mccMainInput, MCCCode, "MCC Main");
            Driver.SwitchTo().DefaultContent();
        }

    }
}
