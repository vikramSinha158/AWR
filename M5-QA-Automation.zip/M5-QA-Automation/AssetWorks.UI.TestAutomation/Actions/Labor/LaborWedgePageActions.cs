﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Labor;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Labor
{
    internal class LaborWedgePageActions : LaborWedgePage
    {
        internal LaborWedgePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Employee Labor Wedge
        /// </summary>
        /// <param name="wedge"></param>
        public void AddEmployeeLaborWedge(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Add Employee Labor Wedge ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(wedge.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputNWOIndCode.SetText(wedge.NWOIndCode, "NWO Indirect Code");
            Driver.WaitForReady();
            _inputNewJobCode.SetText(wedge.NewJobCode, "New Job Code");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputNewPosition);
            _inputNewPosition.SetText(wedge.NewPosition, "New Position");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputWoTimeType);
            _inputWoTimeType.SetText(wedge.WoTimeType, "Wo Time Type");
            Driver.WaitForReady();
            _inputWoPayClass.SetText(wedge.WoPayClass, "Wo Pay Class");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputWoPayStep);
            _inputWoPayStep.SetText(wedge.WoPayStep, "Wo Pay Step");
            Driver.WaitForReady();
            _inputNewPunchTime.SetText(wedge.NewPunchTime, "New Punch Time");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Added Labor Wedge
        /// </summary>
        /// <param name="wedge"></param>
        public void VerifyAddedLaborWedge(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Verify Added Labor Wedge ");
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForSomeTime();
            _extendedPage.SwitchToTableFrame(_frameCurrentLabor);
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "empID"), "Employee No", wedge.EmployeeNo, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "Dept"), "Unit No", wedge.NWOUnitNo, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "JobCode"), "Job Code", wedge.NewJobCode, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "Assign"), "Assignment", wedge.EmployeeNo, false, "value");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Remove Employee Labor Wedge
        /// </summary>
        /// <param name="wedge"></param>
        public void RemoveEmployeeLaborWedge(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Remove Employee Labor Wedge ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, wedge.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputJobStatus.SetText(wedge.JobStatus, "Job Status");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputNWOIndCode);
            _inputNWOIndCode.SetText(wedge.NWOIndCode, "NWO Indirect Code");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForSomeTime();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameCurrentLabor);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableCurrentLabor, "Employee", wedge.EmployeeNo);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
