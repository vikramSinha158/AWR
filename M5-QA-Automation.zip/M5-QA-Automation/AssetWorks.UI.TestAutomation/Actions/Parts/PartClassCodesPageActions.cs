﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    public class PartClassCodesPageActions : PartClassCodesPage
    {
        public PartClassCodesPageActions(IWebDriver? Driver) : base(Driver) { }
        /// <summary>
        /// Create New Part Code
        /// </summary>
        /// <returns>Code</returns>
        public string CreateNewPartClassCode(PartsClassCodesObjects partsClassCodesObject)
        {
            string Code = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(partsClassCodesObject.Code, ref Code, "PartClass", 4))
            {
                Settings.Logger.Info(" Create new part class code ");
                _extendedPage.SwitchToTableFrame(_partClassCodeFrame);
                _partClassNew.SetText(Code, "Part Class Code");
                _descriptionNew.SetText(partsClassCodesObject.Description + Code, "Description");
                _disabledCheckNew.SelectCheckBox("Disabled");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();               
                Driver.WaitForReady();
            }
            return Code;
        }

        /// <summary>
        /// Update Part Class 
        /// </summary>
        /// <param name="partClassCodesObject"></param>
        public void UpdatePartClassCode(PartsClassCodesObjects partClassCodesObject)
        {
            Settings.Logger.Info("Update part class code");
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToTableFrame(_partClassCodeFrame);
            _partClassNew.SetText(partClassCodesObject.Code, "Part Class Code");
            _createdClassCodeDisabledCheck(partClassCodesObject.Code).DeSelectCheckBox("Disabled");
            _createdClassCodeDescription(partClassCodesObject.Code).SetText(partClassCodesObject.Description + partClassCodesObject.Code, "Description");
             Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Part class code
        /// </summary>
        /// <param name="partClassCodesObject"></param>
        public void VerifyPartClassCode(PartsClassCodesObjects partClassCodesObject)
        {
            Settings.Logger.Info(" Verify part class code ");
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToTableFrame(_partClassCodeFrame);
            CommonUtil.AssertTrue(true, _createdClassCode(partClassCodesObject.Code).VerifyElementDisplay("Part Class Code"));
            CommonUtil.AssertTrue(partClassCodesObject.Description + partClassCodesObject.Code, _createdClassCodeDescription(partClassCodesObject.Code).GetAttribute("value"));
            CommonUtil.VerifyCheckboxState(_createdClassCodeDisabledCheck(partClassCodesObject.Code), "Disabled", partClassCodesObject.Disabled);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Verified part class code successfully !!");
        }

        /// <summary>
        /// Verify Delete part Class Code
        /// </summary>
        /// <param name="code"></param>
        public void VerifyDeletePartClassCode(string code)
        {
            Settings.Logger.Info("Delete part class code");
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToTableFrame(_partClassCodeFrame);
            _partClassNew.SetText(code, "Part Class Code");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.DeleteAndSave();
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToTableFrame(_partClassCodeFrame);
            CommonUtil.AssertTrue(0, _createdClassCodeCount(code).Count);
            Settings.Logger.Info(" Verified Delete part class code successfully !!");
        }
    }
}
