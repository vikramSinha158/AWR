﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartMainCatalogPageActions : PartMainCatalogPage
    {

        public PartMainCatalogPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Part
        /// </summary>
        /// <returns>Part No</returns>       
        public string CreateNewPart(PartsMainCatalog partsObject)
        {
            string PartNumber = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(partsObject.PartNumber, ref PartNumber, "PartQuery", 12))
            {
                Settings.Logger.Info(" Create new part ");                
                _inputPartNo.SetText(PartNumber, "Part No", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                partsObject.PartDesc = $"Random desc for {PartNumber}".ToUpper();
                _inputPDesc.SetText(partsObject.PartDesc, "Part Desc", Driver, _extendedPage._contentFrame, "content frame");
                FillPartSettingsValues(partsObject);
                _extendedPage.VerifyCreatedActionNumber(_inputPartNo, PartNumber);
            }
            return PartNumber;
        }

        /// <summary>
        /// Update Part setting values
        /// </summary>
        /// <param name="partsObject"></param>
        /// <param name="partNumber"></param>
        public void UpdatePartSettingsValue(PartsMainCatalog partsObject)
        {
            FillPartSettingsValues(partsObject);
            _extendedPage.ClickOnSaveButton();
        }
        /// <summary>
        /// Fill Part settings values
        /// </summary>
        /// <param name="partsObject"></param>
        public void FillPartSettingsValues(PartsMainCatalog partsObject)
        {
            Settings.Logger.Info(" Fill Part Settings Details");
            _extendedPage.SwitchToContentFrame();
            _manufacturer.SetText(partsObject.Manufacturer, "Manufacturer");
            Driver.WaitForReady();
            _extendedPartDescription.SendKeys(string.Empty);
            _extendedPartDescription.SetText(partsObject.ExtDescription, "Extended Part Description");
            Driver.WaitForReady();
            _inputSPrice.SendKeys(string.Empty);
            _inputSPrice.SetText(partsObject.StandardPrice, "Standard Price");
            Driver.WaitForReady();
            _inputAPrice.SetText(partsObject.AveragePrice, "Average Price");
            Driver.WaitForReady();
            _inputRPrice.SetText(partsObject.RetailPrice, "Retail Price");
            Driver.WaitForReady();
            _inputPDiscountCode.SendKeys(string.Empty);
            _inputPDiscountCode.SetText(partsObject.DiscountCode, "Discount Code");
            Driver.WaitForReady();
            _inputUnitOfInventory.SetText(partsObject.UnitOfInventory, "Unit Of Inventory");
            Driver.WaitForReady();
            _inputCommodity.SetText(partsObject.Commodity, "Commodity");
            Driver.WaitForReady();
            _inputChargeCode.SendKeys(string.Empty);
            _inputChargeCode.SetText(partsObject.ChargeCode, "Charge Code");
            Driver.WaitForReady();
            _inputCostCategory.SendKeys(string.Empty);
            _inputCostCategory.SetText(partsObject.CostCategory, "Cost Category");
            Driver.WaitForReady();
            _inputPartClass.SetText(partsObject.PartClass, "Part Class");
            Driver.WaitForReady();

            Settings.Logger.Info(" Fill Part Classification and Location");
            Driver.WaitForReady();
            _inputATAsys.SendKeys(string.Empty);
            Driver.WaitForReady();
            _inputATAsys.SetText(partsObject.Sys, "Sys");
            Driver.WaitForReady();
            _inputATAcomp.SetText(partsObject.Assembly, "Assembly");
            Driver.WaitForReady();
            _inputATApart.SetText(partsObject.Part, "Part");
            Driver.WaitForReady();
            _selectStockType.SelectFilterValueHavingEqualValue(partsObject.StockType);
            Driver.WaitForReady();
            _inputPriVendor.SendKeys(string.Empty);
            Driver.WaitForReady();
            _inputPriVendor.SetText(partsObject.PrimaryVendor, "Primary Vendor");
            Driver.WaitForReady();
            _inputSecVendor.SendKeys(string.Empty);
            Driver.WaitForReady();
            _inputSecVendor.SetText(partsObject.SecondaryVendor, "Secondary Vendor");
            Driver.WaitForReady();
            _inputSeasonCode.SendKeys(string.Empty);
            Driver.WaitForReady();
            _inputSeasonCode.SetText(partsObject.SeasonCode, "Season Code");
            Driver.WaitForReady();
            _serialized.SelectFilterValueHavingEqualValue(partsObject.Serialized);
            Driver.WaitForReady();
            _autoGenSerial.SelectFilterValueHavingEqualValue(partsObject.AutoGenerateSerial);
            Driver.WaitForReady();
            _reUseSerial.SelectFilterValueHavingEqualValue(partsObject.ReusableSerial);
            Driver.WaitForReady();
            _lottedFlag.SelectFilterValueHavingEqualValue(partsObject.Lotted);
            Driver.WaitForReady();
            _coreCharge.SendKeys(string.Empty);
            Driver.WaitForReady();
            _coreCharge.SetText(partsObject.CoreCharge, "Code Charge");
            Driver.WaitForReady();
            _core_fl.SelectFilterValueHavingEqualValue(partsObject.CoreTracking);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Values
        /// </summary>
        /// <param name="partsObject"></param>
        public void VerifyPartValues(PartsMainCatalog partsObject)
        {
            Settings.Logger.Info($" Verifying Part Values for : {partsObject.PartNumber}");
            _extendedPage.RefreshAndSetText(_inputPartNo, partsObject.PartNumber, " Part Number ");
            Driver.WaitForReady();            
            CommonUtil.VerifyElementValue(_inputPDesc, "Part Desc", partsObject.PartDesc);
            CommonUtil.VerifyElementValue(_manufacturer,"Manufacturer", partsObject.Manufacturer);
            CommonUtil.VerifyElementValue(_extendedPartDescription,"Extended Part Description ", partsObject.ExtDescription);
            CommonUtil.VerifyElementValue(_inputSPrice, "Standard Price", partsObject.StandardPrice);
            CommonUtil.VerifyElementValue(_inputAPrice,"Average Price ", partsObject.AveragePrice);
            CommonUtil.VerifyElementValue(_inputRPrice, "Retail Price", partsObject.RetailPrice);
            CommonUtil.VerifyElementValue(_inputPDiscountCode, "DiscountCode", partsObject.DiscountCode);
            CommonUtil.VerifyElementValue(_inputUnitOfInventory, "UnitOfInventory", partsObject.UnitOfInventory);
            CommonUtil.VerifyElementValue(_inputCommodity, "Commodity", partsObject.Commodity);
            CommonUtil.VerifyElementValue(_inputChargeCode, "Charge Code", partsObject.ChargeCode);
            CommonUtil.VerifyElementValue(_inputCostCategory, "Cost Category", partsObject.CostCategory);
            CommonUtil.VerifyElementValue(_inputPartClass, "PartClass", partsObject.PartClass);
            CommonUtil.VerifyElementValue(_inputATAsys, "Sys", partsObject.Sys);
            CommonUtil.VerifyElementValue(_inputATAcomp, "Assembly", partsObject.Assembly);
            CommonUtil.VerifyElementValue(_inputATApart,"Part", partsObject.Part);
            if (partsObject.StockType != null)
            {
                CommonUtil.AssertTrue(partsObject.StockType, _selectStockType.GetVisibleText());
            }
            if (partsObject.Serialized != null)
            {
                CommonUtil.AssertTrue(partsObject.Serialized, _serialized.GetVisibleText());
            }
            if (partsObject.ReusableSerial != null)
            {
                CommonUtil.AssertTrue(partsObject.ReusableSerial, _reUseSerial.GetVisibleText());
            }
            if (partsObject.AutoGenerateSerial != null)
            {
                CommonUtil.AssertTrue(partsObject.AutoGenerateSerial, _autoGenSerial.GetVisibleText());
            }
            if (partsObject.Lotted != null)
            {
                CommonUtil.AssertTrue(partsObject.Lotted, _lottedFlag.GetVisibleText());
            }
            if (partsObject.CoreTracking != null)
            {
                CommonUtil.AssertTrue(partsObject.CoreTracking, _core_fl.GetVisibleText());
            }
            CommonUtil.VerifyElementValue(_inputPriVendor, "PrimaryVendor", partsObject.PrimaryVendor);
            CommonUtil.VerifyElementValue(_inputSecVendor, "Secondary Vendor", partsObject.SecondaryVendor);
            CommonUtil.VerifyElementValue(_inputSeasonCode, "Season Code", partsObject.SeasonCode);
            CommonUtil.VerifyElementValue(_coreCharge, "Core Charge", partsObject.CoreCharge);
            Driver.SwitchTo().DefaultContent();
        }       
      
        /// <summary>
        /// Verify Deleted Stock Part
        /// </summary>
        /// <returns>Part No</returns>
        public void VerifyDeletedStockPart(string PartNumber)
        {
           _extendedPage.VerifyCodeDeletion(_inputPartNo,PartNumber, "inputPartNo");           
        }
    }
}
