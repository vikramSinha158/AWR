﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartInventoryLocationPageActions : PartInventoryPage
    {
        public PartInventoryLocationPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Part Inventory Location
        /// </summary>       
        public void CreateNewPartInventoryLocation(PartsInventoryLocationObjects partInventoryLocationManager)
        {
            Settings.Logger.Info(" Create new part inventory location");
            _extendpage.SwitchToContentFrame();
            _inputPartNumber.SetText(partInventoryLocationManager.Number, "Part No");
            Driver.WaitForReady();
            _stockType.SelectFilterValueHavingEqualValue(partInventoryLocationManager.StockType);
             Driver.WaitForReady();
            _reorderAllowed.SelectFilterValueHavingEqualValue(partInventoryLocationManager.ReorderAllowed);
             Driver.WaitForReady();
            _issueToDepartment.SelectFilterValueHavingEqualValue(partInventoryLocationManager.IssueToDepartment);
             Driver.WaitForReady();
            _issueToAccount.SelectFilterValueHavingEqualValue(partInventoryLocationManager.IssueToAccount);
             Driver.WaitForReady();
            _coreTracking.SelectFilterValueHavingEqualValue(partInventoryLocationManager.CoreTracking);
             Driver.WaitForReady();
            _coreCharge.SetText(partInventoryLocationManager.CoreCharge, "Core Charge");
            Driver.WaitForReady();
            _chargeCode.SetText(partInventoryLocationManager.ChargeCode, "Charge Code");
            Driver.WaitForReady();
            _costCategory.SetText(partInventoryLocationManager.CategoryCost, "Cost Category");
            Driver.WaitForReady();
            _markupScheme.SetText(partInventoryLocationManager.MarkupScheme, "Markup Scheme");
            Driver.WaitForReady();
            FillsPartsInventoryTabData(partInventoryLocationManager);
            _extendpage.Save();
        }
        /// <summary>
        /// Fill Parts Inventory Location Tab data
        /// </summary>
        /// <param name="partInventoryLocationManager"></param>
        public void FillsPartsInventoryTabData(PartsInventoryLocationObjects partInventoryLocationManager)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Reorder"), "Reorder Tab");
            Driver.WaitForReady();
            _maxInvQty.SetText(partInventoryLocationManager.MaximumInvQty, "Maximum InvQty");
            Driver.WaitForReady();
            _minInvQty.SetText(partInventoryLocationManager.MinimumInvQty, "Minimum InvQty");
            Driver.WaitForReady();
        }
        /// <summary>
        /// Verify Parts Inventory Data
        /// </summary>
        public void VerifyPartsInventoryData(PartsInventoryLocationObjects partInventoryLocationManager)
        {
            Settings.Logger.Info("Verify Parts Inventory Reorder Tab Data for : " + partInventoryLocationManager.Number);           
            Driver.WaitForReady();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputPartNumber.SetText(partInventoryLocationManager.Number, "Part No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_stockType, "Stock Type", partInventoryLocationManager.StockType, true);
            CommonUtil.VerifyElementValue(_reorderAllowed, "Product Type", partInventoryLocationManager.ReorderAllowed, true);
            CommonUtil.VerifyElementValue(_issueToDepartment, "Unit Issue", partInventoryLocationManager.IssueToDepartment, true);
            CommonUtil.VerifyElementValue(_issueToAccount, "Associated Part", partInventoryLocationManager.IssueToAccount, true);
            CommonUtil.VerifyElementValue(_coreTracking, "Fuel Type", partInventoryLocationManager.CoreTracking, true);
            CommonUtil.VerifyElementValue(_coreCharge, "Core Charge", partInventoryLocationManager.CoreCharge);
            CommonUtil.VerifyElementValue(_standard, "Fuel InsideBillItem", partInventoryLocationManager.Standard);
            CommonUtil.VerifyElementValue(_binPrimaryLoc, "Primary Bin Location", partInventoryLocationManager.BinPrimaryLocation);
            CommonUtil.VerifyElementValue(_costCategory, "Category Cost", partInventoryLocationManager.CategoryCost);
            CommonUtil.VerifyElementValue(_markupScheme, "Markup Scheme", partInventoryLocationManager.MarkupScheme);
            //Verify Reorder Tab Data
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Reorder"), "Reorder Tab");
            CommonUtil.VerifyElementValue(_maxInvQty, "Maximum Inventory Quantity", partInventoryLocationManager.MaximumInvQty);
            CommonUtil.VerifyElementValue(_minInvQty, "Minimum Inventory Quantity", partInventoryLocationManager.MinimumInvQty);
        }

        /// <summary>
        /// Verify Part Adjustment
        /// </summary>
        /// <param name="partAdjustmentObjects"></param>
        public void VerifyPartAjustment(PartsAdjustmentObjects partAdjustmentObjects)
        {
            Settings.Logger.Info("Verify Parts Inventory Locations for : " + partAdjustmentObjects.Number);
            _extendpage.RefreshAndSetText(_inputPartNumber, partAdjustmentObjects.Number,"Part Number");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_QtyOnHand, "Quantity On Hand", partAdjustmentObjects.QtyOnHand);
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Stock Status"), "Stock Status");
            CommonUtil.VerifyElementValue(_onHandQuantity, "On Hand Quantity", partAdjustmentObjects.QtyOnHand);
            Driver.WaitForReady();
        }
    }
}