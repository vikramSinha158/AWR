﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartsAdjustmentPageActions : PartAdjustmentPage
    {
        public PartsAdjustmentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Part Inventory Adjustment
        /// </summary>
        public void CreateNewPartAdjustment(PartsAdjustmentObjects partAdjustment)
        {
            Settings.Logger.Info(" Create new part adjustment");
            _extendpage.SwitchToContentFrame();
            _inputPartNumber.SetText(partAdjustment.Number, "Part Number");
            Driver.WaitForReady();
            _ReasonCode.SetText(partAdjustment.ReasonCode, "Reason Codes");
            Driver.WaitForReady();
            _EmployeeNo.SetText(partAdjustment.EmployeeNumber, "Employee Number");
            Driver.WaitForReady();
            _AdjustmentQty.SetText(partAdjustment.AdjustQty, "Adjust Quantity");
            Driver.WaitForReady();
            _AdjustmentPrice.SetText(partAdjustment.AdjustPrice, "Adjust Price");
            Driver.WaitForReady();
            _Notes.SetText(partAdjustment.Notes, "Notes");
            Driver.WaitForReady();
            _extendpage.Save();
        }
    }
}
