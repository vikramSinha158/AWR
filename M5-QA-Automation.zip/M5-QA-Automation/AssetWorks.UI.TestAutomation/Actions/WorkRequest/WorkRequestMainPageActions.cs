﻿using System;
using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest;

namespace AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest
{
    internal class WorkRequestMainPageActions : WorkRequestMainPage
    {
        public WorkRequestMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Work Request
        /// </summary>
        /// <param name="request"></param>
        public string CreateWorkRequest(WorkRequestMain request)
        {
            Settings.Logger.Info("Creating work request");
            _extendedPage.SwitchToContentFrame();
            _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);
            Driver.WaitForReady();
            _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
            Driver.WaitForReady();
            if (request.IsNewTicket)
            {
                _buttonNewWR.ClickElement("new Ticket", Driver);
                Driver.WaitForReady();
            }
            _inputWRJobCode.SetText(request.WRJobCode, "Job Code");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                _extendedPage.ClickOnDialogBoxButton("Yes");
            _extendedPage.SwitchToContentFrame();
            _inputWRJobReason.SetText(request.WRJobReason, "Job Reason");
            Driver.WaitForReady();
            _inputWRShift.SetText(request.WRShift, "Schedule Shift");
            Driver.SwitchTo().DefaultContent();
            if (request.General != null)
            {
                FillGeneralInfo(request.General);
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForSomeTime(10);
            }
            if (request.PartsInfo != null)
            {
                FillPartInfo(request.PartsInfo);
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForSomeTime(10);
            }
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForSomeTime(10);
            _extendedPage.SwitchToContentFrame();
            request.WorkRequestNo = _inputWorkRequestNo.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(request.WorkRequestNo), "work Request number is empty");
            Settings.Logger.Info($"Created work Request {request.WorkRequestNo}");
            Driver.SwitchTo().DefaultContent();
            return request.WorkRequestNo;
        }

        /// <summary>
        /// Load Work Request
        /// </summary>
        /// <param name="request"></param>
        public void LoadWorkRequest(WorkRequestMain request)
        {
            Settings.Logger.Info("Load work request");
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);
            Driver.WaitForReady();
            _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
            Driver.WaitForReady();
            _inputWorkRequestNo.SetText(request.WorkRequestNo, "Work Request No");
            Driver.WaitForReady();
            _inputWROccurance.SendKeys(Keys.Tab);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Work Request Details
        /// </summary>
        /// <param name="request"></param>
        public void VerifyWorkRequestDetails(WorkRequestMain request)
        {
            Settings.Logger.Info("Verify work request details");
            LoadWorkRequest(request);
            CommonUtil.VerifyElementValue(_inputWRJobCode, "Job Code", request.WRJobCode);
            CommonUtil.VerifyElementValue(_inputWRJobCodeDesc, "Job Code Desc", request.WRJobCodeDesc);
            CommonUtil.VerifyElementValue(_inputWRJobReason, "Job Reason", request.WRJobReason);
            CommonUtil.VerifyElementValue(_inputWRJobReasonDesc, "Job Reason Desc", request.WRJobReasonDesc);
            CommonUtil.VerifyElementValue(_inputWRShift, "Schedule Shift", request.WRShift);
            CommonUtil.VerifyElementValue(_inputWRShiftDesc, "Schedule Shift Desc", request.WRShiftDesc);
            CommonUtil.VerifyElementValue(_inputWRReportedBy, "Reported By", request.WRReportedBy);
            CommonUtil.VerifyElementValue(_inputWRContact, "Contact", request.WRContact);
            Driver.SwitchTo().DefaultContent();
            if (request.General != null)
            {
                VerifyAddedGeneralInfo(request.General);
            }
            if (request.PartsInfo != null)
            {
                VerifyAddedPartsInfo(request.PartsInfo);
            }
        }

        /// <summary>
        /// Update Work Request Details
        /// </summary>
        /// <param name="request"></param>
        public void UpdateWorkRequestDetails(WorkRequestMain request)
        {
            Settings.Logger.Info("Update work request details");
            LoadWorkRequest(request);
            _inputWRJobReason.SetText(request.WRJobReason, "Job Reason");
            Driver.WaitForReady();
            _inputWRShift.SetText(request.WRShift, "Schedule Shift");
            Driver.WaitForReady();
            _inputWRReportedBy.SetText(request.WRReportedBy, "Reported By");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Delete Work Request
        /// </summary>
        /// <param name="request"></param>
        public void DeleteWorkRequest(WorkRequestMain request)
        {
            Settings.Logger.Info("Delete work request");
            LoadWorkRequest(request);
            _inputWRJobReason.ClickElement("Job Reason", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            Assert.IsTrue(string.IsNullOrEmpty(_inputWorkRequestNo.GetAttribute("ovalue")), $"Work request - {request.WorkRequestNo} not deleted successfully.");
            Settings.Logger.Info($"Work request - {request.WorkRequestNo} deleted successfully.!");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
        }

        /// <summary>
        /// Fill General tab information
        /// </summary>
        /// <param name="generalInfo"></param>
        public void FillGeneralInfo(General generalInfo)
        {
            Settings.Logger.Info("Adding General info for work request");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("General"), "General Tab");
            _inputWRReportedBy.SetText(generalInfo.ReportedBy, "Reported By");
            Driver.WaitForReady();
            _contactPhone.SetText(generalInfo.ContactPhone, "Contact Phone");
            Driver.WaitForReady();
            _maintLoc.SetText(generalInfo.MaintLoc, "Maintenance Location");
            Driver.WaitForReady();
            _reqRef.SetText(generalInfo.ReqRef, "Requisition Reference");
            Driver.WaitForReady();
            _dirAcct.SetText(generalInfo.DirectAcc, "Direct Account");
            Driver.WaitForReady();
            _employee.SetText(generalInfo.Employee, "Employee");
            Driver.WaitForReady();
            _vendorNo.SetText(generalInfo.VendorNo, "Vendor");
            Driver.WaitForReady();
            _notes.SetText(generalInfo.Notes, "Notes");
            Driver.WaitForReady();
            _correctNote.SetText(generalInfo.WarrentyCorrectionNote, "Warrenty Correct Note");
            Driver.WaitForReady();
            _earlDate.SetText(DateTime.Today.AddDays(Convert.ToInt32(generalInfo.EarliestDate)).ToString("MM\\/dd\\/yyyy"), "Earliest Date");
            Driver.WaitForReady();
            _preferDate.SetText(DateTime.Today.AddDays(Convert.ToInt32(generalInfo.PreferredDate)).ToString("MM\\/dd\\/yyyy"), "Preferred Date");
            Driver.WaitForReady();
            _latestDate.SetText(DateTime.Today.AddDays(Convert.ToInt32(generalInfo.LatestDate)).ToString("MM\\/dd\\/yyyy"), "Latest Date");
            Driver.WaitForReady();
            _source.SetText(generalInfo.Source, "Source");
            Driver.WaitForReady();
            _symptom.SetText(generalInfo.Symptom, "Symptom");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("General info Added for work request");
        }

        /// <summary>
        /// Verify Added genral information
        /// </summary>
        /// <param name="generalInfo"></param>
        public void VerifyAddedGeneralInfo(General generalInfo)
        {
            Settings.Logger.Info("Verify work request General tab info");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("General"), "General Tab");
            CommonUtil.VerifyElementValue(_inputWRReportedBy, "Reported By", generalInfo.ReportedBy);
            CommonUtil.VerifyElementValue(_maintLoc, "Maintenance Location", generalInfo.MaintLoc);
            CommonUtil.VerifyElementValue(_reqRef, "Requisition Reference", generalInfo.ReqRef);
            CommonUtil.VerifyElementValue(_dirAcct, "Direct Account", generalInfo.DirectAcc);
            CommonUtil.VerifyElementValue(_employee, "Employee", generalInfo.Employee);
            CommonUtil.VerifyElementValue(_vendorNo, "Vendor Number", generalInfo.VendorNo);
            CommonUtil.VerifyElementValue(_notes, "Notes", generalInfo.Notes);
            CommonUtil.VerifyElementValue(_correctNote, "Worrenty Correction Note", generalInfo.WarrentyCorrectionNote);
            CommonUtil.VerifyElementValue(_earlDate, "Earliest Date", DateTime.Today.AddDays(Convert.ToInt32(generalInfo.EarliestDate)).ToString("MM\\/dd\\/yyyy"));
            CommonUtil.VerifyElementValue(_preferDate, "Preferred Date", DateTime.Today.AddDays(Convert.ToInt32(generalInfo.PreferredDate)).ToString("MM\\/dd\\/yyyy"));
            CommonUtil.VerifyElementValue(_latestDate, "Latest Date", DateTime.Today.AddDays(Convert.ToInt32(generalInfo.LatestDate)).ToString("MM\\/dd\\/yyyy"));
            CommonUtil.VerifyElementValue(_source, "Source", generalInfo.Source);
            CommonUtil.VerifyElementValue(_symptom, "Symptom", generalInfo.Symptom);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Successfully verified Work request General tab info.");
        }

        /// <summary>
        /// Fill Parts tab details created by presetup data
        /// </summary>
        /// <param name="partsinfo"></param>
        public void FillPartInfo(PartsInfo partsinfo)
        {
            Settings.Logger.Info("Adding Parts info for work request");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Parts"), "Parts Tab");
            Driver.SwitchToFrame(_wrPartsTableFrame, "Part Table Frame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _partsNumberColHeader , "", _partsNo).SetText(partsinfo.PartsNo, "Parts Number Value");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _partsQuantityColHeadere, "", _qty).SetText(partsinfo.Quantity, "Quantity");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Parts info Added for work request");
        }

        /// <summary>
        /// Verify Added parts information
        /// </summary>
        /// <param name="partsInfo"></param>
        public void VerifyAddedPartsInfo(PartsInfo partsInfo)
        {
            Settings.Logger.Info("Verify work request General tab info");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Parts"), "Parts Tab");
            Driver.SwitchToFrame(_wrPartsTableFrame, "Part Table Frame");
            CommonUtil.AssertTrue(partsInfo.PartsNo, _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _partsNumberColHeader, partsInfo.PartsNo, _partsNo).GetAttribute("value"));
            CommonUtil.AssertTrue(partsInfo.Description, _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _descriptionColHeadere, partsInfo.Description, _partsDesc).GetAttribute("value"));
            CommonUtil.AssertTrue(partsInfo.UnitOfInventory, _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _unitInventoryColHeader, partsInfo.UnitOfInventory, _unitInventory).GetAttribute("value"));
            CommonUtil.AssertTrue(partsInfo.Quantity, _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _partsQuantityColHeadere, partsInfo.Quantity, _qty).GetAttribute("value"));
            CommonUtil.AssertTrue(partsInfo.UnitCost, _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _unitCostColHeader, partsInfo.UnitCost, _unitCost).GetAttribute("value"));
            CommonUtil.AssertTrue(partsInfo.TotalQuantity, _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _totalQtyColHeader, partsInfo.TotalQuantity, _totalQty).GetAttribute("value"));
            CommonUtil.AssertTrue(partsInfo.TotalCost, _extendedPage.GetTableActionElementByRelatedColumnValue(_wrPartsTable, _totalCostColHeader, partsInfo.TotalCost, _totalCost).GetAttribute("value"));
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Successfully verified Work request Parts tab info.");
        }
    }
}
