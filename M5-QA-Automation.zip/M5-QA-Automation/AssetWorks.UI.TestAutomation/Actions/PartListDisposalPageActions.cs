﻿using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PartListDisposalPageActions : PartListDisposalPage
    {
        public PartListDisposalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Load Department Information
        /// </summary>
        /// <param name="DeptNo"></param>
        public void LoadDepartmentInformation(string DeptNo)
        {
            _extendedPage.SwitchToContentFrame();
            _selectSearchType.SelectFilterValueHavingEqualValue("Department");
            _inputUnitDeptNo.SetText(DeptNo, "Department");
            Settings.Logger.Info(" Clicked on Show All checkbox ");
            _inputShowAll.VerifyElementDisplay(" Show All checkbox ");
            _inputShowAll.Click();
            Settings.Logger.Info(" Clicked on Show All checkbox ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Set Part For Disposal Values
        /// </summary>
        public void SetPartForDisposalValues()
        {
            _disReason = CommonUtil.DataForKey("DisReason");
            _daPart = CommonUtil.DataForKey("DisPart");
            _disQuantity = CommonUtil.DataForKey("DisQuantity");
            _disIssueValue = CommonUtil.DataForKey("DisIssueValue");
        }

        /// <summary>
        /// Install New Part For Disposal
        /// </summary>
        public void InstallNewPartForDisposal()
        {
            SetPartForDisposalValues();
            _extendedPage.SwitchToTableFrame(_frameDisposalParts);
            Settings.Logger.Info("Install New Part For Disposal");
            _inputNewReason.SetText(_disReason, "Reason");
            Driver.WaitForReady();
            _inputNewPart.SetText(_daPart, "Part");
            Driver.WaitForReady();
            _inputNewQuantity.SetText(_disQuantity, "Quantity");
            _inputNewIssueValue.SetText(_disIssueValue, "Issue Value");
            _extendedPage.AddNotes(_buttonNewNotes);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            VerifyPartInstalled(_daPart);
        }

        /// <summary>
        ///Verify Part Installed
        /// </summary>
        /// <param name="Part"></param>
        public void VerifyPartInstalled(string Part)
        {
            Settings.Logger.Info("Verify Part Installed");
            _extendedPage.SwitchToTableFrame(_frameDisposalParts);
            string partDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableDisposalParts, "Part", Part, "qty").GetAttribute("value");
            Driver.SwitchTo().DefaultContent();
            Assert.IsFalse(string.IsNullOrEmpty(partDesc), "Part not installed successfully.");
            Settings.Logger.Info("Part Installed successfully");
        }
    }
}
