﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{

    internal class DepartmentNumberChangePageActions : DepartmentNumberChangePage
    {

        public DepartmentNumberChangePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Search for department number
        /// </summary>
        public void SearchForDepartmentNumber(string DeptNumber)
        {
            Settings.Logger.Info("Search For Department Number ");
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputDepartmentNumber, " input department number ");
            Driver.SwitchTo().DefaultContent();
            _lov.SearchAndSelectFirstRowData(DeptNumber);
        }

        /// <summary>
        /// Enter department number and press tab key
        /// </summary>
        /// <param name="deptNumber"></param>
        public void EnterDepartmentNumberAndPressTab(string DeptNumber)
        {
            Settings.Logger.Info("Enter Department Number ");
            _extendedPage.SwitchToContentFrame();
            _inputDepartmentNumber.SendKeys(DeptNumber);
            _inputDepartmentNumber.SendKeys(Keys.Tab);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Set department number details
        /// </summary>
        public void SetDepartmentNumberDetails()
        {
            Settings.Logger.Info("Set Department Number Details ");
            _extendedPage.SwitchToContentFrame();
            NCDepartmentDescription = _txtDepartmentDescription.GetElementValueByAttribute("ovalue");
            NCDepartmentStatus = _txtDepartmentStatus.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Enter department number and press tab key
        /// </summary>
        /// <param name="newDeptNumber"></param>
        public void EnterNewDepartmentNumberAndPressTab(string NewDeptNumber)
        {
            _extendedPage.SwitchToContentFrame();
            _inputNewDepartmentNumber.SendKeys(NewDeptNumber);
            _inputNewDepartmentNumber.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Entered departmnent number {NewDeptNumber} ");
        }

        /// <summary>
        /// Update New Department Number
        /// </summary>
        /// <returns>DepartmentMainPageActions</returns>
        public DepartmentMainPageActions UpdateNewDepartmentNumber()
        {
            NCDepartmentNumber = CommonUtil.GetRandomStringWithSpecialChars();
            SetDepartmentNumberDetails();
            EnterNewDepartmentNumberAndPressTab(NCDepartmentNumber);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForInvisibility(By.Id("NewDeptNumber"), " New Department Number ");
            return new DepartmentMainPageActions(Driver);
        }
    }
}
