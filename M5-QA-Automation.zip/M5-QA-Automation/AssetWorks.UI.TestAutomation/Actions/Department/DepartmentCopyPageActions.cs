﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{
    internal class DepartmentCopyPageActions : DepartmentCopyPage
    {
        public DepartmentCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Enter department number and press tab key
        /// </summary>
        /// <param name="deptNumber"></param>
        public void EnterDepartmentNumberAndPressTab(string DeptNumber)
        {
            _inputDeptNumber.SetText(DeptNumber, "Department No", Driver, _extendedPage._contentFrame, "Content frame");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Update New Department Number
        /// </summary>
        /// <returns>DepartmentMainPageActions</returns>
        public DepartmentMainPageActions UpdateNewDepartmentNumber()
        {
            NewDeptNumber = CommonUtil.GetRandomStringWithSpecialChars();
            _inputNewDeptNumber.SetText(NewDeptNumber, "New Department No", Driver, _extendedPage._contentFrame, "Content frame");
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForInvisibility(By.Id("NewDeptNumber"), " New Department Number ");
            return new DepartmentMainPageActions(Driver);
        }
    }
}
