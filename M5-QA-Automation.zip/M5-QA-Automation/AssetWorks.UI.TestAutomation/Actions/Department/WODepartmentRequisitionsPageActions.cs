﻿using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{
    internal class WODepartmentRequisitionsPageActions : WorkOrderDepartmentRequisitionsPage
    {
        public WODepartmentRequisitionsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify Work Order Department Requisitions title
        /// </summary>
        public void VerifyWorkOrderDepartmentRequisitionsTitle()
        {
            Settings.Logger.Info("Verifying WorkOrder Department Requisitions Title ");
            _extendedPage.SwitchToContentFrame();
            Assert.True(_departmentRequisitionsTitle.VerifyElementDisplay(" Department Requisitions title "), "department Requisitions Title Not Dispalyed");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Search for Requisition number
        /// </summary>
        public void SearchForRequisitionNumber(string ReqValue)
        {
            Settings.Logger.Info("Searching For Requisition Number ");
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputRequisitionNumber, "input Requisition Number");
            Driver.SwitchTo().DefaultContent();
            if (ReqValue != null)
                _lov.EnterSearchKeywordInFirstBox(ReqValue);
            _lov.SearchAndSelectFirstRowData();
        }

        /// <summary>
        /// Enter Requisition Number And Press Tab
        /// </summary>
        /// <param name="department"></param>
        public void EnterRequisitionNumberAndPressTab(string ReqNumber)
        {
            _extendedPage.SwitchToContentFrame();
            _inputRequisitionNumber.SendKeys(ReqNumber);
            Settings.Logger.Info($"Entered Requisition Number {ReqNumber}");
            _inputRequisitionNumber.SendKeys(Keys.Tab);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>	
        /// Enter Requisition Description And Press Tab	
        /// </summary>	
        /// <param name="DeptDesc"></param>	
        public void EnterRequisitionDescriptionAndPressTab(string DeptDesc)
        {
            _extendedPage.SwitchToContentFrame();
            _inputRequisitionDescription.SendKeys(DeptDesc);
            _inputRequisitionDescription.SendKeys(Keys.Tab);
            Settings.Logger.Info($"Searching For Requisition Description {DeptDesc} ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Select Requisition status
        /// </summary>
        /// <param name="StatusValue"></param>
        public void SelectRequisitionStatus(string StatusValue)
        {
            _extendedPage.SwitchToContentFrame();
            _selectRequisitionStatus.SelectFilterValueHavingEqualValue(StatusValue);
            _selectRequisitionStatus.SendKeys(Keys.Tab);
            Settings.Logger.Info($"selected For Requisition satus as {StatusValue} ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify selected Requisition status value
        /// </summary>
        /// <param name="statusValue"></param>
        public void VerifySelectRequisitionStatusValue(string StatusValue)
        {
            Settings.Logger.Info("Verifying Selected Requisition Status Value ");
            _extendedPage.SwitchToContentFrame();
            _selectRequisitionStatus.VerifyElementDisplay(" Requisition Status ");
            string reqStatus = _selectRequisitionStatus.GetElementValueByAttribute("ovalue");
            Assert.AreEqual(reqStatus, StatusValue);
            Settings.Logger.Info($"Matched Actual Requisition satus as {reqStatus} and expected Requisition satus as {StatusValue} ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Search for Requisition Department number
        /// </summary>
        /// <param name="reqValue"></param>
        public void SearchForReqDepartmentNumber(string ReqValue)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputReqDepartmentNumber, "input ReqDepartment Number");
            Driver.SwitchTo().DefaultContent();
            _lov.SearchAndSelectFirstRowData(ReqValue);
            Settings.Logger.Info($"Searched Req Department Number as {ReqValue} ");
        }

        /// <summary>
        /// Enter Requisition Department Number And Press Tab
        /// </summary>
        /// <param name="reqDeptNumber"></param>
        public void EnterReqDepartmentNumberAndPressTab(string ReqDeptNumber)
        {
            _extendedPage.SwitchToContentFrame();
            _inputReqDepartmentNumber.SendKeys(ReqDeptNumber);
            _inputReqDepartmentNumber.SendKeys(Keys.Tab);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Search for Requisition Direct Account number
        /// </summary>
        /// <param name="reqValue"></param>
        public void SearchForReqDirectAccountNumber(string ReqValue)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputReqDirectAccountNumber, "Direct AcctNo");
            Driver.SwitchTo().DefaultContent();
            _lov.SearchAndSelectFirstRowData(ReqValue);
        }

        /// <summary>
        /// Enter Requisition Direct Account Number And Press Tab
        /// </summary>
        /// <param name="ReqDeptNumber"></param>
        public void EnterReqDirectAccountNumberAndPressTab(string ReqDeptNumber)
        {
            _extendedPage.SwitchToContentFrame();
            _inputReqDirectAccountNumber.SendKeys(ReqDeptNumber);
            _inputReqDirectAccountNumber.SendKeys(Keys.Tab);
            Settings.Logger.Info($"Entered Requisition Number {ReqDeptNumber}");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Requisition created date
        /// </summary>
        public void VerifyRequisitionCreatedDate()
        {
            Settings.Logger.Info("Verifying Requisition Status Value ");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.VerifySystemDateContainAppdate(_inputReqCreated, "Requisition Created");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>	
        /// Create new Work Order Department Requisition	
        /// </summary>
        public void CreateNewWorkOrderDepartmentRequisition()
        {
            Settings.Logger.Info(" Creating Work order Department Requisition ");
            DepartmentObjects.WoDeptReqNo = CommonUtil.GetRandomStringWithSpecialChars();
            EnterRequisitionNumberAndPressTab(DepartmentObjects.WoDeptReqNo);
            _extendedPage.ActionRequiredWindow("Create");
            EnterRequisitionDescriptionAndPressTab(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqDesc));
            EnterReqDepartmentNumberAndPressTab(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqDeptNo));
            Driver.WaitForReady();
            EnterReqDirectAccountNumberAndPressTab(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqDirectAccNo));
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Update Requisition Status Value
        /// </summary>
        /// <param name="Status"></param>
        public void UpdateRequisitionStatusValue(string Status)
        {
            SelectRequisitionStatus(CommonUtil.DataForKey(Status));
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            VerifyWorkOrderDepartmentRequisitionsTitle();
        }

        /// <summary>
        /// Verify Requisition Status Value
        /// </summary>
        /// <param name="Status"></param>
        public void VerifyRequisitionStatusValue(string Status)
        {
            string flagId;
            Settings.Logger.Info("Verifying Requisition Status Value ");
            _extendedPage.ClickOnRefreshButton();
            EnterRequisitionNumberAndPressTab(DepartmentObjects.WoDeptReqNo);
            if (CommonUtil.DataForKey(Status) == "Open")
                flagId = "O";
            else
                flagId = "C";
            VerifySelectRequisitionStatusValue(flagId);
        }

        /// <summary>
        /// Verify Open Work Order Count
        /// </summary>
        /// <param name="Count"></param>
        public void VerifyOpenWorkOrderCount(string Count)
        {
            Settings.Logger.Info("Verifying Selected Requisition Status Value ");
            _extendedPage.SwitchToContentFrame();
            _inputReqWorkOrderCount.VerifyElementDisplay(" Requisition Work Order Count ");
            string reqCount = CommonUtil.DataForKey(Count);
            string woCount = _inputReqWorkOrderCount.GetElementValueByAttribute("ovalue");
            Assert.AreEqual(woCount, reqCount);
            Settings.Logger.Info($"Matched Actual Req WO Count as {woCount} and expected Req WO Count as {reqCount} ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update and Verify Work Order Department Requisitions Status
        /// </summary>
        public void UpdateAndVerifyWODeptRequisitionStatus()
        {            
            EnterRequisitionNumberAndPressTab(DepartmentObjects.WoDeptReqNo);
            Driver.WaitForReady();
            UpdateRequisitionStatusValue(DepartmentObjects.WoDeptReqUpdatedStatus);
            Driver.WaitForReady();
            VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqUpdatedStatus);
        }
    }
}
