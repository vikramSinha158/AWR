﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetupTanksPageActions : ProductSetupTanksPage
    {
        public ProductSetupTanksPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Product Tank
        /// </summary>
        /// <param name=""></param>
        public void CreateProductTank(ProductTank DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _fuelLocation.SetText(DataObject.FuelLocation, "_fuelLocation");
            Settings.Logger.Info(" Filling Tank Information for Location R-SYS  ");
            Driver.SwitchTo().Frame("LocFuelTankFrame");
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;

            int RowNum = 0;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                if (_verifyTankNo(updateProductTank.TankNo).Count > 0)
                {
                    DeleteSelectedTankNumberRow(updateProductTank.TankNo);
                }
                _extendedPage.GetInputElementAndSetValue($"{_tankNo}{RowNum}", updateProductTank.TankNo, "id");
                Driver.WaitForReady();
                _extendedPage.GetInputElementAndSetValue($"{_productNo}{RowNum}", updateProductTank.ProductNo, "id");
                Driver.WaitForReady();
                _extendedPage.GetInputElementAndSetValue($"{_productType}{RowNum}", updateProductTank.Type, "id");
                Driver.WaitForReady();
                _extendedPage.GetInputElementAndSetValue($"{_adjAccount}{RowNum}", updateProductTank.Adj_Account, "id");
                Driver.WaitForReady();
                _extendedPage.SetCheckBox(_checkBoxEVR($"new_{RowNum}"), "EVR 11");
                Driver.SwitchTo().DefaultContent();
                Driver.WaitForSomeTime();
                RowNum++;
            }
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Existing Row from table
        /// </summary>
        /// <param name=""></param>
        public void DeleteSelectedTankNumberRow(string productTank)
        {
            foreach (IWebElement tank in _verifyTankNo(productTank))
            {
                tank.ClickElement("tank", Driver);
                _extendedPage.DeleteAndSave();
            }
            Driver.SwitchTo().Frame("LocFuelTankFrame");
        }


        /// <summary>
        /// Verify Created Product Tank
        /// </summary>
        /// <param name=""></param>
        public void VerifyCreatedProductTank(ProductTank DataObject)
        {
            int RowNum = 0;
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchTo().Frame("LocFuelTankFrame");
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                String ActualTankNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tTank_no").GetAttribute("value");
                CommonUtil.AssertTrue<string>(updateProductTank.TankNo, ActualTankNo);
                String ActualProductNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tProd_no").GetAttribute("value");
                CommonUtil.AssertTrue<string>(updateProductTank.ProductNo, ActualProductNo);
                String ActualProductDescription = _extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tProdDesc").GetAttribute("value");
                CommonUtil.AssertTrue<string>(updateProductTank.ProductDescription, ActualProductDescription);
                String ActualType = _extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tTank_Type").GetAttribute("value");
                CommonUtil.AssertTrue<string>(updateProductTank.Type, ActualType);
                String ActualAdj_Account = _extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tAdj_Acct").GetAttribute("value");
                CommonUtil.AssertTrue<string>(updateProductTank.Adj_Account, ActualAdj_Account);
                String ActualAccountDescription = _extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tIndAcctDesc").GetAttribute("value");
                CommonUtil.AssertTrue<string>(updateProductTank.AccountDescription, ActualAccountDescription);
                CommonUtil.VerifyCheckboxState(_checkBoxEVR($"new_{RowNum}"), "_checkBoxEVR", true);
                RowNum++;
            }
        }

        /// <summary>
        /// Update and Delete Product Tank
        /// </summary>
        /// <param name=""></param>
        public void UpdateAndDeleteProductTank(ProductTank DataObject)
        {
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToContentFrame();
            _fuelLocation.SetText(DataObject.FuelLocation, "_fuelLocation");
            Driver.SwitchTo().Frame("LocFuelTankFrame");
            Driver.WaitForReady();
            _checkBoxEVR("1").ClickElement("_checkBoxEVR", Driver);
            Settings.Logger.Info("Verify the check box that successfully toggled off ");
            CommonUtil.VerifyCheckboxState(_checkBoxEVR("1"), "_checkBoxEVR", false);

            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                if (_verifyTankNo(updateProductTank.TankNo).Count > 0)
                {
                    DeleteSelectedTankNumberRow(updateProductTank.TankNo);
                }

            }
        }


        /// <summary>
        /// Verify Deleted Product Tank
        /// </summary>
        /// <param name=""></param>
        public void VerifyDeletedProductTank(ProductTank DataObject)
        {
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToContentFrame();
            _fuelLocation.SetText(DataObject.FuelLocation, "_fuelLocation");
            Driver.SwitchTo().Frame("LocFuelTankFrame");
            Driver.WaitForReady();
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                if (_verifyTankNo(updateProductTank.TankNo).Count > 0)
                {
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}