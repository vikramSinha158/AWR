﻿using OpenQA.Selenium;
using Newtonsoft.Json.Linq;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.PositionCodeObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class PositionCodesPageActions : PositionCodePage
    {
        public PositionCodesPageActions(IWebDriver Driver) : base(Driver) { }

        string Code = string.Empty;
        string Desc = string.Empty; 
        
        /// <summary>
        /// Create Position Code
        /// </summary>
        /// <param name="Code"></param>
        public string CreatePositionCode(string DataObjectKey, ref string Desc)
        {
            PositionCodesData posCodeObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<PositionCodesData>();           
            Settings.Logger.Info("Create Position Code");
            _extendedPage.SwitchToTableFrame(_framePositionCodes);
            Code = posCodeObjectValues.CreatePositionCode.Code == "random" ? CommonUtil.GetRandomStringWithSpecialChars(3, true, false).ToUpper() : posCodeObjectValues.CreatePositionCode.Code;
            Desc = posCodeObjectValues.CreatePositionCode.Desc == "random" ? $"{Code} DESCRIPTION" : posCodeObjectValues.CreatePositionCode.Desc;
            _inputPositionCode.SetText(Code, "Position Code");
            _inputPositionCodeDesc.SetText(Desc, "Position Code Description");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            return Code;
        }

        /// <summary>
        /// Verify Position Code Data
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="DescVal"></param>
        public void VerifyPositionCodeData(string CodeVal, string DescVal)
        {            
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_framePositionCodes, "Table frame");
            Settings.Logger.Info("Verify Position Code Description for : " + CodeVal);
            string cellDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(
            _tablePositionCodes, "Position", CodeVal, "desc").GetAttribute("value");
            CommonUtil.AssertTrue(DescVal, cellDesc);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update and Verify Position Code Data
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="UpdatedDesc"></param>
        public void UpdateAndVerifyPositionCodeData(string PosCode,string Desc)
        {            
            Settings.Logger.Info("Update Position Code :");                       
            _extendedPage.SwitchToTableFrame(_framePositionCodes);
            string UdateDesc = $"{ Desc } NEW";
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePositionCodes, "Position", PosCode, "desc").Clear();
           _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePositionCodes, "Position", PosCode, "desc").SendKeys(UdateDesc);
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            VerifyPositionCodeData(Code, UdateDesc);         

        }

        /// <summary>
        /// Delete Position Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeletePositionCode(string CodeVal)
        {

            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_framePositionCodes, "Table frame");
            Settings.Logger.Info("Delete Position Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
            _tablePositionCodes, "Position", CodeVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Deleted Position Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedPositionCode(string CodeVal)
        {         
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_framePositionCodes, "Table frame");
            Settings.Logger.Info("Verify Asset Class Code is Deleted for : " + CodeVal);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tablePositionCodes, "Position", CodeVal);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Error Message
        /// </summary>
        /// <param name="message"></param>
        public void VerifyErrorMessage(string message)
        {
            Assert.IsTrue(_extendedPage.GetErrorMessage().Contains(message));
            Driver.WaitForReady();          
            _extendedPage.ActionRequiredWindow("Leave");
        }

    }
    }

