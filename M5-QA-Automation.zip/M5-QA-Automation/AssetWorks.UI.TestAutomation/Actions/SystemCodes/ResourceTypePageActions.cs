﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Employee
    {
    internal class ResourceTypePageActions : ResourceTypePage
    {

        public ResourceTypePageActions(IWebDriver Driver) : base(Driver) { }

       /// <summary>
       /// Add Resource Type
       /// </summary>
       /// <param name="ResourceObject"></param>
       /// <returns></returns>
        public string AddResourceType(ResourceType ResourceObject)
        {
            string ResourceNo = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(ResourceObject.Resource, ref ResourceNo, "ResourceTypeQuery",4))
            {
                ResourceObject.Resource = ResourceNo;
                Settings.Logger.Info($"Creating Resource Type :-{ResourceObject.Resource}");
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_resourceTypeFrame, "Resource Type frame");
                _resource.SetText(ResourceObject.Resource, "Resource");
                _desc.SetText(ResourceObject.Description, "Description");
                _markUpScheme.SetText(ResourceObject.MarkupScheme, "MarkupScheme");
                Driver.WaitForReady();
                _disabled.SelectCheckBox("Disabled", ResourceObject.Disable);
                _extendedPage.SaveAndChackWarning();
                Settings.Logger.Info($"Completed Adding Resource Type :-{ ResourceObject.Resource}");
            }
            return ResourceObject.Resource;
        }       

      /// <summary>
      /// Verify resource Type
      /// </summary>
      /// <param name="CourseObject"></param>
        public void VerifyResourceType(ResourceType CourseObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_resourceTypeFrame, "Resource Type frame");
            Settings.Logger.Info($"Verifying Resource Type :-{ CourseObject.Resource}");      
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_resourceTable, "Resource", CourseObject.Resource,Description), " Description", CourseObject.Description,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_resourceTable, "Resource", CourseObject.Resource, MarkUpScheme), "Markup Scheme", CourseObject.MarkupScheme, false, "value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_resourceTable, "Resource", CourseObject.Resource, Disabled), "Disabled", CourseObject.Disable);
            Settings.Logger.Info($" Resource Type :-{ CourseObject.Resource} verified Successfully");
            Driver.SwitchTo().DefaultContent();
        }

      /// <summary>
      /// Delete Resource Type
      /// </summary>
      /// <param name="Resource"></param>
        public void DeleteResourceType(string Resource)
        {            
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_resourceTypeFrame, "Resource Type frame");
            Settings.Logger.Info("Deleting Resource Type : " + Resource);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
           _resourceTable, "Resource", Resource, "desc").ClickElement("Description",Driver);
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
        }


        /// <summary>
        /// Verify Training Course Deletion
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedTrainingCourse(string Resource)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_resourceTypeFrame, "Resource Type frame");
            Settings.Logger.Info("Verify Resource Type  Deletion : " + Resource);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_resourceTable, "Resource", Resource);
            Driver.SwitchTo().DefaultContent();
        }

    }
    }   
