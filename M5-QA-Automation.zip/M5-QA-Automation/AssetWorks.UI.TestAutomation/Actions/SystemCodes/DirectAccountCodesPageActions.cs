﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class DirectAccountCodesPageActions : DirectAccountCodesPage
    {
        public DirectAccountCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Direct Account Code
        /// </summary>
        /// <param name="dca"></param>
        /// <returns>DirectAccount</returns>
        public string CreateNewDirectAccountCode(DirectAccountInformation dca)
        {
            Settings.Logger.Info(" Creating Direct Account Code ");
            string DirectAccount = string.Empty;
            if (string.IsNullOrEmpty(dca.DirectAccount) || dca.DirectAccount.ToLower().Equals("random"))
                dca.DirectAccount = $"{CommonUtil.GetRandomStringWithSpecialChars(4)}-{CommonUtil.GetRandomStringWithSpecialChars(4)}-{CommonUtil.GetRandomStringWithSpecialChars(4)}";

            if (!_extendedPage.CheckDataExistenceAndGetActionCode(dca.DirectAccount, ref DirectAccount, "DirectAccountCodeQuery"))
            {
                _inputDirectAccount.SetText(DirectAccount, "Direct Account", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                _extendedPage.ClickOnDialogBoxButton("Create");
                _extendedPage.SwitchToContentFrame();
                _inputDescription.SetText(dca.Description, "Description");
                _selectDisabled.SelectFilterValueHavingEqualValue(dca.Disabled);
                _extendedPage.VerifyRecordCreatedSuccess(_inputDirectAccount, _inputDescription, DirectAccount, "Direct Account");
            }
            return DirectAccount;
        }

        /// <summary>
        /// Verify Direct Account Code
        /// </summary>
        /// <param name="dca"></param>
        public void VerifyDirectAccountCode(DirectAccountInformation dca)
        {
            Settings.Logger.Info(" Verify Direct Account Code ");
            _extendedPage.RefreshAndSetText(_inputDirectAccount, dca.DirectAccount, "Direct Account Code");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputDescription, "Description", dca.Description);
            CommonUtil.VerifyElementValue(_selectDisabled, "Disabled", dca.Disabled, true);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Direct Account Code
        /// </summary>
        /// <param name="dca"></param>
        public void UpdateDirectAccountCode(DirectAccountInformation dca)
        {
            Settings.Logger.Info(" Update Direct Account Code ");
            _extendedPage.RefreshAndSetText(_inputDirectAccount, dca.DirectAccount, "Direct Account Code");
            Driver.WaitForReady();
            _inputDescription.SetText(dca.Description, "Description");
            _selectDisabled.SelectFilterValueHavingEqualValue(dca.Disabled);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Direct Account Code
        /// </summary>
        /// <param name="Code"></param>
        public void DeleteDirectAccountCode(string Code)
        {
            Settings.Logger.Info(" Delete Direct Account Code ");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _inputDirectAccount.SetText(Code, "Direct Account Code");
            Driver.WaitForReady();
            _inputDirectAccount.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
        }
    }
}
