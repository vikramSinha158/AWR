﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;
using System;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class AssetClassCodesPageActions : AssetClassCodesPage
    {
        public AssetClassCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Asset Class Code
        /// </summary>
        /// <param name="Code"></param>
        /// <param name="CodeDesc"></param>
        public string CreateAssetClassCode(string Code, string CodeDesc)
        {
            string AssetClassCode=String.Empty;
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameAssetClassCodes, "Table frame");
            Settings.Logger.Info("Create Asset Class Code");
            if (Code.Equals("random", StringComparison.OrdinalIgnoreCase) || String.IsNullOrEmpty(Code))
                AssetClassCode = CommonUtil.GetRandomStringWithSpecialChars(5).ToUpper();
            else
                AssetClassCode = Code;
            _inputNewCode.SetText(AssetClassCode, "New code");
            _inputNewDesc.SetText(CodeDesc, "New code desc");
            Driver.DoubleClick(_inputNewSmoothShift, "New smooth shift");
            _lov.SelectFirstTableRecord();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            _extendedPage.ClickOnRefreshButton();
            return AssetClassCode;
        }

        /// <summary>
        /// Refresh And Switch To Table Frame
        /// </summary>
        public void RefreshAndSwitchToTable()
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameAssetClassCodes, "Table frame");
        }

        /// <summary>
        /// Verify Asset Class Code Description
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="DescVal"></param>
        public void VerifyAssetClassCodeDescription(string CodeVal, string DescVal)
        {
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Verify Asset Class Code Description for : " + CodeVal);
            string cellDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableAssetClassCodes, "Code", CodeVal, "desc").GetAttribute("value");
            CommonUtil.AssertTrue(DescVal, cellDesc);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Asset Class Code Description
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="UpdatedDesc"></param>
        public void UpdateAssetClassCodeDescription(string CodeVal, string UpdatedDesc)
        {
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Update Asset Class Code Description for : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes,
                "Code", CodeVal, "desc").SetText(UpdatedDesc, "Code Description");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Disable Asset Class Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DisableAssetClassCode(string CodeVal)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameAssetClassCodes, "Table frame");
            Settings.Logger.Info("Disable Asset Class Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableAssetClassCodes, "Code", CodeVal, "disabled").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Disabled Asset Class Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDisabledAssetClassCode(string CodeVal)
        {
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Verify Asset Class Code is Disabled for : " + CodeVal);
            string cellDisabled = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableAssetClassCodes, "Code", CodeVal, "disabled").GetAttribute("checked");
            CommonUtil.AssertTrue("true", cellDisabled);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Asset Class Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteAssetClassCode(string CodeVal)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameAssetClassCodes, "Table frame");
            Settings.Logger.Info("Delete Asset Class Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableAssetClassCodes, "Code", CodeVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
        }


        /// <summary>
        /// Verify Deleted Asset Class Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedAssetClassCode(string CodeVal)
        {
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Verify Asset Class Code is Deleted for : " + CodeVal);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableAssetClassCodes, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Operate Multiple Asset Class Code Description
        /// </summary>
        /// <param name="Option"></param>
        /// <param name="DataKey"></param>
        public void OperateMultipleAssetClassCodeDescription(string Option, string DataKey)
        {
            string _code, _codeDesc;
            var _records = CommonUtil.DataObjectForKey(DataKey);
            if (_records != null)
            {
                foreach (var record in _records)
                {
                    _code = CommonUtil.DataForKey("Code", record);
                    _codeDesc = CommonUtil.DataForKey("Desc", record);
                    if (Option.ToLower().Equals("create"))
                        CreateAssetClassCode(_code, _codeDesc);
                    else if (Option.ToLower().Equals("update"))
                        UpdateAssetClassCodeDescription(_code, _codeDesc);
                    else if (Option.ToLower().Equals("verify"))
                        VerifyAssetClassCodeDescription(_code, _codeDesc);
                    Driver.WaitForReady();
                }
            }
            else
                Settings.Logger.Info("Test data not found to Asset Class Code");
        }

        /// <summary>
        /// Operate Multiple Asset Class Code
        /// </summary>
        /// <param name="Option"></param>
        /// <param name="DataKey"></param>
        public void OperateMultipleAssetClassCode(string Option, string DataKey)
        {
            string[] _codes = CommonUtil.DataObjectForKey(DataKey).ToObject<string[]>();
            if (_codes != null)
            {
                foreach (string _code in _codes)
                {
                    if (Option.ToLower().Equals("disable"))
                        DisableAssetClassCode(_code);
                    else if (Option.ToLower().Equals("delete"))
                        DeleteAssetClassCode(_code);
                    else if (Option.ToLower().Equals("verifydisabled"))
                        VerifyDisabledAssetClassCode(_code);
                    else if (Option.ToLower().Equals("verifydeleted"))
                        VerifyDeletedAssetClassCode(_code);
                }
            }
            else
                Settings.Logger.Info("Test data not found for Asset Class Codes");
        }

        /// <summary>
        /// Get Assect code List
        /// </summary>
        /// <param name="DatObjectKey"></param>
        /// <returns></returns>
        public List<string> GetAssectcodeList(string DatObjectKey)
        {
            List<string> AssetCodeList = new List<string>();
            AssetClassCode? DataObject = CommonUtil.DataObjectForKey(DatObjectKey).ToObject<AssetClassCode>();
            if (DataObject != null)
            {
                List<CreateACC> ACCCodes = DataObject.CreateACC;
                foreach (CreateACC Codedetail in ACCCodes)
                {
                    AssetCodeList.Add(CreateAssetClassCode(Codedetail.Code, Codedetail.Desc));
                }     
            }
            return AssetCodeList;
        }
    }
}
