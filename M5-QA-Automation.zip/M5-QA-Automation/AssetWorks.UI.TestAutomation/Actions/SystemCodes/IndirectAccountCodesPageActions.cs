﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class IndirectAccountCodesPageActions : IndirectAccountCodesPage
    {
        public IndirectAccountCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Indirect Account Code
        /// </summary>
        /// <param name="accountInfo"></param>
        /// <returns>IndirectAccount</returns>
        public string CreateIndirectAccountCode(IndirectAccountInfo accountInfo)
        {
            Settings.Logger.Info(" Creating Indirect Account Code ");
            string IndirectAccount = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(accountInfo.AccountNo, ref IndirectAccount, "InirectAccountCodeQuery", 5))
            {
                _inputAccountNo.SetText(IndirectAccount, "Indirect Account No", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                _extendedPage.ClickOnDialogBoxButton("Create");
                _extendedPage.SwitchToContentFrame();
                _inputDescription.SetText(accountInfo.Description, "Description");
                _selectDisabled.SelectFilterValueHavingEqualValue(accountInfo.Disabled);
                if (accountInfo.Characteristics != null)
                    UpdateIndirectCodeCharacteristics(accountInfo.Characteristics);
                _extendedPage.VerifyRecordCreatedSuccess(_inputAccountNo, _inputDescription, IndirectAccount, "Indirect Account No");
            }
            return IndirectAccount;
        }

        /// <summary>
        /// Update Indirect Code Characteristics
        /// </summary>
        /// <param name="characteristics"></param>
        public void UpdateIndirectCodeCharacteristics(Characteristics characteristics)
        {
            Settings.Logger.Info(" Updating Indirect Account Code Characteristics ");
            if (characteristics.CommercialChargesAllowed)
                _checkboxCommercialChargesAllowed.SelectCheckBox("Commercial Charges Allowed");
            else
                _checkboxCommercialChargesAllowed.DeSelectCheckBox("Commercial Charges Allowed");
        }

        /// <summary>
        /// Verify Indirect Account Code
        /// </summary>
        /// <param name="accountInfo"></param>
        public void VerifyIndirectAccountCode(IndirectAccountInfo accountInfo)
        {
            Settings.Logger.Info(" Verify Indirect Account Code ");
            _extendedPage.RefreshAndSetText(_inputAccountNo, accountInfo.AccountNo, "Indirect Account Code");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputDescription, "Description", accountInfo.Description);
            CommonUtil.VerifyElementValue(_selectDisabled, "Disabled", accountInfo.Disabled, true);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Indirect Account Code
        /// </summary>
        /// <param name="accountInfo"></param>
        public void UpdateIndirectAccountCode(IndirectAccountInfo accountInfo)
        {
            Settings.Logger.Info(" Update Indirect Account Code ");
            _extendedPage.RefreshAndSetText(_inputAccountNo, accountInfo.AccountNo, "Indirect Account Code");
            Driver.WaitForReady();
            _inputDescription.SetText(accountInfo.Description, "Description");
            _selectDisabled.SelectFilterValueHavingEqualValue(accountInfo.Disabled);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Indirect Account Code
        /// </summary>
        /// <param name="code"></param>
        public void DeleteIndirectAccountCode(string code)
        {
            Settings.Logger.Info(" Verify Indirect Account Code Deletion ");
            _extendedPage.VerifyCodeDeletion(_inputAccountNo, code, "Indirect Account Code");
        }
    }
}
