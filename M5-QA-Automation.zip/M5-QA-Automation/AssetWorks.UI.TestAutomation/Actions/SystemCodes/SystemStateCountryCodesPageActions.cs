﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class SystemStateCountryCodesPageActions : SystemStateCountryCodesPage
    {
        public SystemStateCountryCodesPageActions(IWebDriver Driver) : base(Driver) { }

        public void SwitchToTable(IWebElement Table, string TableName)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(Table, $"'{TableName}' table ");
        }

        /// <summary>
        /// Create Country Code
        /// </summary>
        /// <param name="Code"></param>
        /// <param name="CodeDesc"></param>
        /// <param name="CodeLength"></param>
        public void CreateCountryCode(string Code, string CodeDesc, string CodeLength = "4")
        {
            SwitchToTable(_frameCountry, "Country");
            Settings.Logger.Info("Create Country Code");
            _inputNewCountryCode.SetText(Code, "New code");
            _inputNewCountryDesc.SetText(CodeDesc, "New code desc");
            _inputNewStateCodeLeng.SetText(CodeLength, "New state code length");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            _extendedPage.ClickOnRefreshButton();
        }

        /// <summary>
        /// Select Country Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void SelectCountryCode(string CodeVal)
        {
            SwitchToTable(_frameCountry, "Country");
            Settings.Logger.Info("Select Country Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableCountry, "Code", CodeVal, "code").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Country Code Description
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="DescVal"></param>
        public void VerifyCountryCodeDescription(string CodeVal, string DescVal)
        {
            _extendedPage.ClickOnRefreshButton();
            SwitchToTable(_frameCountry, "Country");
            Settings.Logger.Info("Verify Country Code Description for : " + CodeVal);
            string cellDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableCountry, "Code", CodeVal, "desc").GetAttribute("value");
            CommonUtil.AssertTrue(DescVal.ToUpper(), cellDesc);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Country Code Description
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="UpdatedDesc"></param>
        public void UpdateCountryCodeDescription(string CodeVal, string UpdatedDesc)
        {
            _extendedPage.ClickOnRefreshButton();
            SwitchToTable(_frameCountry, "Country");
            Settings.Logger.Info("Update Country Code Description for : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry,
                "Code", CodeVal, "desc").SetText(UpdatedDesc, "Country Code Description");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Create State Code
        /// </summary>
        /// <param name="StateCode"></param>
        /// <param name="StateDesc"></param>
        public void CreateStateCode(string StateCode, string StateDesc)
        {
            SwitchToTable(_frameState, "State");
            Settings.Logger.Info("Create State Code");
            _inputNewStateCode.SetText(StateCode, "New state code");
            _inputNewStateDesc.SetText(StateDesc, "New state desc");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify State Code Description
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="DescVal"></param>
        public void VerifyStateCodeDescription(string CodeVal, string DescVal)
        {
            SwitchToTable(_frameState, "State");
            Settings.Logger.Info("Verify State Code Description for : " + CodeVal);
            string cellDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableState, "State Code", CodeVal, "stdesc").GetAttribute("value");
            CommonUtil.AssertTrue(DescVal, cellDesc);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update State Code Description
        /// </summary>
        /// <param name="CodeVal"></param>
        /// <param name="UpdatedDesc"></param>
        public void UpdateStateCodeDescription(string CodeVal, string UpdatedDesc)
        {
            SwitchToTable(_frameState, "State");
            Settings.Logger.Info("Update State Code Description for : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableState,
                "State Code", CodeVal, "stdesc").SetText(UpdatedDesc, "State Code Description");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete State Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteStateCode(string CodeVal)
        {
            SwitchToTable(_frameState, "State");
            Settings.Logger.Info("Delete State Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableState, "State Code", CodeVal, "stdesc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Country Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteCountryCode(string CodeVal)
        {
            SwitchToTable(_frameCountry, "Country");
            Settings.Logger.Info("Delete Country Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableCountry, "Code", CodeVal, "code").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Deleted Country Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedCountryCode(string CodeVal)
        {
            _extendedPage.ClickOnRefreshButton();
            SwitchToTable(_frameCountry, "Country");
            Settings.Logger.Info("Verify Country Code is Deleted for : " + CodeVal);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableCountry, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Operate Multiple Country Code Description
        /// </summary>
        /// <param name="Option"></param>
        /// <param name="DataKey"></param>
        public void OperateMultipleCountryCodeDescription(string Option, string DataKey)
        {
            string _code, _codeDesc;
            var _records = CommonUtil.DataObjectForKey(DataKey);
            if (_records != null)
            {
                foreach (var record in _records)
                {
                    _code = CommonUtil.DataForKey("Code", record);
                    _codeDesc = CommonUtil.DataForKey("Desc", record);
                    if (Option.ToLower().Equals("create"))
                        CreateCountryCode(_code, _codeDesc);
                    else if (Option.ToLower().Equals("update"))
                        UpdateCountryCodeDescription(_code, _codeDesc);
                    else if (Option.ToLower().Equals("verify"))
                        VerifyCountryCodeDescription(_code, _codeDesc);
                    Driver.WaitForReady();
                }
            }
            else
                Settings.Logger.Info("Test data not found to Country Code");
        }

        /// <summary>
        /// Operate Multiple State Code Description
        /// </summary>
        /// <param name="Option"></param>
        /// <param name="DataKey"></param>
        public void OperateMultipleStateCodeDescription(string Option, string DataKey)
        {
            string _countryCode, _stateCode, _stateDesc;
            var _records = CommonUtil.DataObjectForKey(DataKey);
            if (_records != null)
            {
                foreach (var record in _records)
                {
                    _countryCode = CommonUtil.DataForKey("CCode", record);
                    _stateCode = CommonUtil.DataForKey("SCode", record);
                    _stateDesc = CommonUtil.DataForKey("SDesc", record);
                    _extendedPage.ClickOnRefreshButton();
                    SelectCountryCode(_countryCode);
                    if (Option.ToLower().Equals("create"))
                        CreateStateCode(_stateCode, _stateDesc);
                    else if (Option.ToLower().Equals("update"))
                        UpdateStateCodeDescription(_stateCode, _stateDesc);
                    else if (Option.ToLower().Equals("verify"))
                        VerifyStateCodeDescription(_stateCode, _stateDesc);
                    Driver.WaitForReady();
                }
            }
            else
                Settings.Logger.Info("Test data not found to State Code");
        }

        /// <summary>
        /// Delete Country State Codes
        /// </summary>
        /// <param name="CountryCode"></param>
        /// <param name="StateCodes"></param>
        public void DeleteCountryStateCodes(string CountryCode, string StateCodes)
        {
            _extendedPage.ClickOnRefreshButton();
            string _countryCode = CommonUtil.DataObjectForKey(CountryCode).ToString();
            string[] _stateCodes = CommonUtil.DataObjectForKey(StateCodes).ToObject<string[]>();
            if (_stateCodes != null)
            {
                foreach (string _code in _stateCodes)
                {
                    SelectCountryCode(_countryCode);
                    DeleteStateCode(_code);
                }
                DeleteCountryCode(_countryCode);
            }
            else
                Settings.Logger.Info("Test data not found for Delete Country State Codes");
        }
    }
}
