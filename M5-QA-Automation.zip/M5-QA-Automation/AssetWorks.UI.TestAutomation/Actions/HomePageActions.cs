using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.Actions.Units;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Actions.MotorPool;
using AssetWorks.UI.M5.TestAutomation.Actions.Equipment;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Actions.MarkUp;
using AssetWorks.UI.M5.TestAutomation.Actions.Accidents;
using AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;
using AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest;
using AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.Actions.Labor;
using AssetWorks.UI.M5.TestAutomation.Actions.Driver;
using AssetWorks.UI.M5.TestAutomation.Actions.ServiceOrder;
using AssetWorks.UI.M5.TestAutomation.Actions.ProductOrder;
using AssetWorks.UI.M5.TestAutomation.Actions.ProductLocationReceive;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class HomePageActions : HomePage
    {
        public HomePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify Home Page
        /// </summary>
        public void VerifyHomePage()
        {
            Driver.WaitForVisibility(By.XPath(locatorHome), " Home page tab ");
            Assert.True(_homeTab.VerifyElementDisplay(" Home tab "), "HomePage Not Dispalyed");
        }

        /// <summary>
        /// Wait till Fram Menu is Visible
        /// </summary>
        public void WaitForFrameMenu()
        {
            Driver.WaitForVisibility(By.XPath("//select[@id='menuReduce']"), "Frame Menu");
        }

        /// <summary>
        /// Navigate WorkOrderMain Page
        /// </summary>
        /// <returns></returns>
        public WorkOrderMainPageActions NavigateWorkOrderMainPage()
        {
            Settings.Logger.Info("Navigating to Work Order Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Order Main Page", ScreensUrl.WorkOrderMain);
            return new WorkOrderMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Main Page
        /// </summary>
        /// <returns></returns>
        public DepartmentMainPageActions NavigateToDepartmentMainPage()
        {
            Settings.Logger.Info("Navigating to Department Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Main Page", ScreensUrl.DepartmentMain);
            return new DepartmentMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Unit Main Page
        /// </summary>
        /// <returns></returns>
        public UnitMainPageActions NavigateUnitMainPage()
        {
            Settings.Logger.Info("Navigating to Unit Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Main Page", ScreensUrl.UnitMain);
            return new UnitMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Component Main Page
        /// </summary>
        /// <returns></returns>
        public ComponentMainPageActions NavigateComponentMainPage()
        {
            Settings.Logger.Info("Navigating to Component Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Main Page", ScreensUrl.ComponentMain);
            return new ComponentMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Order Department Requisitions Page
        /// </summary>
        /// <returns></returns>
        public WODepartmentRequisitionsPageActions NavigateToWODepartmentRequisitionsMainPage()
        {
            Settings.Logger.Info("Navigating to Department Requisitions Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Requisitions Main Page", ScreensUrl.WorkOrderDepartmentRequisitions);
            return new WODepartmentRequisitionsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Number Change Page
        /// </summary>
        /// <returns></returns>
        public DepartmentNumberChangePageActions NavigateToDepartmentNumberChangePage()
        {
            Settings.Logger.Info("Navigating to Department Number Change Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Number Change Page", ScreensUrl.DepartmentNumberChange);
            return new DepartmentNumberChangePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Request Main Page
        /// </summary>
        /// <returns></returns>
        public WorkRequestMainPageActions NavigateToWorkRequestMainPage()
        {
            Settings.Logger.Info("Navigating to work request page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("work request page", ScreensUrl.WorkRequestMain);
            return new WorkRequestMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Copy Page
        /// </summary>
        /// <returns>DepartmentCopyPageActions</returns>
        public DepartmentCopyPageActions NavigateToDepartmentCopyPage()
        {
            Settings.Logger.Info("Navigating to Department Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Copy Page", ScreensUrl.DepartmentCopy);
            return new DepartmentCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Department Change Page
        /// </summary>
        /// <returns>UnitDepartmentChangePageActions</returns>
        public UnitDepartmentChangePageActions NavigateToUnitDepartmentChangePage()
        {
            Settings.Logger.Info("Navigating to Unit Department Change Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Department Change Page", ScreensUrl.UnitDepartmentChange);
            return new UnitDepartmentChangePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Groups Page
        /// </summary>
        /// <returns>DepartmentGroupsPageActions</returns>
        public DepartmentGroupsPageActions NavigateToDepartmentGroupsPage()
        {
            Settings.Logger.Info("Navigating to Department Groups Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Groups Page", ScreensUrl.DepartmentGroups);
            return new DepartmentGroupsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to billing Code  Page
        /// </summary>
        /// <returns>BillingCodePageActions</returns>
        public BillingPageActions NavigateToBillingCodePage()
        {
            Settings.Logger.Info("Navigating to Billing Code page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Code page", ScreensUrl.BillingCodes);
            return new BillingPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Asset Class Codes Page
        /// </summary>
        /// <returns>AssetClassCodesPageActions</returns>
        public AssetClassCodesPageActions NavigateToAssetClassCodesPage()
        {
            Settings.Logger.Info("Navigating to Asset Class Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Asset Class Codes Page", ScreensUrl.AssetClassCodes);
            return new AssetClassCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to System State/Country Codes Page
        /// </summary>
        /// <returns>SystemStateCountryCodesPageActions</returns>
        public SystemStateCountryCodesPageActions NavigateToSystemStateCountryCodesPage()
        {
            Settings.Logger.Info("Navigating to System State/Country Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System State/Country Codes Page", ScreensUrl.SystemStateCountryCodes);
            return new SystemStateCountryCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate MCC Main Page 
        /// </summary>
        /// <returns></returns>
        public MCCMainPageActions NavigateToMCCMainPage()
        {
            Settings.Logger.Info("Navigating to MCC Main  page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC Main page", ScreensUrl.MCCMain);
            return new MCCMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Direct Account Codes Page 
        /// </summary>
        /// <returns>DirectAccountCodesPageActions</returns>
        public DirectAccountCodesPageActions NavigateToDirectAccountCodesPage()
        {
            Settings.Logger.Info("Navigating to Direct Account Codes page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Direct Account Codes page", ScreensUrl.DirectAccountCodes);
            return new DirectAccountCodesPageActions(Driver);
        }

        /// Navigate To Standard Job MCC Page
        /// </summary>
        /// <returns>StandardJobMCCActions</returns>
        public StandardJobMCCActions NavigateToStandardJobMCCPage()
        {
            Settings.Logger.Info("Navigating to Standard Job MCC page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Standard Job MCC page", ScreensUrl.StandardJobMCC);
            return new StandardJobMCCActions(Driver);
        }

        /// <summary>
        /// Navigate to System Codes Page
        /// </summary>
        /// <returns>SystemCodesPageActions</returns>
        public SystemCodesPageActions NavigateToSystemCodesPage()
        {
            Settings.Logger.Info("Navigating to System Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System Codes Page", ScreensUrl.SystemCodes);
            return new SystemCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Main Catalog Page
        /// </summary>
        /// <returns>PartMainCatalogPageActions</returns>
        public Parts.PartMainCatalogPageActions NavigateToPartMainCatalogPage()
        {
            Settings.Logger.Info("Navigating to Part Main Catalog Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Main Catalog Page", ScreensUrl.PartMainCatalog);
            return new Parts.PartMainCatalogPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Main Page
        /// </summary>
        /// <returns></returns>
        public EmployeeMainPageActions NavigateToEmployeeMainPage()
        {
            Settings.Logger.Info("Navigating to Employee Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Main Page", ScreensUrl.EmployeeMain);
            return new EmployeeMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Motor Pool Rental Class Page
        /// </summary>
        /// <returns>MotorPoolRentalClassPageActions</returns>
        public MotorPoolRentalClassPageActions NavigateToMotorPoolRentalClassPage()
        {
            Settings.Logger.Info("Navigating to Motor Pool Rental Class Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Rental Class Page", ScreensUrl.MotorPoolRentalClass);
            return new MotorPoolRentalClassPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Role Maintenance Page
        /// </summary>
        /// <returns>PartMainCatalogPageActions</returns>
        public RoleMaintenancePageActions NavigateToRoleMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Role Maintenance Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Role Maintenance Page", ScreensUrl.RoleMaintenance);
            return new RoleMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate Vendor Main Page 
        /// </summary>
        /// <returns>VendorMainPageActions</returns>
        public VendorMainPageActions NavigateToVendorMainPage()
        {
            Settings.Logger.Info("Navigating to Vendor Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Main Page", ScreensUrl.VendorMain);
            return new VendorMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Vendor Main Page 
        /// </summary>
        /// <returns>VendorMainPageActions</returns>
        public VendorMainPageActions NavigateToCopyVendorPage()
        {
            Settings.Logger.Info("Navigating to Copy Vendor Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Copy Page", ScreensUrl.VendorCopy);
            return new VendorMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Vendor Number Change Page 
        /// </summary>
        /// <returns>VendorMainPageActions</returns>
        public VendorMainPageActions NavigateToVendorNumberChangePage()
        {
            Settings.Logger.Info("Navigating to Vendor Number Change Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Number Change Page", ScreensUrl.VendorNumberChange);
            return new VendorMainPageActions(Driver);
        }

        /// <summary>
        /// Naigate to Customer Main Page
        /// </summary>
        /// <returns></returns>
        public CustomerMainPageActions NavigateToCustomerMainPage()
        {
            Settings.Logger.Info("Navigating to Customer Main  page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Customer Main  page", ScreensUrl.CustomerMain);
            return new CustomerMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Application User Maintenance Page 
        /// </summary>
        /// <returns></returns>
        public AppUserMaintenancePageActions NavigateToApplicationUserMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Application User Maintenance Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Application User Maintenance Page", ScreensUrl.ApplicationUserMaintenance);
            return new AppUserMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Request Page
        /// </summary>
        /// <returns>UnitRequestPageActions</returns>
        public Units.UnitRequestPageActions NavigateToUnitRequestPage()
        {
            Settings.Logger.Info("Navigating to Unit Request Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Request Page", ScreensUrl.UnitRequest);
            return new Units.UnitRequestPageActions(Driver);
        }

        /// <summary>
        ///Navigate to Customer Type Codes     
        /// </summary>
        /// <returns></returns>
        public CustomerTypeCodesPageActions NavigateToCustomerTypeCodesPage()
        {
            Settings.Logger.Info("Navigating to Customer Type Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Customer Type Codes Page", ScreensUrl.CustomerTypeCodes);
            return new CustomerTypeCodesPageActions(Driver);
        }

        /// <summary>
        ///Navigate to Booking Type Codes     
        /// </summary>
        /// <returns></returns>
        public BookingTypeCodesPageActions NavigateToBookingTypeCodesPage()
        {
            Settings.Logger.Info("Navigating to Booking Type Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Type Codes Page", ScreensUrl.BookingTypeCodes);
            return new BookingTypeCodesPageActions(Driver);
        }
        /// <summary>
        /// Navigate to Application user page
        /// </summary>
        /// <returns></returns>
        public AppUserCopyPageActions NavigateToApplicationUserCopyPage()
        {
            Settings.Logger.Info("Navigating to Application User Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Application User Copy Page", ScreensUrl.ApplicationUserCopy);
            return new AppUserCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Profile Type page
        /// </summary>
        /// <returns></returns>
        public EqipProfileTypesPageActions NavigateToEquipmentProfileTypePage()
        {
            Settings.Logger.Info("Navigating to Equipment Profile Type Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Profile Types", ScreensUrl.EquipmentProfileTypes);
            return new EqipProfileTypesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Tax Type page
        /// </summary>
        /// <returns></returns>
        public TaxTypePageActions NavigateToTaxTypePage()
        {
            Settings.Logger.Info("Navigating to Tax Type Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Tax Type", ScreensUrl.TaxType);
            return new TaxTypePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Application user page
        /// </summary>
        /// <returns>EquipmentTypesSKUPageActions</returns>
        public EquipmentTypesSKUPageActions NavigateToEquipmentTypesSKUPage()
        {
            Settings.Logger.Info("Navigating to Equipment Types SKU Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Types SKU", ScreensUrl.EquipmentTypesSKU);
            return new EquipmentTypesSKUPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Tech Spec Main Page
        /// </summary>
        /// <returns></returns>
        public TechSpecMainPageActions NavigateToTechSpecMainPage()
        {
            Settings.Logger.Info("Navigating to Tech Spec Main Page ");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.TechSpecMain);
            return new TechSpecMainPageActions(Driver);
        }

        /// <summary>
        /// Tech Spec Copy Page Actions
        /// </summary>
        /// <returns></returns>
        public TechSpecCopyPageActions NavigateToTechSpecCopyPage()
        {
            Settings.Logger.Info("Navigating to Tech Spec Copy Page ");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.TechSpecCopy);
            return new TechSpecCopyPageActions(Driver);
        }

        /// <summary>
        /// Standard Job Tech Specs
        /// </summary>
        /// <returns></returns>
        public StandardJobTechSpecPageActions NavigateToStandardJobTechSpecPage()
        {
            Settings.Logger.Info("Navigating to Standard Job Tech Spec Page Actions ");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.StandardJobTechSpec);
            return new StandardJobTechSpecPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Request Copy Page
        /// </summary>
        /// <returns>UnitRequestCopyPageActions</returns>
        public Units.UnitRequestCopyPageActions NavigateToUnitRequestCopyPage()
        {
            Settings.Logger.Info("Navigating to Unit Request Copy Page");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.UnitRequestCopy);
            return new Units.UnitRequestCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Group Page
        /// </summary>
        /// <returns>UnitGroupPageActions</returns>
        public Units.UnitGroupPageActions NavigateToUnitGroupPage()
        {
            Settings.Logger.Info("Navigating to Unit Group Page");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.UnitGroup);
            return new Units.UnitGroupPageActions(Driver);
        }

        /// <summary>
        /// Component Items Page Actions
        /// </summary>
        /// <returns></returns>
        public ComponentItemsPageActions NavigateToComponentItemsPage()
        {
            Settings.Logger.Info("Navigating to Component Items");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.ComponentItems);
            return new ComponentItemsPageActions(Driver);
        }

        /// <summary>
        /// Chat Group Maintenance Page Actions
        /// </summary>
        /// <returns></returns>
        public ChatGroupMaintenancePageActions NavigateToChatGroupMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Chat Group Maintenance Page");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.ChatGroupMaintenance);
            return new ChatGroupMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Conditions page
        /// </summary>
        /// <returns>EquipmentConditionsPageActions</returns>
        public EquipmentConditionsPageActions NavigateToEquipmentConditionsPage()
        {
            Settings.Logger.Info("Navigating to Equipment Conditions Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Conditions", ScreensUrl.EquipmentConditions);
            return new EquipmentConditionsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Main Catalog Page
        /// </summary>
        /// <returns>PartMainCatalogPageActions</returns>
        public PartBinPageActions NavigateToPartBinPage()
        {
            Settings.Logger.Info("Navigating to Part Bin Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Bin Page", ScreensUrl.PartBinPage);
            return new PartBinPageActions(Driver);
        }

        /// Navigate to Unit Purchase Orders page
        /// </summary>
        /// <returns>UnitPurchaseOrdersPageActions</returns>
        public UnitPurchaseOrdersPageActions NavigateToUnitPurchaseOrdersPage()
        {
            Settings.Logger.Info("Navigating to Unit Purchase Orders Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Purchase Orders", ScreensUrl.UnitPurchaseOrders);
            return new UnitPurchaseOrdersPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Copy page
        /// </summary>
        /// <returns>UnitCopyPageActions</returns>
        public UnitCopyPageActions NavigateToUnitCopyPage()
        {
            Settings.Logger.Info("Navigating to Unit Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Copy", ScreensUrl.UnitCopy);
            return new UnitCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Position Code Page
        /// </summary>
        /// <returns></returns>
        public PositionCodesPageActions NavigateToPositionCodePage()
        {
            Settings.Logger.Info("Navigating to Position Code Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Position Code", ScreensUrl.PositionCode);
            return new PositionCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to System Position Page"
        /// </summary>
        public SystemPositionPageActions NavigateToSystemPositionPage()
        {
            Settings.Logger.Info("Navigating to System Position Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Position Code", ScreensUrl.SystemPosition);
            return new SystemPositionPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Title page
        /// </summary>
        /// <returns>UnitCopyPageActions</returns>
        public EmployeeTitlePageActions NavigateToEmployeeTitlePage()
        {
            Settings.Logger.Info("Navigating to EmployeeTitle Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Title", ScreensUrl.EmployeeTitle);
            return new EmployeeTitlePageActions(Driver);
        }

        /// Navigate to System Flag Page
        /// </summary>
        /// <returns>UnitCopyPageActions</returns>
        public SystemFlagsPageActions NavigateToSystemFlagPage()
        {
            Settings.Logger.Info("Navigating to System Flag Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System Flag", ScreensUrl.SystemFlag);
            return new SystemFlagsPageActions(Driver);
        }

        /// Navigate to Non Company Unit Main page
        /// </summary>
        /// <returns>NonCompanyUnitMainPageActions</returns>
        public NonCompanyUnitMainPageActions NavigateToNonCompanyUnitMainPage()
        {
            Settings.Logger.Info("Navigating to Non Company Unit Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Non Company Unit Main", ScreensUrl.NonCompanyUnitMain);
            return new NonCompanyUnitMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Purchase Requisitions Page
        /// </summary>
        /// <returns>UnitPurchaseRequisitionsPageActions</returns>
        public Units.UnitPurchaseRequisitionsPageActions NavigateToUnitPurchaseRequisitionsPage()
        {
            Settings.Logger.Info("Navigating to Unit Purchase Requisitions Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Purchase Requisitions", ScreensUrl.UnitPurchaseRequisitions);
            return new Units.UnitPurchaseRequisitionsPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Role Copy Page
        /// </summary>
        /// <returns></returns>
        public RoleCopyPageActions NavigateToRoleCopyPage()
        {
            Settings.Logger.Info("Navigating to Role Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("RoleCopy", ScreensUrl.RoleCopy);
            return new RoleCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Tax Scheme page
        /// </summary>
        /// <returns></returns>
        public TaxSchemePageActions NavigateToTaxSchemePage()
        {
            Settings.Logger.Info("Navigating to Tax Scheme Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Tax Scheme", ScreensUrl.TaxScheme);
            return new TaxSchemePageActions(Driver);
        }

        /// <summary>
        /// Billing Fixed Charge Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingFixedChargePageActions NavigateToBillingFixedCharges()
        {
            Settings.Logger.Info("Navigating to Billing Fixed Charges");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("BillingFixedCharges", ScreensUrl.BillingFixedCharges);
            return new BillingFixedChargePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Employee Group Page
        /// </summary>
        /// <returns>EmployeeGroupPageActions</returns>
        public EmployeeGroupPageActions NavigateToEmployeeGroupPage()
        {
            Settings.Logger.Info("Navigating to Employee Group Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Group", ScreensUrl.EmployeeGroup);
            return new EmployeeGroupPageActions(Driver);
        }

        /// <summary>
        ///Employee Transfers Page Actions
        /// </summary>
        /// <returns></returns>
        public EmployeeTransfersPageActions NavigateToEmployeeTransfersPage()
        {
            Settings.Logger.Info("Navigating to Employee Transfers Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.EmployeeTransfer);
            return new EmployeeTransfersPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Employee Shift Assignment
        /// </summary>
        /// <returns></returns>
        public EmployeeShiftAssignPageActions NavigateToEmployeeShiftAssignmentPage()
        {
            Settings.Logger.Info("Navigating to Employee Shift Assignment Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Shift Assignment", ScreensUrl.EmployeeShiftAssignment);
            return new EmployeeShiftAssignPageActions(Driver);
        }


        /// Navigate To Customer Contract Page
        /// </summary>
        /// <returns></returns>
        public CustomerContractPageActions NavigateToCustomerContractPage()
        {
            Settings.Logger.Info("Navigating to Customer Contract Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.CustomerContract);
            return new CustomerContractPageActions(Driver);         
         }

        /// Navigate To Customer Contract Copy Page
        /// </summary>
        /// <returns></returns>
        public CustomerContractCopyPageActions NavigateToCustomerContractCopyPage()
        {
            Settings.Logger.Info("Navigating to Customer Contract Copy Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.CustomerContractCopy);
            return new CustomerContractCopyPageActions(Driver);
        }

        /// <summary>
        ///Employee Copy Page Actions
        /// </summary>
        /// <returns></returns>
        public EmployeeMainPageActions NavigateToEmployeeCopyPage()
        {
            Settings.Logger.Info("Navigating to Employee Copy Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeCopyPage", ScreensUrl.EmployeeCopy);
            return new EmployeeMainPageActions(Driver);
        }

        /// Purchase Requisitions Page Actions
        /// </summary>
        /// <returns></returns>
        public PurchaseRequisitionsPageActions NavigateToPurchaseRequisitions()
        {
            Settings.Logger.Info("Navigating to Purchase Requisitions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.PurchaseRequisitions);
            return new PurchaseRequisitionsPageActions(Driver);
        }

        /// <summary>
        /// Equipment Profile Maintenance Page Actions
        /// </summary>
        /// <returns></returns>
        public EquipmentProfileMaintenancePageActions NavigateToPurcEquipmentProfile()
        {
            Settings.Logger.Info("Navigating to Equipment Profile Maintenance");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Profile Maintenancee", ScreensUrl.EquipmentProfile);
            return new EquipmentProfileMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Item Master Definition Page
        /// </summary>
        /// <returns>ItemMasterDefinitionPageActions</returns>
        public ItemMasterDefinitionPageActions NavigateToItemMasterDefinitionPage()
        {
            Settings.Logger.Info("Navigating to Item Master Definition Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Item Master DefinitionPage", ScreensUrl.ItemMasterDefinition);
            return new ItemMasterDefinitionPageActions(Driver);
        }

        /// <summary>
        /// MCC Copy Page Actions
        /// </summary>
        /// <returns></returns>
        public MCCCopyPageActions NavigateToMCCCopy()
        {
            Settings.Logger.Info("Navigating to MCC Copy");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC Copye", ScreensUrl.MCCCopy);
            return new MCCCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate To MarkUp Scheme Page
        /// </summary>
        /// <returns></returns>
        public MarkUpSchemePageActions NavigateToMarkUpScheme()
        {
            Settings.Logger.Info("Navigate To MarkUp Scheme Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" MarkUp Scheme Page", ScreensUrl.MarkUpScheme);
            return new MarkUpSchemePageActions(Driver);
        }


        /// <summary>
        /// Navigate To Copy MarkUp Scheme Page
        /// </summary>
        /// <returns></returns>
        public MarkUpSchemePageActions NavigateToCopyMarkUpScheme()
        {
            Settings.Logger.Info("Navigate To Copy MarkUp Scheme Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Copy MarkUp Scheme Page", ScreensUrl.CopyMarkUpScheme);
            return new MarkUpSchemePageActions(Driver);
        }

        /// MCC Unit Display Page Actions
        /// </summary>
        /// <returns></returns>
        public MCCUnitDisplayPageActions NavigateToMCCUnitDisplay()
        {
            Settings.Logger.Info("Navigating to MCC Unit Display");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC Unit Display", ScreensUrl.MCCUnitDisplay);
            return new MCCUnitDisplayPageActions(Driver);
        }

        /// <summary>
        /// MCC Query Page Actions
        /// </summary>
        /// <returns></returns>
        public MCCQueryPageActions NavigateToMCCQuery()
        {
            Settings.Logger.Info("Navigating to MCC Query");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC MCC Query", ScreensUrl.MCCQuery);
            return new MCCQueryPageActions(Driver);

        }

        /// <summary>
        /// Employee number change actions
        /// </summary>
        /// <returns></returns>
        public EmployeeNumberChangeActions NavigateToEmployeeNumberChange()
        {
            Settings.Logger.Info("Navigating to Employee number change Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Number Change", ScreensUrl.EmployeeNumberChange);
            return new EmployeeNumberChangeActions(Driver);
        }

        /// Navigate To Accident Type Page
        /// </summary>
        /// <returns></returns>
        public AccidentsTypePageActions NavigateToAccidentTypePage()
        {
            Settings.Logger.Info("Navigating to Accident Type Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Type", ScreensUrl.AccidentType);
            return new AccidentsTypePageActions(Driver);
        }

        /// Navigate To Accident Category Page
        /// </summary>
        /// <returns></returns>
        public AccidentCategoryPageActions NavigateToAccidentCategoryPage()
        {
            Settings.Logger.Info("Navigating to Accident Category Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Type", ScreensUrl.AccidentCategory);
            return new AccidentCategoryPageActions(Driver);
        }

        /// Navigate To Fuel Product main
        /// </summary>
        /// <returns></returns>
        public FuelProductPageActions NavigateToFuelProductsMain()
        {
            Settings.Logger.Info("Navigating to Fuel Product ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Fuels Product", ScreensUrl.FuelProducts);
            return new FuelProductPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Product Setup Tanks
        /// </summary>
        /// <returns></returns>
        public ProductSetupTanksPageActions NavigateToProductSetupTanksPage()
        {
            Settings.Logger.Info("Navigating to Product Setup Tanks Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Tanks", ScreensUrl.ProductSetupTanks);
            return new ProductSetupTanksPageActions(Driver);
        }

        /// <summary>
        /// Navigating to System Active User Display
        /// </summary>
        /// <returns></returns>
        public SystemActiveUserDisplayAction NavigateToSystemActiveUserDsiplay()
        {
            Settings.Logger.Info("Navigating to System Active User Display");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System Active User Display", ScreensUrl.ActiveUserDisplay);
            return new SystemActiveUserDisplayAction(Driver);
        }
        /// Navigate To Accident Entry Page
        /// </summary>
        /// <returns></returns>
        public AccidentEntryPageActions NavigateToAccidentEntryPage()
        {
            Settings.Logger.Info("Navigating to Accident Entry Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Entry", ScreensUrl.AccidentEntry);
            return new AccidentEntryPageActions(Driver);
        }


        /// <summary>
        /// Navigate To Vendor Contract Page
        /// </summary>
        /// <returns></returns>
        public VendorContractPageActions NavigateToVendorContractPage()
        {
            Settings.Logger.Info("Navigating to Vendor Contract Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Contract ", ScreensUrl.VendorContract);
            return new VendorContractPageActions(Driver);
        }

        /// <summary>
        /// Component Copy Actions
        /// </summary>
        /// <returns></returns>
        public ComponentCopyActions NavigateToComponentCopy()
        {
            Settings.Logger.Info("Navigating to Component Copy Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Copy", ScreensUrl.ComponentCopy);
            return new ComponentCopyActions(Driver);
        }

        /// <summary>
        /// Navigate To Component Number Change
        /// </summary>
        /// <returns></returns>
        public ComponentNumberChangePageActions NavigateToComponentNumberChange()
        {
            Settings.Logger.Info("Navigating to Component Number Change Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Number Change", ScreensUrl.ComponentNumberChange);
            return new ComponentNumberChangePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Billing Adjustment
        /// </summary>
        /// <returns></returns>
        public BillingAdjustmentPageActions NavigateToBillingAdjustment()
        {
            Settings.Logger.Info("Navigating to Billing Adjustment");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Adjustment", ScreensUrl.BillingAdjustment);
            return new BillingAdjustmentPageActions(Driver);
        }

        /// <summary>
        ///Navigate to Booking Decline/Cancel Codes     
        /// </summary>
        /// <returns></returns>
        public BookingDeclineCancelCodesPageActions NavigateToBookingDeclineCancelCodesPage()
        {
            Settings.Logger.Info("Navigating to Booking Decline Cancel Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Decline Cancel Codes Page", ScreensUrl.BookingDeclineCancelCodes);
            return new BookingDeclineCancelCodesPageActions(Driver);
        }
        /// <summary>
        /// Navigating to Unit Request Approve Page
        /// </summary>
        /// <returns></returns>
        public UnitRequestApprovePageActions NavigateUnitRequestApprovePage()
        {
            Settings.Logger.Info("Navigating to Unit Request Approve Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Request Approve", ScreensUrl.UnitRequestApprove);
            return new UnitRequestApprovePageActions(Driver);
        }
        /// <summary>
        /// Naigate to Booking Source Code Page
        /// </summary>
        /// <returns></returns>
        public BookingSourceCodePageActions NavigateToBookingSourceCodesPage()
        {
            Settings.Logger.Info("Navigate to Booking Source Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Source Codes", ScreensUrl.BookingSourceCodes);
            return new BookingSourceCodePageActions(Driver);
        }

        ///Navigate to Booking Appointment   
        /// </summary>
        /// <returns></returns>
        public BookingAppointmentPageActions NavigateToBookingAppointmentPage()
        {
            Settings.Logger.Info("Navigating to Booking Appointment Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Appointment Page", ScreensUrl.BookingAppointment);
            return new BookingAppointmentPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Main Page
        /// </summary>
        /// <returns></returns>
        public EmployeeTrainingTransciptPageActions NavigateToEmpTrainingTransciptPage()
        {
            Settings.Logger.Info("Navigating to Employee Training Transcipt Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Training Transcipt Page", ScreensUrl.EmployeeTrainingTranscipt);
            return new EmployeeTrainingTransciptPageActions(Driver);
        }

        /// Navigating to Employee Training Course SetUp Page
        /// </summary>
        /// <returns></returns>
        public EmpCoureSetUpPageActions NavigateToEmpCourseSetUpPage()
        {
            Settings.Logger.Info("Navigating to Employee Training Course SetUp Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Training Course SetUp Page", ScreensUrl.EmpTrainingCourseSetUp);
            return new EmpCoureSetUpPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Billing Unit Accounts Page
        /// </summary>
        /// <returns></returns>
        public BillingUnitAccountsPageActions NavigateToBillingUnitAccountsPage()
        {
            Settings.Logger.Info("NavigateToBillingUnitAccountsPage");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("NavigateToBillingUnitAccountsPage", ScreensUrl.BillingUnitAccounts);
            return new BillingUnitAccountsPageActions(Driver);
        }
        /// Booking Change Dates Reasons Page
        /// </summary>
        /// <returns></returns>
        public BookingChangeDatesReasonsPageActions NavigateToBookingChangeDateReasonsPage()
        {
            Settings.Logger.Info("Navigate to Booking ChangeDate Reasons Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Navigate to Booking ChangeDate Reasons Page", ScreensUrl.BookingChangeDateReason);
            return new BookingChangeDatesReasonsPageActions(Driver);
        }

        /// Navigate to Employee Course Query Page
        /// </summary>
        /// <returns></returns>
        public EmployeeCourseQueryPageActions NavigateToEmpCourseQueryPage()
        {
            Settings.Logger.Info("Navigating to Employee Course Query Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Course Query Page", ScreensUrl.EmpCourseQuery);
            return new EmployeeCourseQueryPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Resource Type Page
        /// </summary>
        /// <returns></returns>
        public ResourceTypePageActions NavigateToResourceTypePage()
        {
            Settings.Logger.Info("Navigating to Resource Type Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Resource Type", ScreensUrl.ResourceType);
            return new ResourceTypePageActions(Driver);        
        }
        
        /// <summary>
        /// Navigate to Parts Inventory Location Manager
        /// </summary>
        public PartInventoryLocationPageActions NavigateToPartInventoryLocationManager()
        {
            Settings.Logger.Info("Navigating to Parts Inventory Location Manager");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Parts Inventory Location Manager setup page", ScreensUrl.PartInventoryLocManager);
            return new PartInventoryLocationPageActions(Driver);
        }
        
        /// <summary>
        /// Navigate to Part Adjustment
        /// </summary>
        /// <returns></returns>
        public PartsAdjustmentPageActions NavigateToPartAdjustment()
        {
            Settings.Logger.Info("Navigating to Parts Adjustment");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Parts Adjustment Page", ScreensUrl.PartAdjustment);
            return new PartsAdjustmentPageActions(Driver);
        }

        /// <summary>
        /// Employee Items Page Actions
        /// </summary>
        /// <returns></returns>
        public EmployeeItemsPageActions NavigateToEmployeeItems()
        {
            Settings.Logger.Info("Navigating to Employee Items");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Items", ScreensUrl.EmployeeItems);
            return new EmployeeItemsPageActions(Driver);
        }
        
        /// Navigate To Accident Cause Page
         /// </summary>
         /// <returns></returns>
        public AccidentCausePageActions NavigateToAccidentCausePage()
        {
            Settings.Logger.Info("Navigating to Accident Cause Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Cause", ScreensUrl.AccidentCause);
            return new AccidentCausePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Request Campaign Page
        /// </summary>
        /// <returns></returns>
        public WorkRequestCampaignPageActions NavigateToWorkRequestCampaignPage()
        {
            Settings.Logger.Info("Navigating to Work Request Campaign Manager page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Request Campaign Manager page", ScreensUrl.WorkRequestCampaignManager);
            return new WorkRequestCampaignPageActions(Driver);
        }

        /// <summary>
        /// Navigating to Location Main Page
        /// </summary>
        /// <returns></returns>
        public LocationMainPageActions NavigateToLocationMain()
        {
            Settings.Logger.Info("Navigating to Location Main");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Location Main Page", ScreensUrl.LocationMain);
            return new LocationMainPageActions(Driver);
        }
           
        /// <summary>
        /// Navigate Warranty TechSpec
        /// </summary>
        /// <returns></returns>
        public TechSpecWarrantyPageActions NavigateWarrantyTechSpec()
        {          
            Settings.Logger.Info("Navigating to WarrantyTechSpec Approve Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("TechSpecWarrantyPageActions", ScreensUrl.WarrantyTechSpec);
            return new TechSpecWarrantyPageActions(Driver);
        }

        /// <summary>
        /// Company Definition Page Actions
        /// </summary>
        /// <returns></returns>
        public CompanyDefinitionPageActions NavigateCompanyDefinition()
        {
            Settings.Logger.Info("Navigating to Company Definition");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("CompanyDefinition", ScreensUrl.CompanyDefinition);
            return new CompanyDefinitionPageActions(Driver);
        }

        /// <summary>
        /// BillingCodeCopyPageActions
        /// </summary>
        /// <returns></returns>
        public BillingCodeCopyPageActions NavigateBillingCodeCopy()
        {
            Settings.Logger.Info("Navigating to Billing Code Copy");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Code Copy", ScreensUrl.BillingCodeCopy);
            return new BillingCodeCopyPageActions(Driver);
        }

        /// <summary>
        /// Billing Items Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingItemsPageActions NavigateBillingItems()
        {
            Settings.Logger.Info("Navigating to Billing Items");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Items", ScreensUrl.BillingItems);
            return new BillingItemsPageActions(Driver);
        }

        /// <summary>
        /// Billing Items Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingItemSourcePageActions NavigateBillingItemSources()
        {
            Settings.Logger.Info("Navigating to Billing Item Source");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Item Source", ScreensUrl.BillingItemSource);
            return new BillingItemSourcePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Planned Absences Page
        /// </summary>
        /// <returns>EmployeePlannedAbsencesPageActions</returns>
        public EmployeePlannedAbsencesPageActions NavigateToEmployeePlannedAbsences()
        {
            Settings.Logger.Info("Navigating to Employee Planned Absences");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Planned Absences", ScreensUrl.EmployeePlannedAbsences);
            return new EmployeePlannedAbsencesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Labor Wedge Page
        /// </summary>
        /// <returns>LaborWedgePageActions</returns>
        public LaborWedgePageActions NavigateToLaborWedgePage()
        {
            Settings.Logger.Info("Navigating to Labor Wedge Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Labor Wedge", ScreensUrl.LaborWedge);
            return new LaborWedgePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Equipment Request Page
        /// </summary>
        /// <returns></returns>
        public EquipmentRequestPageActions NavigateEquipmentRequest()
        {
            Settings.Logger.Info("Navigating to Equipment Request");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EquipmentRequest", ScreensUrl.EquipmentRequest);
            return new EquipmentRequestPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Menu Maintenance Page
        /// </summary>
        /// <returns>MenuMaintenancePageActions</returns>
        public MenuMaintenancePageActions NavigateToMenuMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Menu Maintenance Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Menu Maintenance Page", ScreensUrl.MenuMaintenance);
            return new MenuMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Billing Indirect Items Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingIndirectItemsPageActions NavigateBillingIndirectItems()
        {
            Settings.Logger.Info("Navigating to Billing Indirect Items");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Indirect Items", ScreensUrl.BillingIndirectItems);
            return new BillingIndirectItemsPageActions(Driver);
        }

        /// <summary>
        /// Navigating to Motor Pool Manager Page
        /// </summary>
        /// <returns>MotorPoolManagerPageActions</returns>
        public MotorPoolManagerPageActions NavigateToMotorPoolManager()
        {
            Settings.Logger.Info("Navigating to Motor Pool Manager");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Manager", ScreensUrl.MotorPoolManager);
            return new MotorPoolManagerPageActions(Driver);
        }

        /// <summary>
        /// Driver Status Code Page Actions
        /// </summary>
        /// <returns></returns>
        public DriverStatusCodePageActions NavigateToDriverStatusCodeScreen()
        {
            Settings.Logger.Info("Navigate To Driver Status Code Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Status Codes", ScreensUrl.DriverStatusCodes);
            return new DriverStatusCodePageActions(Driver);
        }

        /// <summary>
        /// Driver Allocation Reasons Page Actions
        /// </summary>
        /// <returns></returns>
        public DriverAllocationReasonsPageActions NavigateToDriverAllocationReasonsScreen()
        {
            Settings.Logger.Info("Navigate To Driver Allocation Reasons Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Allocation Reasons", ScreensUrl.DriverAllocationReasons);
            return new DriverAllocationReasonsPageActions(Driver);
        }

        /// <summary>
        /// Driver Types Page Actions
        /// </summary>
        /// <returns></returns>
        public DriverTypesPageActions NavigateToDriverTypesScreen()
        {
            Settings.Logger.Info("Navigate To Driver Allocation Reasons Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Types", ScreensUrl.DriverTypes);
            return new DriverTypesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Request Incident Page
        /// </summary>
        /// <returns></returns>
        public WorkRequestIncidentPageActions NavigateToWorkRequestIncidentPage()
        {
            Settings.Logger.Info("Navigating to Work Request Incident page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Request Incident page", ScreensUrl.WorkRequestIncident);
            return new WorkRequestIncidentPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Service Order Page
        /// </summary>
        /// <returns></returns>
        public ServiceOrderPageActions NavigateToServiceOrderPage()
        {
            Settings.Logger.Info("Navigating to Service Order page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Service Order page", ScreensUrl.ServiceOrder);
            return new ServiceOrderPageActions(Driver);
        }

        /// <summary>
        /// Billing Department Account
        /// </summary>
        /// <returns></returns>
        public BillingDepartmentAccountsPageActions NavigateBillingDepartmentAccount()
        {
            Settings.Logger.Info("NavigateBillingDepartmentAccount");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Department Accounts", ScreensUrl.BillingDepartmentAccounts);
            return new BillingDepartmentAccountsPageActions(Driver);
        }

        /// <summary>
        /// Navigate Bill Single Department Account
        /// </summary>
        /// <returns></returns>
        public BillSingleDepartmentAccountPageActions NavigateBillSingleDepartmentAccount()
        {
            Settings.Logger.Info("Navigating to Bill Single Department Account");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("BillSingleDepartmentAccount", ScreensUrl.BillSingleDepartmentAccount);
            return new BillSingleDepartmentAccountPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Booking Billing Single Unit Account Page
        /// </summary>
        /// <returns></returns>
        public BillingSingleUnitAccountPageActions NavigateToBookingBillingSingleUnitAccountPage()
        {
            Settings.Logger.Info("Navigating to  Bill Single Unit Account Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Bill Single Unit Account Page", ScreensUrl.BillSingleUnitAccount);
            return new BillingSingleUnitAccountPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Class Codes
        /// </summary>
        /// <returns>PartClassCodesPageActions</returns>
        public PartClassCodesPageActions NavigateToPartClassCodesPage()
        {
            Settings.Logger.Info("Navigating to Part Class Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Class Codes Page", ScreensUrl.PartClassCodes);
            return new PartClassCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Indirect Account Codes Page
        /// </summary>
        /// <returns>IndirectAccountCodesPageActions</returns>
        public IndirectAccountCodesPageActions NavigateToIndirectAccountCodesPage()
        {
            Settings.Logger.Info("Navigating to Indirect Account Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Indirect Account Codes Page", ScreensUrl.IndirectAccountCodes);
            return new IndirectAccountCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Return Reason Page
        /// </summary>
        /// <returns></returns>
        public EqipRetReasonsPageActions NavigateToEquipmentReturnReasonPage()
        {
            Settings.Logger.Info("Navigating to Equipment Return Reason Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Return Reason Page", ScreensUrl.EquipRetReasons);
            return new EqipRetReasonsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver Event Class
        /// </summary>
        /// <returns></returns>
        public DriverEventClassesPageActions NavigateToDriverEventClasses()
        {
            Settings.Logger.Info("Navigating to Driver Event Class Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Classses", ScreensUrl.DriverEventClasses);
            return new DriverEventClassesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver Event Types
        /// </summary>
        /// <returns>DriverEventTypesPageActions</returns>
        public DriverEventTypesPageActions NavigateToDriverEventTypes()
        {
            Settings.Logger.Info("Navigating to Driver Event Types Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Types", ScreensUrl.DriverEventTypes);
            return new DriverEventTypesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Return Reason Page
        /// </summary>
        /// <returns>DriverEventTypesPageActions</returns>
        public DriverEventItemPageActions NavigateToDriverEventItem()
        {
            Settings.Logger.Info("Navigating to Driver Event Item Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Item", ScreensUrl.DriverEventItem);
            return new DriverEventItemPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver Licence Classes
        /// </summary>
        /// <returns></returns>
        public DriverLicenceClassesPageActions NavigateToDriverLicenseClasses()
        {
            Settings.Logger.Info("Navigating to Driver License Classes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver License Classses", ScreensUrl.DriverLicenseClasses);
            return new DriverLicenceClassesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Product Orders
        /// </summary>
        /// <returns>ProductOrderActions</returns>
        public ProductOrderActions NavigateToProductOrderPage()
        {
            Settings.Logger.Info("Navigating to Product Order Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Order Page", ScreensUrl.ProductOrder);
            return new ProductOrderActions(Driver);
        }

        /// <summary>
        /// Navigate to Product Location Receive Page
        /// </summary>
        /// <returns>ProductLocationReceiveActions</returns>
        public ProductLocationReceiveActions NavigateToProductReceivePage()
        {
            Settings.Logger.Info("Navigating to Product Receive Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Receive Page", ScreensUrl.ProductReceive);
            return new ProductLocationReceiveActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver Main Screen
        /// </summary>
        /// <returns></returns>
        public DriverMainPageActions NavigateToDriverMainScreen()
        {
            Settings.Logger.Info("Navigating to Driver Main Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Main", ScreensUrl.DriverMain);
            return new DriverMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Service Order Query Page
        /// </summary>
        /// <returns>ServiceOrderQueryPageActions</returns>
        public ServiceOrderQueryPageActions NavigateToServiceOrderQueryPage()
        {
            Settings.Logger.Info("Navigating to Service Order Query Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Service Order Query Page", ScreensUrl.ServiceOrderQuery);
            return new ServiceOrderQueryPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Service Order Receipt Page
        /// </summary>
        /// <returns>ServiceOrderReceiptPageActions</returns>
        public ServiceOrderReceiptPageActions NavigateToServiceOrderReceiptPage()
        {
            Settings.Logger.Info("Navigating to Service Order Receipt Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Service Order Receipt Page", ScreensUrl.ServiceOrderReceipt);
            return new ServiceOrderReceiptPageActions(Driver);
        }

        /// Navigate To Product SetUp Locatio
        /// </summary>
        /// <returns></returns>
        public ProductSetUpLocationPageActions NavigateToProductSetupLocationPage()
        {
            Settings.Logger.Info("Navigating to Product Setup Location Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Location", ScreensUrl.ProductSetupLocation);
            return new ProductSetUpLocationPageActions(Driver);
        }

        /// Navigate To Product Setup Employees
        /// </summary>
        /// <returns></returns>
        public ProductSetupEmployee NavigateToProductSetUpEmployee()
        {
            Settings.Logger.Info("Navigating to Product Setup Employee Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Employees", ScreensUrl.ProductSetUpEmployees);
            return new ProductSetupEmployee(Driver);
        }
    }
}