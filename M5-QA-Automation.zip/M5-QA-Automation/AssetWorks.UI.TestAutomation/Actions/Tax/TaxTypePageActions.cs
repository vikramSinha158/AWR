﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using System;


namespace AssetWorks.UI.M5.TestAutomation.Actions
    {
        internal class TaxTypePageActions : TaxTypeMainPage
        {
        
        public TaxTypePageActions(IWebDriver Driver) : base(Driver) { }

        string TClass = string.Empty;
        string TDesc = string.Empty;

        /// <summary>
        /// Create New Tax Type Record
        /// </summary>
        /// <param name="Datakey"></param>       
        public string CreateTaxType(string Datakey)
        {
            AddRecords createEmpObjectValues = CommonUtil.DataObjectForKey(Datakey).ToObject<AddRecords>();
            _extendPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameTaxType, "Table frame");
            Settings.Logger.Info("Creating Tax Type");
            FillTaxTypeData(Datakey);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClicKSave();
            TaxTypeMainPage.TaxClass = TClass;
            TaxTypeMainPage.TaxDescription = TDesc;
            return TaxClass;
        }

        /// <summary>
        /// Fill Tax Type Data
        /// </summary>
        /// <param name="Datakey"></param>
        public void FillTaxTypeData(string Datakey)
        {
            AddTaxTypeRecord TaxValues = CommonUtil.DataObjectForKey(Datakey).ToObject<AddTaxTypeRecord>();
            TClass = CommonUtil.GetRandomStringWithSpecialChars(4);
            TDesc = $"AUT {TClass}";
            _inputNewTaxDesc.SetText(TDesc, "New Tax Descrption");
            _inputNewTaxClass.SetText(TClass, "New Tax Class");          
            _ckbNewTaxDisabled.SelectCheckBox("Disabled", TaxValues.Disabled);
        }


        /// <summary>
        /// Verify the Tax Type Record Data
        /// </summary>
        /// <param name="Datavalue"></param>
        /// <param name="Taxclass"></param>
        public void VerifyTaxRecord(string Datavalue,string Taxclass)
        {           
            RefreshAndSwitchToTable();        
            bool flagDiabled = false;
            AddTaxTypeRecord RecordData = CommonUtil.DataObjectForKey(Datavalue).ToObject<AddTaxTypeRecord>();
            string ActualDesc = _extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType, "Tax Class", Taxclass, "desc").GetAttribute("value");
            CommonUtil.AssertTrue<string>(TaxTypeMainPage.TaxDescription, ActualDesc);         
            string ActualStateDisabledCkb = _extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType, "Tax Class", Taxclass, "disabled").GetAttribute("value");
            flagDiabled = ActualStateDisabledCkb == "Y" ? true : false;
            CommonUtil.AssertTrue<bool>(RecordData.Disabled, flagDiabled);
        }

        /// <summary>
        /// Edit Tax Type Record
        /// </summary>
        /// <param name="DataKey"></param>
        /// <param name="ClassVal"></param>
        public void EditTaxRecord(string DataKey, string ClassVal)
        {
            EditTaxTypeRecord taxtValues = CommonUtil.DataObjectForKey(DataKey).ToObject<EditTaxTypeRecord>();
            Driver.SwitchTo().DefaultContent();
            RefreshAndSwitchToTable();
           string UpdatedTClass = CommonUtil.GetRandomStringWithSpecialChars(4);
           string UpdatedTDesc = $"AUT {UpdatedTClass} UPDATED";
            Settings.Logger.Info("Update Tax Type Record for : " + ClassVal);
            _extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType,
                "Tax Class", ClassVal, "desc").SetText(UpdatedTDesc, "Tax Description");
            _extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType,
                "Tax Class", ClassVal, "taxClass").SetText(UpdatedTClass, "Tax Class");
            _extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType,
              "Tax Class", UpdatedTClass, "disabled").SelectCheckBox("Disabled Checkbox", taxtValues.Disabled);     
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();
            TaxTypeMainPage.TaxClass = UpdatedTClass;
            TaxTypeMainPage.TaxDescription = UpdatedTDesc;
        }

        /// <summary>
        /// Delete Tax Type Record
        /// </summary>
        /// <param name="ClassVal"></param>
        public void DeleteTaxType(string ClassVal)
        {
            Driver.SwitchTo().DefaultContent();
            RefreshAndSwitchToTable();           
            Settings.Logger.Info("Deleting Equipment Profile Type : " + ClassVal);
            _extendPage.GetTableActionElementByRelatedColumnValue(
           _tableTaxType, "Tax Class", ClassVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnDeleteButton();
            _extendPage.ClickOnSaveButton();
        }


        /// <summary>
        /// Verify Equiment Tax Type Record Deletion
        /// </summary>
        /// <param name="ClassVal"></param>
        public void VerifyDeletedTaxType(string ClassVal)
        {
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Verify Tax Type is Deleted for : " + ClassVal);
            _extendPage.VerifyTableColumnDoesNotContainValue(_tableTaxType, "Tax Class", ClassVal);
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Refresh And Switch To Table Frame
        /// </summary>
        public void RefreshAndSwitchToTable()
        {
            _extendPage.ClickOnRefreshButton();
            _extendPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameTaxType, "Table frame");
        }
    }
    }   
