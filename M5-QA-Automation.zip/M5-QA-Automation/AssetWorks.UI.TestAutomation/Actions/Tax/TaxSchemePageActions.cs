﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;


namespace AssetWorks.UI.M5.TestAutomation.Actions
    {
    internal class TaxSchemePageActions : TaxSchemeMainPage
    {

        public TaxSchemePageActions(IWebDriver Driver) : base(Driver) { }
        string EffectiveDate = string.Empty;

        /// <summary>
        /// Create New Tax Scheme Record
        /// </summary>
        /// <param name="Datakey"></param>       
        public string CreateTaxScheme(string AppliedTo, TaxScheme createTaxSchemeObject, bool flagCancel = false)
        {            
            TaxSchemeID = createTaxSchemeObject.CreateTaxScheme.TaxScheme.ToLower() == "random" ? CommonUtil.GetRandomStringWithSpecialChars(8) : createTaxSchemeObject.CreateTaxScheme.TaxScheme;
            if (flagCancel)
            {
                _inputTaxScheme.SetText(TaxSchemeID, "Tax Scheme ID", Driver, _extendPage._contentFrame, "content frame");
                _extendPage.ActionRequiredWindow("Cancel");
            }
            _inputTaxScheme.SetText(TaxSchemeID, "Tax Scheme ID", Driver, _extendPage._contentFrame, "content frame");
            _extendPage.ActionRequiredWindow("Create");
            _extendPage.SwitchToContentFrame();
            TaxSchemeID = FillTaxSchemeData(createTaxSchemeObject.CreateTaxScheme, AppliedTo);
            Driver.SwitchToFrame(_frameTaxScheme, "Table frame");
            for (int i = 0; i < createTaxSchemeObject.CreateTaxScheme.TaxRateData.Count; i++)
            {
                FillTaxRateData(i, createTaxSchemeObject.CreateTaxScheme);
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClicKSave();
            _extendPage.ClickOnRefreshButton();
            return TaxSchemeID;
        }
        /// <summary>
        /// Fill Tax Scheme Data
        /// </summary>
        /// <param name="createTaxSchemeObject"></param>
        /// <param name="AppliedTo"></param>
        /// <returns></returns>
        public string FillTaxSchemeData(CreateTaxScheme createTaxSchemeObject, string? AppliedTo)
        {
            Settings.Logger.Info("Entering Tax Scheme Data");
            Driver.WaitForReady();
            _inputSchemeDesc.SetText(createTaxSchemeObject.TaxSchemeDesc, "Description");
            _disableTaxScheme.SelectFilterValueHavingEqualValue(createTaxSchemeObject.DisableTax);
            if (!string.IsNullOrEmpty(createTaxSchemeObject.EffectiveDate))
            {
                EffectiveDate = createTaxSchemeObject.EffectiveDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(createTaxSchemeObject.EffectiveDate)).ToString("MM/dd/yyyy");
                _effectiveDate.SetText(EffectiveDate, "EffectiveDate");
            }
            _appliedTo.SelectFilterValueHavingEqualValue(AppliedTo);
            _calcucType.SelectFilterValueHavingEqualValue(createTaxSchemeObject.TaxCalculus);
            return TaxSchemeID;
        }

        /// <summary>
        /// Fill Tax Scheme Rates Data Rows
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="createTaxSchemeObject"></param>
        public void FillTaxRateData(int RowNum, CreateTaxScheme createTaxSchemeObject, bool newData = true)
        {
            string locRandom = string.Empty;
            int rowLoc;
            if (newData)
            {
                locRandom = "new_";
                rowLoc = RowNum;
            }
            else { rowLoc = RowNum + 1; }
            Settings.Logger.Info("Filling Tax Rate Data Rows");          
            if (newData)
            {
                _extendPage.GetElementForInput($"{_line}{locRandom}{rowLoc}", "name").Click();
                Driver.WaitForReady();
                _extendPage.GetElementForInput($"{_line}{locRandom}{rowLoc}", "name").SendKeys(Keys.Tab);
            }
            Driver.WaitForReady();
            if (!string.IsNullOrEmpty(createTaxSchemeObject.TaxRateData[RowNum].TopOFLine))
                _extendPage.GetInputElementAndSetValue($"{_topOfLine}{locRandom}{rowLoc}", createTaxSchemeObject.TaxRateData[RowNum].TopOFLine, "name");
            if (!string.IsNullOrEmpty(createTaxSchemeObject.TaxRateData[RowNum].TaxType))
                _extendPage.GetInputElementAndSetValue($"{_taxType}{locRandom}{rowLoc}", createTaxSchemeObject.TaxRateData[RowNum].TaxType, "name");
            if (!string.IsNullOrEmpty(createTaxSchemeObject.TaxRateData[RowNum].TaxRate))
                _extendPage.GetInputElementAndSetValue($"{_taxRate}{locRandom}{rowLoc}", createTaxSchemeObject.TaxRateData[RowNum].TaxRate, "name");
            if (!string.IsNullOrEmpty(createTaxSchemeObject.TaxRateData[RowNum].FlatRate))
                _extendPage.GetInputElementAndSetValue($"{_flatRate}{locRandom}{rowLoc}", createTaxSchemeObject.TaxRateData[RowNum].FlatRate, "name");
            if (!string.IsNullOrEmpty(createTaxSchemeObject.TaxRateData[RowNum].AlternateFlatRate))
                _extendPage.GetInputElementAndSetValue($"{_alternateFlatRate}{locRandom}{rowLoc}", createTaxSchemeObject.TaxRateData[RowNum].AlternateFlatRate, "name");
        }

        /// <summary>
        /// Verify Tax Scheme Data
        /// </summary>
        /// <param name="schemeID"></param>
        /// <param name="AppliedTo"></param>
        /// <param name="updateTaxSchemeObject"></param>
        public void VerifyTaxScheme(string schemeID, string AppliedTo, CreateTaxScheme updateTaxSchemeObject)
        {
            _extendPage.RefreshAndSetText(_inputTaxScheme, schemeID, "Scheme ID");
            CommonUtil.VerifyElementValue(_inputSchemeDesc, "Scheme Description", updateTaxSchemeObject.TaxSchemeDesc);
            CommonUtil.VerifyElementValue(_disableTaxScheme, "Disable Full Tax Scheme", updateTaxSchemeObject.DisableTax, true);
            CommonUtil.VerifyElementValue(_effectiveDate, "Effective Date", EffectiveDate);
            CommonUtil.VerifyElementValue(_appliedTo, "Applied To", AppliedTo, true);
            CommonUtil.VerifyElementValue(_calcucType, "Is Tax Added", updateTaxSchemeObject.TaxCalculus, true);
            Driver.SwitchToFrame(_frameTaxScheme, "Table frame");
            for (int i = 1; i <= updateTaxSchemeObject.TaxRateData.Count; i++)
            {
                Driver.WaitForReady();
                if (!string.IsNullOrEmpty(updateTaxSchemeObject.TaxRateData[i - 1].Line))
                    CommonUtil.VerifyElementValue(_extendPage.GetElementForInput($"{_line}{i}"), "Line", updateTaxSchemeObject.TaxRateData[i - 1].Line, false, "value");
                if (!string.IsNullOrEmpty(updateTaxSchemeObject.TaxRateData[i - 1].TopOFLine))
                    CommonUtil.VerifyElementValue(_extendPage.GetElementForInput($"{_topOfLine}{i}"), "Top Of Line", updateTaxSchemeObject.TaxRateData[i - 1].TopOFLine, false, "value");
                if (!string.IsNullOrEmpty(updateTaxSchemeObject.TaxRateData[i - 1].TaxType))
                    CommonUtil.VerifyElementValue(_extendPage.GetElementForInput($"{_taxType}{i}"), "Tax Type", updateTaxSchemeObject.TaxRateData[i - 1].TaxType, false, "value");
                if (!string.IsNullOrEmpty(updateTaxSchemeObject.TaxRateData[i - 1].TaxRate))
                    CommonUtil.VerifyElementValue(_extendPage.GetElementForInput($"{_taxRate}{i}"), "Tax Rate", updateTaxSchemeObject.TaxRateData[i - 1].TaxRate, false, "value");
                if (!string.IsNullOrEmpty(updateTaxSchemeObject.TaxRateData[i - 1].FlatRate))
                    CommonUtil.VerifyElementValue(_extendPage.GetElementForInput($"{_flatRate}{i}"), "Flat Rate", updateTaxSchemeObject.TaxRateData[i - 1].FlatRate, false, "value");
                if (!string.IsNullOrEmpty(updateTaxSchemeObject.TaxRateData[i - 1].AlternateFlatRate))
                    CommonUtil.VerifyElementValue(_extendPage.GetElementForInput($"{_alternateFlatRate}{i}"), "Alternate Flat Rate", updateTaxSchemeObject.TaxRateData[i - 1].AlternateFlatRate, false, "value");
            }
             Driver.SwitchTo().DefaultContent();           
        }

        /// <summary>
        /// Edit Tax Scheme Data
        /// </summary>
        /// <param name="TaxID"></param>
        /// <param name="updateTaxSchemeObject"></param>
        /// <param name="AppliedTo"></param>
        public void UpdateTaxScheme(string TaxID, TaxScheme updateTaxSchemeObject, string? AppliedTo)
        {
            _extendPage.SwitchToContentFrame();
            FillTaxSchemeData(updateTaxSchemeObject.UpdateTaxScheme, AppliedTo);
            Driver.SwitchToFrame(_frameTaxScheme, "Table frame");
            for (int i = 0; i < updateTaxSchemeObject.UpdateTaxScheme.TaxRateData.Count; i++)
            {
                FillTaxRateData(i, updateTaxSchemeObject.UpdateTaxScheme, false);
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClicKSave();
            _extendPage.ClickOnRefreshButton();
        }

        /// <summary>
        /// Delete Tax Scheme Data
        /// </summary>
        /// <param name="TaxID"></param>
        public void DeleteTaxScheme(string TaxID)
        {
            _extendPage.RefreshAndSetText(_inputTaxScheme, TaxID, "Tax scheme ID");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameTaxScheme, "Table frame");
            int TotalTableRows = Driver.FindElements(By.XPath(tableRows)).Count;
            while (TotalTableRows > 2)
            {
                int rowNow = TotalTableRows - 2;
                _extendPage.GetElementForInput($"line_no${rowNow}").ClickElement("Line NO", Driver);
                Driver.SwitchTo().DefaultContent();
                _extendPage.ClickOnDeleteButton();
                _extendPage.ClickOnSaveButton();
                _extendPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameTaxScheme, "Table frame");
                TotalTableRows--;
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.SwitchToContentFrame();
            _inputSchemeDesc.ClickElement("Tax Scheme Description",Driver);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnDeleteButton();
            _extendPage.ActionRequiredWindow("Delete");       
        }

        /// <summary>
        /// Verify Deletion
        /// </summary>
        /// <param name="TaxID"></param>
        public void VerifyDeletion(string TaxID)
        {
            _extendPage.RefreshAndSetText(_inputTaxScheme, TaxID, "Tax scheme ID");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Assert.IsTrue(_extendPage._createDialog.VerifyElementDisplay(" Action Required Dialog "));
            _extendPage.ActionRequiredWindow("Cancel");
        }
    }
    }   
