﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingSingleUnitAccountPageActions : BillingSingleUnitAccountPage
    {
        public BillingSingleUnitAccountPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Bill Single Unit Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void AddBillSingleUnitAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            _extendedPage.RefreshAndSetText(_billSingleunit, BillSingleUnitDetail.UnitNo, "Unit Number");
            if (BillSingleUnitDetail.BillSingleUnitExpenseAccount != null)
            {
                AddUnitExpenseAccount(BillSingleUnitDetail);
            }
            if (BillSingleUnitDetail.BillSingleUnitRevenueAccount != null)
            {
                AddUnitRevenueAccount(BillSingleUnitDetail);
            }
            Settings.Logger.Info("-- Added Bill Single Unit Accoun--");
        }

        /// <summary>
        /// Add Unit Expense Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void AddUnitExpenseAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            Driver.SwitchToFrame(_framebillSingleunit, "Table Frame");
            Driver.WaitForReady();
            if (_tablebillSingleunitRows.Count > 2 && BillSingleUnitDetail.CheckExpenseAccountTable)
            { _extendedPage.DeleteTableRowsUsingColumnName(_tablebillSingleunit, "Expense Account\r\n(default accounts displayed in bold)", "ExpAcct", _framebillSingleunit); }
            _expenseEffectiveDate = CommonUtil.GenerateRandomDateString(BillSingleUnitDetail.NoOfDays);
            if (BillSingleUnitDetail.ExpenseEffectiveDate == null) { BillSingleUnitDetail.ExpenseEffectiveDate = _expenseEffectiveDate; }
            ExpenseEffectiveDates.Add(BillSingleUnitDetail.ExpenseEffectiveDate);
            Driver.WaitForSomeTime();
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tablebillSingleunit, "Effective Date", "", "ExpEffDate").SetText(BillSingleUnitDetail.ExpenseEffectiveDate, "ExpenseEffectiveDate");
            Driver.WaitForSomeTime();
            _extendedPage.GetTableActionElementByRelatedColumnValue(
              _tablebillSingleunit, "Effective Date", BillSingleUnitDetail.ExpenseEffectiveDate, "SpreadAlloc").Click();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_content2Frame, "content frame");
            Driver.SwitchToFrame(_frameexpenseAllocAccount, "Table Frame");
            AddUnitExpenseAccountInAllocationFrame(BillSingleUnitDetail.BillSingleUnitExpenseAccount);
            _extendedPage.Save();
            Driver.WaitForSomeTime();
            Driver.ClickOnElement(_closebutton, "Close Button");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            Settings.Logger.Info("-- Added Bill Single Unit Expense Accoun--");
        }

        /// <summary>
        /// Add Unit Revenue Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void AddUnitRevenueAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_billSingleAcctRevFrame, "billSingleAcctRevFrame");
            Driver.WaitForReady();
            if (_tableBillAcctRevRows.Count > 2 && BillSingleUnitDetail.CheckRevenueAccountTable)
            { _extendedPage.DeleteTableRowsUsingColumnName(_tableBillAcctRev, "Revenue Account\r\n(default accounts displayed in bold)", "RevAcct", _billSingleAcctRevFrame); }
            List<RevenueAccountAllocation> RevenueAccountAllocation = BillSingleUnitDetail.BillSingleUnitRevenueAccount.RevenueAccountAllocation;
            foreach (RevenueAccountAllocation RevenueAccountAList in RevenueAccountAllocation)
            {
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableBillAcctRev, "Effective Date", "", "EffDt").SetText(RevenueAccountAList.RevenueEffectiveDate, "RevenueEffectiveDate");
                _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableBillAcctRev, "Effective Date", RevenueAccountAList.RevenueEffectiveDate, "RevAcct").
                    SetText(RevenueAccountAList.RevenueAccount, "Revenue Account Number");
            }
            _extendedPage.Save();
            Settings.Logger.Info("-- Added Bill Single Unit Revenue Accoun--");
        }

        /// <summary>
        /// Verify BillSingle Unit Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void VerifyBillSingleUnitAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            _extendedPage.RefreshAndSetText(_billSingleunit, BillSingleUnitDetail.UnitNo, "Unit Number");
            if (BillSingleUnitDetail.BillSingleUnitExpenseAccount != null)
            {
                Driver.SwitchToFrame(_framebillSingleunit, "Table Frame");
                Driver.WaitForSomeTime();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablebillSingleunit, "Effective Date", _expenseEffectiveDate, "SpreadAlloc").Click();
                Driver.SwitchTo().DefaultContent();
                Driver.WaitForSomeTime();
                Driver.SwitchToFrame(_content2Frame, "content frame");
                Driver.SwitchToFrame(_frameexpenseAllocAccount, "Table Frame");
                VerifyBillSingleUnitExpenseAccount(BillSingleUnitDetail);
            }
            if (BillSingleUnitDetail.BillSingleUnitRevenueAccount != null)
            {
                VerifyBillSingleUnitRevenueAccount(BillSingleUnitDetail);
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("-- Successfully Verified Bill Single Unit Accoun--");
        }

        /// <summary>
        /// Delete Bill Single Unit Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void DeleteBillSingleUnitAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            _extendedPage.RefreshAndSetText(_billSingleunit, BillSingleUnitDetail.UnitNo, "Unit Number");
            if (BillSingleUnitDetail.BillSingleUnitExpenseAccount != null)
            {
                DeleteUnitExpenseAccount();
            }
            if (BillSingleUnitDetail.BillSingleUnitRevenueAccount != null)
            {
                DeleteBillSingleUnitRevenueAccount(BillSingleUnitDetail);
            }
            Settings.Logger.Info("-- Deleted Bill Single Unit Accoun--");
        }

        /// <summary>
        /// Verify Deletion BillSingle Unit Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void VerifyDeletionBillSingleUnitAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            _extendedPage.RefreshAndSetText(_billSingleunit, BillSingleUnitDetail.UnitNo, "Unit Number");
            if (BillSingleUnitDetail.BillSingleUnitExpenseAccount != null)
            {
                VerifyDeletionteExpenseAccountField();
            }
            if (BillSingleUnitDetail.BillSingleUnitRevenueAccount != null)
            {
                VerifyDelelionBillSingleUnitRevenueAccount(BillSingleUnitDetail);
            }
            Settings.Logger.Info("-- Successfully Verified Deletion Bill Single Unit Accoun--");
        }

        /// <summary>
        /// Add Expense to Multiple Account
        /// </summary>
        /// <param name="Unitnumber"></param>
        public void AddUnitExpenseAccountInAllocationFrame(BillSingleUnitExpenseAccount DataObject)
        {
            List<ExpenseAccountAllocation> ExpenseAccountAllocation = DataObject.ExpenseAccountAllocation;
            foreach (ExpenseAccountAllocation ExpenseAccountAList in ExpenseAccountAllocation)
            {
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(
              _TableframeexpenseAllocAccount, "Expense Account", "", "ExpAllocAcct").SetText(ExpenseAccountAList.ExpenseAccount, "Direct Account Number");
                _extendedPage.SelectAllAndClearField(_extendedPage.GetTableActionElementByRelatedColumnValue(
                    _TableframeexpenseAllocAccount, "Expense Account", ExpenseAccountAList.ExpenseAccount, "ExpAlloc"));
                _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _TableframeexpenseAllocAccount, "Expense Account", ExpenseAccountAList.ExpenseAccount, "ExpAlloc").
                    SetText(ExpenseAccountAList.Allocation, "Expense Account Number");
            }
            Settings.Logger.Info("--Added Expense Allocation to Mutliple Accounts Successufully--");
        }


        /// <summary>
        /// Verify Expense Multiple Account Field
        /// </summary>
        /// <param name="Unitnumber"></param>
        public void VerifyBillSingleUnitExpenseAccount(BillSingleUnitDetail DataObject)
        {
            List<ExpenseAccountAllocation> ExpenseAccountAllocation = DataObject.BillSingleUnitExpenseAccount.ExpenseAccountAllocation;
            foreach (ExpenseAccountAllocation ExpenseAccountAList in ExpenseAccountAllocation)
            {
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_TableframeexpenseAllocAccount, "Expense Account", ExpenseAccountAList.ExpenseAccount, "ExpAllocAcct"), "Expense Acct", ExpenseAccountAList.ExpenseAccount, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue( _TableframeexpenseAllocAccount, "Expense Account", ExpenseAccountAList.ExpenseAccount, "ExpAlloc"), "Expense Number", ExpenseAccountAList.Allocation, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_TableframeexpenseAllocAccount, "Expense Account", ExpenseAccountAList.ExpenseAccount, "ExpEffAllocDate"), "ExpEff Date", DataObject.ExpenseEffectiveDate, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
            Driver.ClickOnElement(_closebutton, "Close Button");
            Settings.Logger.Info("-- Verified Added Expense Allocation to Mutliple Accounts Successufully--");
        }

        /// <summary>
        /// Verify Bill Single Unit Revenue Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void VerifyBillSingleUnitRevenueAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_billSingleAcctRevFrame, "billSingleAcctRevFrame");
            List<RevenueAccountAllocation> RevenueAccountAllocation = BillSingleUnitDetail.BillSingleUnitRevenueAccount.RevenueAccountAllocation;
            foreach (RevenueAccountAllocation RevenueAccountAList in RevenueAccountAllocation)
            {
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableBillAcctRev, "Effective Date", RevenueAccountAList.RevenueEffectiveDate, "EffDt"), "Revenue Effective Date", RevenueAccountAList.RevenueEffectiveDate, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableBillAcctRev, "Effective Date", RevenueAccountAList.RevenueEffectiveDate, "RevAcct"), "Revenue Account", RevenueAccountAList.RevenueAccount, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("-- Verified Added Revenue Allocation to Mutliple Accounts Successufully--");
        }

        /// <summary>
        /// Delete Expense Multiple Account Field
        /// </summary>
        /// <param name="Unitnumber"></param>
        public void DeleteUnitExpenseAccount()
        {
            Driver.SwitchToFrame(_framebillSingleunit, "Table Frame");
            foreach (string ExpenseEffectiveDate in ExpenseEffectiveDates)
            {
                Driver.WaitForSomeTime();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablebillSingleunit,
                 "Effective Date", ExpenseEffectiveDate, "ExpEffDate").Click();
                Driver.WaitForSomeTime();
                _extendedPage.DeleteAndSave();
                Driver.SwitchToFrame(_framebillSingleunit, "Table Frame");
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("-- Deleted Added Expense Account Successfully--");
        }

        /// <summary>
        /// Delete Bill Single Unit Revenue Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void DeleteBillSingleUnitRevenueAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_billSingleAcctRevFrame, "billSingleAcctRevFrame");
            List<RevenueAccountAllocation> RevenueAccountAllocation = BillSingleUnitDetail.BillSingleUnitRevenueAccount.RevenueAccountAllocation;
            foreach (RevenueAccountAllocation RevenueAccountAList in RevenueAccountAllocation)
            {
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableBillAcctRev, "Effective Date", RevenueAccountAList.RevenueEffectiveDate, "EffDt").Click();
                _extendedPage.DeleteAndSave();
                Driver.SwitchToFrame(_billSingleAcctRevFrame, "billSingleAcctRevFrame");
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("--  Deleted Added Revenue Account Successfully--");
        }

        /// <summary>
        /// Verify Delete Expense Multiple Account Field
        /// </summary>
        /// <param name="Unitnumber"></param>
        public void VerifyDeletionteExpenseAccountField()
        {
            Driver.SwitchToFrame(_framebillSingleunit, "Table Frame");
            Driver.WaitForSomeTime();
            foreach (string ExpenseEffectiveDate in ExpenseEffectiveDates)
            {
                Driver.WaitForReady();
                _extendedPage.VerifyTableColumnDoesNotContainValue(_tablebillSingleunit,
                 "Effective Date", ExpenseEffectiveDate);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_framebillSingleunit, "Table Frame");
            }
            Settings.Logger.Info("-- Verified Deleted Expense Account Successfully--");
        }

        /// <summary>
        /// Verify Delelion  Bill Single Unit Revenue Account
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void VerifyDelelionBillSingleUnitRevenueAccount(BillSingleUnitDetail BillSingleUnitDetail)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_billSingleAcctRevFrame, "billSingleAcctRevFrame");
            List<RevenueAccountAllocation> RevenueAccountAllocation = BillSingleUnitDetail.BillSingleUnitRevenueAccount.RevenueAccountAllocation;
            foreach (RevenueAccountAllocation RevenueAccountAList in RevenueAccountAllocation)
            {
                Driver.WaitForReady();
                _extendedPage.VerifyTableColumnDoesNotContainValue(_tableBillAcctRev,"Effective Date", RevenueAccountAList.RevenueEffectiveDate);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_billSingleAcctRevFrame, "billSingleAcctRevFrame");
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("-- Verified Deleted Revenue Account Successfully--");
        }

        /// <summary>
        /// Delete Expense Account From Allocations Frame
        /// </summary>
        /// <param name="BillSingleUnitDetail"></param>
        public void DeleteExpenseAccountFromAllocationsFrame(BillSingleUnitDetail BillSingleUnitDetail)
        {
            _extendedPage.RefreshAndSetText(_billSingleunit, BillSingleUnitDetail.UnitNo, "Unit Number");
            Driver.SwitchToFrame(_framebillSingleunit, "Table Frame");
            Driver.WaitForSomeTime();
            _extendedPage.GetTableActionElementByRelatedColumnValue(
              _tablebillSingleunit, "Effective Date", BillSingleUnitDetail.ExpenseEffectiveDate, "SpreadAlloc").Click();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_content2Frame, "content frame");
            Driver.SwitchToFrame(_frameexpenseAllocAccount, "Table Frame");
            List<ExpenseAccountAllocation> ExpenseAccountAllocation = BillSingleUnitDetail.BillSingleUnitExpenseAccount.ExpenseAccountAllocation;
            foreach (ExpenseAccountAllocation ExpenseAccountAList in ExpenseAccountAllocation)
            {
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(
              _TableframeexpenseAllocAccount, "Expense Account", ExpenseAccountAList.ExpenseAccount, "ExpAllocAcct").Click();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDeleteButton();
                Driver.SwitchTo().DefaultContent();
                Driver.SwitchToFrame(_content2Frame, "content frame");
                Driver.SwitchToFrame(_frameexpenseAllocAccount, "Table Frame");
            }
            _extendedPage.Save();
            Settings.Logger.Info("--  Deleted Added Revenue Account FromA llocations Frame--");
        }
    }
}
