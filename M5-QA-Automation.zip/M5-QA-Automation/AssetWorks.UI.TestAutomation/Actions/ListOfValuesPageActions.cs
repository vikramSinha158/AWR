﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using System.Collections.Generic;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ListOfValuesPageActions: ListOfValuesPage
    {
        public ListOfValuesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Search And Select First Row Data
        /// </summary>
        public void SearchAndSelectFirstRowData()
        {
            Settings.Logger.Info("Search and select data from LOV:");
            parentWindow = Driver.SwitchToNewWindow();
            ClickOnSearchButton();
            DoubleClickOnFirstTableRecord(_firstListItem,"LOV item");
        }
        /// <summary>
        /// Click Search Button and Select First LOV Value
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="ElementName"></param>
        /// <param name="SelectLOV"></param>
        public void SearchAndSelectFirstRowData(IWebElement Element,string ElementName, bool SelectLOV)
        {
            if (SelectLOV)
            {
                Settings.Logger.Info("Search and select data from LOV:");
                Driver.WaitForReady();
                Driver.DoubleClick(Element, ElementName);
                parentWindow = Driver.SwitchToNewWindow();
                ClickOnSearchButton();
                DoubleClickOnFirstTableRecord(_firstListItem, "LOV item");
                _extendpage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Search keyword And Select First Row Data
        /// </summary>
        /// <param name="Keyword"></param>
        public void SearchAndSelectFirstRowData(string Keyword)
        {
            Settings.Logger.Info("Search and select data from LOV:");
            parentWindow = Driver.SwitchToNewWindow();
            if (Keyword != null)
            {
                EnterSearchKeywordInFirstBox(Keyword);
                Settings.Logger.Info($"Enterd value for search for {Keyword}");
            }
            ClickOnSearchButton();
            DoubleClickOnFirstTableRecord(_firstListItem,"LOV item");
        }

        /// <summary>
        /// Click On Search Button
        /// </summary>
        public void ClickOnSearchButton()
        {
            Driver.ScrollInView(_buttonSearch);
            _buttonSearch.VerifyElementDisplay("LOV search button");
            _buttonSearch.Click();
            Settings.Logger.Info("LOV Searched button clicked :");
        }

        /// <summary>
        /// Enter Search Key word In First Box
        /// </summary>
        /// <param name="Keyword"></param>
        public void EnterSearchKeywordInFirstBox(string Keyword)
        {
            _buttonSearch.VerifyElementDisplay("LOV search button");
            _firstInputBox.SendKeys(Keyword);
        }

        /// <summary>
        /// Click On Clear Button
        /// </summary>
        public void ClickOnClearButton()
        {
            _buttonSearch.VerifyElementDisplay("LOV Clear button");
            _buttonClear.Click();
        }

        /// <summary>
        /// Search And Select Componenet Data
        /// </summary>
        public void SearchAndSelectComponenetData()
        {
            parentWindow = Driver.SwitchToNewWindow();
            ClickOnSearchButton();
            DoubleClickOnFirstTableRecord(_componentItem,"Component Data");
        }

        /// <summary>
        /// Double Click On First Table Record
        /// </summary>
        /// <param name="clickItem"></param>
        public void DoubleClickOnFirstTableRecord(IWebElement ClickItem,string Elementname)
        {
            Driver.WaitForReady();
            Driver.DoubleClick(ClickItem, Elementname);
            Driver.SwitchTo().Window(parentWindow);
        }

        /// <summary>
        /// Unit Search Field
        /// </summary>
        /// <param name="searchFieldNo"></param>
        public void EnterSearchField(string SearchFieldNo)
        {
            Settings.Logger.Info("Enter and Search data from LOV:");
            parentWindow = Driver.SwitchToNewWindow();
            _serachField.SendKeys(SearchFieldNo);
            Settings.Logger.Info($"Enterd value for search for {SearchFieldNo}");
            _selectsataus.SelectFilterValueHavingEqualValue("All");
            ClickOnSearchButton();
            DoubleClickOnFirstTableRecord(_firstListItem,"LOV  item");
        }

        /// <summary>
        /// Create WorkOrder Job
        /// </summary>
        public void CreateWorkOrderJob()
        {
            Settings.Logger.Info("Creating workorder job from LOV");
            parentWindow = Driver.SwitchToNewWindow();
            if (_buttonSearch.VerifyElementDisplay("")) { }
            Driver.WaitForReady();
            _selectwac.GetValuedropdownByIndex(1);
            if (_buttonSearch.VerifyElementDisplay("")) { }
            _sysCode.GetValuedropdownByIndex(1);
            if (_buttonSearch.VerifyElementDisplay("")) { }
            _componentCode.GetValuedropdownByIndex(1);
            Driver.WaitForReady();
            _okBtn.Click();
            Driver.SwitchTo().Window(parentWindow);
        }

        /// <summary>
        /// Select code 
        /// </summary>
        public void SelectCode()
        {
            Settings.Logger.Info("Select code from LOV");
            Driver.WaitForReady();
            parentWindow = Driver.SwitchToNewWindow();
            DoubleClickOnFirstTableRecord(_codeList,"LOV list ");
        }
        /// <summary>
        /// Select code 
        /// </summary>
        public void SelectCode(IWebElement Element,string ElementName, bool SelectLOV)
        {
            if (SelectLOV)
            { 
                Settings.Logger.Info("Select code from LOV");
                Driver.WaitForReady();
                Driver.DoubleClick(Element, ElementName);
                Driver.WaitForReady();
                parentWindow = Driver.SwitchToNewWindow();
                DoubleClickOnFirstTableRecord(_codeList, "LOV list ");
                _extendpage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Search And Click Element
        /// </summary>
        /// <param name="seartchkey"></param>
        public void SearchAndClickElement(string Seartchkey)
        {
            parentWindow = Driver.SwitchToNewWindow();
            _searchtext.SendKeys(Seartchkey);
            DoubleClickOnFirstTableRecord(_firstListItem,"LOV list");
            Driver.SwitchTo().Window(parentWindow);
        }

        /// <summary>
        /// Select First Table Record
        /// </summary>
        public void SelectFirstTableRecord()
        {
            Settings.Logger.Info("Select data from LOV");
            parentWindow = Driver.SwitchToNewWindow();
            DoubleClickOnFirstTableRecord(_firstListItem, "first or default LOV item");
        }
        /// <summary>
        /// 
        /// </summary>
        public void SelectFirstTableRecord(IWebElement Element,string ElementName,bool SelectLOV)
        {
            if (SelectLOV)
            {
                Driver.WaitForReady();
                Driver.DoubleClick(Element, ElementName);
                Settings.Logger.Info("Select data from LOV");
                parentWindow = Driver.SwitchToNewWindow();
                DoubleClickOnFirstTableRecord(_firstListItem, "first or default LOV item");
                _extendpage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Enter Desired Filter Keyword And Select Record
        /// </summary>
        /// <param name="Keyword"></param>
        /// <param name="FieldName"></param>
        public void EnterDesiredFilterKeywordAndSelectRecord(string Keyword, string FieldName, string FieldType = "input")
        {
            Settings.Logger.Info("Enter Filter Keyword in LOV:");
            parentWindow = Driver.SwitchToNewWindow();
            GetFilterOptionByLabel(FieldName, "operator").Click();
            if (FieldType.ToLower().Equals("select"))
                GetFilterOptionByLabel(FieldName, "select").SelectFilterValueHavingEqualValue(Keyword);
            else
                GetFilterOptionByLabel(FieldName, "input").SetText(Keyword, FieldName);
            ClickOnSearchButton();
            DoubleClickOnFirstTableRecord(_firstListItem, "LOV item");
        }

        /// <summary>
        /// Get LOV Filter Option By Label
        /// </summary>
        /// <param name="Label"></param>
        /// <param name="Option"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public IWebElement GetFilterOptionByLabel(string Label, string Option)
        {
            string operatorId;
            string? labelId = null;
            try
            {
                IList<IWebElement> filterList = _table.FindElements(By.XPath("//label"));
                //get id by label
                foreach (IWebElement filter in filterList)
                {
                    if (filter.Text.Equals(Label + ":"))
                    {
                        labelId = filter.GetElementValueByAttribute("for");
                        break;
                    }
                }
                //get filter option by label id
                if (labelId != null)
                {
                    if (Option.ToLower() == "checkbox")
                        operatorId = labelId;
                    else if (Option.ToLower() == "operator")
                        operatorId = labelId.Replace("mc", "mb");
                    else
                        operatorId = labelId.Replace("mc", "md");
                }
                else
                    throw new Exception("Filter lable not found.!");
                return Driver.FindElement(By.Id(operatorId));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Search Text and get Result Text
        /// </summary>
        /// <param name="Seartchkey"></param>
        /// <returns></returns>
        public string SearchAndGetSearchCount(string Seartchkey)
        {
            parentWindow = Driver.SwitchToNewWindow();
            _searchtext.SendKeys(Seartchkey);       
             string text= _searchCountText.GetText("Search Result Text");
            Driver.SwitchTo().Window(parentWindow);
            return text;
        }

        /// <summary>
        /// Search And Select LOV Data
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="Keyword"></param>
        /// <param name="SelectLOV"></param>
        public void SearchAndSelectLOVData(IWebElement Element, string Keyword)
        {
            Driver.WaitForReady();
            Driver.DoubleClickWithJS(Element, " Double Click Element ");
            Driver.SwitchTo().DefaultContent();
            parentWindow = Driver.SwitchToNewWindow();
            if (_buttonSearch.VerifyElementDisplay("LOV search button"))
            {
                _firstInputBox.SendKeys(Keyword);
                Settings.Logger.Info($"Enterd value for search for {Keyword}");
                ClickOnSearchButton();
                DoubleClickOnFirstTableRecord(_firstListItem, "LOV item");
             }
            else{
                Driver.WaitForReady();
                _searchtext.SendKeys(Keyword);
                DoubleClickOnFirstTableRecord(_firstListItem, "LOV list");
            }
            Driver.SwitchTo().Window(parentWindow);
            Settings.Logger.Info($"Searched and select data { Keyword } from LOV:");
        }

        /// <summary>
        /// Select Job Code Components from LOV
        /// </summary>
        /// <param name="Code1"></param>
        /// <param name="Code2"></param>
        /// <param name="Code3"></param>
        public void SelectJobCode(string Code1, string Code2, string Code3)
        {
            parentWindow= Driver.SwitchToNewWindow();
            Driver.WaitForReady();
            if (!string.IsNullOrEmpty(Code1))
            {
                _selectWA.SelectFilterValueHavingEqualValue(Code1);
                Settings.Logger.Info($"Selected Work Accomplished as {Code1}");
                Driver.WaitForReady();
            }
            if (!string.IsNullOrEmpty(Code2))
            {
                _selectSystem.SelectFilterValueHavingEqualValue(Code2);
                Settings.Logger.Info($"Selected System Code as {Code2}");
                Driver.WaitForReady();
            }
            if (!string.IsNullOrEmpty(Code3))
            {
                _selectComponent.SelectFilterValueHavingEqualValue(Code3);
                Settings.Logger.Info($"Selected Component Code as {Code3}");
            }         
            _okBtn.Click();          
            Driver.SwitchTo().Window(parentWindow);
        }
    }
}
