﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class StandardJobTechSpecPageActions : StandardJobTechSpecPage
    {
        public StandardJobTechSpecPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create StandardJob TechSpec
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="TechSpecNo"></param>
        public void CreateStandardJobTechSpec(StandardJobTechSpec StandardTechSpec)
        {
            Settings.Logger.Info(" Created Standard Job TechSpec");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _standJobNo.SetText(StandardTechSpec.StandJobNo, "Stand Job No");
            Driver.WaitForReady();
            _standSpecNo.SetText(StandardTechSpec.TechSpecNo, "Tech Spec No");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            if (StandardTechSpec.DependentJobsTab != null)
            {
                FillDependentJobsTab(StandardTechSpec.DependentJobsTab);
            }
            if (StandardTechSpec.StandardJobDetailTab != null)
            {
                FillDetailJobTab(StandardTechSpec.StandardJobDetailTab);
            }
            if (StandardTechSpec.PartJobTab != null)
            {
                FillPartJobTab(StandardTechSpec.PartJobTab);
            }
            if (StandardTechSpec.TestSuitesTab != null)
            {
                FillTestSuitesTab(StandardTechSpec.TestSuitesTab);
            }
            if (StandardTechSpec.EstimatesTab != null)
            {
                FillEstimatesTab(StandardTechSpec.EstimatesTab);
            }
            if (StandardTechSpec.DeptFixedCostsTab != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_deptFixedCostTab);
                FillDeptFixedCost(StandardTechSpec.DeptFixedCostsTab);
            }
        }

        /// <summary>
        /// Fill Dependent Jobs Tab
        /// </summary>
        /// <param name="StandTechSpac"></param>
        public void FillDependentJobsTab(DependentJobsTab StandTechSpac)
        {
            Settings.Logger.Info(" Fill Dependent Jobs Tab");
            _extendpage.SwitchToContentFrameAndTabClick(_dependentJobsTab);
            Driver.SwitchToFrame(_standJobSpecDJFrame, "techSpecProdFrame");
            Driver.WaitForReady();
            if (_standJobSpecDJTableRows.Count > 1 && StandTechSpac.CheckDependentJobsTable)
            { _extendpage.DeleteTableRowsUsingColumnName(_standJobSpecDJTable, _jobHeadeName, _dDependentJobId, _standJobSpecDJFrame); }
            Driver.WaitForReady();
            if (StandTechSpac.DependentJobIdNotExist)
            _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDJTable,
                 _jobHeadeName, "", _dDependentJobId).SetText(StandTechSpac.DependentJob, "DependentJob");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDJTable,
                _jobHeadeName, StandTechSpac.DependentJob, _dLocationId).SetText(StandTechSpac.DependentLocation, "Dependent Location");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDJTable,
                _jobHeadeName, StandTechSpac.DependentJob, _dJobRsnId).SetText(StandTechSpac.DependentReason, "Dependent Reason");
            _extendpage.Save();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Detail Job Tab
        /// </summary>
        /// <param name="StandTechSpac"></param>
        public void FillDetailJobTab(StandardJobDetailTab StandTechSpac)
        {
            Settings.Logger.Info(" Fill Detail Jobs Tab");
            _extendpage.SwitchToContentFrameAndTabClick(_detailJobsTab);
            _refShift.SetText(StandTechSpac.PreferredShift, "PreferredShif");
            Driver.WaitForReady();
            _jobSpan.SelectCheckBox("JobSpan", StandTechSpac.JobSpan);
            Driver.WaitForReady();
            _addToWOFl.SelectCheckBox("AddToWOFl", StandTechSpac.AddToWOFl);
            Driver.WaitForReady();
            _changeAssocFl.SelectCheckBox("changeAssocFl", StandTechSpac.ChangeAssocFl);
            Driver.WaitForReady();
            _changeBaseFl.SelectCheckBox("changeBaseFl", StandTechSpac.ChangeBaseFl);
            Driver.WaitForReady();
            if (StandTechSpac.VendorFl) { _vendorFl.SelectCheckBox("VendorFl", StandTechSpac.VendorFl); }
            else {_vendorFl.DeSelectCheckBox("VendorFl");}          
            Driver.WaitForReady();
            if (StandTechSpac.ExcludeFl) { _excludeFl.SelectCheckBox("ExcludeFl", StandTechSpac.ExcludeFl); }
            else { _excludeFl.DeSelectCheckBox("ExcludeFl"); }          
            Driver.WaitForReady();
            _addToWOExpFl.SelectCheckBox("AddToWOExpFl", StandTechSpac.AddToWOExpFl);
            Driver.WaitForReady();
            _fixPriceFl.SelectCheckBox("FixPriceFl", StandTechSpac.FixPriceFl);
            Driver.WaitForReady();
            _defJobReason.SetText(StandTechSpac.DefJobReason, "DefJobReason");
            Driver.WaitForReady();
            _newIdBtn.ClickElement("newIdBtn", Driver);          
            _extendpage.SelectAllAndClearField(_note);
            Driver.WaitForReady();
            _note.SetText(StandTechSpac.Note, "Note");
            _extendpage.SelectAllAndClearField(_complaintNote);
            Driver.WaitForReady();
            _complaintNote.SetText(StandTechSpac.ComplaintNote, "ComplaintNote");
            _extendpage.SelectAllAndClearField(_causeNote);
            Driver.WaitForReady();
            _causeNote.SetText(StandTechSpac.CauseNote, "CauseNote");
            _extendpage.SelectAllAndClearField(_correctNote);
            Driver.WaitForReady();
            _correctNote.SetText(StandTechSpac.correctNote, "correctNote");
            Driver.WaitForReady();
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Test Suites Tab
        /// </summary>
        /// <param name="StandTechSpac"></param>
        public void FillTestSuitesTab(TestSuitesTab StandTechSpac)
        {
            Settings.Logger.Info(" Fill TestSuites Tab");
            _extendpage.SwitchToContentFrameAndTabClick(_testSuitesTab);
            Driver.SwitchToFrame(_standJobSpecTSFrame, "standJobSpecTSFrame");
            if (StandTechSpac.BrakeTestFl) { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.BrakeTest, _testSuitSelectedId).SelectCheckBox("BrakeTestFl", StandTechSpac.BrakeTestFl); }
            else { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.BrakeTest, _testSuitSelectedId).DeSelectCheckBox("BrakeTestFl"); }           
            Driver.WaitForReady();
            if (StandTechSpac.BrakeFl) { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.Brake, _testSuitSelectedId).SelectCheckBox("BrakeFl", StandTechSpac.BrakeFl); }
            else { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.Brake, _testSuitSelectedId).DeSelectCheckBox("BrakeFl"); }            
            Driver.WaitForReady();
            if (StandTechSpac.BriBreaksFl) { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.BriBreaks, _testSuitSelectedId).SelectCheckBox("BrakeFl", StandTechSpac.BriBreaksFl); }
            else { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.BriBreaks, _testSuitSelectedId).DeSelectCheckBox("BrakeFl"); }          
            Driver.WaitForReady();
            if (StandTechSpac.CerysTestFl) { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.CerysTest, _testSuitSelectedId).SelectCheckBox("BrakeFl", StandTechSpac.CerysTestFl); }
            else { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.CerysTest, _testSuitSelectedId).DeSelectCheckBox("BrakeFl"); }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Part Job Tab
        /// </summary>
        /// <param name="PartJobTabData"></param>
        public void FillPartJobTab(PartJobTab PartJobTabData)
        {
            Settings.Logger.Info(" Fill Detail Jobs Tab");
            List<PartJobDataList> PartList = PartJobTabData.PartJobDataList;
            _extendpage.SwitchToFrameAfterTabClick(_partJobTab, _StandJobSpecPartFrame);
            int RowNum = 0;
            foreach (PartJobDataList partItem in PartList)
            {
               IWebElement PartNoElement= _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable,_partHeadeName, "", _partNoJobId);
                Driver.WaitForReady();
                if (partItem.FillPartNo) {
                    _extendpage.SetTextWithLovOption(PartNoElement, partItem.PartNo, partItem.PartNoLOV);
                }          
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable, _partHeadeName, partItem.PartNo, _qtyPartJobId, "value").SetText(partItem.Quantity, "Quantity");
                Driver.WaitForReady();
                if (partItem.RequiredInfo) { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable, _partHeadeName, partItem.PartNo, _requiredPartCbId, "value").SelectCheckBox("RequiredInfo", partItem.RequiredInfo); }
                else { _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable, _partHeadeName, partItem.PartNo, _requiredPartCbId, "value").DeSelectCheckBox("RequiredInfo"); }                
                RowNum++;
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Estimates Tab
        /// </summary>
        /// <param name="StandTechSpac"></param>
        public void FillEstimatesTab(EstimatesTab StandTechSpac)
        {
            Settings.Logger.Info(" Fill Estimates Tab");
            List<AssignedLaborResource> LaborResourcesList = StandTechSpac.AssignedLaborResources;
            _extendpage.SwitchToContentFrameAndTabClick(_estimatesTab);
            Driver.WaitForReady();
            _laborTime.SetText(StandTechSpac.LaborTime, "LaborTime");
            Driver.WaitForReady();
            _laborCost.SetText(StandTechSpac.LborCost, "laborCost");
            Driver.WaitForReady();
            _shopTime.SetText(StandTechSpac.ShopTime, "shopTime");
            Driver.WaitForReady();
            _partCost.SetText(StandTechSpac.PartCost, "partCost");
            Driver.WaitForReady();
            _contingencyTime.SetText(StandTechSpac.ContingencyTime, "contingencyTime");
            Driver.WaitForReady();
            _commCost.SetText(StandTechSpac.CommCost, "commCost");
            Driver.WaitForReady();
            _bookTime.SetText(StandTechSpac.BookTime, "bookTime");
            Driver.WaitForReady();
            _estCost.SetText(StandTechSpac.EstCost, "estCost");
            Driver.WaitForReady();
            _indStdTime.SetText(StandTechSpac.IndStdTime, "_indStdTime");
            Driver.WaitForReady();
            _bookTimeMin.SetText(StandTechSpac.BookTimeMin, "bookTimeMin");
            Driver.WaitForReady();
            _bookTimeMax.SetText(StandTechSpac.BookTimeMax, "bookTimeMax");
            Driver.SwitchToFrame(_laborSourceFrame, "laborSourceFrame");
            int RowNum = 0;
            int LaborResourceRowCount = _laborResourceTableRows.Count;
            foreach (AssignedLaborResource laborResourceItem in LaborResourcesList)
            {
                if (laborResourceItem.AddResourceField) {
                    IWebElement ResourceElement = _extendpage.GetTableActionElementByRelatedColumnValue(_laborResourceTable, _resourceHeadeName, "", _resource);
                    Driver.WaitForReady();
                    ResourceElement.SetText(laborResourceItem.Resource, "Resource");
                }            
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_laborResourceTable, _resourceHeadeName, laborResourceItem.Resource, _resQty).SetText(laborResourceItem.Quantity, "Quantity");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_laborResourceTable, _resourceHeadeName, laborResourceItem.Resource, _primaryFL).SelectCheckBox("PrimaryFL", laborResourceItem.PrimaryFL);
                RowNum++;
            }
            _extendpage.Save(); 
        }

        /// <summary>
        /// Verify Standard Job Tech Spec Deletion
        /// </summary>
        /// <param name="StandardJobCode"></param>
        /// <param name="TechSpecNo"></param>
        public void VerifyStandardJobTechSpecDeletion(string StandardJobCode,string TechSpecNo)
        {
            RefreshAndOpenStandardTechSpec(StandardJobCode, TechSpecNo);
            DeleteStandardJobTechSpec(StandardJobCode);
            Driver.WaitForInvisibility(By.XPath(Settings.ActionDialog), "Deletion dialog ");
            _extendpage.SwitchToContentFrame();
            string ValueAfterDeletion = _standSpecNo.GetAttribute("ovalue");
            Assert.True(String.IsNullOrEmpty(ValueAfterDeletion), "tandardJobTechSpec  not deleted, found value { ValueAfterDeletion}");
            Settings.Logger.Info("tandardJobTechSpec Deleted successfully  ");
        }

        /// <summary>
        /// Delete Standard Job TechSpec
        /// </summary>
        /// <param name="StandardJobCode"></param>
        public void DeleteStandardJobTechSpec(string StandardJobCode)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _standJobNo.ClickElement("StandJobNo", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            _extendpage.ActionRequiredWindow("Delete"); 
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Standard Job TechSpec
        /// </summary>
        /// <param name="StandardTechSpec"></param>
        public void VerifyStandardJobTechSpec(StandardJobTechSpec StandardTechSpec)
        {
            RefreshAndOpenStandardTechSpec(StandardTechSpec.StandJobNo, StandardTechSpec.TechSpecNo);      
            if (StandardTechSpec.StandardJobDetailTab != null)
            {
                VerifyDetailJobTab(StandardTechSpec.StandardJobDetailTab);
            }
            if (StandardTechSpec.PartJobTab != null)
            {
                VerifyPartJobTab(StandardTechSpec.PartJobTab);
            }
            if (StandardTechSpec.DependentJobsTab != null)
            {
                VerifyDependentJobTab(StandardTechSpec.DependentJobsTab);
            }
            if (StandardTechSpec.TestSuitesTab != null)
            {
                VerifyTestSuitesTab(StandardTechSpec.TestSuitesTab);
            }
            if (StandardTechSpec.EstimatesTab != null)
            {
                VerifyEstimatesTab(StandardTechSpec.EstimatesTab);
            }
            if (StandardTechSpec.DeptFixedCostsTab != null)
            {
                VerifyDeptFixedCost(StandardTechSpec.DeptFixedCostsTab);
            } 
        }

        /// <summary>
        /// Verify Detail JobTab
        /// </summary>
        /// <param name="StandardTechSpec"></param>
        public void VerifyDetailJobTab(StandardJobDetailTab StandardTechSpec)
        {
            _extendpage.SwitchToContentFrameAndTabClick(_detailJobsTab);
            CommonUtil.VerifyElementValue(_refShift, "PreferredShif", StandardTechSpec.PreferredShift);
            CommonUtil.VerifyCheckboxState(_jobSpan, "JobSpan", StandardTechSpec.JobSpan);
            CommonUtil.VerifyCheckboxState(_addToWOFl, "AddToWOFl", StandardTechSpec.AddToWOFl);
            CommonUtil.VerifyCheckboxState(_changeAssocFl, "changeAssocFl", StandardTechSpec.ChangeAssocFl);
            CommonUtil.VerifyCheckboxState(_changeBaseFl, "AddToWOFl", StandardTechSpec.ChangeBaseFl);
            CommonUtil.VerifyCheckboxState(_vendorFl, "VendorFl", StandardTechSpec.VendorFl); 
            CommonUtil.VerifyCheckboxState(_excludeFl, "ExcludeFl", StandardTechSpec.ExcludeFl);
            CommonUtil.VerifyCheckboxState(_addToWOExpFl, "AddToWOExpFl", StandardTechSpec.AddToWOExpFl);
            CommonUtil.VerifyCheckboxState(_fixPriceFl, "FixPriceFl", StandardTechSpec.FixPriceFl);
            CommonUtil.VerifyElementValue(_defJobReason, "DefJobReason", StandardTechSpec.DefJobReason);     
            CommonUtil.VerifyElementValue(_note, "Note", StandardTechSpec.Note);
            CommonUtil.VerifyElementValue(_complaintNote, "ComplaintNote", StandardTechSpec.ComplaintNote); 
            CommonUtil.VerifyElementValue(_causeNote, "ComplaintNote", StandardTechSpec.CauseNote);
            CommonUtil.VerifyElementValue(_correctNote, "correctNote", StandardTechSpec.correctNote);
            Settings.Logger.Info(" Successfully Verified Detail Job Tab Tech Spec");
        }

        /// <summary>
        /// Verify Part JobTab
        /// </summary>
        /// <param name="PartJobTabData"></param>
        public void VerifyPartJobTab(PartJobTab PartJobTabData)
        {
            Settings.Logger.Info(" Fill Detail Jobs Tab");
            List<PartJobDataList> PartList = PartJobTabData.PartJobDataList;
            _extendpage.SwitchToFrameAfterTabClick(_partJobTab, _StandJobSpecPartFrame);
            int RowNum = 0;
            foreach (PartJobDataList partItem in PartList)
            {
                IWebElement PartNoElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable, _partHeadeName, partItem.PartNo, _partNoJobId);
                CommonUtil.VerifyElementValue(PartNoElement, "PartNo", partItem.PartNo, false, "value");
                IWebElement QuantityElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable, _partHeadeName, partItem.PartNo, _qtyPartJobId);
                CommonUtil.VerifyElementValue(QuantityElement, "Quantity", partItem.Quantity, false, "value");
                Driver.WaitForReady();
                IWebElement RequiredInfoElement =_extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable, _partHeadeName, partItem.PartNo, _requiredPartCbId);
                CommonUtil.VerifyCheckboxState(RequiredInfoElement, "RequiredInfo", partItem.RequiredInfo);
                RowNum++;
            }
        }

        /// <summary>
        /// Verify Dependent Job Tab
        /// </summary>
        /// <param name="StandardTechSpec"></param>
        public void VerifyDependentJobTab(DependentJobsTab StandardTechSpec)
        {
            _extendpage.SwitchToFrameAfterTabClick(_dependentJobsTab, _standJobSpecDJFrame);
            IWebElement DependentJobNameElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDJTable, _jobHeadeName, StandardTechSpec.DependentJob, _dDependentJobId);
            CommonUtil.VerifyElementValue(DependentJobNameElement, "DependentJob", StandardTechSpec.DependentJob, false, "value");
            IWebElement DependentLocationElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDJTable, _jobHeadeName, StandardTechSpec.DependentJob, _dLocationId);
            CommonUtil.VerifyElementValue(DependentLocationElement, "DependentLocation", StandardTechSpec.DependentLocation, false, "value");
            IWebElement DependentReasonElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDJTable, _jobHeadeName, StandardTechSpec.DependentJob, _dJobRsnId);
            CommonUtil.VerifyElementValue(DependentReasonElement, "DependentReason", StandardTechSpec.DependentReason, false, "value");
            Settings.Logger.Info(" Successfully Verified Dependent Job Tab Tech Spec");
        }

        /// <summary>
        /// Verify TestSuites Tab
        /// </summary>
        /// <param name="StandTechSpac"></param>
        public void VerifyTestSuitesTab(TestSuitesTab StandTechSpac)
        {
            _extendpage.SwitchToFrameAfterTabClick(_testSuitesTab, _standJobSpecTSFrame);
            IWebElement BrakeTestFlElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.BrakeTest, _testSuitSelectedId);
            CommonUtil.VerifyCheckboxState(BrakeTestFlElement, "RequiredInfo", StandTechSpac.BrakeTestFl);
            Driver.WaitForReady();
            IWebElement BrakeFkElement =_extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.Brake, _testSuitSelectedId);
            CommonUtil.VerifyCheckboxState(BrakeTestFlElement, "RequiredInfo", StandTechSpac.BrakeFl);
            IWebElement BriBreaksFlElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.BriBreaks, _testSuitSelectedId);
            CommonUtil.VerifyCheckboxState(BriBreaksFlElement, "RequiredInfo", StandTechSpac.BriBreaksFl);
            Driver.WaitForReady();
            IWebElement CerysTestFkElement = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecTSTable, _testSuiteHeadeName, StandTechSpac.CerysTest, _testSuitSelectedId);
            CommonUtil.VerifyCheckboxState(CerysTestFkElement, "RequiredInfo", StandTechSpac.CerysTestFl);
            Settings.Logger.Info(" Successfully Verified TestSuites Tab Tech Spec");
        }

        /// <summary>
        /// Verify Estimates Tab
        /// </summary>
        /// <param name="StandTechSpac"></param>
        public void VerifyEstimatesTab(EstimatesTab StandTechSpac)
        {
            Settings.Logger.Info(" Verify Estimates Tab");
            List<AssignedLaborResource> LaborResourcesList = StandTechSpac.AssignedLaborResources;
            _extendpage.SwitchToContentFrameAndTabClick(_estimatesTab);
            CommonUtil.VerifyElementValue(_laborTime, "LaborTime", StandTechSpac.LaborTime);  
            CommonUtil.VerifyElementValue(_laborCost, "PreferredShif", StandTechSpac.LborCost);
            CommonUtil.VerifyElementValue(_shopTime, "ShopTime", StandTechSpac.ShopTime);
            CommonUtil.VerifyElementValue(_partCost, "PartCost", StandTechSpac.PartCost);
            CommonUtil.VerifyElementValue(_contingencyTime, "ContingencyTime", StandTechSpac.ContingencyTime);
            CommonUtil.VerifyElementValue(_commCost, "CommCost", StandTechSpac.CommCost); 
            CommonUtil.VerifyElementValue(_bookTime, "BookTime", StandTechSpac.BookTime);
            CommonUtil.VerifyElementValue(_estCost, "EstCost", StandTechSpac.EstCost);
            CommonUtil.VerifyElementValue(_indStdTime, "IndStdTime", StandTechSpac.IndStdTime);
            CommonUtil.VerifyElementValue(_bookTimeMin, "BookTimeMin", StandTechSpac.BookTimeMin);
            CommonUtil.VerifyElementValue(_bookTimeMax, "BookTimeMax", StandTechSpac.BookTimeMax);
            Driver.SwitchToFrame(_laborSourceFrame, "laborSourceFrame");
            int RowNum = 0;
            foreach (AssignedLaborResource laborResourceItem in LaborResourcesList)
            {
                IWebElement ResourceElement = _extendpage.GetTableActionElementByRelatedColumnValue(_laborResourceTable, _resourceHeadeName, laborResourceItem.Resource, _resource);
                CommonUtil.VerifyElementValue(ResourceElement, "Resource", laborResourceItem.Resource, false, "value");
                IWebElement ResQtyElement = _extendpage.GetTableActionElementByRelatedColumnValue(_laborResourceTable, _resourceHeadeName, laborResourceItem.Resource, _resQty);
                CommonUtil.VerifyElementValue(ResQtyElement, "Quantity", laborResourceItem.Quantity, false, "value");
                IWebElement PrimaryFLlement = _extendpage.GetTableActionElementByRelatedColumnValue(_laborResourceTable, _resourceHeadeName, laborResourceItem.Resource, _primaryFL);
                CommonUtil.VerifyCheckboxState(PrimaryFLlement, "PrimaryFL", laborResourceItem.PrimaryFL);
                RowNum++;
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Estimates Tab ");
        }


        /// <summary>
        /// Refresh And Open Standard TechSpec
        /// </summary>
        /// <param name="StandardJobCode"></param>
        /// <param name="TechSpecNo"></param>
        public void RefreshAndOpenStandardTechSpec(string StandardJobCode, string TechSpecNo)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _standJobNo.SetText(StandardJobCode, "Stand Job No");
            Driver.WaitForReady();
            _standSpecNo.SetText(TechSpecNo, "Tech Spec No"); ;
        }

        /// <summary>
        /// Fill DeptF ixed Cost
        /// </summary>
        /// <param name="DeptFixedCostsTab"></param>
        public void FillDeptFixedCost(DeptFixedCostsTab DeptFixedCostsTab)
        {
            _extendpage.SwitchToContentFrameAndTabClick(_deptFixedCostTab);
            if (DeptFixedCostsTab.FillDeptFixedCost)
            {
                _extendpage.AddRecordsInTable(_standJobSpecDeptCostTable, _standJobSpecDeptCostFrame, DeptFixedCostsTab.DeptFixedCostsTableKey);
                TableData TableData = CommonUtil.DataObjectForKey(DeptFixedCostsTab.DeptFixedCostsTableKey).ToObject<TableData>();
                _effDateDeptFirstRow =_extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDeptCostTable, "Department", TableData.Table.TableRowsList[0].TableItemsList[2].SearchValue, TableData.Table.TableRowsList[0].TableItemsList[2].ItemName).GetAttribute("value");
                if(TableData.Table.TableRowsList.Count > 1) _effDateDeptSecondRow = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDeptCostTable, "Department", TableData.Table.TableRowsList[1].TableItemsList[2].SearchValue, TableData.Table.TableRowsList[1].TableItemsList[2].ItemName).GetAttribute("value");
                _extendpage.Save();
            }
        }

        /// <summary>
        /// Verify Dept Fixed Cost
        /// </summary>
        /// <param name="DeptFixedCostsTab"></param>
        public void VerifyDeptFixedCost(DeptFixedCostsTab DeptFixedCostsTab)
        {
            _extendpage.SwitchToContentFrameAndTabClick(_deptFixedCostTab);
            TableData TableData = CommonUtil.DataObjectForKey(DeptFixedCostsTab.DeptFixedCostsTableKey).ToObject<TableData>();
            _extendpage.VerifyRecordsInTable(_standJobSpecDeptCostTable, _standJobSpecDeptCostFrame, DeptFixedCostsTab.DeptFixedCostsTableKey);
            IWebElement EffDateDeptFirstRow = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDeptCostTable, "Department", TableData.Table.TableRowsList[0].TableItemsList[2].SearchValue, TableData.Table.TableRowsList[0].TableItemsList[2].ItemName);
            CommonUtil.VerifyElementValue(EffDateDeptFirstRow, "EffDateDeptFirstRow", _effDateDeptFirstRow,false ,"value");
            IWebElement EffDateDeptSecondRow = _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecDeptCostTable, "Department", TableData.Table.TableRowsList[1].TableItemsList[2].SearchValue, TableData.Table.TableRowsList[1].TableItemsList[2].ItemName);
            CommonUtil.VerifyElementValue(EffDateDeptSecondRow, "EffDateDeptSecondRow", _effDateDeptSecondRow, false, "value");
            Settings.Logger.Info(" Successfully Verified Dept Fixed Costs Tab Tech Spec");
        }

        /// <summary>
        /// Delete Standard Job Tech Spec Table
        /// </summary>
        /// <param name="StandardTechSpec"></param>
        public void DeleteStandardJobTechSpecTable(StandardJobTechSpec StandardTechSpec)
        {
            RefreshAndOpenStandardTechSpec(StandardTechSpec.StandJobNo, StandardTechSpec.TechSpecNo);
            Driver.WaitForReady();
            if (StandardTechSpec.PartJobTab != null)
            {
                DeletePartTable(StandardTechSpec.PartJobTab);
            }
            if (StandardTechSpec.EstimatesTab != null)
            {
                DeleteEstimatesTable(StandardTechSpec.EstimatesTab);
            }
            if (StandardTechSpec.DeptFixedCostsTab != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_deptFixedCostTab);
                _extendpage.DeleteRecordsFromTable(_standJobSpecDeptCostTable, _standJobSpecDeptCostFrame, StandardTechSpec.DeptFixedCostsTab.DeptFixedCostsTableKey);
            }
            Settings.Logger.Info("deleted Standard Job TechS pec Table");
        }

        /// <summary>
        /// Update Standard Job Tech Spec
        /// </summary>
        /// <param name="StandardTechSpec"></param>
        public void UpdateStandardJobTechSpec(StandardJobTechSpec StandardTechSpec)
        {
            RefreshAndOpenStandardTechSpec(StandardTechSpec.StandJobNo, StandardTechSpec.TechSpecNo);
            if (StandardTechSpec.StandardJobDetailTab != null)
            {
                FillDetailJobTab(StandardTechSpec.StandardJobDetailTab);
            }
            if (StandardTechSpec.PartJobTab != null)
            {
                FillPartJobTab(StandardTechSpec.PartJobTab);
            }
            if (StandardTechSpec.TestSuitesTab != null)
            {
                FillTestSuitesTab(StandardTechSpec.TestSuitesTab);
            }
            if (StandardTechSpec.DependentJobsTab != null)
            {
                FillDependentJobsTab(StandardTechSpec.DependentJobsTab);
            }
            if (StandardTechSpec.EstimatesTab != null)
            {
                FillEstimatesTab(StandardTechSpec.EstimatesTab);
            }
            if (StandardTechSpec.DeptFixedCostsTab != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_deptFixedCostTab);
                FillDeptFixedCost(StandardTechSpec.DeptFixedCostsTab);
            }
        }

        /// <summary>
        /// Delete Estimates Table
        /// </summary>
        /// <param name="StandTechSpac"></param>
        public void DeleteEstimatesTable(EstimatesTab StandTechSpac)
        {
            List<AssignedLaborResource> LaborResourcesList = StandTechSpac.AssignedLaborResources;
            Driver.PageScrollDown();
            _extendpage.SwitchToFrameAfterTabClick(_estimatesTab,_laborSourceFrame);
            foreach (AssignedLaborResource laborResourceItem in LaborResourcesList)
            {
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_laborResourceTable, _resourceHeadeName, laborResourceItem.Resource, _resQty).Click();
                _extendpage.DeleteAndSave();
                Driver.SwitchToFrame(_laborSourceFrame, "laborSourceFrame");
            }
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
        }

        /// <summary>
        /// DeletePartTable
        /// </summary>
        /// <param name="PartJobTab"></param>
        public void DeletePartTable(PartJobTab PartJobTab)
        {
            List<PartJobDataList> PartList = PartJobTab.PartJobDataList;
            _extendpage.SwitchToFrameAfterTabClick(_partJobTab, _StandJobSpecPartFrame);
            foreach (PartJobDataList PartListItem in PartList)
            {
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_standJobSpecPartTable, _partHeadeName, PartListItem.PartNo, _qtyPartJobId, "value").Click();
                _extendpage.DeleteAndSave();
                Driver.SwitchToFrame(_StandJobSpecPartFrame, "StandJobSpecPartFrame");
            }
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
        }

        /// <summary>
        /// Verify Deletion Standard Job Tech Spec Table
        /// </summary>
        /// <param name="StandardTechSpec"></param>
        public void VerifyDeletionStandardJobTechSpecTable(StandardJobTechSpec StandardTechSpec)
        {
            RefreshAndOpenStandardTechSpec(StandardTechSpec.StandJobNo, StandardTechSpec.TechSpecNo);
            Driver.WaitForReady();
            if (StandardTechSpec.PartJobTab != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_partJobTab);
                _extendpage.VerifyTableRowDeletion(_StandJobSpecPartFrame, _standJobSpecPartTableRows, "Stand Job Spec Part Table ");
            }
            if (StandardTechSpec.EstimatesTab != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_estimatesTab);
                _extendpage.VerifyTableRowDeletion(_laborSourceFrame, _laborResourceTableRows, "Estimates labor Resource Table");
            }
            if (StandardTechSpec.DeptFixedCostsTab != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_deptFixedCostTab);
                _extendpage.VerifyTableRowDeletion(_standJobSpecDeptCostFrame, _standJobSpecDeptCostTableRows, "Stand Job Spec Dept Cost Table");
            }
        }
    }
}
