﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Accidents;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Accidents
{
    internal class AccidentCausePageActions :  AccidentCausePage
    {
        public AccidentCausePageActions(IWebDriver Driver) : base(Driver) { }

        /// Create Accident Cause
        /// </summary>      
        public string CreateAccidentCause(AccidentCause accidentCauseC)
        {
            if (accidentCauseC.CauseNo == null)
                accidentCauseC.CauseNo = CommonUtil.GetRandomStringWithSpecialChars(5);
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_accidentCauseFrame, "Table Frame");
              _accidentCause.SetText(accidentCauseC.CauseNo, "New Accident Cause");
            Settings.Logger.Info("Create Accident Category");
            _accidentDescription.SetText(accidentCauseC.CauseDescription, "Cause Description");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Settings.Logger.Info("Saved Accident Category");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_accidentCauseFrame);
            _extendedPage.VerifyTableColumnContainValue(_accidentCauseTable, "Cause", accidentCauseC.CauseNo);
            Driver.SwitchTo().DefaultContent();
            return accidentCauseC.CauseNo;           
        }

        /// <summary>
        /// Update Accident Category
        /// </summary>
        /// <returns></returns>
        public void EditAccidentCause(AccidentCause editAccidentCause)
        {
            _extendedPage.RefreshAndSwitchToTable(_accidentCauseFrame, "Table Frame");
            Settings.Logger.Info("Update Accident Casue Code Description for : " + editAccidentCause.CauseNo);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_accidentCauseTable,
                "Cause", editAccidentCause.CauseNo, "desc").SetText(editAccidentCause.CauseDescription, "Cause Description");
            if(!editAccidentCause.CauseEnable)
                _extendedPage.GetTableActionElementByRelatedColumnValue(
               _accidentCauseTable, "Cause", editAccidentCause.CauseNo, "disabled").DeSelectCheckBox("Disabled");
            _extendedPage.GetTableActionElementByRelatedColumnValue(
             _accidentCauseTable, "Cause", editAccidentCause.CauseNo, "disabled").SelectCheckBox("Disabled", editAccidentCause.CauseEnable);
            _extendedPage.Save();
            Settings.Logger.Info("Edit Accident Cause Successfully");
        }

        /// <summary>
        /// Verify Accident Cause 
        /// </summary>
        /// <param name="CauseVal"></param>
        public void VerifyAccidentCauseDescription(AccidentCause createAccidentCause)
        {
            _extendedPage.RefreshAndSwitchToTable(_accidentCauseFrame,"Table Frame");
            Settings.Logger.Info("Verify Accident Cause Description");
            string causeCode = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _accidentCauseTable, "Cause", createAccidentCause.CauseNo, "cause_no").GetAttribute("value");
            CommonUtil.AssertTrue(createAccidentCause.CauseNo, causeCode);
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Verify Accident Cause
        /// </summary>
        public void VerifyAfterDeletionAccidentCause(string CauseVal)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_accidentCauseFrame, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_accidentCauseTable, "Cause", CauseVal);
        }
        /// <summary>
        /// Delete AccidentCause
        /// </summary>
        /// <param name="CauseVal"></param>
        public void DeleteAccidentCause(string CauseVal)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_accidentCauseFrame, "Table frame");
            Settings.Logger.Info("Delete Accident Cause: " + CauseVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _accidentCauseTable, "Cause", CauseVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
            Settings.Logger.Info("Delete Accident Cause");
        }
    }
}
