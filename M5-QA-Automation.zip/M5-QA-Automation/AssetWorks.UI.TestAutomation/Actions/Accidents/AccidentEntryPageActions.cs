﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Accidents;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Accidents
{
    internal class AccidentEntryPageActions : AccidentEntryPage
    {
        public AccidentEntryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Accident Entry 
        /// </summary>
        /// <param name="accidentEntry"></param>
        /// <returns></returns>
        public string CreateAccidentEntry(AccidentEntry accidentEntry)
        {
            if (accidentEntry.UnitNo == null)
                accidentEntry.UnitNo = CommonUtil.GetRandomStringWithSpecialChars(5);
            if (accidentEntry.IsAddNew)
            {
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForClickable(_addAccident, "Add Accident");
                _addAccident.Click();
                Driver.WaitForSomeTime();
            }
            else
            {
                if (string.IsNullOrEmpty(accidentEntry.AccidentNo) || accidentEntry.AccidentNo.ToLower().Equals("random"))
                    accidentEntry.AccidentNo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
                _accidentEntryAccidentNo.SetText(accidentEntry.AccidentNo, "AccidentNo", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
            }
            _unitNo.SetText(accidentEntry.UnitNo, "Unit Number");
            Settings.Logger.Info("Create Accident Entry");
            Driver.WaitForReady();
            if (accidentEntry.UnitInformationTab != null)
                FillUnitInformationTab(accidentEntry.UnitInformationTab);
            if (accidentEntry.accidentDetailTab != null)
                FillAccidentDetailTabInfo(accidentEntry.accidentDetailTab);
            if (accidentEntry.unitDamageTab != null)
                FillUnitDamageTabInfo(accidentEntry.unitDamageTab);
            if (accidentEntry.VendorEstimateTab != null)
                FillVendorTabInfo(accidentEntry.VendorEstimateTab);
            if (accidentEntry.WorkRequestTab != null)
                FillWorkRequestTabInfo(accidentEntry.WorkRequestTab);
            if (accidentEntry.insuranceClaimsTab != null)
                FillInsuranceClaimsTabInfo(accidentEntry.insuranceClaimsTab);
            if (accidentEntry.paymentsTab != null)
                FillPaymentsTabInfo(accidentEntry.paymentsTab);
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            accidentEntry.AccidentNo = _accidentEntryAccidentNo.GetAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return accidentEntry.AccidentNo;
        }

        /// <summary>
        /// Verify Accident Entry
        /// </summary>
        /// <param name="accidentEntry"></param>
        public void VerifyAccidentEntry(AccidentEntry accidentEntry)
        {
            Settings.Logger.Info("Verify Accident Entry for : " + accidentEntry.AccidentNo);
            _extendedPage.RefreshAndSetText(_accidentNo, accidentEntry.AccidentNo, "Accident Number");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_unitNo, "UnitNo", accidentEntry.UnitNo);
            if (accidentEntry.UnitInformationTab != null)
                VerifyUnitInformationTabData(accidentEntry.UnitInformationTab);
            if (accidentEntry.accidentDetailTab != null)
                VerifyAccidentDetailTabInfo(accidentEntry.accidentDetailTab);
            if (accidentEntry.unitDamageTab != null)
                VerifyUnitDamageTabInfo(accidentEntry.unitDamageTab);
            if (accidentEntry.VendorEstimateTab != null)
                VerifyVendorTabData(accidentEntry.VendorEstimateTab);
            if (accidentEntry.WorkRequestTab != null)
                VerifyWorkRequestTabData(accidentEntry.WorkRequestTab);
            if (accidentEntry.insuranceClaimsTab != null)
                VerifyInsuranceClaimsTabInfo(accidentEntry.insuranceClaimsTab);
            if (accidentEntry.paymentsTab != null)
                VerifyPaymentsTabInfo(accidentEntry.paymentsTab);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Accident Entry Successfully for : " + accidentEntry.AccidentNo);
        }

        /// <summary>
        /// Fill Unit Information Tab information
        /// </summary>
        /// <param name="accidentEntryUnitInfoTab"></param>
        public void FillUnitInformationTab(UnitInformationTab accidentEntryUnitInfoTab)
        {
            Settings.Logger.Info("Verify Accident Entry for Unit Information tab");
            _accidentEntryOperator.SetText(accidentEntryUnitInfoTab.Operator, "Accident Operator");
            Driver.WaitForReady();
            _accidentEntryOperatorName.SetText(accidentEntryUnitInfoTab.Name, "Accident Operator Name");
            Driver.WaitForReady();
            _accidentEntryDrivingLicense.SetText(accidentEntryUnitInfoTab.DriverLicense, "Accident Driver License");
            Driver.WaitForReady();
            _accidentEntryDriverCountry.SetText(accidentEntryUnitInfoTab.Country, "Accident Country");
            Driver.WaitForReady();
            _accidentEntryDriverState.SetText(accidentEntryUnitInfoTab.State, "Accident State");
            Driver.WaitForReady();
            _accidentEntryDriverPhone.SetText(accidentEntryUnitInfoTab.Phone, "Accident Phone");
            Driver.WaitForReady();
            _accidentEntryDriverEmail.SetText(accidentEntryUnitInfoTab.Email, "Accident Email");
            Driver.WaitForReady();
            _accidentEntrySupervisor.SetText(accidentEntryUnitInfoTab.Supervisor, "Accident Supervisor");
            Driver.WaitForReady();
            _accidentEntryInsuranceCompany.SetText(accidentEntryUnitInfoTab.InsuranceCompany, "Accident Insurance Company");
            Driver.WaitForReady();
            _accidentEntryPolicyNo.SetText(accidentEntryUnitInfoTab.PolicyNo, "Accident Policy No");
            Driver.WaitForReady();
            _accidentEntryExpiryDate.SetText(accidentEntryUnitInfoTab.ExpiryDate, "Accident Expiry Date");
            Driver.WaitForReady();
            _accidentEntryInsurancePhone.SetText(accidentEntryUnitInfoTab.ContactPhone, "Accident Contact Phone");
            Driver.WaitForReady();
            _accidentEntryTripOrig.SetText(accidentEntryUnitInfoTab.TripOrig, "Accident Trip Org");
            Driver.WaitForReady();
            _accidentEntryTripDest.SetText(accidentEntryUnitInfoTab.Destination, "Accident Trip Destination");
            Driver.WaitForReady();
            _accidentEntryStartTime.SetText(DateTime.Now.ToString(), "Accident Entry Start Time");
            Driver.WaitForReady();
            _accidentEntryPurpose.SetText(accidentEntryUnitInfoTab.Purpose, "Accident Purpose");
            Driver.WaitForReady();
            _accidentEntryScope.SelectCheckBox("Scope");
            Driver.WaitForReady();
            _accidentEntryRoute.SelectCheckBox("Route");
            Driver.WaitForReady();
            _accidentActivity.SelectCheckBox("Activity");
            Driver.WaitForReady();
            _accidentEntryWorkHours.SelectCheckBox("WorkHours");
            Driver.WaitForReady();
            _accidentEntryOnDuty.SelectCheckBox("OnDuty");
            _extendedPage.Save();
            Settings.Logger.Info("Unit Information for Accident Entry successfully Created");
        }

        /// <summary>
        /// Fill Vendor tab data
        /// </summary>
        /// <param name="accidentEntryVendorTabInfo"></param>
        public void FillVendorTabInfo(VendorEstimateTab accidentEntryVendorTabInfo)
        {
            Settings.Logger.Info("Verify Accident Entry for Vendor tab");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Vendor Estimate"), "Vendor Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_vendorTabFrame, "Vendor Frame");
            _vendorNo.SetText(accidentEntryVendorTabInfo.VendorNo, "Vendor Name");
            Driver.WaitForReady();
            _refNo.SetText(accidentEntryVendorTabInfo.RefNo, "Reference Number");
            Driver.WaitForReady();
            _laborHours.SetText(accidentEntryVendorTabInfo.LaborHours, "Labour Hours");
            Driver.WaitForReady();
            _estimatedDate.SetText(DateTime.Now.ToString(), "Estimated Date");
            Driver.WaitForReady();
            _miscCost.SetText(accidentEntryVendorTabInfo.MiscCost, "Misc Cost");
            Driver.WaitForReady();
            _laborCost.SetText(accidentEntryVendorTabInfo.LaborCost, "Labor Cost");
            Driver.WaitForReady();
            _partCost.SetText(accidentEntryVendorTabInfo.PartCost, "Part Cost");
            Driver.WaitForReady();
            _commCost.SetText(accidentEntryVendorTabInfo.CommCost, "Comm Cost");
            Driver.WaitForReady();
            _tax.SetText(accidentEntryVendorTabInfo.Tax, "Tax");
            Driver.WaitForReady();
            _extendedPage.Save();
            _extendedPage.SwitchToContentFrame();
            Settings.Logger.Info("Vendor Tab INformation successfully Updated");
        }

        /// <summary>
        /// Verify Unit Information Tab data
        /// </summary>
        /// <param name="unitinfoTab"></param>
        public void VerifyUnitInformationTabData(UnitInformationTab unitinfoTab)
        {
            Settings.Logger.Info("Verify Accident Entry for Unit Information tab");
            CommonUtil.VerifyElementValue(_accidentEntryOperator, "Operator", unitinfoTab.Operator);
            CommonUtil.VerifyElementValue(_accidentEntryOperatorName, "Operator", unitinfoTab.Name);
            CommonUtil.VerifyElementValue(_accidentEntryDrivingLicense, "Driver License", unitinfoTab.DriverLicense);
            CommonUtil.VerifyElementValue(_accidentEntryDriverCountry, "Driver Country", unitinfoTab.Country);
            CommonUtil.VerifyElementValue(_accidentEntryDriverState, "Driver State", unitinfoTab.State);
            CommonUtil.VerifyElementValue(_accidentEntrySupervisor, "Supervisor", unitinfoTab.Supervisor);
            CommonUtil.VerifyElementValue(_accidentEntryInsuranceCompany, "Supervisor", unitinfoTab.InsuranceCompany);
            CommonUtil.VerifyElementValue(_accidentEntryPolicyNo, "PolicyNo", unitinfoTab.PolicyNo);
            CommonUtil.VerifyElementValue(_accidentEntryExpiryDate, "ExpiryDate", DateTime.Now.ToString("MM/dd/yyyy"));
            CommonUtil.VerifyElementValue(_accidentEntryInsurancePhone, "Contact Phone", unitinfoTab.ValidateContactPhone);
            CommonUtil.VerifyElementValue(_accidentEntryDriverPhone, "InsurancePhone", unitinfoTab.Phone);
            CommonUtil.VerifyElementValue(_accidentEntryTripOrig, "TripOrig", unitinfoTab.TripOrig);
            CommonUtil.VerifyElementValue(_accidentEntryTripDest, "TripDest", unitinfoTab.Destination);
            CommonUtil.VerifyElementValue(_accidentEntryPurpose, "Purpose", unitinfoTab.Purpose);
            CommonUtil.VerifyElementValue(_accidentEntryStartTime, "Start Time", DateTime.Now.ToString("MM/dd/yyyy 00:00:00"));
            CommonUtil.VerifyCheckboxState(_accidentEntryScope, "Scope", unitinfoTab.Scope);
            CommonUtil.VerifyCheckboxState(_accidentEntryRoute, "Route", unitinfoTab.Route);
            CommonUtil.VerifyCheckboxState(_accidentActivity, "Activity", unitinfoTab.Activity);
            CommonUtil.VerifyCheckboxState(_accidentEntryWorkHours, "Work Hours", unitinfoTab.WorkHours);
            CommonUtil.VerifyCheckboxState(_accidentEntryOnDuty, "On Duty", unitinfoTab.OnDuty);
        }

        /// <summary>
        /// Verify Vendor Tab data 
        /// </summary>
        /// <param name="accidentEntry"></param>
        public void VerifyVendorTabData(VendorEstimateTab vendorTabData)
        {
            Settings.Logger.Info("Verify Accident Entry for Vendor Estimate Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Vendor Estimate"), "Vendor Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_vendorTabFrame, "Vendor Frame");
            string refNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "RefNo").GetAttribute("value");
            CommonUtil.AssertTrue(vendorTabData.RefNo, refNo);
            string estimatedDate = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "Est_date").GetAttribute("value");
            CommonUtil.AssertTrue(DateTime.Now.ToString("MM/dd/yyyy 00:00:00"), estimatedDate);
            string laborHours = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "Labor_hrs").GetAttribute("value");
            CommonUtil.AssertTrue(vendorTabData.LaborHours, laborHours);
            string laborCost = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "Labor_do").GetAttribute("value");
            CommonUtil.AssertTrue(vendorTabData.LaborCost, laborCost);
            string partCost = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "part_do").GetAttribute("value");
            CommonUtil.AssertTrue(vendorTabData.PartCost, partCost);
            string commCost = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "comm_do").GetAttribute("value");
            CommonUtil.AssertTrue(vendorTabData.CommCost, commCost);
            string miscCost = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "Misc_do").GetAttribute("value");
            CommonUtil.AssertTrue(vendorTabData.MiscCost, miscCost);
            string tax = _extendedPage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor", vendorTabData.VendorNo, "tax_do").GetAttribute("value");
            CommonUtil.AssertTrue(vendorTabData.Tax, tax);
            Settings.Logger.Info("Verified Vendor Tab data Successfully");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Work Request Tab Data
        /// </summary>
        /// <param name="workRequestTabData"></param>
        public void VerifyWorkRequestTabData(WorkRequestTab workRequestTabData)
        {
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Work Requests"), "Work Requests Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_workRequestFrame, "Vendor Frame");
            string occurance = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "occurance").GetAttribute("value");
            CommonUtil.AssertTrue(workRequestTabData.WROccurence, occurance);
            string jobCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "job").GetAttribute("value");
            CommonUtil.AssertTrue(workRequestTabData.WRJobCode, jobCode);
            string jobDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "jobdesc").GetAttribute("value");
            CommonUtil.AssertTrue(workRequestTabData.WRJobDesc, jobDesc);

            string visitReason = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "visitreason").GetAttribute("value");
            CommonUtil.AssertTrue(workRequestTabData.WRVisitReason, visitReason);
            
            string EarliestDate= _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "firstDate").GetAttribute("value");
            CommonUtil.AssertTrue(DateTime.Now.ToString("MM/dd/yyyy"), EarliestDate);
            string DueDate = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "due").GetAttribute("value");
            CommonUtil.AssertTrue(DateTime.Now.ToString("MM/dd/yyyy"), DueDate);
            string LatestDate = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "lastDate").GetAttribute("value");
            CommonUtil.AssertTrue(DateTime.Now.ToString("MM/dd/yyyy"), LatestDate);

            string Location = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "location").GetAttribute("value");
            CommonUtil.AssertTrue(workRequestTabData.WRLocation, Location);

            string Hours = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "hrs").GetAttribute("value");
            CommonUtil.AssertTrue(workRequestTabData.WRHrs, Hours);

            string Cost = _extendedPage.GetTableActionElementByRelatedColumnValue(_workRequestTable, "Occurance", workRequestTabData.WROccurence, "cost").GetAttribute("value");
            CommonUtil.AssertTrue(workRequestTabData.WRCost, Cost);
            Settings.Logger.Info("Verify Accident Entry for WorkRequest Tab");
        }

        /// <summary>
        /// Fill WorkRequest tab data
        /// </summary>
        /// <param name="accidentEntryVendorTabInfo"></param>
        public void FillWorkRequestTabInfo(WorkRequestTab worReqTabInfo)
        {
            Settings.Logger.Info("Enter the Work Request Information in tab");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Work Requests"), "Work Requests");
            Driver.WaitForReady();
            _workRequests.Click();
            Driver.WaitForReady();
            Settings.Logger.Info("Work Requests Tab Information successfully Updated");
            CreateNewWorkRequest(worReqTabInfo);
            Settings.Logger.Info("Work Requests successfully Created");
        }

        /// <summary>
        /// Create New work request
        /// </summary>
        /// <param name="worReqTabInfo"></param>
        public void CreateNewWorkRequest(WorkRequestTab worReqTabInfo)
        {
            Settings.Logger.Info("Work Request Main screen opens successfully");
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(_contentFrame, "new Frame");
            _newWorkRequests.ClickElement("New work Req", Driver);
            Driver.WaitForReady();
            _jobCode.SetText(worReqTabInfo.WRJobCode, "Job Code");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                _extendedPage.ClickOnDialogBoxButton("Yes");
            Driver.SwitchToFrame(_contentFrame, "new Frame");
            _jobReason.SetText(worReqTabInfo.WRJobReason, "Job Reason");
            Driver.WaitForReady();
            _scheduleShift.SetText(worReqTabInfo.WRShift, "Shift");
            Driver.WaitForReady();
            _mainLocation.SetText(worReqTabInfo.WRLocation, "WR Location");
            Driver.WaitForReady();
            _earliestDate.SetText(worReqTabInfo.WREarliestDate, "WR Earliest Date");
            Driver.WaitForReady();
            _dueDate.SetText(worReqTabInfo.WRDueDate, "WR Due Date");
            Driver.WaitForReady();
            _latestDate.SetText(worReqTabInfo.WRLatestDate, "WR Latest Date");
            Driver.WaitForReady();
            _extendedPage.Save();
            Driver.WaitForSomeTime();
            Settings.Logger.Info("Work Request Main screen saved successfully");
        }

        /// <summary>
        /// Fill Accident Detail Tab Info
        /// </summary>
        /// <param name="accidentDetail"></param>
        public void FillAccidentDetailTabInfo(AccidentDetailTab accidentDetail)
        {
            Settings.Logger.Info("Fill Accident Detail Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Accident Detail"), "Accident Detail");
            Driver.WaitForReady();
            _inputAccidentDate.SetText(accidentDetail.AccidentDate, "Accident Date");
            Driver.WaitForReady();
            _inputAddress1.SetText(accidentDetail.Address1, "Address 1");
            Driver.WaitForReady();
            _inputCity.SetText(accidentDetail.City, "City");
            Driver.WaitForReady();
            _inputCountry.SetText(accidentDetail.Country, "Country");
            Driver.WaitForReady();
            _inputState.SetText(accidentDetail.State, "State");
            Driver.WaitForReady();
            _inputZip.SetText(accidentDetail.Zip, "Zip");
            Driver.WaitForReady();
            _inputAccidentType.SetText(accidentDetail.AccidentType, "Accident Type");
            Driver.WaitForReady();
            _inputAccidentCause.SetText(accidentDetail.AccidentCause, "Accident Cause");
            Driver.WaitForReady();
            _inputWeatherCondition.SetText(accidentDetail.WeatherCondition, "Weather Condition");
            Driver.WaitForReady();
            _inputRoadCondition.SetText(accidentDetail.RoadCondition, "Road Condition");
            Driver.WaitForReady();
            _inputVisibility.SetText(accidentDetail.Visibility, "Visibility");
            Driver.WaitForReady();
            if (accidentDetail.SeatBeltUsed)
                _checkboxSeatBeltUsed.SelectCheckBox("Seat Belt Used");
            if (accidentDetail.PersonalInjury)
                _checkboxPersonalInjury.SelectCheckBox("Personal Injury");
            if (accidentDetail.Fatalities)
                _checkboxFatalities.SelectCheckBox("Fatalities");
            if (accidentDetail.PoliceReport)
                _checkboxPoliceReport.SelectCheckBox("Police Report");
            Driver.WaitForReady();
            _inputReportNo.SetText(accidentDetail.ReportNo, "Report No");
            Driver.WaitForReady();
            _inputPoliceDept.SetText(accidentDetail.PoliceDept, "Police Dept");
            Driver.WaitForReady();
            _inputOfficerName.SetText(accidentDetail.OfficerName, "Officer Name");
            Driver.WaitForReady();
            _inputPoliceAddress.SetText(accidentDetail.PoliceAddress, "Police Address");
            Driver.WaitForReady();
            _inputPoliceCity.SetText(accidentDetail.PoliceCity, "Police City");
            Driver.WaitForReady();
            _inputPoliceState.SetText(accidentDetail.PoliceState, "Police State");
            Driver.WaitForReady();
            _inputPoliceZip.SetText(accidentDetail.PoliceZip, "Police Zip");
            Driver.WaitForReady();
            _inputPoliceCountry.SetText(accidentDetail.PoliceCountry, "Police Country");
            Driver.WaitForReady();
            if (accidentDetail.DrugFlag)
                _checkboxDrugFlag.SelectCheckBox("DrugFlag");
            _selectSobriety.SelectFilterValueHavingEqualValue(accidentDetail.Sobriety);
            Driver.WaitForReady();
            _inputDateCleared.SetText(accidentDetail.DateCleared, "Date Cleared");
            Driver.WaitForReady();
            if (accidentDetail.witnessDetails != null)
            {
                Driver.SwitchToFrame(_frameWitness, "Witness");
                foreach (WitnessDetails witness in accidentDetail.witnessDetails)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", "", 
                        "Witsq", "ovalue").SetText(witness.SeqNo, "Seq No");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitName", "ovalue").SetText(witness.Name, "Name");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitCountry", "ovalue").SetText(witness.Country, "Country");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitAddress1", "ovalue").SetText(witness.Address1, "Address1");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitAddress2", "ovalue").SetText(witness.Address2, "Address2");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitCity", "ovalue").SetText(witness.City, "City");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitState", "ovalue").SetText(witness.State, "State");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitZip", "ovalue").SetText(witness.Zip, "Zip");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                        witness.SeqNo, "WitPhone", "ovalue").SetText(witness.Phone, "Phone");
                    Driver.WaitForReady();
                    if (witness.Victim)
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                            witness.SeqNo, "WitVictimFl", "ovalue").SelectCheckBox("Victim");
                    if (witness.Witness)
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                            witness.SeqNo, "WitWitnessFl", "ovalue").SelectCheckBox("Witness");
                    if (witness.Passenger)
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No", 
                            witness.SeqNo, "WitPassengerFl", "ovalue").SelectCheckBox("Passenger");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitAge", "ovalue").SetText(witness.Age, "Age");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitSex", "ovalue").SetText(witness.Sex, "Sex");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitBirthDt", "ovalue").SetText(witness.DateOfBirth, "Date Of Birth");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitVehicleOccupied", "ovalue").SetText(witness.VehicleOccupied, "Vehicle Occupied");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitVehiclePosition", "ovalue").SetText(witness.PositionInVehicle, "Position In Vehicle");
                    Driver.WaitForReady();
                    if (witness.SafetyEquipUsed)
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                            witness.SeqNo, "WitSafetyEquipUsedFl", "ovalue").SelectCheckBox("Safety Equip Used");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitInjury", "ovalue").SetText(witness.Injury, "Injury");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitRank", "ovalue").SetText(witness.Rank, "Rank");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitTransportedBy", "ovalue").SetText(witness.TransportedBy, "Transported By");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitTransportedTo", "ovalue").SetText(witness.TransportedTo, "Transported To");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitDeathDt", "ovalue").SetText(witness.DateOfDeath, "Date Of Death");
                    Driver.WaitForReady();
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Fill Unit Damage Tab Info
        /// </summary>
        /// <param name="unitDamage"></param>
        public void FillUnitDamageTabInfo(UnitDamageTab unitDamage)
        {
            Settings.Logger.Info("Fill Unit Damage Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Unit Damage"), "Unit Damage");
            Driver.WaitForReady();
            _inputClaimNo.SetText(unitDamage.ClaimNo, "Claim No");
            Driver.WaitForReady();
            _selectClaimStatus.SelectFilterValueHavingEqualValue(unitDamage.ClaimStatus);
            Driver.WaitForReady();
            _inputEstimateRepair.SetText(unitDamage.EstimateRepair, "Estimate Repair");
            Driver.WaitForReady();
            _inputOtherPartyActual.SetText(unitDamage.OtherPartyActual, "Other Party Actual");
            Driver.WaitForReady();
            _selectWriteOff.SelectFilterValueHavingEqualValue(unitDamage.WriteOff);
            Driver.WaitForReady();
            _inputBuyBackAmt.SetText(unitDamage.BuyBackAmt, "Buy Back Amt");
            Driver.WaitForReady();
            _inputSubrogationAmount.SetText(unitDamage.SubrogationAmount, "Subrogation Amount");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Accident Detail Tab Info
        /// </summary>
        /// <param name="accidentDetail"></param>
        public void VerifyAccidentDetailTabInfo(AccidentDetailTab accidentDetail)
        {
            Settings.Logger.Info("Verify Accident Detail Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Accident Detail"), "Accident Detail");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputAddress1, "Address 1", accidentDetail.Address1);
            CommonUtil.VerifyElementValue(_inputCity, "City", accidentDetail.City);
            CommonUtil.VerifyElementValue(_inputCountry, "Country", accidentDetail.Country);
            CommonUtil.VerifyElementValue(_inputState, "State", accidentDetail.State);
            CommonUtil.VerifyElementValue(_inputZip, "Zip", accidentDetail.Zip);
            CommonUtil.VerifyElementValue(_inputAccidentType, "Accident Type", accidentDetail.AccidentType);
            CommonUtil.VerifyElementValue(_inputAccidentCause, "Accident Cause", accidentDetail.AccidentCause);
            CommonUtil.VerifyElementValue(_inputWeatherCondition, "Weather Condition", accidentDetail.WeatherCondition);
            CommonUtil.VerifyElementValue(_inputRoadCondition, "Road Condition", accidentDetail.RoadCondition);
            CommonUtil.VerifyElementValue(_inputVisibility, "Visibility", accidentDetail.Visibility);
            CommonUtil.VerifyElementValue(_inputReportNo, "Report No", accidentDetail.ReportNo);
            CommonUtil.VerifyElementValue(_inputPoliceDept, "Police Dept", accidentDetail.PoliceDept);
            CommonUtil.VerifyElementValue(_inputOfficerName, "Officer Name", accidentDetail.OfficerName);
            CommonUtil.VerifyElementValue(_inputPoliceAddress, "Police Address", accidentDetail.PoliceAddress);
            CommonUtil.VerifyElementValue(_inputPoliceCity, "Police City", accidentDetail.PoliceCity);
            CommonUtil.VerifyElementValue(_inputPoliceState, "Police State", accidentDetail.PoliceState);
            CommonUtil.VerifyElementValue(_inputPoliceZip, "Police Zip", accidentDetail.PoliceZip);
            CommonUtil.VerifyElementValue(_inputPoliceCountry, "Police Country", accidentDetail.PoliceCountry);
            CommonUtil.VerifyElementValue(_selectSobriety, "Sobriety", accidentDetail.Sobriety, true);
            if (accidentDetail.witnessDetails != null)
            {
                Driver.SwitchToFrame(_frameWitness, "Witness");
                foreach (WitnessDetails witness in accidentDetail.witnessDetails)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitName", "ovalue"), "Name", witness.Name);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitCountry", "ovalue"), "Country", witness.Country);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitAddress1", "ovalue"), "Address1", witness.Address1);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitAddress2", "ovalue"), "Address2", witness.Address2);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitCity", "ovalue"), "City", witness.City);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitState", "ovalue"), "State", witness.State);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitZip", "ovalue"), "Zip", witness.Zip);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitPhone", "ovalue"), "Phone", witness.Phone);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitAge", "ovalue"), "Age", witness.Age);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitSex", "ovalue"), "Sex", witness.Sex);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitBirthDt", "ovalue"), "Date Of Birth", witness.DateOfBirth);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitVehicleOccupied", "ovalue"), "Vehicle Occupied", witness.VehicleOccupied);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitVehiclePosition", "ovalue"), "Position In Vehicle", witness.PositionInVehicle);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitInjury", "ovalue"), "Injury", witness.Injury);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitRank", "ovalue"), "Rank", witness.Rank);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitTransportedBy", "ovalue"), "Transported By", witness.TransportedBy);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitTransportedTo", "ovalue"), "Transported To", witness.TransportedTo);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWitness, "Seq No",
                        witness.SeqNo, "WitDeathDt", "ovalue"), "Date Of Death", witness.DateOfDeath);
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Verify Unit Damage Tab Info
        /// </summary>
        /// <param name="unitDamage"></param>
        public void VerifyUnitDamageTabInfo(UnitDamageTab unitDamage)
        {
            Settings.Logger.Info("Verify Unit Damage Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Unit Damage"), "Unit Damage");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputClaimNo, "Claim No", unitDamage.ClaimNo);
            CommonUtil.VerifyElementValue(_selectClaimStatus, "Claim Status", unitDamage.ClaimStatus, true);
            CommonUtil.VerifyElementValue(_inputEstimateRepair, "Estimate Repair", unitDamage.EstimateRepair);
            CommonUtil.VerifyElementValue(_inputOtherPartyActual, "Other Party Actual", unitDamage.OtherPartyActual);
            CommonUtil.VerifyElementValue(_selectWriteOff, "Write Off", unitDamage.WriteOff, true);
            CommonUtil.VerifyElementValue(_inputBuyBackAmt, "Buy Back Amt", unitDamage.BuyBackAmt);
            CommonUtil.VerifyElementValue(_inputSubrogationAmount, "Subrogation Amount", unitDamage.SubrogationAmount);
        }

        /// <summary>
        /// Fill Insurance Claims Tab Info
        /// </summary>
        /// <param name="claims"></param>
        public void FillInsuranceClaimsTabInfo(IList<InsuranceClaims> claims)
        {
            Settings.Logger.Info("Fill Insurance Claims Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Insurance Claims"), "Insurance Claims");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameInsuranceClaims, "Insurance Claims");
            foreach (InsuranceClaims claim in claims)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", "", 
                    "Claimsq", "ovalue").SetText(claim.Order, "Order");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "CalimNo", "ovalue").SetText(claim.InsuranceClaim, "Insurance Claim");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "insName", "ovalue").SetText(claim.InsurantName, "Insurant Name");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "phoneNo", "ovalue").SetText(claim.Phone, "Phone");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "ClaimPolicy", "ovalue").SetText(claim.Policy, "Policy");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "faxNo", "ovalue").SetText(claim.Fax, "Fax");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "InsEmail", "ovalue").SetText(claim.EmailAddress, "Email Address");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "RepName", "ovalue").SetText(claim.RepName, "Rep Name");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "DateSent", "ovalue").SetText(claim.SentDate, "Sent Date");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "DateReceipt", "ovalue").SetText(claim.ReceiptConfirmDate, "Receipt Confirm Date");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "OfferAmt", "ovalue").SetText(claim.OfferAmt, "Offer Amt");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "DatetoComp", "ovalue").SetText(claim.DateTo, "Date To");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "ApprovalDate", "ovalue").SetText(claim.ApprovalDate, "Approval Date");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "CompPDClm", "ovalue").SetText(claim.PDClaim, "PD Claim");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "cpClaimNo", "ovalue").SetText(claim.ComptrollerClaim, "Comptroller Claim");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "cpClaimAmt", "ovalue").SetText(claim.ClaimAmt, "Claim Amt");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order", 
                    claim.Order, "othSetAmt", "ovalue").SetText(claim.ThirdPartySettlement, "3rd Party Settlement");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
        }

        /// <summary>
        /// Fill Payments Tab Info
        /// </summary>
        /// <param name="payments"></param>
        public void FillPaymentsTabInfo(IList<Payments> payments)
        {
            Settings.Logger.Info("Fill Payments Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Payments"), "Payments");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_framePayments, "Payments");
            foreach (Payments payment in payments)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order", "",
                    "Paysq", "ovalue").SetText(payment.Order, "Order");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "Calim", "ovalue").SetText(payment.Claim, "Claim");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "PayDate", "ovalue").SetText(payment.PayDate, "Pay Date");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "CheckNo", "ovalue").SetText(payment.CheckNo, "Check No");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "paidBy", "ovalue").SetText(payment.PaidBy, "Paid By");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "AmtRcvd", "ovalue").SetText(payment.AmountReceived, "Amount Received");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "payNo", "ovalue").SetText(payment.PaymentNo, "Payment No");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "payType", "ovalue").SetText(payment.PaymentType, "Payment Type");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Insurance Claims Tab Info
        /// </summary>
        /// <param name="claims"></param>
        public void VerifyInsuranceClaimsTabInfo(IList<InsuranceClaims> claims)
        {
            Settings.Logger.Info("Verify Insurance Claims Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Insurance Claims"), "Insurance Claims");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameInsuranceClaims, "Insurance Claims");
            foreach (InsuranceClaims claim in claims)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "CalimNo", "ovalue"), "Insurance Claim", claim.InsuranceClaim);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "insName", "ovalue"), "Insurant Name", claim.InsurantName);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "phoneNo", "ovalue"), "Phone", claim.Phone);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "ClaimPolicy", "ovalue"), "Policy", claim.Policy);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "faxNo", "ovalue"), "Fax", claim.Fax);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "InsEmail", "ovalue"), "Email Address", claim.EmailAddress);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "RepName", "ovalue"), "Rep Name", claim.RepName);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "OfferAmt", "ovalue"), "Offer Amt", claim.OfferAmt);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "CompPDClm", "ovalue"), "PD Claim", claim.PDClaim);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "cpClaimNo", "ovalue"), "Comptroller Claim", claim.ComptrollerClaim);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "cpClaimAmt", "ovalue"), "Claim Amt", claim.ClaimAmt);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableInsuranceClaims, "Order",
                    claim.Order, "othSetAmt", "ovalue"), "3rd Party Settlement", claim.ThirdPartySettlement);
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Payments Tab Info
        /// </summary>
        /// <param name="payments"></param>
        public void VerifyPaymentsTabInfo(IList<Payments> payments)
        {
            Settings.Logger.Info("Verify Payments Tab Info");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Payments"), "Payments");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_framePayments, "Payments");
            foreach (Payments payment in payments)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "Calim", "ovalue"), "Claim", payment.Claim);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "CheckNo", "ovalue"), "Check No", payment.CheckNo);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "paidBy", "ovalue"), "Paid By", payment.PaidBy);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "AmtRcvd", "ovalue"), "Amount Received", payment.AmountReceived);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "payNo", "ovalue"), "Payment No", payment.PaymentNo);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePayments, "Order",
                    payment.Order, "payType", "ovalue"), "Payment Type", payment.PaymentType);
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
