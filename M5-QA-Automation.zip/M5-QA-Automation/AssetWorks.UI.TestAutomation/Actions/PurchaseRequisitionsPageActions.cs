﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.Core.Utils;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PurchaseRequisitionsPageActions : PurchaseRequisitionsPage
    {
        public PurchaseRequisitionsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Part Purchase Requisition
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public string CreatePartPurchaseRequisition(string ObjectKey)
        {
            Settings.Logger.Info(" Create Part Purchase Requisition ");
            PartPurchaseRequisition DataObject = CommonUtil.DataObjectForKey(ObjectKey).ToObject<PartPurchaseRequisition>();
            Settings.Logger.Info(" Creating Purchase OrderNo");
            string PartRequisitionsNo = String.Empty;
            _extendpage.SwitchToContentFrame();
            _newReqButton.ClickElement(" New ReqButton ", Driver);
            Driver.WaitForReady();
            _hvendorInput.SetText(DataObject.PartDetail.PRVendor, "Vendor Name");
            Driver.WaitForReady();
            _hQuotedCheckBox.SelectCheckBox("Quoted Check Box", DataObject.PartDetail.QuotedCheckBox);
            Driver.WaitForReady();
            _hvendorCheckBox.SelectCheckBox("vendor Check Box", DataObject.PartDetail.VendorCheckBox);
            if (DataObject.PartDetail.PartRequisitionData != null)
            {
                FillRequisitionTab(DataObject);
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            _extendpage.SwitchToContentFrame();
            PartRequisitionsNo = _reqNoInput.GetElementValueByAttribute("ovalue");
            UnitReserveRefNO = DataObject.PartDetail.ApprovalResvRefNo;  
            return PartRequisitionsNo;
        }

        /// <summary>
        /// Fill Requisition Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillRequisitionTab(PartPurchaseRequisition DataObject)
        {
            _noteForPR = null;
            Settings.Logger.Info(" Fill Requisition Tab ");
            Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
            List<PartRequisitionData> PartDetailList = DataObject.PartDetail.PartRequisitionData;
            int RowNum = 0;
            foreach (PartRequisitionData PartDetailData in PartDetailList)
            {
                if (RowNum == 0)
                {
                    _extendpage.GetElementForInput($"{_lineNo}{RowNum}", "name").SendKeys(Keys.Tab); ;
                }              
                _extendpage.GetInputElementAndSetValue($"{_prPartNoName}{RowNum}", PartDetailData.PartNo, "name");
                _extendpage.GetInputElementAndSetValue($"{_prQty}{RowNum}", PartDetailData.Quantity, "name");
                _extendpage.GetInputElementAndSetValue($"{_prUnitCost}{RowNum}", PartDetailData.UnitCost, "name");
                _extendpage.GetInputElementAndSetValue($"{_prNeededBy}{RowNum}", PartDetailData.NeededBy, "name");
                _extendpage.GetSelectElementAndSelectValue($"{_prReserveCode}{RowNum}", PartDetailData.ReservationCode, "name");
                _extendpage.GetInputElementAndSetValue($"{_prResvRefNo}{RowNum}", PartDetailData.ResvRefNo, "name");
                _extendpage.GetInputElementAndSetValue($"{_refNo}{RowNum}", PartDetailData.RefNo, "name");
                _extendpage.GetElementForInput($"{_contract}{RowNum}", "name").SendKeys(Keys.Tab); 
                _extendpage.GetElementForInput($"{_rejApproval}{RowNum}", "name").SendKeys(Keys.Tab); 
                _extendpage.GetElementForInput($"{_prRejReason}{RowNum}", "name").SendKeys(Keys.Tab); 
                if (PartDetailData.AddNote)
                {
                    _noteForPR = _extendpage.GetButtonElement($"{_prNoteBtn}{RowNum}", "name");
                    _extendpage.AddNotes(_noteForPR, PartDetailData.AddNoteDetail);
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
                }
                _extendpage.GetElementForInput($"{_prQuoted}{RowNum}", "name").SendKeys(Keys.Tab);
                RowNum++;
            }       
        }

        /// <summary>
        /// Approve Part Requisition
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="ReservRefApproval"></param>
        public void ApprovePartRequisition(string ObjectKey,string ReservRefApproval)
        {
            Settings.Logger.Info(" Approve Part Requisition ");
            PartPurchaseRequisition DataObject = CommonUtil.DataObjectForKey(ObjectKey).ToObject<PartPurchaseRequisition>();
            List<PartRequisitionData> PartDetailList = DataObject.PartDetail.PartRequisitionData;         
            Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
            int RowNum = 0;
            int RowsCount = _prPartTableRows.Count - 1;
            if (PartDetailList.Count<=RowsCount)
            {
                foreach (PartRequisitionData PartDetailData in PartDetailList)
                {
                    if (ReservRefApproval.Equals(PartDetailData.ResvRefNo,StringComparison.OrdinalIgnoreCase))
                    {
                         Driver.WaitForReady();
                        _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "PartNo").Click();
                        _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "approval_fl").SelectCheckBox("Rej Approval", PartDetailData.Approval);
                        _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "RejReason").SetText(PartDetailData.RejectionReason, "RejectionReason");
                        Driver.SwitchTo().DefaultContent();
                        _extendpage.ActionRequiredWindow("Continue");
                        _extendpage.Save();
                    }
                    RowNum++;
                }
            }
        }

        /// <summary>
        /// Verify Part Requisitions
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="RequisitionsNumber"></param>
        public void VerifyPartRequisitions(string ObjectKey, string RequisitionsNumber)
        {
            PartPurchaseRequisition DataObject = CommonUtil.DataObjectForKey(ObjectKey).ToObject<PartPurchaseRequisition>();
            Settings.Logger.Info(" Verifying Part Requisitions ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_reqNoInput, RequisitionsNumber, "PartRequisitions Number ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_reqNoInput, "Equipment Profile ID", RequisitionsNumber);
            CommonUtil.VerifyElementValue(_hvendorInput, "Equipment Profile ID", DataObject.PartDetail.PRVendor);
            CommonUtil.VerifyCheckboxState(_hQuotedCheckBox, "hQuotedCheckBox", DataObject.PartDetail.QuotedCheckBox);
            CommonUtil.VerifyCheckboxState(_hvendorCheckBox, "approval Check box", DataObject.PartDetail.VendorCheckBox);
            Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
            List<PartRequisitionData> PartDetailList = DataObject.PartDetail.PartRequisitionData;
            foreach (PartRequisitionData PartDetailData in PartDetailList)
            {
                _approvalCheckbox = null;
                _tQuotedCheckBox = null;
                Driver.WaitForReady();
                String ActualPartNo = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "PartNo").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.PartNo, ActualPartNo);
                String ActualPartDesc = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "pDesc").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.PartDesc, ActualPartDesc);
                String ActualPartVendor = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "vendor").GetAttribute("value");
                CommonUtil.AssertTrue<string>(DataObject.PartDetail.PRVendor, ActualPartVendor);
                String ActualQuantity = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "qty").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.Quantity, ActualQuantity);
                String ActualUnitCost = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "cpunitcost").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.UnitCost,ActualUnitCost);
                String ActualUnitinv = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "unitinv").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.Unitinv, ActualUnitinv);
                String ActualPartNeededBy = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "needby").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.NeededBy, ActualPartNeededBy);
                string ActualReserveCode = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "chargeCodeI").GetVisibleText();
                CommonUtil.AssertTrue<string>(PartDetailData.ReservationCode, ActualReserveCode);
                String ActualResvRefNo = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "typeNumI").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.ResvRefNo, ActualResvRefNo);
                String ActualRefNo = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "lineRefNo").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.RefNo, ActualRefNo);
                _approvalCheckbox = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "approval_fl");
                CommonUtil.VerifyCheckboxState(_approvalCheckbox, "approval Check box", PartDetailData.Approval);
                String ActualRejectionReason = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "RejReason").GetAttribute("value");
                CommonUtil.AssertTrue<string>(PartDetailData.RejectionReason, ActualRejectionReason);
                if (PartDetailData.AddNote)
                {
                    _noteForPR = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "noteBtn");
                    _extendpage.VerifyAddedNotes(_noteForPR, PartDetailData.AddNoteDetail);
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
                }
                _tQuotedCheckBox = _extendpage.GetTableActionElementByRelatedColumnValue(_prPartTable, _headerResvRefNo, PartDetailData.ResvRefNo, "Quoted");
                CommonUtil.VerifyCheckboxState(_tQuotedCheckBox, "Quoted Check box", DataObject.PartDetail.QuotedCheckBox);
                Settings.Logger.Info(" Successfully Verified Part Requisitions ");
            }  
        } 
    }
}
