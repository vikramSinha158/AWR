﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class WorkOrderMainPageActions: WorkOrderMainPage
    {
        public WorkOrderMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify Work Order Title
        /// </summary>
        public void VerifyWorkOrderTitle()
        {
            Settings.Logger.Info("Verifying work order page to display");
            _extendedPage.SwitchToContentFrame();
            Assert.True(_workOrderTitle.VerifyElementDisplay(" Workorder page title "), "WorkOrder Page Not Dispalyed");
            Settings.Logger.Info("Verified work order page successfully");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Search for work order
        /// </summary>
        public void SearchForWorkOrder()
        {
            Settings.Logger.Info("Creating workorder");
            ClickActionLOVForWorkOrder(_searchLinkWorkOrderNo);
        }

        /// <summary>
        /// Search For UnitNo
        /// </summary>
        public void SearchForUnitNo()
        {
            Settings.Logger.Info("Creating workorder for unit");
            ClickActionLOVForWorkOrder(_searchLinkUnitNo);
        }

        /// <summary>
        /// Search For Component
        /// </summary>
        public void SearchForComponent()
        {
            Settings.Logger.Info("Creating workorder for component");
            ClickActionLOVForWorkOrder(_searchLinkComponent);
        }

        /// <summary>
        /// Verify work order details
        /// </summary>
        public void VerifyWorkOrderInformation()
        {
            Settings.Logger.Info("Verifying workorder number and satus");
            _extendedPage.SwitchToContentFrame();
            string woStatus = _workOrderStatus.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(woStatus), "work order status is empty");
            VerifyWorkorderNumber();
        }

        /// <summary>
        /// Verifying generated work order
        /// </summary>
        public void VerifyWorkorderNumber()
        {
            WONumber = _workOrderNumber.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(WONumber), "work order number is empty");
            Settings.Logger.Info($"Created workorder number {WONumber}");
        }

        /// <summary>
        /// Click Action LOV For Work Order
        /// </summary>
        /// <param name="ActionLovLink"></param>
        public void ClickActionLOVForWorkOrder(IWebElement ActionLovLink)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.WaitForClickable(_inputWorkOrderNo, "Wo text box");
            _inputWorkOrderNo.Clear();
            WaitUntilDisplayed(_inputWorkOrderNo,"Input workorder number ");
            Driver.DoubleClick(_inputWorkOrderNo, " Input workorder number ");
            Driver.SwitchTo().DefaultContent();
            ActionLovLink.VerifyElementDisplay(" Action list ");
            Driver.WaitForReady();
            ActionLovLink.Click();
        }

        /// <summary>
        /// Click OnWork Order Build
        /// </summary>
        public void ClickOnWorkOrderBuild()
        {
            Driver.WaitForClickable(_buildButton," Build button ");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_buildButton, " Build button ");
        }

        /// <summary>
        /// VisitRequestReason
        /// </summary>
        /// <param name="VisitReason"></param>
        public void VisitRequestReason(string VisitReason)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();         
            Driver.MouseHover(_visitReq, " visit request number ");
            Driver.ScrollIntoViewAndClick(_visitReq, " visit request number");
            _visitReq.SendKeys(VisitReason);
            Settings.Logger.Info($"Entered visit reason {VisitReason}");
            Driver.WaitForReady();
            _visitReq.SendKeys(Keys.Tab);
        }

        /// <summary>
        /// verify work order
        /// </summary>
        public void CreateAndVerifyWorkOrder()
        {
            _extendedPage.SwitchToContentFrame();
            ClickOnWorkOrderBuild();
            Driver.WaitForReady();
            VisitRequestReason("0");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            VerifyWorkorderNumber();
        }

        /// <summary>
        /// Verify Added Action WorkOrder
        /// </summary>
        /// <param name="actionnumber"></param>
        public void VerifyAddedActionWorkOrder(string ActionNumber)
        {
            string actualActionNumber = _unitNo.GetElementValueByAttribute("ovalue");
            Assert.True(ActionNumber.Equals(actualActionNumber.Trim()), "work order status is empty");
            Settings.Logger.Info($" Matched Actual action number : {actualActionNumber} and expacted number as {ActionNumber}");
        }

        /// <summary>
        /// Add Job To Work Order
        /// </summary>
        public void AddJobToWorkOrder()
        {
            Settings.Logger.Info("Adding job in workorder ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.MouseHover(_jobTab," job tab ");
            Driver.ScrollIntoViewAndClick(_jobTab," job tab ");
            AddJobInfo();
        }

        /// <summary>
        /// Add Job Info
        /// </summary>
        public void AddJobInfo()
        {
            if (_jobInformation.VerifyElementDisplay("Job information dialog "))
            {
                Driver.SwitchToFrame(_jobFormFrame,"job frame ");
                Driver.WaitForReady();
                _jobCode.SetText(Settings.JobCode, "Settings.JobCode");
                Driver.WaitForReady();
                _jobStatus.SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _jobReason.SetText("0", "Job reason");
                Driver.SwitchTo().DefaultContent();
                Driver.WaitForSomeTime();
                Driver.AcceptAlert();
                _extendedPage.ClicKSave();
            }
        }

        /// <summary>
        /// Verify Created Workorder Job
        /// </summary>
        public void VerifyCreatedWorkorderJob()
        {
            _extendedPage.SwitchToContentFrame();
            Assert.True(_jobLoadedMsg.VerifyElementDisplay("Job loaded"), "Job not added");
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
            string addworkorferjob = _jobCode.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(addworkorferjob), "work order number is empty");
        }

        /// <summary>
        /// veify Workorder Job Deletion
        /// </summary>
        public void veifyWorkorderJobDeletion()
        {
            Settings.Logger.Info("Verifying created workorder job deletion ");
            Driver.WaitForReady();
            _jobStatus.SetText("CAN", " job status");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            Assert.True(_jobDeletedMsg.VerifyElementDisplay("Job deleted message "), "Job not deleted");
        }

        /// <summary>
        /// Delete work order
        /// </summary>
        public void DeleteWorkOrder()
        {
            Settings.Logger.Info("Deleting existing workorder ");
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Proceed");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady(69);
            Driver.FindElement(By.XPath(canclecbxpath)).Click();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_wolistframe,"workorder list frame ");
            Driver.WaitForReady();
            Assert.True(WONumber.Equals(_canWOnumber.GetAttribute("value")) && _woStatus.GetAttribute("value").Equals("CANCELLED"), WONumber + " not found cancelled");
            Settings.Logger.Info(" Verify work order no : " + WONumber + " status : CANCELLED ");
            _extendedPage.VerifySystemDateContainAppdate(_woCloseDate, "WO Closed");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Refresh And Verify Work Order Complete Dates
        /// </summary>
        public void RefreshAndVerifyWOCompleteDates()
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");
            Driver.WaitForReady();
            _extendedPage.VerifySystemDateContainAppdate(_woVisitInfoCompleteDate, "WO Visit Info Complete");
            _extendedPage.VerifySystemDateContainAppdate(_woVisitInfoCloseDate, "WO Visit Info Closed");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Click Work Order Filter
        /// </summary>
        public void ClickWorkOrderFilter()
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _workOrderFilter.ClickElement("work order filter", Driver);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Adding Work Request InJob
        /// </summary>
        public void AddWorkRequestInJob()
        {
            Settings.Logger.Info(" Adding work request in work order job ");
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(WorkOrderMainPage.WONumber, "Work order number text field ");
            if (_workRequestList.Text.ToString().Contains("1"))
            {
                _workRequestList.ClickElement("work request list ", Driver);
                Driver.SwitchTo().DefaultContent();
                if (_workRequestDialog.VerifyElementDisplay("Work Request Dialog"))
                {
                    if (_workRequesRows.Count > 1)
                    {
                        _addWorkRequest.ClickElement(" Add work request ", Driver);
                        _saveWRBtn.ClickElement("Save work request", Driver);
                    }
                    else
                    {
                        Settings.Logger.Info("WorkRequest is not visible in worklist dialog ");
                        Assert.Fail(" WorkRequest is not visible in worklist dialog ");
                    }
                }
            }
            else
            {
                Settings.Logger.Info(" WorkRequest is not added in workorderlis ");
                Assert.Fail(" WorkRequest is not added in workorderlist");
            }
        }

        /// <summary>
        /// verifying Added Work Request
        /// </summary>
        public void VerifyAddedWorkRequest()
        {
            Settings.Logger.Info(" verifying Added Work Request ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            if (_workRequestList.Text.ToString().Contains("0"))
            {
                _jobTab.ClickElement("Job Tab", Driver);
                Assert.True(_jobLoadedMsg.VerifyElementDisplay("Job loaded"), "Job not added");
            }
            else {
                Settings.Logger.Info(" WorkRequestList not added in job  ");
                Assert.Fail("Job not added");
            }
        }

        /// <summary>
        /// Adding  Labor In WorkOrder
        /// </summary>
        /// <param name="JobCode"></param>
        /// <param name="EmployeeCode"></param>
        /// <param name="Position"></param>
        public void AddLaborInWorkOrder(string JobCode,string EmployeeCode,string Position)
        {
            Settings.Logger.Info(" Adding  Labor In WorkOrder ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _laborTab.ClickElement("Labor Tab ", Driver);
            Driver.SwitchToFrame(_woLaborframe,"Labor frame ");
            _laborJobCode.SetText(JobCode, JobCode);
            Driver.WaitForReady();
            _employeeCode.SetText(EmployeeCode, EmployeeCode);
            Driver.WaitForReady();
            _employeePosition.SetText(Position, Position);
            Driver.WaitForReady();
            _inDateTime.SetText("-1", "");
            _enteredInDateTime = _inDateTime.GetElementValueByAttribute("ovalue");
            Driver.WaitForReady();
            _outDateTime.SetText("-1","");
            _enteredOutDateTime = _outDateTime.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
        }

        /// <summary>
        /// Verifying Labor Information
        /// </summary>
        public void VerifyLaborInformation()
        {
            Settings.Logger.Info(" verifying Added Labor  Information ");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_woLaborframe, "Labor frame ");
            string LaborJobCodeValue=_laborJobCode.GetElementValueByAttribute("ovalue");
            _extendedPage.AssetTrue(LaborJobCodeValue, Settings.JobCode);
            string EmployeeCodeValue = _employeeCode.GetElementValueByAttribute("ovalue");
            _extendedPage.AssetTrue(EmployeeCodeValue, Settings.EmployeeCode);
            string EmployeeNameValue = _employeeName.GetElementValueByAttribute("ovalue");
            _extendedPage.AssetTrue(EmployeeNameValue, Settings.EmployeeName);
            string EmployeePositionValue = _employeePosition.GetElementValueByAttribute("ovalue");
            _extendedPage.AssetTrue(EmployeePositionValue, Settings.EmployeePosition);
            string TimeTypeValue= _timeType.GetElementValueByAttribute("ovalue");
            _extendedPage.AssetTrue(TimeTypeValue, Settings.TimeType);
            string PayClassValue = _payClass.GetElementValueByAttribute("ovalue");
            _extendedPage.AssetTrue(PayClassValue, Settings.PayClass);
            string PayStepValue = _payStep.GetElementValueByAttribute("ovalue");
            _extendedPage.AssetTrue(PayStepValue, Settings.PayStep);
        }

        /// <summary>
        /// Edit Timout Hour
        /// </summary>
        public void EditTimoutHour()
        {
            Settings.Logger.Info(" Editing out date time hour ");
            _enteredOutDateTime =String.Empty;
           _outDateTime.ClickElement("Out Date time Hour ", Driver);
            string CurrentOutDate=_outDateTime.GetElementValueByAttribute("ovalue");
            _outDateTime.Clear();
            _outDateTime.SetText(CommonUtil.GenerateRandomDateString(-1), "");
            _enteredOutDateTime = _outDateTime.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.CheckkWarningMessage();
        }

        /// <summary>
        /// Labor Record Deletion
        /// </summary>
        public void LaborRecordDeletion()
        {
            Settings.Logger.Info(" Deleting Labor  Information ");
            _outDateTime.ClickElement("Out Date time Hour ", Driver);
            _laborJobCode.ClickElement("Labor Job Code ", Driver);
            Driver.AcceptAlert();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.AcceptAlert();
            Driver.WaitForReady();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            Assert.True(_LaborChargeDeletetInfo.VerifyElementDisplay("Job deleted message "), "Job not deleted");
        }

        /// <summary>
        /// Add And Verify Stock Part Records
        /// </summary>
        /// <param name="RowCount"></param>
        /// <param name="DataObject"></param>
        public void AddStockPartRecords(int RowCount,dynamic DataObject)
        {
            Settings.Logger.Info(" Added Stock Part Information ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
            for (int i = 0; i < RowCount; i++)
            {
                AddAndVerifyStockPart(i,DataObject[i]);
            }          
        }

        /// <summary>
        /// Add And Verify Stock Part for each recoed
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddAndVerifyStockPart(int RowNum,JObject DataObject)
        {
            Settings.Logger.Info($" Adding and Verifying  Stock Part Information for record No { RowNum} ");
            _partJobCode = null;
            _partNumber = null;
            _partEmpNo = null;
            _partQty = null;
            _failCode=null;
            _refNo=null;
            _empPosition=null;
            _pRONumber = null;
            Driver.WaitForReady();  
            if (RowNum>=1)
            {
                _partJobCode =_extendedPage.GetElementForInput($"{_partCodeName}{RowNum}");
                Driver.WaitForReady();
                _jobstockPCode = CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject).ToString().Trim();
                Driver.WaitForReady();
                _extendedPage.SelectAllAndClearField(_partJobCode);
                Driver.WaitForReady();
                _partJobCode.SendKeys(_jobstockPCode);
                Driver.WaitForReady();
                _partJobCode.SendKeys(Keys.Tab);
            }
            else
            {
                _partJobCode = _extendedPage.GetInputElementAndSetValue($"{_partCodeName}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject), "name");
            }
            Driver.AcceptAlert();
            Driver.WaitForReady();
            _partNumber=_extendedPage.GetInputElementAndSetValue($"{_partNumberId}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PartNo, DataObject));
            Driver.WaitForReady();
            _partEmpNo =_extendedPage.GetInputElementAndSetValue($"{_employeeId}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.EmployeeCode, DataObject));
            Driver.WaitForReady();
            _partQty=_extendedPage.GetInputElementAndSetValue($"{_qtyId}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PartQty, DataObject));
            Driver.WaitForReady();
            _extendedPage.GetAndClickElement($"{_printTagId}{RowNum}");
            Driver.WaitForReady();
            _failCode=_extendedPage.GetInputElementAndSetValue($"{_failCodeId}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.FailCode, DataObject));
            Driver.WaitForReady();
            _refNo=_extendedPage.GetInputElementAndSetValue($"{_refNoId}{RowNum}",Convert.ToString(CommonUtil.GenerateRandomIntValue()));
            Driver.WaitForReady();
            _pRONumber=_extendedPage.GetInputElementAndSetValue($"{_pRONumberId}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PRONumber, DataObject));
            Driver.WaitForReady();
            _empPosition = _extendedPage.GetInputElementAndSetValue($"{_positionId}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Position, DataObject));
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SaveAndReloadActionCode(_inputWorkOrderNo, WONumber);
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchToFrame(_partInfoframe, "Stock Part frame ");
            VerifyStockPartInformation(0,DataObject);
        }

        /// <summary>
        /// Verify Stock Part Information
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void VerifyStockPartInformation(int RowNum,dynamic DataObject)
        {
            Settings.Logger.Info(" verifying added stock part information ");
            string PartJobCodeValue = _extendedPage.GetAttributeValueForInput($"{_partCodeName}{RowNum}"); ;
            _extendedPage.AssetTrue(PartJobCodeValue, CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject));
            string PartNumberValue = _extendedPage.GetAttributeValueForInput($"{_partNumberId}{RowNum}");
            _extendedPage.AssetTrue(PartNumberValue, CommonUtil.DataForKey(WorkOrderObjects.PartNo, DataObject));
            string EmployeeNoValue = _extendedPage.GetAttributeValueForInput($"{_employeeId}{RowNum}");
            _extendedPage.AssetTrue(EmployeeNoValue, CommonUtil.DataForKey(WorkOrderObjects.EmployeeCode, DataObject));
            string PartQtyValue = _extendedPage.GetAttributeValueForInput($"{_qtyId}{RowNum}");
            _extendedPage.AssetTrue(PartQtyValue, CommonUtil.DataForKey(WorkOrderObjects.PartQty, DataObject));
            string FailCodeValue = _extendedPage.GetAttributeValueForInput($"{_failCodeId}{RowNum}");
            _extendedPage.AssetTrue(FailCodeValue, CommonUtil.DataForKey(WorkOrderObjects.FailCode, DataObject));
             string PRONumberValue = _extendedPage.GetAttributeValueForInput($"{_pRONumberId}{RowNum}");
            _extendedPage.AssetTrue(PRONumberValue, CommonUtil.DataForKey(WorkOrderObjects.ExpectedPRONumber, DataObject));
        }

        /// <summary>
        /// Add Job Records
        /// </summary>
        /// <param name="RowCount"></param>
        /// <param name="DataObject"></param>
        public void AddJobRecords(int RowCount, dynamic DataObject)
        {
            Settings.Logger.Info("Adding job Information ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.MouseHover(_jobTab, " job tab ");
            Driver.ScrollIntoViewAndClick(_jobTab, " job tab ");
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
            for (int i = 0; i < RowCount; i++)
            {
                AddJobToWorkOrder(i, DataObject[i]);
            }
        }

        /// <summary>
        /// Add Job To WorkOrder
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddJobToWorkOrder(int RowNum, JObject DataObject)
        {
            Settings.Logger.Info($" Adding job Information for record No { RowNum} ");
            Driver.WaitForReady();
            _extendedPage.GetInputElementAndSetValue($"{_jobCodename}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.JobCode, DataObject),"name");
            Driver.WaitForReady();
            _extendedPage.GetElementForInput($"{_jobStatusId}{RowNum}","name").SendKeys(Keys.Tab);
            Driver.WaitForReady();
            _extendedPage.GetInputElementAndSetValue($"{_jobReasonId}{RowNum}","0", "name");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
        }

        /// <summary>
        /// Edit And Verify StockPartRecord
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void EditAndVerifyStockPartRecord(int RowNum,dynamic DataObject)
        {
            Settings.Logger.Info(" Edit And Verify Stock Part Record ");
            var EditData = DataObject[RowNum];
            _partQty = null;
            _partQty = _extendedPage.GetInputElementAndSetValue($"{_qtyId}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PartQty, EditData));
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SaveAndReloadActionCode(_inputWorkOrderNo, WONumber);
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchToFrame(_partInfoframe, "Stock Part frame ");
            VerifyStockPartInformation(0, EditData);
        }

        /// <summary>
        /// Delete And VerifyStockPartRecord
        /// </summary>
        public void DeleteAndVerifyStockPartRecord()
        {
            Settings.Logger.Info(" Deleting  and Verify Stock Part Record ");
            _partNumber = null;
            int StockReordCount = _stockPartRecords.Count;
            StockReordCount = _stockPartRecords.Count;
            for (int i = 1; i < StockReordCount; i++)
            {
                _partNumber = _extendedPage.GetElementForInput($"{_partNumberId}{0}");
                _partNumber.ClickElement("Part Number", Driver);
                 Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDeleteButton();
                Driver.WaitForReady();
                _extendedPage.ClicKSave();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_partInfoframe, "Stock Part frame ");
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Assert.True(_stockPartDeletetInfo.VerifyElementDisplay("Stock Part deleted message "), "Stock Part not deleted");
        }  

        /// <summary>
        /// Create Work Order With Dept Req
        /// </summary>
        /// <param name="DeptNo"></param>
        /// <param name="DeptReqNo"></param>
        public void CreateWorkOrderWithDeptReq(string DeptNo, string DeptReqNo)
        {
            Settings.Logger.Info(" Creating Work order with dept req.");
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(CommonUtil.DataForKey(DeptNo), "Work order number");
            ClickOnWorkOrderBuild();
            _visitReq.SetText(DeptReqNo, "Dept req No");
            Driver.WaitForReady();
            _datetimeWOField.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            VerifyWorkorderNumber();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Enter And Delete Work Order
        /// </summary>
        public void EnterAndDeleteWorkOrder()
        {
            Settings.Logger.Info(" Entering Work order no ");
            SearchForWorkOrder();
            _lov.SearchAndSelectFirstRowData(WONumber);
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _woVisitInfoOpenDate.SendKeys(Keys.Tab);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleting existing workorder ");
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Proceed");
        }

        /// <summary>
        /// Verify Department WorkOrder
        /// </summary>
        public void VerifyDepartmentWorkOrder()
        {
            Settings.Logger.Info(" Verifying Department WorkOrder Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");
            Driver.WaitForReady();
            string ActualDeptNameValue = _unitNo.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqDeptNo), ActualDeptNameValue);
            string ActualDeptDescValue = _woDescription.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqDesc), ActualDeptDescValue);
            string ActualWOStatusValue = _workOrderStatus.GetElementValueByAttribute("ovalue");
            string DeptReqstatus = CommonUtil.DataForKey(DepartmentObjects.WoDeptReqStatus).ToUpper();
            CommonUtil.AssertTrue<string>(DeptReqstatus, ActualWOStatusValue);
            string ActualLocationValue = _woLocation.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(Settings.Location, ActualLocationValue);
            string ActualRequisitionValue = _reqN.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(DepartmentObjects.WoDeptReqNo, ActualRequisitionValue);
            Settings.Logger.Info(" Successfully Verified Department WorkOrder Information");
        }

        /// <summary>
        /// Close Work Order 
        /// </summary>
        public void CloseWorkOrder()
        {
            if (WONumber != null) { 
            Settings.Logger.Info(" Closing Department WorkOrder");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");             
            Driver.WaitForReady();
                if (_workOrderStatus.GetElementValueByAttribute("ovalue").ToUpper().Trim() != WorkOrderObjects.WorkOrderClosed)
                { 
                    _woVisitInfoCloseDate.SetText("Now", "Visit Information CLOSED Field");
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ActionRequiredWindow("Yes");
                    Driver.WaitForReady(); 
                    _extendedPage.ClicKSave();
                    Settings.Logger.Info($" Successfully Closed the  WorkOrder {WONumber}");
                }
            }          
        }

        /// <summary>
        /// Verify Work Order Status
        /// </summary>
        public void VerifyWorkOrderStatusAsClosed()
        {            
            Settings.Logger.Info(" Closing WorkOrder with Department Requision ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");
            Driver.WaitForReady();      
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqUpdatedStatus).ToUpper().Trim(), _workOrderStatus.GetElementValueByAttribute("ovalue").ToUpper().Trim());
            Driver.SwitchTo().DefaultContent();
        }           

        /// <summary>
        /// Add Non Stock Part Records
        /// </summary>
        /// <param name="RowCount"></param>
        /// <param name="DataObjectKey"></param>
        public void AddNonStockPartRecords(int RowCount, String DataObjectKey)
        {
            Settings.Logger.Info(" Adding Non Stock Part Information");
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            Settings.Logger.Info(" Added Stock Part Information ");
            ReloadWOAndMoveToNoNStockFrame();
            for (int i = 0; i < RowCount; i++)
            {
                AddAndVerifyNonStockPart(i, DataObject[i]);
            }
        }

        /// <summary>
        /// Add And Verify NonStock Part
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddAndVerifyNonStockPart(int RowNum,dynamic DataObject)
        {          
            if (DataObject != null)
            {
                _wnsPartJobCode = _extendedPage.GetInputElementAndSetValue($"{_wnspJoBCode}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject), "name");
                Driver.WaitForReady();
                _wnsPartNumber = _extendedPage.GetInputElementAndSetValue($"{_wnspPartNumber}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PartNo, DataObject));
                Driver.WaitForSomeTime();
                Driver.AcceptAlert();
                Driver.WaitForReady();
                _wnsPartVendor = _extendedPage.GetInputElementAndSetValue($"{_wnspVendor}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Vendor, DataObject));
                Driver.WaitForReady();
                _wnsPartEmpNo = _extendedPage.GetInputElementAndSetValue($"{_wnspEmpNo}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.EmployeeCode, DataObject));
                Driver.WaitForReady();
                _wnsPartQty = _extendedPage.GetInputElementAndSetValue($"{_wnspQty}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PartQty, DataObject));
                Driver.WaitForReady();
                _extendedPage.GetAndClickElement($"{_wnspPrintPartTag}{RowNum}");
                Driver.WaitForReady();
                _wnsPartFailCode = _extendedPage.GetInputElementAndSetValue($"{_wnspFailCode}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.FailCode, DataObject));
                Driver.WaitForReady();
                _wnsPartRefNo = _extendedPage.GetInputElementAndSetValue($"{_wnspRefNo}{RowNum}", Convert.ToString(CommonUtil.GenerateRandomIntValue()));
                Driver.WaitForReady();
                _wnsPartPRONumber = _extendedPage.GetInputElementAndSetValue($"{_wnspProNo}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PRONumber, DataObject));
                Driver.WaitForReady();
                _wnsPartEmpPosition = _extendedPage.GetInputElementAndSetValue($"{_wnspJobPosition}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Position, DataObject));
                Driver.WaitForReady();
                ReloadWOAndMoveToNoNStockFrame();
                VerifyNonStockPartInformation(0, DataObject);
            }
            else { Assert.Fail("Data not vailable for Non stock part "); }          
        }

        /// <summary>
        /// Verify Non Stock Part Information
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void VerifyNonStockPartInformation(int RowNum, dynamic DataObject)
        {
            Settings.Logger.Info(" verifying added non stock part information ");
            string PartJobCodeValue = _extendedPage.GetAttributeValueForInput($"{_wnspJoBCode}{RowNum}"); ;
            CommonUtil.AssertTrue<string>( CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject), PartJobCodeValue);
            string PartNumberValue = _extendedPage.GetAttributeValueForInput($"{_wnspPartNumber}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.PartNo, DataObject), PartNumberValue);
            string PartVendorValue = _extendedPage.GetAttributeValueForInput($"{_wnspVendor}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.Vendor, DataObject), PartVendorValue);
            string EmployeeNoValue = _extendedPage.GetAttributeValueForInput($"{_wnspEmpNo}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.EmployeeCode, DataObject), EmployeeNoValue);
            string PartQtyValue = _extendedPage.GetAttributeValueForInput($"{_wnspQty}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.PartQty, DataObject), PartQtyValue);
            string FailCodeValue = _extendedPage.GetAttributeValueForInput($"{_wnspFailCode}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.FailCode, DataObject), FailCodeValue);
            string PRONumberValue = _extendedPage.GetAttributeValueForInput($"{_wnspProNo}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.ExpectedPRONumber, DataObject), PRONumberValue);
            string PositionValue = _extendedPage.GetAttributeValueForInput($"{_wnspJobPosition}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.Position, DataObject), PositionValue);
            Settings.Logger.Info(" Successfully Verified  Non Stock Part Information");
        }

        /// <summary>
        /// Edit And Verify Non Stock Part Record
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObjectKey"></param>
        public void EditAndVerifyNonStockPartRecord(int RowNum, String DataObjectKey)
        {
            Settings.Logger.Info(" Edit And Verify Non Stock Part Record ");
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            if (DataObject != null)
            {            
            var EditData = DataObject[RowNum];
            _wnsPartVendor = null;
            _wnsPartPRONumber = null;
            Driver.WaitForReady();
            _wnsPartVendor = _extendedPage.GetInputElementAndSetValue($"{_wnspVendor}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Vendor, EditData));
            Driver.WaitForReady();
            _wnsPartPRONumber = _extendedPage.GetInputElementAndSetValue($"{_wnspProNo}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.PRONumber, EditData));
            Driver.WaitForReady();
            ReloadWOAndMoveToNoNStockFrame();
            VerifyNonStockPartInformation(0, EditData);
            }
            else{Assert.Fail("Data not vailable for Non stock part ");}
        }

        /// <summary>
        /// Delete Non Stock Part
        /// </summary>
        public void DeleteNonStockPart()
        {
            _wnsPartNumber=null;
            _wnsPartNumber=_extendedPage.GetAndClickElement($"{_wnspPartNumber}{0}");
            _wnsPartNumber.ClickElement("Part Number",Driver);
            _extendedPage.ClickDeleteAndVerifyDeletionMessage(_nonStockPartDeletetInfo);
            Settings.Logger.Info(" Successfully Deleted  Non Stock Part Information");
        }

        /// <summary>
        /// ReloadWO And MoveTo NoN Stock Part Frame
        /// </summary>
        private void ReloadWOAndMoveToNoNStockFrame()
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SaveAndReloadActionCode(_inputWorkOrderNo, WONumber);
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_nonStockPartframe, "NonStock  frame ");
        }

        /// <summary>
        /// Add Commercial Charge Records
        /// </summary>
        /// <param name="RowCount"></param>
        /// <param name="DataObjectKey"></param>
        public void AddCommercialChargeRecords(int RowCount, String DataObjectKey)
        {
            Settings.Logger.Info(" Adding Commercial Charge Information");
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.SwitchToFrame(_commframe, "Commercial frame ");

            for (int i = 0; i < RowCount; i++)
            {
                AddAndVerifyCommercialCharge(i, DataObject[i]);
            }
        }

        /// <summary>
        /// Add And Verify Commercia lCharge
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddAndVerifyCommercialCharge(int RowNum, dynamic DataObject)
        {
            if (DataObject != null)
            {
                _wnsPartJobCode = _extendedPage.GetInputElementAndSetValue($"{_wcJobCode}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject), "name");
                Driver.WaitForReady();
                _commvendorr = _extendedPage.GetInputElementAndSetValue($"{_wcvendor}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Vendor, DataObject));
                Driver.WaitForReady();
                _invnoValue = Convert.ToString(CommonUtil.GenerateRandomIntValue(1000, 9999));
                _commInvno = _extendedPage.GetInputElementAndSetValue($"{_wcinvno}{RowNum}", _invnoValue);
                _wclaborcostvalue = Convert.ToString(CommonUtil.GenerateRandomIntValue(10, 99));
                _commlaborcost = _extendedPage.GetInputElementAndSetValue($"{_wclaborcost}{RowNum}", _wclaborcostvalue);
                _wcpartcostValue = Convert.ToString(CommonUtil.GenerateRandomIntValue(10, 99));
                _commPartcost = _extendedPage.GetInputElementAndSetValue($"{_wcpartcost}{RowNum}", _wcpartcostValue);
                _wcmisccostValue = Convert.ToString(CommonUtil.GenerateRandomIntValue(10, 99));
                _commMisccost = _extendedPage.GetInputElementAndSetValue($"{_wcmisccost}{RowNum}", _wcmisccostValue);
                _wctaxValue = Convert.ToString(CommonUtil.GenerateRandomIntValue(10, 99));
                _commTax = _extendedPage.GetInputElementAndSetValue($"{_wctax}{RowNum}", _wctaxValue);
                _commPosition = _extendedPage.GetInputElementAndSetValue($"{_wcposition}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Position, DataObject));
                Driver.WaitForReady();
                _extendedPage.SaveAndChackWarning();
            }
            else { Assert.Fail("Data not vailable for Commercial charge  "); }
        }

        /// <summary>
        /// Verify Commercial Charge Information
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void VerifyCommercialChargeInformation(int RowNum,String DataObjectKey)
        {
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WONumber," Work Order ");
            Driver.WaitForReady();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.SwitchToFrame(_commframe, "Commercial frame ");
            var AddData = CommonUtil.DataObjectForKey(DataObjectKey);
            var DataObject = AddData[RowNum];
            if (DataObject != null)
            {                
            Settings.Logger.Info(" verifying added Commercial Charge information ");
            string ActualJobCodeValue = _extendedPage.GetAttributeValueForInput($"{_wcJobCode}{RowNum}"); ;
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject), ActualJobCodeValue);
            string ActaulVendorValue = _extendedPage.GetAttributeValueForInput($"{_wcvendor}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.Vendor, DataObject), ActaulVendorValue);
            string Actaulinvno = _extendedPage.GetAttributeValueForInput($"{_wcinvno}{RowNum}");
            CommonUtil.AssertTrue<string>(_invnoValue, Actaulinvno);
            string ActuallaborcostValue = _extendedPage.GetAttributeValueForInput($"{_wclaborcost}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wclaborcostvalue+".00", ActuallaborcostValue);
            string ActaulpartcostValue = _extendedPage.GetAttributeValueForInput($"{_wcpartcost}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wcpartcostValue+".00", ActaulpartcostValue);
            string ActaulMisccostValue = _extendedPage.GetAttributeValueForInput($"{_wcmisccost}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wcmisccostValue+".00", ActaulMisccostValue);
            string ActaulTaxValue = _extendedPage.GetAttributeValueForInput($"{_wctax}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wctaxValue+".00", ActaulTaxValue);
            string ActaulTotalValue = _extendedPage.GetAttributeValueForInput($"{_wctotal}{RowNum}");
            CommonUtil.AssertTrue<string>(GetTotalCommAmount(), ActaulTotalValue);
            string PositionValue = _extendedPage.GetAttributeValueForInput($"{_wcposition}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.Position, DataObject), PositionValue);
            Settings.Logger.Info(" Successfully Verified  Commercial Charge Information");
            }
            else { Assert.Fail("Data not vailable for Commercial charge part "); }
        }

        /// <summary>
        /// Get Total Comm Amount
        /// </summary>
        /// <returns></returns>
        public string GetTotalCommAmount()
        {
            int TotalValue = 0;
            TotalValue = int.Parse(_wclaborcostvalue) + int.Parse(_wcpartcostValue) + int.Parse(_wcmisccostValue) + int.Parse(_wctaxValue);
            string TotalValueString = "$" + Convert.ToString(TotalValue) + ".00";
            return TotalValueString;
        }

        /// <summary>
        /// Edit Commercial Charge Information
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObjectKey"></param>
        public void EditCommercialChargeInformation(int RowNum,string DataObjectKey)
        {
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            if (DataObject != null)
            {
                Settings.Logger.Info(" Editing and verifying Commercial Charge information ");
               ReloadWoAndMoveToCommFrame();
                Driver.WaitForSomeTime();
                _commvendorr = _extendedPage.GetInputElementAndSetValue($"{_wcvendor}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Vendor, DataObject[RowNum]));
                _commPosition = _extendedPage.GetInputElementAndSetValue($"{_wcposition}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.Position, DataObject[RowNum]));
                Driver.WaitForSomeTime();
                ReloadWoAndMoveToCommFrame();
                VerifyCommercialChargeInformation(0, DataObject[RowNum]);
            }        
        }

        /// <summary>
        /// Delete Commercial Charge Information
        /// </summary>
        public void DeleteCommercialChargeInformation()
        {
            _commvendorr = null;
            ReloadWoAndMoveToCommFrame();
            Driver.WaitForReady();
            _commvendorr = _extendedPage.GetAndClickElement($"{_wcvendor}{0}");
            _commvendorr.ClickElement("Vendor Number", Driver);
            _extendedPage.ClickDeleteAndVerifyDeletionMessage(_commChargetDeletetInfo);
            Settings.Logger.Info(" Successfully Deleted  Commercial Charge Information");
        }

        /// <summary>
        /// ReloadWo And Move To Comm Frame
        /// </summary>
        public void ReloadWoAndMoveToCommFrame()
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SaveAndReloadActionCode(_inputWorkOrderNo, WONumber);
            Driver.WaitForReady();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.SwitchToFrame(_commframe, "Commercial frame ");
        }

        /// <summary>
        /// Reload Wo And Move To Fluid Frame
        /// </summary>
        public void ReloadWoAndMoveToFluidFrame()
        {
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WONumber, " Work Order ");
            Driver.WaitForReady();
            _fluidtab.ClickElement("Fluid Tab ", Driver);
            Driver.SwitchToFrame(_fluidframe, "Fluid frame ");
        }

        /// <summary>
        /// Add Fluid Records
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void AddFluidRecords(string ObjectKey)
        {
            Settings.Logger.Info(" Adding Fluid Charge Information");
            FluidRecords FluidDetails = CommonUtil.DataObjectForKey(ObjectKey).ToObject<FluidRecords>();
            List<AddFluidRecord> FluidFieldsList = FluidDetails.AddFluidRecords;
            Settings.Logger.Info(" Adding Fluid Charge Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _fluidtab.ClickElement("Fuild Tab ", Driver);
            Driver.SwitchToFrame(_fluidframe, "fluid frame ");
            int i = 0;
            foreach(AddFluidRecord fluidList in FluidFieldsList)
            {
                AddFluidDetails(i, fluidList);
                i++;
            }
        }

        /// <summary>
        /// Add Fluid Details
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddFluidDetails(int RowNum, dynamic DataObject)
        {
            if (DataObject != null)
            {
                Settings.Logger.Info(" verifying added Fluid information ");
                _fluidJobCode = _extendedPage.GetInputElementAndSetValue($"{_wfJobCode}{RowNum}", DataObject.FluidJobCode, "name");
                Driver.WaitForReady();
                _fluidHose = _extendedPage.GetInputElementAndSetValue($"{_wfHose}{RowNum}", DataObject.HoseNo, "name");
                Driver.WaitForReady();
                _fluidQty = _extendedPage.GetInputElementAndSetValue($"{_wfQty}{RowNum}", DataObject.Quantity, "name");
                Driver.WaitForReady();
                _fluidEmpNo = _extendedPage.GetInputElementAndSetValue($"{_wfEmpNo}{RowNum}", DataObject.EmployeeCode, "name");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
            }
            else { Assert.Fail("Data not vailable for Commercial charge  "); }
        }

        /// <summary>
        /// Edit Fluid Records
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void EditFluidRecords(string ObjectKey)
        {
            int RowNum = 0;
            Settings.Logger.Info(" Editing Fluid Charge Information");
            FluidRecords FluidDetails = CommonUtil.DataObjectForKey(ObjectKey).ToObject<FluidRecords>();
            List<AddFluidRecord> FluidFieldsList = FluidDetails.AddFluidRecords;
            Settings.Logger.Info(" Adding Fluid Charge Information");
            Driver.SwitchTo().DefaultContent();
            ReloadWoAndMoveToFluidFrame();
            foreach (AddFluidRecord fluidList in FluidFieldsList)
            {
                _extendedPage.GetInputElementAndSetValue($"{_wfQty}{RowNum}", fluidList.Quantity, "name");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
                RowNum++;
            }
        }

        /// <summary>
        /// Verify Fluid Information
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void VerifyFluidInformation(string ObjectKey)
        {
            int RowNum = 0;
            FluidRecords FluidDetails = CommonUtil.DataObjectForKey(ObjectKey).ToObject<FluidRecords>();
            List<AddFluidRecord> FluidFieldsList = FluidDetails.AddFluidRecords;
            ReloadWoAndMoveToFluidFrame();
            foreach (AddFluidRecord fluidList in FluidFieldsList)
            {              
                string ActualJobCodeValue = _extendedPage.GetAttributeValueForInput($"{_wfJobCode}{RowNum}"); ;
                CommonUtil.AssertTrue<string>(fluidList.FluidJobCode, ActualJobCodeValue);
                string ActualHoseValue = _extendedPage.GetAttributeValueForInput($"{_wfHose}{RowNum}"); ;
                CommonUtil.AssertTrue<string>(fluidList.HoseNo, ActualHoseValue);
                string ActualQtyValue = _extendedPage.GetAttributeValueForInput($"{_wfQty}{RowNum}"); ;
                CommonUtil.AssertTrue<string>(fluidList.Quantity, ActualQtyValue);
                string ActualEmpNoValue = _extendedPage.GetAttributeValueForInput($"{_wfEmpNo}{RowNum}"); ;
                CommonUtil.AssertTrue<string>(fluidList.EmployeeCode, ActualEmpNoValue);
                RowNum++;
            }
            Settings.Logger.Info(" Successfully Verified  Fluid Charge Information");
        }

        /// <summary>
        /// Delete Fluid Information
        /// </summary>
        public void DeleteFluidInformation()
        {
            _fluidJobCode = null;
            Driver.SwitchTo().DefaultContent();
            ReloadWoAndMoveToFluidFrame();
            Driver.WaitForReady();
            _fluidJobCode = _extendedPage.GetAndClickElement($"{_wfJobCode}{0}");
            _fluidJobCode.ClickElement("Job code ", Driver);
            _extendedPage.ClickDeleteAndVerifyDeletionMessage(_fluidDeletetInfo);
            Settings.Logger.Info(" Successfully Deleted fluid Charge Information");
        }

        /// <summary>
        /// Create WorkOrder
        /// </summary>
        /// <param name="ActionValue"></param>
        public void CreateWorkOrder(string ActionValue)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(ActionValue, ActionValue);
            ClickOnWorkOrderBuild();
            Driver.WaitForReady();
            VisitRequestReason("0");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            VerifyWorkorderNumber();
            Settings.Logger.Info($"Created the  WorkOrder {WONumber}");
        }

        /// <summary>
        /// Open Exiting Work Order
        /// </summary>
        public void OpenExitingWorkOrder()
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Close Opened WorkOrder
        /// </summary>
        /// <param name="ActionValue"></param>
        public void CloseOpenedWorkOrder(string ActionValue)
        {
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(ActionValue, ActionValue);
            WONumber = _workOrderNumber.GetElementValueByAttribute("ovalue");
            if (WONumber != null)
            {
                Settings.Logger.Info(" Closing opened WorkOrder");
                Driver.WaitForReady();
                if (_workOrderStatus.GetElementValueByAttribute("ovalue").ToUpper().Trim() == WorkOrderObjects.WorkOrderOpen)
                {
                    CloseWorkOrder();
                    WONumber =null;
                }
            }
        }
    }
}
