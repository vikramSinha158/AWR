﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.TestAutomation.PagesObject;
using NUnit.Framework;
using OpenQA.Selenium;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class LoginPageActions: LoginPage
    {
        public LoginPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Login into application with default user name and password
        /// </summary>
        /// <returns></returns>
        public HomePageActions LoginM5()
        {
            try
            {
                Settings.Logger.Info("Login Page");
                _userName.SendKeys(Settings.UserName);
                Settings.Logger.Info($"Entering user name as '{Settings.UserName}'");
                _password.SendKeys(Settings.Password);
                Settings.Logger.Info($"Entering password name as '{Settings.Password}'");
                _location.SendKeys(Settings.Location);
                Settings.Logger.Info($"Clicking on loginButton");
                _loginButton.Click();
            }
            catch (NoSuchElementException ex)
            {
                Settings.Logger.Error($"M5 Application login not happened successfully");
                Assert.Fail(ex.Message);
            }
            return new HomePageActions(Driver);
        }

        /// <summary>
        /// Login into application with given user and password
        /// </summary>
        /// <param name="LoginUserName"></param>
        /// <param name="LoginPassword"></param>
        /// <returns></returns>
        public HomePageActions LoginM5(string LoginUserName, string LoginPassword)
        {
            try
            {
                Settings.Logger.Info("Login Page");
                _userName.SendKeys(LoginUserName);
                Settings.Logger.Info($"Entering user name as '{LoginUserName}'");
                _password.SendKeys(LoginPassword);
                Settings.Logger.Info($"Entering password as '{LoginPassword}'");
                Driver.WaitForClickable(_loginButton, "Login Button");            
                _loginButton.ClickElement("Login Button",Driver);
                Settings.Logger.Info($"Clicking on loginButton");
                Driver.WaitForReady();
            }
            catch (NoSuchElementException ex)
            {
                Settings.Logger.Error($"M5 Application login not happened successfully");
                Assert.Fail(ex.Message);
            }

            return new HomePageActions(Driver);
        }

        /// <summary>
        /// LogOff the application
        /// </summary>
        public void LoggOffApplication()
        {
            Settings.Logger.Info("Logoff the application");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForClickable(_loggOff, "LogOFF");
            _loggOff.Click();
        }
    }
}
