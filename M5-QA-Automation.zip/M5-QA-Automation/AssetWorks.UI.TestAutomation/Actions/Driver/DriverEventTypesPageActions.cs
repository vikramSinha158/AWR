﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverEventTypesPageActions : DriverEventTypesPage
    {
        public DriverEventTypesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Event Type
        /// </summary>
        /// <param name=""></param>
        public void CreateDriverEventType(DriverEventTypes DataObject)
        {
            var obj = DataObject.Notification_Frequency;
            _extendedPage.SwitchToContentFrame();
            _eventClassTxtBox.SetText(DataObject.Class, "Event Class");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            if (_tableEventType(DataObject.Code).Count > 0)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "DISABLED_FL").DeSelectCheckBox("Disabled");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, "", "EVENT_TYPE").SetText(DataObject.Code, "Driver Type code");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "Driver Type Description");
            Driver.WaitForReady();
            if (DataObject.Enquiry)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "EXP_NOTIF").SelectCheckBox("Expire Notification");
            Driver.WaitForReady();
            if (DataObject.Pre_Enquiry)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_NOTIF").SelectCheckBox("Pre-Expire Notification");
            Driver.WaitForReady();
            if (DataObject.Notification_Frequency != null)
            {
                var _frequencyList = new List<string>() { obj.One_week, obj.Two_Weeks, obj.Two_Months, obj.One_Month, obj.None };
                foreach (var notification in _frequencyList)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_FREQ").ClickDropDownValuebyContainingText(notification);
                    Driver.WaitForReady();
                }
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_FREQ").ClickDropDownValuebyContainingText(obj.None);
            }
            if (DataObject.Selected_Notification_Frequency != null && DataObject.Notification_Frequency.None != DataObject.Selected_Notification_Frequency)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_NOTIF").SelectCheckBox("Pre-Expire Notification");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_FREQ").ClickDropDownValuebyContainingText(DataObject.Selected_Notification_Frequency);
            }
            if (DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Created Driver Event Types
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverEventType(DriverEventTypes DataObjects)
        {
            _extendedPage.SwitchToContentFrame();
            _eventClassTxtBox.SetText(DataObjects.Class, "Event Class");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObjects.Code, "EVENT_TYPE"), "Event Code", DataObjects.Code, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObjects.Code, "DESCRIPTION"), "discription", DataObjects.Description, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObjects.Code, "PREEXP_FREQ"), "droupdown", DataObjects.Selected_Notification_Frequency, true);
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObjects.Code, "DISABLED_FL");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObjects.Disabled);
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObjects.Code, "EXP_NOTIF");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObjects.Enquiry);
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObjects.Code, "PREEXP_NOTIF");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObjects.Pre_Enquiry);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Driver Event Type
        /// </summary>
        /// <param name=""></param>
        public void UpdateDriverEventType(DriverEventTypes DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _eventClassTxtBox.SetText(DataObject.Class, "Event Class");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            if (DataObject.Description != null)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "Driver Type Description");
            Driver.WaitForReady();
            if (DataObject.Enquiry)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "EXP_NOTIF").SelectCheckBox("Expire Notification");
            Driver.WaitForReady();
            if (DataObject.Pre_Enquiry)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_NOTIF").SelectCheckBox("Pre-Expire Notification");
            Driver.WaitForReady();
            if (DataObject.Selected_Notification_Frequency != null && DataObject.Notification_Frequency.None != DataObject.Selected_Notification_Frequency)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_NOTIF").SelectCheckBox("Pre-Expire Notification");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "PREEXP_FREQ").ClickDropDownValuebyContainingText(DataObject.Selected_Notification_Frequency);
            }
            if (DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObject.Code, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }


        /// <summary>
        /// Delete Driver Event Types
        /// </summary>
        /// <param name=""></param>
        public void VerifyDeleteDriverEventType(DriverEventTypes DataObjects)
        {
            _extendedPage.RefreshAndSetText(_eventClassTxtBox, DataObjects.Class, "Event Class");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventTypesTable, _headerCode, DataObjects.Code, "EVENT_TYPE").Click();
            _extendedPage.DeleteAndSave();
            _eventClassTxtBox.SetText(DataObjects.Class, "Event Class");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverEventTypesTable, _headerCode, DataObjects.Code);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
