﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverAllocationReasonsPageActions : DriverAllocationReasonsPage
    {
        public DriverAllocationReasonsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Allocation Reason code
        /// </summary>
        /// <param name=""></param>
        public string CreateDriverAllocationReasonCode(AllocationReasonsType DataObject) 
        {
            _extendedPage.SwitchToTableFrame(_tableFrame);
            if (DataObject.Code == "random")
                DataObject.Code = CommonUtil.GetRandomStringWithSpecialChars(8);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, "", "ALLOC_REASON").SetText(DataObject.Code, "Status code");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
            Driver.WaitForReady();
            if(DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObject.Code, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            return DataObject.Code;
        }

        /// <summary>
        /// Verify Created Driver allocation reason code
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverAllocationReasonCode(AllocationReasonsType DataObjects)
        {
            _disabledCheckBox = null;
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            String StatusCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObjects.Code, "ALLOC_REASON").GetAttribute("value");
            CommonUtil.AssertTrue<string>(DataObjects.Code, StatusCode);
            String Description = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObjects.Code, "DESCRIPTION").GetAttribute("value");
            CommonUtil.AssertTrue<string>(DataObjects.Description, Description);
            if (DataObjects.Disabled)
            {
                _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObjects.Code, "DISABLED_FL");
                CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObjects.Disabled);
            }
        }

        /// <summary>
        /// Update Driver allocation reason code
        /// </summary>
        /// <param name=""></param>
        public void UpdateAllocationReasonCode(AllocationReasonsType DataObject)
        {
            if (!DataObject.Disabled)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObject.Code, "DISABLED_FL").DeSelectCheckBox("Disabled");
                Driver.WaitForReady();
               if(DataObject.Description != null)
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        ///<summary>
        ///Delete Create Driver Allocation Code
        ///</summary>
        ///<param name="DataObject"></param>
        public void VerifyDeletedAllocationReasonCode(AllocationReasonsType DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverAllocReasonsTable, _headerCode, DataObject.Code, "ALLOC_REASON").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverAllocReasonsTable, _headerCode, DataObject.Code);
        }
    }
}
