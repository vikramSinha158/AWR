﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverStatusCodePageActions : DriverStatusCodePage
    {
        public DriverStatusCodePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create status code
        /// </summary>
        /// <param name="DataObject"></param>
        public string CreateStatusCode(StatusCodeType DataObject) 
        {
            Settings.Logger.Info("Create Status Code");
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, "", "DRIVER_STATUS").SetText(DataObject.Code, "StatusCode");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
            Driver.WaitForReady();
            if (DataObject.Inactive)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "ACTIVE_DRIVER").SelectCheckBox("Inactive");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            return DataObject.Code;
        }


        /// <summary>
        /// Verify Created status code
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyStatusCode(StatusCodeType DataObject)
        {
            _inactiveCheckBox = null;
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            Driver.WaitForReady();
            String Code = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "DRIVER_STATUS").GetAttribute("value");
            CommonUtil.AssertTrue<string>(Code, DataObject.Code);
            if(DataObject.Description != null)
            {
                String Description = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "DESCRIPTION").GetAttribute("value");
                CommonUtil.AssertTrue<string>(Description, DataObject.Description);
            }
            if (DataObject.Inactive)
            {
                _inactiveCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "ACTIVE_DRIVER");
                CommonUtil.VerifyCheckboxState(_inactiveCheckBox, "Check box", DataObject.Inactive);
            }
            if (DataObject.Default)
            {
                _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "DISABLED_FL");
                CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObject.Default);
                bool InactiveCheckboxReadonly = Convert.ToBoolean(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "ACTIVE_DRIVER").GetAttribute("readonly"));
                CommonUtil.AssertTrue<bool>(DataObject.Inactive, InactiveCheckboxReadonly);
                bool DefaultCheckboxReadonly = Convert.ToBoolean( _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "DEFAULT_FL").GetAttribute("readonly"));
                CommonUtil.AssertTrue<bool>(DataObject.Default, DefaultCheckboxReadonly);
            }

            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update status code
        /// </summary>
        /// <param name="DataObject"></param>
        public void UpdateStatusCode(StatusCodeType DataObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            if(DataObject.Default)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Created status code
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDeleteStatusCode(StatusCodeType DataObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverStatusCodeTable, _headerCode, DataObject.Code, "DRIVER_STATUS").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverStatusCodeTable, _headerCode, DataObject.Code);
            Driver.WaitForReady();
        }
    }
}
