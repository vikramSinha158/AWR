﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverLicenceClassesPageActions : DriverLicenseClassesPage
    {
        public DriverLicenceClassesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Licence Class
        /// </summary>
        /// <param name=""></param>
        public void CreateDriverLicenceClasses(DriverLicenseClasses DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.Issuing_Authority, "Issue Authority");
            Driver.WaitForReady();
            _LicenceTypeTxtBox.SetText(DataObject.LicenceType, "Licence Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            if(_verifyLicenceClass(DataObject.Code).Count>0)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "DISABLED_FL").DeSelectCheckBox("Disabled");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, "", "LICENCE_CLASS").SetText(DataObject.Code, "Driver Licence Class");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "Driver Driscription");
            Driver.WaitForReady();
            if (DataObject.Restrictions != null)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "RESTRICTION").SetText(DataObject.Restrictions, "driver Restriction");
            Driver.WaitForReady();
            if (DataObject.Note != null)
            {
                _extendedPage.AddNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "Notes"), DataObject.Note);
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_tableFrame, "Table frame");
            }
            Driver.WaitForReady();
            if (DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Created Driver Licence Classes
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverLicenceClasses(DriverLicenseClasses DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.Issuing_Authority, "Issue Authority");
            Driver.WaitForReady();
            _LicenceTypeTxtBox.SetText(DataObject.LicenceType, "Licence Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "LICENCE_CLASS"), "Event Code", DataObject.Code, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "DESCRIPTION"), "Event Code", DataObject.Description, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "RESTRICTION"), "RESTRICTION", DataObject.Restrictions, false, "value");
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "DISABLED_FL");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObject.Disabled);
            if (DataObject.Note != null)
            {
                _extendedPage.VerifyAddedNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "Notes"), DataObject.Note);
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_tableFrame, "Table frame");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// update Driver Licence Class
        /// </summary>
        /// <param name=""></param>
        public void UpdateDriverLicenceClasses(DriverLicenseClasses DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.Issuing_Authority, "Issue Authority");
            Driver.WaitForReady();
            _LicenceTypeTxtBox.SetText(DataObject.LicenceType, "Licence Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            if (DataObject.Description != null)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "Driver Discription");
            Driver.WaitForReady();
            if (DataObject.Restrictions != null)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "RESTRICTION").SetText(DataObject.Restrictions, "driver Restriction");
            Driver.WaitForReady();
            if (DataObject.Note != null)
            {
                _extendedPage.AddNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "Notes"), DataObject.Note);
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_tableFrame, "Table frame");
            }
            Driver.WaitForReady();
            if (DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Delete Driver Licence Class
        /// </summary>
        /// <param name=""></param>
        public void VerifyDeleteDriverLicenceClasses(DriverLicenseClasses DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.Issuing_Authority, "Issue Authority");
            Driver.WaitForReady();
            _LicenceTypeTxtBox.SetText(DataObject.LicenceType, "Licence Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code, "LICENCE_CLASS").Click();
            _extendedPage.DeleteAndSave();
            _issuingAuthorityTxtBox.SetText(DataObject.Issuing_Authority, "Issue Authority");
            Driver.WaitForReady();
            _LicenceTypeTxtBox.SetText(DataObject.LicenceType, "Licence Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverLicenceClassesTable, _headerLicence, DataObject.Code);

        }
    }
}
