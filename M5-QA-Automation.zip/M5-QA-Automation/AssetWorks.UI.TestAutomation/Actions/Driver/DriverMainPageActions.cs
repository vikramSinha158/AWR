﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverMainPageActions : DriverMainPage
    {
        public DriverMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Main 
        /// </summary>
        /// <param name="DataObject"></param>
        public void CreateDriverMain(DriverMain DataObject) 
        {
            if (DataObject.Employee_ID == "random")
                DataObject.Employee_ID = CommonUtil.GetRandomStringWithSpecialChars(6);
            _inputEmployeeID.SetText(DataObject.Employee_ID, "Employee ID", Driver, _extendedPage._contentFrame, "content frame");
            Driver.WaitForReady();
            if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                _extendedPage.ClickOnDialogBoxButton("Create");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputEmployeeName.SetText(DataObject.Employee_Name,"Employee Name");
            Driver.WaitForReady();
            _inputEmployeeStatusDropdown.ClickDropDownValuebyContainingText(DataObject.Employee_Status);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            if (DataObject.GeneralTab != null)
                FillGenderalTabInfo(DataObject.GeneralTab);
            if (DataObject.LicenseTab != null)
                FillLicenseTabInfo(DataObject.LicenseTab, DataObject.Attachments);
            if (DataObject.MotorPoolTab != null)
                FillMotorPoolTab(DataObject.MotorPoolTab);
            if (DataObject.Attachments != null)
                FillAttachments(DataObject.Attachments);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            _extendedPage.ClickRefresh();
        }

        /// <summary>
        /// Filling Genderal Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillGenderalTabInfo(DriverMainGeneralInfo DataObject)
        {
            Settings.Logger.Info(" Fill Driver General Information");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("General").Click();
            Driver.WaitForReady();
            //Driver Information
            if (DataObject.DriverNumber == "random")
                DataObject.DriverNumber = Convert.ToString(CommonUtil.GenerateRandomDecimalNumber());
            _inputDriverNumber.SetText(DataObject.DriverNumber,"DriverNumber");
            Driver.WaitForReady();
            _inputTaxDropdown.ClickDropDownValuebyContainingText(DataObject.TaxFormOnFile);
            Driver.WaitForReady();
            _inputLicenceNo.SetText(DataObject.LicenseNo,"LicenceNumber");
            Driver.WaitForReady();
            _inputLicenceExpirtDate.SetText(DataObject.License_Expiry,"LicenceExpireDate");
            //General Infermation
            _inputHomeLocation.SetText(DataObject.Home_Location,"HomeLocation");
            Driver.WaitForReady();
            _inputDepartmentNo.SetText(DataObject.Department,"Department");
            Driver.WaitForReady();
            //Driver Code
            _inputDriverStatus.SetText(DataObject.Driver_Status,"DriverStatus");
            Driver.WaitForReady();
            _inputDriverType.SetText(DataObject.Driver_Type,"DriverType");
            Driver.WaitForReady();
            _inputDriverClass.SetText(DataObject.Driver_Class,"DriverClass");
            Driver.WaitForReady();
            //Shift Code
            _inputShiftCode.SetText(DataObject.Shift_Code,"ShiftCode");
            Driver.WaitForReady();
            if(DataObject.Shift_EffectiveDate != "Now")
                _inputShiftEffectDate.SetText(DataObject.Shift_EffectiveDate, "ShiftEffectDate");
            Driver.WaitForReady();
            //Driver Address
            _inputAddress.SetText(DataObject.Address, "Address");
            Driver.WaitForReady();
            _inputCity.SetText(DataObject.Town,"City/Town");
            Driver.WaitForReady();
            _inputState.SetText(DataObject.State, "State");
            Driver.WaitForReady();
            _inputZipCode.SetText(DataObject.Zip,"ZipCode");
            Driver.WaitForReady();
            _inputRegion.SetText(DataObject.Region, "Region");
            Driver.WaitForReady();
            _inputMunicipality.SetText(DataObject.Municipality,"Municipality");
            Driver.WaitForReady();
            _inputCounty.SetText(DataObject.Country,"County");
            Driver.WaitForReady();
            _inputPhoneNumber.SetText(DataObject.Telephone,"TelephoneNumber");
            Driver.WaitForReady();
            _inputMobileNumber.SetText(DataObject.Mobile,"MobileNumber");
            Driver.WaitForReady();
            _inputEmailAddress.SetText(DataObject.Email,"Email");
            //Driver Personal
            _inputDOB.SetText(DataObject.DOB,"DateOfBirth");
            Driver.WaitForReady();
            _inputBirthPlace.SetText(DataObject.PlaceOfBirth,"PlaceOfBirth");
            Driver.WaitForReady();
            _inputDateOfJoin.SetText(DataObject.DateOfJoined, "DateOfJoined");
            Driver.WaitForReady();
            _inputTaxRefarance.SetText(DataObject.Tax_Reference,"TaxRefeance");
            Driver.WaitForReady();
            _inputCallSign.SetText(DataObject.Call_Sign,"call sign");
            Driver.WaitForReady();
            _inputDriverReference.SetText(DataObject.Driver_Ref,"DriverReferance");
            _inputContactDetails.SetText(DataObject.Contact_Details,"contact");
            Driver.WaitForReady();
            _inputDriverPin.SetText(DataObject.Pin,"pin");
            //Driver Other
            _inputNextKin.SetText(DataObject.NextOfKin,"Next Kin");
            _inputKinContact.SetText(DataObject.Contact_Details,"contact");
            //Employee Note
            _inputNote.SetText(DataObject.Employee_Note,"Note");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
        }

        ///<summary>
        ///Fill license tab Info
        ///</summary>
        /// <param name="DataObjects"></param>
        public void FillLicenseTabInfo(DriverMainLicenseTab DataObject, DriverAttachments DataObjects)
        {
            Settings.Logger.Info(" Fill Driver License Tab Information");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("License").Click();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_iframeTableLicenseItem,"LicenseItems");
            Settings.Logger.Info(" Fill Driver License Items Table");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable,_headerAuthority,"", "dliISSUE_AUTH").SetText(DataObject.Authority, "Authority");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICENCE_TYPE").SetText(DataObject.Type, "Type");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliVALIDFROM_DT").SetText(DataObject.Valid_From, "Valid_From");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliEXPIRY_DT").SetText(DataObject.Expiry, "Expiry");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICENCE_NO").SetText(DataObject.LicenceNo, "LicenceNo");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICISS_NO").SetText(DataObject.Issue, "Issue");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliPASS_DT").SetText(DataObject.Passed, "Passed");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliRENEWAL_DT").SetText(DataObject.Renewal, "Renewal");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICSER_NO").SetText(DataObject.Serial_No, "Serial_No");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICREF_NO").SetText(DataObject.Ref_No, "Ref_No");
            Driver.WaitForReady();
            _extendedPage.AddNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLicNote"),DataObject.Note);
            Driver.WaitForReady();
            _extendedPage.ClicKSave();
            if (DataObject.licenseClasses != null)
                FillLicenseClasses(DataObject.licenseClasses);
        }

        public void FillLicenseClasses(LicenseClasses DataObject)
        {
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_iframeTableLicenseClasses, "LicenseClasses");
            Settings.Logger.Info(" Fill Driver License classes Table");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, "", "dlicLICENCE_CLASS").SetText(DataObject.Code, "Code");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicRESTRICTIONS").SetText(DataObject.Restrictions, "Restrictions");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicPERMITEXP_DT").SetText(DataObject.Permit_Exp, "Permit_Exp");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Motor Pool Tab
        /// </summary>
        /// <param name="DataObjects"></param>
        public void FillMotorPoolTab(DriverMainMotorPoolTab DataObject)
        {
            Driver.PageScrollUp();
            Settings.Logger.Info(" Fill Driver Motor Pool classes Table");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("Motor Pool Class").Click();
            Driver.WaitForReady();
            _restMPReservationCheckBox.SelectCheckBox("_restMPReservationCheckBox");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_iframeTableMotorPoolClasses, "Motor Pool");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverMotorPoolClassTable, _headerMotorPool, "", "empClass").SetText(DataObject.Motor_Pool_Class, "Motor_Pool_Class");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Attachments for Driver Main
        /// </summary>
        /// <param name="DataObjects"></param>
        public void FillAttachments(DriverAttachments DataObject)
        {
            Settings.Logger.Info(" Fill Driver Motor Pool classes Table");
            _attachButton.ClickElement("_attachButton",Driver);
            Driver.SwitchToFrame(_contentFrame2,"Content2");
            AddNewFile(DataObject);
            AddNewWebAddress(DataObject);
            AddExistingAttachment(DataObject);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Add New File Attachment
        /// </summary>
        /// <param name="NewFileData"></param>
        public void AddNewFile(DriverAttachments DataObject)
        {
            Driver.WaitForReady();
            _attachNewFile.Click();
            Driver.WaitForReady();
            _chooseFile.SendKeys(AppDomain.CurrentDomain.BaseDirectory + "\\TestData\\" + DataObject.InputFile);
            _FileDesc.SetText(DataObject.NewAttachment_Dec, "File Description");
            _attachNewFileBtn.ClickElement("Save File Button", Driver);
        }

        /// <summary>
        /// Attach New Web Address
        /// </summary>
        /// <param name="WebAddress"></param>
        public void AddNewWebAddress(DriverAttachments WebAddress)
        {
            _attachWebAddress.ClickElement("Attach Web Address Link", Driver);
            Driver.WaitForReady();
            _webAddress.SetText(WebAddress.WebAddress, "Web Address");
            Driver.WaitForReady();
            _webAddressDesc.SetText(WebAddress.WebAddress_Dec, "File Description");
            Driver.WaitForReady();
            _attachAddressBtn.ClickElement("Attach Address Button", Driver);
        }

        /// <summary>
        /// Attach Previously Uploaded File
        /// </summary>
        /// <param name="PreviouslyAttachedDoc"></param>
        public void AddExistingAttachment(DriverAttachments PreviouslyAttachedDoc)
        {
            _attachExistingFile.ClickElement("Attach previously Uploaded File Link", Driver);
            Driver.WaitForReady();
            if (string.IsNullOrEmpty(PreviouslyAttachedDoc.PreviouslyAttachedDoc))
            {
                Driver.DoubleClickWithJS(_previousUploadedFile, "File or Address");
                _lov.SearchAndSelectFirstRowData();
                Driver.SwitchTo().DefaultContent();
                Driver.SwitchToFrame(_contentFrame2, "");
            }
            else
            {
                _previousUploadedFile.SetText(PreviouslyAttachedDoc.PreviouslyAttachedDoc, "Web Address");
            }
            Driver.WaitForReady();
            _associateBtn.ClickElement("Associate Button", Driver);
        }

        /// <summary>
        /// Verify Created Driver Main
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyDriverMain(DriverMain DataObject)
        {
            Settings.Logger.Info(" Verify Driver Main Information");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputEmployeeID.SetText(DataObject.Employee_ID, "Employee ID");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputEmployeeName, "name", DataObject.Employee_Name);
            CommonUtil.VerifyElementValue(_inputEmployeeStatusDropdown, "Status", DataObject.Employee_Status, true);
            if (DataObject.GeneralTab != null)
                VerifyFillGenderalTabInfo(DataObject.GeneralTab);
            if (DataObject.LicenseTab != null)
                VerifyFillLicenseTabInfo(DataObject.LicenseTab);
            if (DataObject.MotorPoolTab != null)
                VerifyFillMotorPoolTab(DataObject.MotorPoolTab);
            if (DataObject.Attachments != null)
                VerifyAttachments(DataObject.Attachments);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify  Driver Attachments Tab
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyAttachments(DriverAttachments DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verify Driver Attachments Table");
            _attachButton.ClickElement("_attachButton", Driver);
            Driver.SwitchToFrame(_contentFrame2, "_contentFrame2");
            Driver.SwitchToFrame(_attachTableFrame, "_attachTableFrame");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_attachTable, "Command", "Open", "ATdesc"),"Attachment", DataObject.NewAttachment_Dec,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_attachTable, "Command", "Go", "ATdesc"), "Attachment", DataObject.WebAddress_Dec,false,"value");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Motor Pool Tab
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyFillMotorPoolTab(DriverMainMotorPoolTab DataObject)
        {
            Settings.Logger.Info("  Verify Fill Motor Pool classes Tab");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("Motor Pool Class").Click();
            CommonUtil.VerifyCheckboxState(_restMPReservationCheckBox, "_restMPReservationCheckBox", true);
            Driver.SwitchToFrame(_iframeTableMotorPoolClasses, "Motor Pool");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverMotorPoolClassTable, _headerMotorPool, DataObject.Motor_Pool_Class, "empClass"), "Motor_Pool_Class", DataObject.Motor_Pool_Class);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Filling Genderal Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyFillGenderalTabInfo(DriverMainGeneralInfo DataObject)
        {
            Settings.Logger.Info("Verify Fill Driver General Information");
            Driver.WaitForReady();
            //Driver Information
            CommonUtil.VerifyElementValue(_inputDriverNumber, "DriverNumber", DataObject.DriverNumber);
            CommonUtil.VerifyElementValue(_inputTaxDropdown, "TaxFormOnFile", DataObject.TaxFormOnFile,true);
            CommonUtil.VerifyElementValue(_inputLicenceNo, "LicenceNumber", DataObject.LicenseNo);
            CommonUtil.VerifyElementValueNotBlank(_inputLicenceExpirtDate, "LicenceExpireDate", true);
            //General Infermation
            CommonUtil.VerifyElementValue(_inputHomeLocation, "HomeLocation", DataObject.Home_Location);
            CommonUtil.VerifyElementValue(_inputDepartmentNo, "Department", DataObject.Department);
            //Driver Code
            CommonUtil.VerifyElementValue(_inputDriverStatus, "DriverStatus", DataObject.Driver_Status);
            CommonUtil.VerifyElementValue(_inputDriverType, "DriverType", DataObject.Driver_Type);
            CommonUtil.VerifyElementValue(_inputDriverClass, "DriverClass", DataObject.Driver_Class);
            //Shift Code
            CommonUtil.VerifyElementValue(_inputShiftCode, "ShiftCode", DataObject.Shift_Code);
            CommonUtil.VerifyElementValueNotBlank(_inputShiftEffectDate, "ShiftEffectDate", true);
            //Driver Address
            CommonUtil.VerifyElementValue(_inputAddress, "Address", DataObject.Address);
            CommonUtil.VerifyElementValue(_inputCity, "City/Town", DataObject.Town.ToUpper());
            CommonUtil.VerifyElementValue(_inputState, "State", DataObject.State);
            CommonUtil.VerifyElementValue(_inputZipCode, "ZipCode", DataObject.Zip);
            CommonUtil.VerifyElementValue(_inputRegion, "Region", DataObject.Region.ToUpper());
            CommonUtil.VerifyElementValue(_inputMunicipality, "Municipality", DataObject.Municipality.ToUpper());
            CommonUtil.VerifyElementValue(_inputCounty, "County", DataObject.Country.ToUpper());
            CommonUtil.VerifyElementValue(_inputPhoneNumber, "TelephoneNumber", DataObject.Telephone);
            CommonUtil.VerifyElementValue(_inputMobileNumber, "MobileNumber", DataObject.Mobile);
            CommonUtil.VerifyElementValue(_inputEmailAddress, "Email", DataObject.Email);
            //Driver Personal
            CommonUtil.VerifyElementValue(_inputDOB, "DateOfBirth", DataObject.DOB);
            CommonUtil.VerifyElementValue(_inputBirthPlace, "PlaceOfBirth", DataObject.PlaceOfBirth.ToUpper());
            CommonUtil.VerifyElementValue(_inputDateOfJoin, "DateOfJoined", DataObject.DateOfJoined);
            CommonUtil.VerifyElementValue(_inputTaxRefarance, "TaxRefeance", DataObject.Tax_Reference);
            CommonUtil.VerifyElementValue(_inputCallSign, "call sign", DataObject.Call_Sign);
            CommonUtil.VerifyElementValue(_inputDriverReference, "DriverReferance", DataObject.Driver_Ref);
            CommonUtil.VerifyElementValue(_inputContactDetails, "contact", DataObject.Contact_Details);
            CommonUtil.VerifyElementValue(_inputDriverPin, "pin", DataObject.Pin);
            //Driver Other
            CommonUtil.VerifyElementValue(_inputNextKin, "Next Kin", DataObject.NextOfKin);
            CommonUtil.VerifyElementValue(_inputKinContact, "contact", DataObject.Contact_Details);
            //Employee Note
            CommonUtil.VerifyElementValue(_inputNote, "Note", DataObject.Employee_Note);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Driver License Tab Info
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyFillLicenseTabInfo(DriverMainLicenseTab DataObject)
        {
            Settings.Logger.Info("Verify Fill Driver License Tab Information");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("License").Click();
            Driver.SwitchToFrame(_iframeTableLicenseItem, "LicenseItems");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliISSUE_AUTH"), "Authority", DataObject.Authority,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICENCE_TYPE"), "Type", DataObject.Type, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliVALIDFROM_DT"), "Valid_From", DataObject.Valid_From, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliEXPIRY_DT"), "Expiry", DataObject.Expiry, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICENCE_NO"), "LicenceNo", DataObject.LicenceNo, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICISS_NO"), "Issue", DataObject.Issue, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliPASS_DT"), "Passed", DataObject.Passed, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliRENEWAL_DT"), "Renewal", DataObject.Renewal, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICSER_NO"), "Serial_No", DataObject.Serial_No, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLICREF_NO"), "Ref_No", DataObject.Ref_No, false, "value");
            _extendedPage.VerifyAddedNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliLicNote"), DataObject.Note);
            if (DataObject.licenseClasses != null)
            {
                VerifyFillLicenseClasses(DataObject.licenseClasses);
            }
        }

        /// <summary>
        /// Verify Driver License Tab Info
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyFillLicenseClasses(LicenseClasses DataObject)
        {
            Settings.Logger.Info("Verify Fill Driver License Class Table Information");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_iframeTableLicenseClasses, "LicenseClasses");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicLICENCE_CLASS"), "Code", DataObject.Code, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicRESTRICTIONS"), "Restrictions", DataObject.Restrictions, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicPERMITEXP_DT"), "Permit_Exp", DataObject.Permit_Exp, false, "value");
            CommonUtil.VerifyElementValueNotBlank(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicDESCRIPTION"), "Description", true);
            CommonUtil.VerifyElementValueNotBlank(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicACQUIRED_DT"), "Acquired Date", true);
            CommonUtil.VerifyElementValueNotBlank(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.Code, "dlicVALIDTO_DT"), "Valid To", true);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Created Driver Main
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyDeleteDriverMain(DriverMain DataObject)
        {
            Settings.Logger.Info(" Verify Delete Driver Main Information");
            _extendedPage.RefreshAndSetText(_inputEmployeeID, DataObject.Employee_ID, "Employee ID");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            if (DataObject.LicenseTab != null)
                DeleteDriverLicenseTabInfo(DataObject.LicenseTab);
            if (DataObject.MotorPoolTab != null)
                DeleteDriverMotorPoolTabInfo(DataObject.MotorPoolTab);
            if (DataObject.Attachments != null)
                DeleteAttachments(DataObject.Attachments);
            _extendedPage.RefreshAndSetText(_inputEmployeeID, DataObject.Employee_ID, "Employee ID");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.WaitForReady();
            if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                _extendedPage.ClickOnDialogBoxButton("Delete");
            VerifyDriverDoesNotExist(DataObject.Employee_ID);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Driver main Does Not Exist
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverDoesNotExist(string Employee_ID)
        {
            Settings.Logger.Info("Verifying Driver main Does Not Exist ");
            Driver.WaitForReady();
            _inputEmployeeID.SetText(Employee_ID, "Employee ID", Driver, _extendedPage._contentFrame, "content frame");
            Driver.WaitForReady();
            _dialogTitle.VerifyElementDisplay(" Dialog title ");
            string txt = _dialogTitle.Text;
            Assert.IsTrue(txt.Contains(Employee_ID.ToUpper()));
            _extendedPage.ClickOnDialogBoxButton("Cancel");
        }

        /// <summary>
        /// Delete Licence Tab info
        /// </summary>
        /// <param name="DataObjects"></param>
        public void DeleteDriverLicenseTabInfo(DriverMainLicenseTab DataObject)
        {
            Settings.Logger.Info("Delete Driver Main License Tab Information");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("License").Click();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_iframeTableLicenseItem, "LicenseItems");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliISSUE_AUTH").Click();
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_iframeTableLicenseClasses, "LicenseClasses");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseClassesTable, _headerCode, DataObject.licenseClasses.Code, "dlicLICENCE_CLASS").Click();
            _extendedPage.DeleteAndSave();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_iframeTableLicenseItem, "LicenseItems");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenseItemTable, _headerAuthority, DataObject.Authority, "dliISSUE_AUTH").Click();
            _extendedPage.DeleteAndSave();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
        }

        /// <summary>
        /// Delete Licence Tab info
        /// </summary>
        /// <param name="DataObjects"></param>
        public void DeleteDriverMotorPoolTabInfo(DriverMainMotorPoolTab DataObject)
        {
            Settings.Logger.Info("Delete Driver Main Motor Tab Information");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("Motor Pool Class").Click();
            Driver.SwitchToFrame(_iframeTableMotorPoolClasses, "Motor Pool");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverMotorPoolClassTable, _headerMotorPool, DataObject.Motor_Pool_Class, "empClass").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Driver Attachments
        /// </summary>
        /// <param name="DataObjects"></param>
        public void DeleteAttachments(DriverAttachments DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verify Driver Attachments Table");
            _attachButton.ClickElement("_attachButton", Driver);
            Driver.SwitchToFrame(_contentFrame2, "_contentFrame2");
            Driver.SwitchToFrame(_attachTableFrame, "_attachTableFrame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_attachTable, "Command", "Open", "ATdesc").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClicKSave();
            Driver.SwitchToFrame(_contentFrame2, "_contentFrame2");
            Driver.SwitchToFrame(_attachTableFrame, "_attachTableFrame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_attachTable, "Command", "Go", "ATdesc").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClicKSave();
            Driver.SwitchToFrame(_contentFrame2, "_contentFrame2");
            Driver.SwitchToFrame(_attachTableFrame, "_attachTableFrame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_attachTable, "Command", "Open", "ATdesc").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
        }
    }
}
