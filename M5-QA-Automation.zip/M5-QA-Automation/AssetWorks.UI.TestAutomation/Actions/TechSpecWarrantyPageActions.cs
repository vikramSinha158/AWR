﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class TechSpecWarrantyPageActions : TechSpecWarrantyPage
    {
        public TechSpecWarrantyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Warranty TechSpec
        /// </summary>
        /// <param name="WarrantyTechSpec"></param>
        public void CreateWarrantyTechSpec(WarrantyTechSpec WarrantyTechSpec)
        {          
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            if (WarrantyTechSpec.TechSpecNo == null)
                WarrantyTechSpec.TechSpecNo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
            _warrantyTechSpecInput.SetText(WarrantyTechSpec.TechSpecNo, "Warranty Tech Spec");
            if (WarrantyTechSpec.WholeUnitTab != null)
            {
                FillWholeUnit(WarrantyTechSpec.WholeUnitTab);
            }
            if (WarrantyTechSpec.WarrantySubUnitTab != null)
            {
                FillWarrantySubUnitTab(WarrantyTechSpec.WarrantySubUnitTab);
            }
            if (WarrantyTechSpec.WarrantyPartTab != null)
            {
                FillWarrantyPartTab(WarrantyTechSpec.WarrantyPartTab);
            }
            Settings.Logger.Info("Created Warranty TechSpec");
        }

        /// <summary>
        /// Fill Whole Unit
        /// </summary>
        /// <param name="WholeUnitTab"></param>
        public void FillWholeUnit(WholeUnitTab WholeUnitTab)
        {
            _wholeUnitTab.ClickElement("wholeUnitTab",Driver);
            _extendpage.SelectAllAndClearField(_vendorNoInput);
            Driver.WaitForReady();
            _vendorNoInput.SetText(WholeUnitTab.VendorNo, "VendorNo");
            _extendpage.SelectAllAndClearField(_usageInput);
            Driver.WaitForReady();
            _usageInput.SetText(WholeUnitTab.Usage, "Usage");
            Driver.WaitForReady();
            _meterType.ClickDropDownValuebyContainingText(WholeUnitTab.MeterType);
            _extendpage.SelectAllAndClearField(_elapsedTimeInput);
            Driver.WaitForReady();
            _elapsedTimeInput.SetText(WholeUnitTab.ElapsedTime, "ElapsedTime");
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Warranty SubUnit Tab
        /// </summary>
        /// <param name="WarrantySubUnitTab"></param>
        public void FillWarrantySubUnitTab(WarrantySubUnitTab WarrantySubUnitTab)
        {
            _extendpage.SwitchToContentFrameAndTabClick(_warrantySubUnitTab);
            if (WarrantySubUnitTab.FillWarrantyTechSpecSubUnitTable)
            {
                _extendpage.AddRecordsInTable(_specWarrTable, _specWarrFrame, WarrantySubUnitTab.SubUnitTableKey);
                _extendpage.Save();
            }
        }

        /// <summary>
        /// Fill Warranty Part Tab
        /// </summary>
        /// <param name="WarrantyPartTab"></param>
        public void FillWarrantyPartTab(WarrantyPartTab WarrantyPartTab)
        {
            _extendpage.SwitchToContentFrameAndTabClick(_warrantyPartTab);
            if (WarrantyPartTab.FillWarrantyTechSpecPartTable)
            {
                _extendpage.AddRecordsInTable(_specPartWarrTable, _specPartWarrFrame, WarrantyPartTab.PartTableKey);
                _extendpage.Save();
            }
        }

        /// <summary>
        /// Verify Warranty TechSpec
        /// </summary>
        /// <param name="WarrantyTechSpec"></param>
        public void VerifyWarrantyTechSpec(WarrantyTechSpec WarrantyTechSpec)
        {           
            _extendpage.RefreshAndSetText(_warrantyTechSpecInput, WarrantyTechSpec.TechSpecNo, " TechSpecNo ");
            if (WarrantyTechSpec.WholeUnitTab != null)
            {
                VerifyWholeUnit(WarrantyTechSpec.WholeUnitTab);
            }
            if (WarrantyTechSpec.WarrantyPartTab != null)
            {
                _warrantyPartTab.ClickElement("warrantyPartTab", Driver);
                _extendpage.VerifyRecordsInTable(_specPartWarrTable, _specPartWarrFrame, WarrantyTechSpec.WarrantyPartTab.PartTableKey);
            }
            if (WarrantyTechSpec.WarrantySubUnitTab != null)
            {
                _warrantySubUnitTab.ClickElement("warrantySubUnitTab", Driver);
                _extendpage.VerifyRecordsInTable(_specWarrTable, _specWarrFrame, WarrantyTechSpec.WarrantySubUnitTab.VerifySubUnitTableKey);
            }
            Settings.Logger.Info(" Successfully Verified Warranty Tech Spec");
        }

        /// <summary>
        /// Delete Warranty TechSpec
        /// </summary>
        /// <param name="WarrantyTechSpec"></param>
        public void DeleteWarrantyTechSpec(WarrantyTechSpec WarrantyTechSpec)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_warrantyTechSpecInput, WarrantyTechSpec.TechSpecNo, " TechSpecNo ");          
            if (WarrantyTechSpec.WarrantySubUnitTab != null)
            {
                _warrantySubUnitTab.ClickElement("warrantySubUnitTab", Driver);
                _extendpage.DeleteRecordsFromTable(_specWarrTable, _specWarrFrame, WarrantyTechSpec.WarrantySubUnitTab.SubUnitTableKey);
            }
            if (WarrantyTechSpec.WarrantyPartTab != null)
            {
                _warrantyPartTab.ClickElement("warrantyPartTab", Driver);
                _extendpage.DeleteRecordsFromTable(_specPartWarrTable, _specPartWarrFrame, WarrantyTechSpec.WarrantyPartTab.PartTableKey);
            }
            Settings.Logger.Info("deleted Warranty Tech Spec");
        }

        /// <summary>
        /// Verify Delete Warranty TechSpec
        /// </summary>
        /// <param name="WarrantyTechSpec"></param>
        public void VerifyDeleteWarrantyTechSpec(WarrantyTechSpec WarrantyTechSpec)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_warrantyTechSpecInput, WarrantyTechSpec.TechSpecNo, " TechSpecNo ");
            if (WarrantyTechSpec.WarrantySubUnitTab != null)
            {
                _warrantySubUnitTab.ClickElement("warrantySubUnitTab", Driver);
                _extendpage.VerifyRecordDeletionFromTable(_specWarrTable, _specWarrFrame, WarrantyTechSpec.WarrantySubUnitTab.SubUnitTableKey);
            }
            if (WarrantyTechSpec.WarrantyPartTab != null)
            {
                _warrantyPartTab.ClickElement("warrantyPartTab", Driver);
                _extendpage.VerifyRecordDeletionFromTable(_specPartWarrTable, _specPartWarrFrame, WarrantyTechSpec.WarrantyPartTab.PartTableKey);
            }
            Settings.Logger.Info(" Successfully Verified deletion  Warranty Tech Spec");
        }

        /// <summary>
        /// Verify Whole Unit
        /// </summary>
        /// <param name="WholeUnitTab"></param>
        public void VerifyWholeUnit(WholeUnitTab WholeUnitTab)
        {
            _wholeUnitTab.ClickElement("wholeUnitTab", Driver);
            CommonUtil.VerifyElementValue(_vendorNoInput, "vendorNoInput", WholeUnitTab.VendorNo);     
            CommonUtil.VerifyElementValue(_usageInput, "Usage", WholeUnitTab.Usage);
            CommonUtil.VerifyElementValue(_meterType, "MeterType", WholeUnitTab.MeterType,true);
            CommonUtil.VerifyElementValue(_elapsedTimeInput, "ElapsedTime", WholeUnitTab.ElapsedTime);
        }
    }
 
}
