﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Equipment
{
    internal class EquipmentTypesSKUPageActions : EquipmentTypesSKUPage
    {
        public EquipmentTypesSKUPageActions(IWebDriver Driver) : base(Driver) { }
        public string CreateNewEquipmentType(EquipmentTypeSKU EquipmentTypeObject)
        {
            if (EquipmentTypeObject.EquipmentTypeNo == null)
                EquipmentTypeObject.EquipmentTypeNo = "random";
            string EquipTypeNo = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(EquipmentTypeObject.EquipmentTypeNo, ref EquipTypeNo, "EquipTypeQuery"))
            {
                Settings.Logger.Info($" Create a new Equipment Type: {EquipTypeNo} ");
                EquipmentTypeObject.EquipmentTypeNo = EquipTypeNo.ToUpper();
                _inputEquipmentType.SetText(EquipmentTypeObject.EquipmentTypeNo, "Equipment Type", Driver, _extendedPage._contentFrame, "content frame");
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                _inputDescription.SetText(EquipmentTypeObject.Description, "Description", Driver, _extendedPage._contentFrame, "content frame");
                _extendedPage.ClickOnSaveButton();
                if (EquipmentTypeObject.EquipmentTypes != null)
                {
                    _extendedPage.SwitchToContentFrame();
                    _inputDescription.SendKeys(Keys.Tab);
                    Driver.SwitchToFrame(_frameEquipmentTypes, "Table frame");
                    Driver.WaitForReady();
                    _inputNewSKU.SetText(EquipmentTypeObject.EquipmentTypes.SKU, "SKU");
                    Driver.WaitForReady();
                    _inputNewSKUDescription.SetText(EquipmentTypeObject.EquipmentTypes.SKUDesc, "SKU Description");
                    Driver.WaitForReady();
                    if (EquipmentTypeObject.EquipmentTypes.IsSerial)
                        _checkboxNewSKUSerial.Click();
                    if (EquipmentTypeObject.EquipmentTypes.Disabled)
                        _checkboxNewSKUDisabled.Click();
                    Driver.SwitchTo().DefaultContent();
                }
                _extendedPage.VerifyCreatedActionNumber(_inputEquipmentType, EquipmentTypeObject.EquipmentTypeNo);
            }
                return EquipmentTypeObject.EquipmentTypeNo;
        }

        public void VerifyEquipmentTypeInfo(EquipmentTypeSKU EquipmentTypeObject)
        {
            Settings.Logger.Info(" Verify Equipment Type ");
            _extendedPage.RefreshAndSetText(_inputEquipmentType, EquipmentTypeObject.EquipmentTypeNo, "Equipment Type");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputDescription, "Description", EquipmentTypeObject.Description);          
           if (EquipmentTypeObject.EquipmentTypes != null)
            {
                Driver.SwitchToFrame(_frameEquipmentTypes, "Table frame");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
                    EquipmentTypeObject.EquipmentTypes.SKU, "SKU"), "SKU", EquipmentTypeObject.EquipmentTypes.SKU, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
                   EquipmentTypeObject.EquipmentTypes.SKU, "SKU_DESCRIPTION"), "SKU Description", EquipmentTypeObject.EquipmentTypes.SKUDesc, false, "value");
                CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
                 EquipmentTypeObject.EquipmentTypes.SKU, "SERIAL_NUMBER_REQ_FL"), "Serial Checkbox", EquipmentTypeObject.EquipmentTypes.IsSerial);
                CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
                EquipmentTypeObject.EquipmentTypes.SKU, "DISABLED_FL"), "Disabled Checkbox", EquipmentTypeObject.EquipmentTypes.Disabled);
            }
            Driver.SwitchTo().DefaultContent();
        }



    }
}
