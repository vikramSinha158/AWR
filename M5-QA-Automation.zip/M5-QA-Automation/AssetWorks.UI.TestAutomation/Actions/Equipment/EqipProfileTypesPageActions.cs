﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using System;


namespace AssetWorks.UI.M5.TestAutomation.Actions
    {
        internal class EqipProfileTypesPageActions : EquipProfileTypesMainPage
        {
        
        public EqipProfileTypesPageActions(IWebDriver Driver) : base(Driver) { }

        string EquipCode = string.Empty;
        string EquipDesc = string.Empty;

        /// <summary>
        /// Create New Equipment Profilr Type Record
        /// </summary>
        /// <param name="Datakey"></param>       
        public string CreateEquipmentProfileType(AddRecords Datakey, AddRecords DummyKey)
        {     
            _extendPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameEquipProfileType, "Table frame");
            Settings.Logger.Info("Creating Equipment Profile Type");
            if (GetTotalTableRecords() == 0)
            {             
                EquipCode = DummyKey.ECode == "random" ? CommonUtil.GetRandomStringWithSpecialChars(3) : DummyKey.ECode;
                _inputNewCode.SetText(EquipCode, "New code");
                _inputNewDesc.SetText(DummyKey.EDescription, "New code desc");
                _ckbNewDefault.SelectCheckBox("Default", DummyKey.Default);
                _ckbNewDisabled.SelectCheckBox("Default", DummyKey.Disabled);
                Driver.SwitchTo().DefaultContent();
                _extendPage.ClicKSave();
                _extendPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameEquipProfileType, "Table frame");
            }            
            FillEquipmentData(Datakey);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClicKSave();
            EquipProfileTypesMainPage.ECode = EquipCode;
            EquipProfileTypesMainPage.EDescription = EquipDesc;
            return EquipCode;
        }

        /// <summary>
        /// Fill Equiment Profile Type Data
        /// </summary>
        /// <param name="Datakey"></param>
        public void FillEquipmentData(AddRecords DataObject)
        {           
            EquipCode = DataObject.ECode == "random" ? CommonUtil.GetRandomStringWithSpecialChars(3) : DataObject.ECode;
            _inputNewCode.SetText(EquipCode, "New code");
            _inputNewDesc.SetText(DataObject.EDescription, "New code desc");            
            _ckbNewDefault.SelectCheckBox("Default", DataObject.Default);
            if (DataObject.Disabled)
                _ckbNewDisabled.SelectCheckBox("Disabled", DataObject.Disabled);
            else
                _ckbNewDisabled.DeSelectCheckBox("Deselecting Disabled CheckBox");
        }

        /// <summary>
        /// Get Total Equipment Profile Type Records
        /// </summary>
        /// <returns></returns>
        public int GetTotalTableRecords()
        {
            return _tablerows.Count - 1;
        }

        /// <summary>
        /// Verify the Equipment Profile Type Record Data
        /// </summary>
        /// <param name="Datavalue"></param>
        /// <param name="code"></param>
        public void VerifyEquipmentRecord(AddRecords Datavalue,string code)
        {           
            RefreshAndSwitchToTable();          
            bool flagDefault=false;
            bool flagDiabled = false;           
            string ActualDesc = _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipProfileType, "Code", code, "desc").GetAttribute("value");
            CommonUtil.AssertTrue<string>(Datavalue.EDescription, ActualDesc);            
            string ActualStateDefaultCkb = _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipProfileType, "Code", code, "default").GetAttribute("value");
            flagDefault = ActualStateDefaultCkb == "Y" ? true : false;                  
            CommonUtil.AssertTrue<bool>(Datavalue.Default, flagDefault);
            string ActualStateDisabledCkb = _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipProfileType, "Code", code, "disabled").GetAttribute("value");
            flagDiabled = ActualStateDisabledCkb == "Y" ? true : false;
            CommonUtil.AssertTrue<bool>(Datavalue.Disabled, flagDiabled);
        }

        /// <summary>
        /// Edit Equiment profile Type Record
        /// </summary>
        /// <param name="DataKey"></param>
        /// <param name="CodeVal"></param>
        public void EditEquipmentRecord(AddRecords DataObject, string CodeVal)
        {           
            Driver.SwitchTo().DefaultContent();
            RefreshAndSwitchToTable();            
            Settings.Logger.Info("Update Equipment Profile Record for : " + CodeVal);
            _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipProfileType,
                "Code", CodeVal, "desc").SetText(DataObject.EDescription, "Code Description");
            _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipProfileType,               
               "Code", CodeVal, "default").SelectCheckBox("Default Checkbox", DataObject.Default);
            _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipProfileType,
              "Code", CodeVal, "disabled").SelectCheckBox("Disabled Checkbox", DataObject.Disabled); 
            if(!DataObject.Disabled)
                _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipProfileType,
             "Code", CodeVal, "disabled").DeSelectCheckBox("Disabled Checkbox");
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();           
            
        }

        /// <summary>
        /// Delete Equiment Profile Type Record
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteEquipmentProfileType(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            RefreshAndSwitchToTable();           
            Settings.Logger.Info("Deleting Equipment Profile Type : " + CodeVal);
            _extendPage.GetTableActionElementByRelatedColumnValue(
           _tableEquipProfileType, "Code", CodeVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnDeleteButton();
            _extendPage.ClickOnSaveButton();
        }


        /// <summary>
        /// Verify Equiment Profile Type Record Deletion
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedEquipmentProfileType(string CodeVal)
        {
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Verify Equiment Profile Type is Deleted for : " + CodeVal);
            _extendPage.VerifyTableColumnDoesNotContainValue(_tableEquipProfileType, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Refresh And Switch To Table Frame
        /// </summary>
        public void RefreshAndSwitchToTable()
        {
            _extendPage.ClickOnRefreshButton();
            _extendPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameEquipProfileType, "Table frame");
        }




    }
    }   
