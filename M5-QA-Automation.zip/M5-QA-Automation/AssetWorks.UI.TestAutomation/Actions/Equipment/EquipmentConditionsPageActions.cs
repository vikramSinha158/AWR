﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Equipment
{
    internal class EquipmentConditionsPageActions : EquipmentConditionsPage
    {
        public EquipmentConditionsPageActions(IWebDriver Driver) : base(Driver) { }

        EquipmentCondition equipCondition = new EquipmentCondition();

        /// <summary>
        /// Create New Equipment Condition
        /// </summary>
        /// <param name="Code"></param>
        /// <returns></returns>
        public string CreateNewEquipmentCondition(string Code = "random")
        {
            Settings.Logger.Info(" Create new Equipment Condition ");
            if (Code.ToLower().Equals("random"))
                equipCondition.Code = CommonUtil.GetRandomStringWithSpecialChars(5).ToUpper();
            else
                equipCondition.Code = Code.ToUpper();
            equipCondition.Description = CommonUtil.DataObjectForKey("Description").ToString().ToUpper() + equipCondition.Code;
            _extendedPage.SwitchToTableFrame(_frameEquipmentConditions);
            _inputNewCode.SetText(equipCondition.Code, "Code");
            _inputNewDescription.SetText(equipCondition.Description, "Description");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameEquipmentConditions);
            string _desc = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions,
                "Code", equipCondition.Code, "DESCRIPTION").GetElementValueByAttribute("value");
            CommonUtil.AssertTrue<string>(equipCondition.Description, _desc);
            Driver.SwitchTo().DefaultContent();
            return equipCondition.Code;
        }

        /// <summary>
        /// Update Equipment Condition
        /// </summary>
        /// <param name="Code"></param>
        /// <param name="DataKey"></param>
        public void UpdateEquipmentCondition(string Code, string DataKey)
        {
            Settings.Logger.Info(" Update Equipment Condition ");
            equipCondition = CommonUtil.DataObjectForKey(DataKey).ToObject<EquipmentCondition>();
            _extendedPage.SwitchToTableFrame(_frameEquipmentConditions);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                Code, "DESCRIPTION").SetText(equipCondition.Description, "Description");
            Driver.WaitForReady();
            if (equipCondition.DisallowCheckOut == "true")
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                    Code, "DISALLOW_CHECKOUT_FL").Click();
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                Code, "JobCode").SetText(equipCondition.JobCode, "Job Code");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                Code, "JobRsn").SetText(equipCondition.JobReason, "Job Reason");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                Code, "JobPriority").SetText(equipCondition.JobPriority, "Job Priority");
            if (equipCondition.Disabled == "true")
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                    Code, "DISABLED_FL").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Equipment Condition
        /// </summary>
        /// <param name="Code"></param>
        /// <param name="DataKey"></param>
        public void VerifyEquipmentCondition(string Code, string DataKey)
        {
            Settings.Logger.Info(" Verify Equipment Condition ");
            equipCondition = CommonUtil.DataObjectForKey(DataKey).ToObject<EquipmentCondition>();
            _extendedPage.SwitchToTableFrame(_frameEquipmentConditions);
            if (equipCondition.Description != null)
            {
                string actualDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions,
                    "Code", Code, "DESCRIPTION").GetElementValueByAttribute("value");
                CommonUtil.AssertTrue<string>(equipCondition.Description, actualDesc);
            }
            if (equipCondition.DisallowCheckOut != null)
            {
                string actualDisFlag = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                    Code, "DISALLOW_CHECKOUT_FL").GetElementValueByAttribute("checked");
                CommonUtil.AssertTrue<string>(equipCondition.DisallowCheckOut, actualDisFlag);
            }
            if (equipCondition.JobCode != null)
            {
                string actualJobCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, 
                    "Code" ,Code, "JobCode").GetElementValueByAttribute("value");
                CommonUtil.AssertTrue<string>(equipCondition.JobCode, actualJobCode);
            }
            if (equipCondition.JobReason != null)
            {
                string actualJobReason = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, 
                    "Code", Code, "JobRsn").GetElementValueByAttribute("value");
                CommonUtil.AssertTrue<string>(equipCondition.JobReason, actualJobReason);
            }
            if (equipCondition.JobPriority != null)
            {
                string actualJobPriority = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions,
                    "Code", Code, "JobPriority").GetElementValueByAttribute("value");
                CommonUtil.AssertTrue<string>(equipCondition.JobPriority, actualJobPriority);
            }
            if (equipCondition.Disabled != null)
            {
                string actualDisabled = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, "Code",
                    Code, "DISABLED_FL").GetElementValueByAttribute("checked");
                CommonUtil.AssertTrue<string>(equipCondition.Disabled, actualDisabled);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Equipment Condition
        /// </summary>
        /// <param name="Code"></param>
        public void DeleteEquipmentCondition(string Code)
        {
            Settings.Logger.Info(" Delete Equipment Condition ");
            _extendedPage.SwitchToTableFrame(_frameEquipmentConditions);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentConditions, 
                "Code", Code, "DESCRIPTION").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameEquipmentConditions);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableEquipmentConditions, "Code", Code);
        }
    }
}
