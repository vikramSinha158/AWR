﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects.Equipment;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Equipment
    {
        internal class EqipRetReasonsPageActions : EquipRetReasonsPage
        {
        
        public EqipRetReasonsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Equipment Return Reason
        /// </summary>
        /// <param name="ReasonsData"></param>
        /// <returns></returns>        
        public List<EquipmentReturnReasons> CreateEquipmentReturnReasons(List<EquipmentReturnReasons> ReasonsData)
        {   
            Settings.Logger.Info("Creating Equipment Return Reason");
            foreach (EquipmentReturnReasons reason in ReasonsData)
            {
                _extendPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameEquipRetReason, "Table frame");
                if (string.IsNullOrEmpty(reason.Code))
                {
                    reason.Code= CommonUtil.GetRandomStringWithSpecialChars(6);
                }
                Settings.Logger.Info($"Creating Equipment Return Reason :{reason.Code}");
                _inputNewCode.SetText(reason.Code, "New Code");
                Driver.WaitForReady();
                _inputNewDesc.SetText(reason.Description, "New code desc");
                Driver.WaitForReady();
                if (_tablerowsEquipRetReason.Count - 1 ==0)
                {
                    _ckbNewDefault.SelectCheckBox("Default", reason.Default);
                }
                else
                {
                    reason.Default = false;
                }
                _ckbNewDisabled.SelectCheckBox("Disabled", reason.Disabled);
                _extendPage.Save();            
            }
            return ReasonsData;
        }

        /// <summary>
        /// Verify Equipment Return Reason
        /// </summary>
        /// <param name="ReasonsData"></param>
        public void VerifyEquipmentReturnReasons(List<EquipmentReturnReasons> ReasonsData)
        {           
            RefreshAndSwitchToTable();
            foreach (EquipmentReturnReasons reason in ReasonsData)
            {
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRetReason, "Code", reason.Code, "DESCRIPTION"), "DESCRIPTION", reason.Description,false,"value");
                CommonUtil.VerifyCheckboxState(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRetReason, "Code", reason.Code, "DEFAULT_FL"), "DEFAULT", reason.Default);
                CommonUtil.VerifyCheckboxState(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRetReason, "Code", reason.Code, "DISABLED_FL"), "DISABLED", reason.Disabled);
            }
            Settings.Logger.Info("Verified Equipment Return Reason");
        }

        /// <summary>
        /// Edit Equipment Return Reasons
        /// </summary>
        /// <param name="EditReasonsData"></param>
        public void EditEquipmentReturnReasons(List<EquipmentReturnReasons> EditReasonsData)
        {
            Driver.SwitchTo().DefaultContent();           
            foreach (EquipmentReturnReasons reason in EditReasonsData)
            {
                RefreshAndSwitchToTable();             
                Settings.Logger.Info("Update Equipment Return Reason : " + reason.Code);              
                if (_tablerowsEquipRetReason.Count - 1>1)
                {
                    _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRetReason, "Code", reason.Code, "DEFAULT_FL").DeSelectCheckBox("DEFAULT");
                }
                else
                {
                    reason.Default = true;
                }
                 _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRetReason, "Code", reason.Code, "DISABLED_FL").DeSelectCheckBox("DISABLED");
                _extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRetReason, "Code", reason.Code, "DESCRIPTION").SetText(reason.Description, "DESCRIPTION");
                _extendPage.Save();               
            }

        }

        /// <summary>
        /// Delete Equipment Return Reasons
        /// </summary>
        /// <param name="DeletetReasonsData"></param>
        public void DeleteEquipmentReturnReasons(List<EquipmentReturnReasons>  DeletetReasonsData)
        {
            Driver.SwitchTo().DefaultContent();
            foreach (EquipmentReturnReasons reason in DeletetReasonsData)
            {
                RefreshAndSwitchToTable();
                Settings.Logger.Info("Deleting Equipment Return Reason : " + reason.Code);
                _extendPage.GetTableActionElementByRelatedColumnValue( _tableEquipRetReason, "Code", reason.Code, "DESCRIPTION").Click();
                Driver.WaitForReady();             
                _extendPage.DeleteAndSave();
                Driver.SwitchTo().DefaultContent();
            }
        }

        /// <summary>
        /// Verify  Deleted Equipment Return Reasons
        /// </summary>
        /// <param name="DeletetReasonsData"></param>
        public void VerifyDeletedEquipmentReturnReasons(List<EquipmentReturnReasons> VerifyDeletetReasonsData)
        {
            RefreshAndSwitchToTable();
            foreach (EquipmentReturnReasons reason in VerifyDeletetReasonsData)
            {                
                Settings.Logger.Info($"Verify Equiment Return Reason- {reason.Code} is Deleted");
                _extendPage.VerifyTableColumnDoesNotContainValue(_tableEquipRetReason, "Code", reason.Code);               
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Refresh And Switch To Table Frame
        /// </summary>
        public void RefreshAndSwitchToTable()
        {
            _extendPage.ClickOnRefreshButton();
            _extendPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameEquipRetReason, "Table frame");
        }

    }
    }   
