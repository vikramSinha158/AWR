﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.ProductOrder;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ProductLocationReceive
{
    internal class ProductLocationReceiveActions : ProductLocationReceivePage
    {
        public ProductLocationReceiveActions(IWebDriver Driver) : base(Driver) { }
        public void VerifyCheckProductReceived(ProductOrderObjects productOrder, string productNumber)
        {
            VerifyCreatedProductOrder(productOrder, productNumber);
            VerifyProductDetail(productOrder.ProductOrderDetail);
            FillPODetailInLocation(productOrder.ProductOrderDetail);
        }

        public void VerifyCheckProductRecievedWithToggleOn(ProductOrderObjects productOrder,string productNumber)
        {
            VerifyCreatedProductOrder(productOrder, productNumber);
            Driver.ScrollIntoViewAndClick(_displayClosedItems, "Display Closed Items");
            VerifyProductDetail(productOrder.ProductOrderDetail);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForSomeTime();
            VerifyPODetailReadOnly(productOrder.ProductOrderDetail,false);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToContentFrame();
            _productOrder.SetText(productNumber, "Product Order");
            Driver.WaitForSomeTime();
            _referenceNumber.SetText(productNumber, "Reference Number");
            Driver.ScrollIntoViewAndClick(_displayClosedItems, "Displayed Closed Items");
            Driver.ScrollIntoViewAndClick(_reOpenClosedItems, "ReOpen Closed Items");
            VerifyPODetailReadOnly(productOrder.ProductOrderDetail,true);
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
            foreach (IWebElement element in _completeLineCheckBox)
                element.ClickElement("_completeLineCheckBox", Driver);
            _extendedPage.Save();
            VerifyCreatedProductOrder(productOrder,productNumber);
            _displayClosedItems.ClickElement("_displayClosedItems", Driver);
            VerifyProductDetail(productOrder.ProductOrderDetail);
        }

        public void VerifyCreatedProductOrder(ProductOrderObjects productOrder,string productNumber)
        {
            Settings.Logger.Info("Verify Created Product Order");
            _extendedPage.RefreshAndSetText(_productOrder, productNumber, "_poNumber");
            Driver.WaitForReady();
            _referenceNumber.SetText(productNumber, "ReferenceNumber");
            _vendorInvDate.SetText(DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy HH:mm:ss"), "Vendor Inv Date");
        }

        public void VerifyProductDetail(List<ProductOrderDetail> productOrder)
        {
            int Position = 0;
            foreach (ProductOrderDetail product in productOrder)
            {
                Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
                CommonUtil.VerifyElementValue(_prod[Position], "_prod", product.Product.ToUpper(), false, "value");
                CommonUtil.VerifyElementValue(_prodTank[Position], "_prodTank", product.Tank, false, "value");
                CommonUtil.VerifyElementValue(_prodUnitCost[Position], "_prodUnitCost", product.UnitCost,false,"value");
                CommonUtil.VerifyElementValue(_prodQuantity[Position], "_prodQuantity", product.OrderQuantity, false, "value");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Position++;
            }
        }

        public void FillPODetailInLocation(List<ProductOrderDetail> productOrder)
        {
            int Position = 0;
            foreach (ProductOrderDetail product in productOrder)
            {
                Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
                _receivedQuantity[Position].SetText(product.ReceivedQuantity, "Received Quantity");
                Driver.WaitForSomeTime();
                if (product.CompleteLineCheck)
                    Driver.ScrollIntoViewAndClick(_completeLineCheckBox[Position],"Complete Line Check");
                string TotalCost = _totalCost[Position].GetAttribute("value");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                _extendedPage.Save();
                _extendedPage.SwitchToContentFrame();
                if(product.TotalInvoiceVerification)
                   CommonUtil.VerifyElementValue(_totalInvoiceCost, "_totalInvoiceCost", TotalCost);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
            Driver.SwitchTo().DefaultContent();
        }

        public void VerifyPODetailReadOnly(List<ProductOrderDetail> productOrder,bool ReOpen)
        {
            int Position = 0;
            foreach (ProductOrderDetail product in productOrder)
            {
                Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
                if (ReOpen)
                {
                    CommonUtil.AssertTrue(false, Convert.ToBoolean(_receivedDate[Position].GetAttribute("readonly")));
                    CommonUtil.AssertTrue(false, Convert.ToBoolean(_receivedQuantity[Position].GetAttribute("readonly")));
                    CommonUtil.AssertTrue(false, Convert.ToBoolean(_completeLineCheckBox[Position].GetAttribute("readonly")));
                }
               else
                {
                    CommonUtil.AssertTrue(true, Convert.ToBoolean(_receivedQuantity[Position].GetAttribute("readonly")));
                    CommonUtil.AssertTrue(true, Convert.ToBoolean(_totalCost[Position].GetAttribute("readonly")));
                    CommonUtil.AssertTrue(true, Convert.ToBoolean(_completeLineCheckBox[Position].GetAttribute("readonly")));
                }
                Position++;
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
