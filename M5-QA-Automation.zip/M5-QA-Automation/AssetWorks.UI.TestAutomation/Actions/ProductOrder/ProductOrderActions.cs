﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.ProductOrder;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ProductOrder
{
    internal class ProductOrderActions : ProductOrderPage
    {
        public ProductOrderActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Product Order
        /// </summary>
        public string CreateNewProductOrders(ProductOrderObjects productOrder)
        {
            Settings.Logger.Info("Create new Product Order");
            _extendedPage.SwitchToContentFrame();
            if (productOrder.PONumber.ToUpper() == "New")
                _newPOButton.ClickElement("New PO Button", Driver);

            else
            {
                if (productOrder.PONumber.ToUpper() == "RANDOM")
                    _poNumber.SetText(CommonUtil.GenerateRandomIntValue().ToString(), "Product Number");
                else
                    _poNumber.SetText(productOrder.PONumber, "Product Number");
                Driver.SwitchTo().DefaultContent();
                _createButton.ClickElement("Create Button", Driver);
            }
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _vendorNumber.SetText(productOrder.VendorNo, "Vendor Number");
            Driver.WaitForReady();
            _contractNumber.SetText(productOrder.ContractNo, "Contract Number");
            FillPoDetail(productOrder.ProductOrderDetail);
            return _poNumber.GetAttribute("ovalue");
        }

        /// <summary>
        /// Verify Created Product Order
        /// </summary>
        public void VerifyCreatedProductOrder(ProductOrderObjects productOrder, string productNumber)
        {
            Settings.Logger.Info("Verify Created Product Order");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_poNumber, productNumber, "_poNumber");
            CommonUtil.VerifyElementValue(_vendorNumber, "_vendorNumber", productOrder.VendorNo);
            CommonUtil.VerifyElementValue(_contractNumber, "ContractNo", productOrder.ContractNo);
            VerifyProductOrderDetail(productOrder.ProductOrderDetail);
            Driver.SwitchTo().DefaultContent();
        }

        public void FillPoDetail(List<ProductOrderDetail> productOrder)
        {
            foreach(ProductOrderDetail product in productOrder)
            {
                Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
                _prodInput.SendKeys(product.Product);
                Driver.WaitForReady();
                _prodInput.SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _prodTankInput.SetText(product.Tank, "Tank Input");
                Driver.WaitForReady();
                _prodUnitCostInput.SetText(product.UnitCost, "Unit Cost");
                Driver.WaitForReady();
                _prodQuantityInput.SetText(product.OrderQuantity, "Order Quantity");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _acceptButton.ClickElement("Accept button", Driver);
                _extendedPage.SwitchToContentFrame();
                _extendedPage.Save();
                _extendedPage.SwitchToContentFrame();
            }
        }

        public void VerifyProductOrderDetail(List<ProductOrderDetail> productOrder)
        {
            int Position = 0;
            foreach (ProductOrderDetail product in productOrder)
            {
                Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
                CommonUtil.VerifyElementValue(_prod[Position], "_prod", product.Product.ToUpper(), false, "value");
                CommonUtil.VerifyElementValue(_prodTank[Position], "_prodTank", product.Tank, false, "value");
                CommonUtil.VerifyElementValue(_prodUnitCost[Position], "_prodUnitCost", product.UnitCost, false, "value");
                CommonUtil.VerifyElementValue(_prodQuantity[Position], "_prodQuantity", product.OrderQuantity,false,"value" );
                Position++;
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Delete Product Order
        /// </summary>
        public void DeleteProductOrder(List<ProductOrderDetail> productOrder,string productNumber)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_poNumber, productNumber, "_poNumber");
            Driver.WaitForReady();
            int Position = 0;
            foreach (ProductOrderDetail product in productOrder)
            {
                Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
                _prodQuantity[Position].ClickElement("_prodQuantity", Driver);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDeleteButton();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Position++;
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
        }

        /// <summary>
        /// Delete Product Order
        /// </summary>
        public void verifyDeletedProductOrder(string productNumber)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_poNumber, productNumber, "_poNumber");
            Driver.SwitchToFrame(_fuelFrame, "_fuelFrame");
            Driver.WaitForSomeTime(15);
            CommonUtil.AssertTrue(true, _prodInputs.Count == 0);
        }
    }
}
