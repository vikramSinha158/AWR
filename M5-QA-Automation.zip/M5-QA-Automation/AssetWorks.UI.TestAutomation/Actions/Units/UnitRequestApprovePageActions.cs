﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitRequestApprovePageActions : UnitRequestApprovePage
    {
        public UnitRequestApprovePageActions(IWebDriver Driver) : base(Driver) { }


        /// <summary>
        /// To perform the retrive action
        /// </summary>
        /// <param name="requestor"></param>
        public void RetriveUnitRequests(UnitRequestApprove requestor)
        {
            Settings.Logger.Info(" Retrive Unit Requests ");
            _extendedPage.SwitchToContentFrame();
            _URAParking.SetText(requestor.ParkingLoc, "Parking Location");
            Driver.WaitForReady();
            _URAMaintenance.SetText(requestor.MaintenanceLoc, "Maintenance Location");
            Driver.WaitForReady();
            _URAUsing.SetText(requestor.UsingDept, "Using department");
            Driver.WaitForReady();
            _URAOwning.SetText(requestor.OwningDept, "Owning department");
            Driver.WaitForReady();
            _URARequestor.SetText(requestor.Requestor,"Requestor number");
            Driver.WaitForReady();
            _buttonRetrieve.Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// To verify the unit no in unit request approve
        /// </summary>
        /// <param name="requestor"></param>
        public void VerifyUnitRequestApproveRetriveDetails(UnitRequestApprove requestor)
        {
            Settings.Logger.Info(" Verify Unit Requests Info ");
            _extendedPage.SwitchToTableFrame(_URATableframe);
            Driver.WaitForReady();
            _extendedPage.VerifyTableColumnContainValue(_URATable, "Unit No", requestor.UnitNo);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Open Request Number
        /// </summary>
        /// <param name="requestor"></param>
        public void OpenRequestNumber(string unitNo)
        {
            Settings.Logger.Info(" Open Request Number ");
            _extendedPage.SwitchToTableFrame(_URATableframe);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_URATable, "Unit No", unitNo, "RequestNo").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _buttonClose.Click();
        }

        /// <summary>
        /// Approve Unit Request
        /// </summary>
        /// <param name="requestor"></param>
        public void ApproveUnitRequest(UnitRequestApprove requestor)
        {
            Settings.Logger.Info(" Approve Unit Request ");
            _extendedPage.SwitchToTableFrame(_URATableframe);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_URATable, "Unit No", requestor.UnitNo, 
                "reqApprover").SetText(requestor.Approver, "Approver");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_URATable, "Unit No", requestor.UnitNo, "Approve").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            _extendedPage.SwitchToTableFrame(_URATableframe);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_URATable, "Unit No", requestor.UnitNo);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
