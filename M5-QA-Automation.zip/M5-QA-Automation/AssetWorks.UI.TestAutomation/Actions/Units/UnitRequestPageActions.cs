﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitRequestPageActions : UnitRequestPage
    {
        public UnitRequestPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Unit Request
        /// </summary>
        /// <param name="UnitReq"></param>
        /// <returns></returns>
        public string CreateUnitRequest(UnitRequest UnitReq)
        {
            string RequestNo = string.Empty;
            if (UnitReq.RequestNo == null && UnitReq.NewRequest)
                RequestNo = CreateNewUnitRequest(UnitReq);
            else
            {
                if (!_extendedPage.CheckDataExistenceAndGetActionCode(UnitReq.RequestNo, ref RequestNo, "UnitRequestQuery", 10))
                {
                    UnitReq.RequestNo = RequestNo;
                    RequestNo = CreateNewUnitRequest(UnitReq);
                }
            }
            return RequestNo;
        }


        /// <summary>
        /// Create New Unit Request
        /// </summary>
        /// <param name="UnitReq"></param>
        /// <returns>RequestNo</returns>
        public string CreateNewUnitRequest(UnitRequest UnitReq)
        {
            Settings.Logger.Info(" Create a new Unit Request ");
            if (UnitReq.RequestNo != null && UnitReq.RequestNo.ToLower().Equals("random"))
                UnitReq.RequestNo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
            if (UnitReq.ReqUnitNo != null && UnitReq.ReqUnitNo.ToLower().Equals("random"))
                UnitReq.ReqUnitNo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();

            _extendedPage.SwitchToContentFrame();
            if (UnitReq.NewRequest)
            {
                _buttonNewRequest.Click();
                Settings.Logger.Info("Clicked on New Request button");
            }
            if (UnitReq.NewUnit)
            {
                _buttonNewUnit.Click();
                Settings.Logger.Info("Clicked on New Unit button");
            }
            _inputRequestNo.SetText(UnitReq.RequestNo, "Request No");
            Driver.WaitForReady();
            if (UnitReq.RequestNo != null)
            {
                Driver.SwitchTo().DefaultContent();
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                _extendedPage.SwitchToContentFrame();
            }

            _inputUnitNo.SetText(UnitReq.ReqUnitNo, "Unit No");

            _selectOwnership.SelectFilterValueHavingEqualValue(UnitReq.ReqOwnership);
            _selectReqType.SelectFilterValueHavingEqualValue(UnitReq.ReqType);

            _inputDeliveryDt.SetText(UnitReq.ReqDeliveryDate, "Delivery Date");
            _inputLeaseType.SetText(UnitReq.ReqLeaseType, "Lease Type");

            if (UnitReq.ReqDetail != null)
                UpdateDetailTabInformation(UnitReq.ReqDetail);
            if (UnitReq.ReqCategoryOptions != null)
                UpdateCategoryOptionsTabInformation(UnitReq.ReqCategoryOptions);
            if (UnitReq.ReqClass != null)
                UpdateClassTabInformation(UnitReq.ReqClass);

            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            UnitReq.RequestNo = _inputRequestNo.GetElementValueByAttribute("ovalue");
            UnitReq.ReqUnitNo = _inputUnitNo.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return UnitReq.RequestNo;
        }

        /// <summary>
        /// Update Unit Request
        /// </summary>
        /// <param name="UnitReq"></param>
        public void UpdateUnitRequest(UnitRequest UnitReq)
        {
            Settings.Logger.Info($" Update Unit Request Details - {UnitReq.RequestNo}");
            _extendedPage.RefreshAndSetText(_inputRequestNo, UnitReq.RequestNo, "Request No");
            Driver.WaitForSomeTime();
            string status = _selectStatus.GetVisibleText();
            if (status == "APPROVED")
                _buttonReopen.Click();
            _inputUnitNo.SetText(UnitReq.ReqUnitNo, "Unit No");
            Driver.WaitForReady();
            _selectOwnership.SelectFilterValueHavingEqualValue(UnitReq.ReqOwnership);
            _selectReqType.SelectFilterValueHavingEqualValue(UnitReq.ReqType);
            _inputDeliveryDt.SetText(UnitReq.ReqDeliveryDate, "Delivery Date");
            _inputLeaseType.SetText(UnitReq.ReqLeaseType, "Lease Type");
            if (UnitReq.ReqDetail != null)
                UpdateDetailTabInformation(UnitReq.ReqDetail);
            if (UnitReq.ReqCategoryOptions != null)
                UpdateCategoryOptionsTabInformation(UnitReq.ReqCategoryOptions);
            if (UnitReq.ReqClass != null)
                UpdateClassTabInformation(UnitReq.ReqClass);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Update Detail Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void UpdateDetailTabInformation(ReqDetail DataObject)
        {
            Settings.Logger.Info(" Update Unit Request Detail Information");
            _extendedPage.GetTabLinkByText("Detail").Click();
            Settings.Logger.Info("Clicked on Detail Tab");
            Driver.WaitForReady();
            _inputReplacesUnit.SetText(DataObject.ReqReplacesUnit, "Replaces Unit");
            Driver.WaitForReady();
            _selectDisposalStatus.SelectFilterValueHavingEqualValue(DataObject.ReqDisposalStatus);
            Driver.WaitForReady();
            if (DataObject.ReqOwnerDept != null)
            {
                Driver.DoubleClick(_inputOwnerDept, "Owner Dept");
                _lov.SearchAndClickElement(DataObject.ReqOwnerDept);
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
            if (DataObject.ReqEstimatedDate != null)
            {
                _extendedPage.SelectAllAndClearField(_inputEstimatedDate);
                _inputEstimatedDate.SetText(DataObject.ReqEstimatedDate, "Estimated Date");
                Driver.WaitForReady();
            }
            if (DataObject.ReqUsingDept != null)
                _inputUsingDept.SetText(DataObject.ReqUsingDept, "Using Dept");
            else
                _inputUsingDept.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (DataObject.ReqDisposalReason != null)
            {
                _inputDisposalReason.Click();
                _inputDisposalReason.SetText(DataObject.ReqDisposalReason, "Disposal Reason");
                Driver.WaitForReady();
            }
            if (DataObject.ReqParkingLoc != null)
                _inputParkingLoc.SetText(DataObject.ReqParkingLoc, "Parking Loc");
            else
                _inputParkingLoc.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (DataObject.ReqEmployee != null)
            {
                _extendedPage.SelectAllAndClearField(_inputEmployee);
                _inputEmployee.SetText(DataObject.ReqEmployee, "Employee");
                Driver.WaitForReady();
            }
            if (DataObject.ReqMaintLoc != null)
                _inputMaintLoc.SetText(DataObject.ReqMaintLoc, "Maint Loc");
            else
                _inputMaintLoc.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (DataObject.ReqFuelLoc != null)
                _inputFuelLoc.SetText(DataObject.ReqFuelLoc, "Fuel Loc");
            else
                _inputFuelLoc.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (DataObject.ReqDelLoc != null)
                _inputDelLoc.SetText(DataObject.ReqDelLoc, "Delivery Loc");
            else
                _inputDelLoc.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            _inputActivity.SetText(DataObject.ReqActivity, "Activity");
            Driver.WaitForReady();
            _inputTechSpec.SetText(DataObject.ReqTechSpec, "Tech Spec");
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            Driver.WaitForReady();
            _inputMcc.SetText(DataObject.ReqMcc, "Mcc");
            Driver.WaitForReady();
            _inputOperator.SetText(DataObject.ReqOperator, "Operator");
            Driver.WaitForReady();
            if (DataObject.ReqNotes != null)
            {
                _inputNote.Click();
                Driver.WaitForReady();
                _inputNote.SetText(DataObject.ReqNotes, "Notes");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Category Options Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void UpdateCategoryOptionsTabInformation(ReqCategoryOptions DataObject)
        {
            Settings.Logger.Info(" Update Unit Request Category Options Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Category Options"), "Category Options Tab");
            Driver.WaitForReady();
            if (DataObject.ReqCategoryCode != null)
            {
                Driver.DoubleClick(_inputCategoryCode, "Category Code");
                _lov.SearchAndClickElement(DataObject.ReqCategoryCode);
                Driver.WaitForSomeTime();
                Driver.AcceptAlert();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
            if (DataObject.ReqOptionSelection)
            {
                Driver.SwitchToFrame(_frameNewUnit, "New Unit Frame");
                int rowCount = _tableOptionSelection.FindElements(By.XPath("//td[@col='2']")).Count;
                if (rowCount > 0)
                {
                    for (int i = 0; i < rowCount; i++)
                    {
                        _extendedPage.GetElementForInput($"sel${i}", "name").Click();
                    }
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Class Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void UpdateClassTabInformation(ReqClass DataObject)
        {
            Settings.Logger.Info(" Update Unit Request Class Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Class"), "Class Tab");
            Driver.WaitForReady();
            if (DataObject.ReqClass1 != null)
            {
                Driver.DoubleClick(_inputClass1, "Class1");
                _lov.SearchAndSelectFirstRowData(DataObject.ReqClass1);
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
            if (DataObject.ReqClass2 != null)
                _inputClass2.SetText(DataObject.ReqClass2, "Class 2");
            else
                _inputClass2.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (DataObject.ReqClass3 != null)
                _inputClass3.SetText(DataObject.ReqClass3, "Class 3");
            else
                _inputClass3.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (DataObject.ReqClass4 != null)
                _inputClass4.SetText(DataObject.ReqClass4, "Class 3");
            else
                _inputClass4.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            _inputClass5.SetText(DataObject.ReqClass5, "Class 5");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Unit Request Information
        /// </summary>
        /// <param name="RequestNo"></param>
        public void VerifyUnitRequestInformation(string RequestNo, UnitRequest UnitReq)
        {
            Settings.Logger.Info(" Verify Unit Request Information ");
            _extendedPage.RefreshAndSetText(_inputRequestNo, RequestNo, "Request No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputUnitNo, "Unit No", UnitReq.ReqUnitNo);
            CommonUtil.VerifyElementValue(_selectStatus, "Status", UnitReq.ReqStatus);
            CommonUtil.VerifyElementValue(_inputLeaseType, "Lease Type", UnitReq.ReqLeaseType);
            _extendedPage.VerifySystemDateContainAppdate(_inputStatusDate, "Status Date");
            if (UnitReq.ReqDetail != null)
                VerifyDetailTabInformation(UnitReq.ReqDetail);
            if (UnitReq.ReqCategoryOptions != null)
                VerifyCategoryOptionsTabInformation(UnitReq.ReqCategoryOptions);
            if (UnitReq.ReqClass != null)
                VerifyClassTabInformation(UnitReq.ReqClass);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Detail Tab Information
        /// </summary>
        /// <param name="Detail"></param>
        public void VerifyDetailTabInformation(ReqDetail Detail)
        {
            Settings.Logger.Info(" Verify Detail Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Detail"), "Detail Tab");
            Settings.Logger.Info("Clicked on Detail Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputReplacesUnit, "Replaces Unit", Detail.ReqReplacesUnit);
            CommonUtil.VerifyElementValue(_inputOwnerDept, "Owner Dept", Detail.ReqOwnerDept);
            CommonUtil.VerifyElementValue(_inputUsingDept, "Using Dept", Detail.ReqUsingDept);
            CommonUtil.VerifyElementValue(_inputParkingLoc, "Parking Loc", Detail.ReqParkingLoc);
            CommonUtil.VerifyElementValue(_inputMaintLoc, "Maint Loc", Detail.ReqMaintLoc);
            CommonUtil.VerifyElementValue(_inputFuelLoc, "Fuel Loc", Detail.ReqFuelLoc);
            CommonUtil.VerifyElementValue(_inputDelLoc, "Delivery Loc", Detail.ReqDelLoc);
            CommonUtil.VerifyElementValue(_inputActivity, "Activity", Detail.ReqActivity);
            CommonUtil.VerifyElementValue(_inputTechSpec, "Tech Spec", Detail.ReqTechSpec);
            CommonUtil.VerifyElementValue(_inputMcc, "Mcc", Detail.ReqMcc);
            CommonUtil.VerifyElementValue(_inputOperator, "Operator", Detail.ReqOperator);
            CommonUtil.VerifyElementValue(_inputNote, "Note", Detail.ReqNotes);
        }

        /// <summary>
        /// Verify Category Options Tab Information
        /// </summary>
        /// <param name="CategoryOption"></param>
        public void VerifyCategoryOptionsTabInformation(ReqCategoryOptions CategoryOption)
        {
            Settings.Logger.Info(" Verify Category Options Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Category Options"), "Category Options Tab");
            Settings.Logger.Info("Clicked on Category Options Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputCategoryCode, "Category Code", CategoryOption.ReqCategoryCode);
        }

        /// <summary>
        /// Verify Class Tab Information
        /// </summary>
        /// <param name="Class"></param>
        public void VerifyClassTabInformation(ReqClass Class)
        {
            Settings.Logger.Info(" Verify Class Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Class"), "Class Tab");
            Settings.Logger.Info("Clicked on Class Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputClass1, "Class 1", Class.ReqClass1);
            CommonUtil.VerifyElementValue(_inputClass2, "Class 2", Class.ReqClass2);
            CommonUtil.VerifyElementValue(_inputClass3, "Class 3", Class.ReqClass3);
            CommonUtil.VerifyElementValue(_inputClass4, "Class 4", Class.ReqClass4);
            CommonUtil.VerifyElementValue(_inputClass5, "Class 5", Class.ReqClass5);
        }

        /// <summary>
        /// Verify Copy Unit Request Information
        /// </summary>
        /// <param name="RequestNo"></param>
        public void VerifyCopyUnitRequestInformation(string RequestNo)
        {
            Settings.Logger.Info(" Verify Copy Unit Request Information ");
            _extendedPage.SwitchToContentFrame();
            string ActualRequestNo = _inputRequestNo.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue(RequestNo, ActualRequestNo);
            string ActualStatus = _selectStatus.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue("AWAITING", ActualStatus);
            _extendedPage.VerifySystemDateContainAppdate(_inputStatusDate, "Status Date");
        }

        /// <summary>
        /// Approve Unit Request
        /// </summary>
        /// <param name="RequestNo"></param>
        /// <param name="Approver"></param>
        public void ReopenApproveUnitRequest(string RequestNo, string Approver)
        {
            Settings.Logger.Info(" Approve Unit Request ");
            _extendedPage.RefreshAndSetText(_inputRequestNo, RequestNo, "Request No");
            Driver.WaitForReady();
            string status = _selectStatus.GetVisibleText();
            if (status == "REJECT")
                _inputRejectReason.Clear();
            else if (status == "APPROVED")
                _buttonReopen.Click();
            Driver.WaitForReady();
            _inputApprover.SetText(Approver, " Approver ");
            _buttonApprove.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ActionRequiredWindow("Yes");
            _extendedPage.ClickOnSaveButton();
            VerifyUnitRequestStatus("APPROVED");
        }

        /// <summary>
        /// Reject Unit Request
        /// </summary>
        /// <param name="RequestNo"></param>
        /// <param name="Reason"></param>
        public void RejectUnitRequest(string RequestNo, string Reason)
        {
            Settings.Logger.Info(" Reject Unit Request ");
            _extendedPage.RefreshAndSetText(_inputRequestNo, RequestNo, "Request No");
            Driver.WaitForReady();
            string status = _selectStatus.GetVisibleText();
            if (status == "APPROVED")
            {
                _buttonReopen.Click();
                _inputApprover.Clear();
            }
            _inputRejectReason.SetText(Reason, " Reject Reason ");
            _buttonReject.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            VerifyUnitRequestStatus("REJECT");
        }

        /// <summary>
        /// Verify Unit Request Status
        /// </summary>
        /// <param name="expectedStatus"></param>
        public void VerifyUnitRequestStatus(string expectedStatus)
        {
            Settings.Logger.Info(" Verify Unit Request Status ");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            CommonUtil.AssertTrue(expectedStatus, _selectStatus.GetVisibleText());
            Driver.SwitchTo().DefaultContent();
        }
    }
}
