﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitGroupPageActions : UnitGroupPage
    {
        public UnitGroupPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Unit Group
        /// </summary>
        /// <param name="GroupNo"></param>
        /// <returns></returns>
        public string CreateNewUnitGroup(GroupUnit DataObject,string GroupNo = "random")
        {
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(GroupNo, ref _unitGroupNo, "UnitGroupQuery"))
            {
                _inputGroupNo.SetText(_unitGroupNo, "Group No", Driver, _extendedPage._contentFrame, "content frame");
                _extendedPage.ClickOnDialogBoxButton("Cancel");
                _inputGroupNo.SetText(_unitGroupNo, "Group No", Driver, _extendedPage._contentFrame, "content frame");
                _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                if (DataObject.GroupUnitDetail != null)
                {
                    FillGruopUnitListDetail(DataObject.GroupUnitDetail);
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.VerifyCreatedActionNumber(_inputGroupNo, _unitGroupNo);
            }
            return _unitGroupNo;
        }

        /// <summary>
        /// Verify Unit Group
        /// </summary>
        /// <param name="GroupNo"></param>
        /// <param name="DataObject"></param>
        public void VerifyUnitGroup(string GroupNo, GroupUnit DataObject)
        {
            Settings.Logger.Info(" Verify Unit Group ");
            _extendedPage.RefreshAndSetText(_inputGroupNo, GroupNo, "Group No");
            Driver.WaitForReady();            
            if (DataObject.GroupUnitDetail == null)
            {
                string statusVal = _inputStatus.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(_unitGroupNoStatus, statusVal);
            }
            if (DataObject.GroupUnitDetail != null)
            {
                VerifyGroupUnitList(DataObject.GroupUnitDetail);
            }          
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Unit in Group unit ");
        }

        /// <summary>
        /// Verify Unit Group Deletion
        /// </summary>
        /// <param name="GroupNo"></param>
        public void VerifyUnitGroupDeletion(string GroupNo)
        {
            Settings.Logger.Info(" Verify Unit Group Deletion ");
            _extendedPage.RefreshAndSetText(_inputGroupNo, GroupNo, "Group No");
            _inputGroupNo.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForInvisibility(By.XPath(Settings.ActionDialog), "Deletion dialog ");
            string ValueAfterDeletion = _inputGroupNo.GetAttribute("ovalue");
            Assert.True(String.IsNullOrEmpty(ValueAfterDeletion), $"Group No not deleted, found value {ValueAfterDeletion}");
            Settings.Logger.Info($"Group No Deleted successfully  ");
        }

        /// <summary>
        /// Fill GruopUnitList Detail
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillGruopUnitListDetail(GroupUnitDetail DataObject)
        {
            Settings.Logger.Info(" Fill Unit list in unit group  ");
            Driver.SwitchToFrame(_frameGroupUnits, "_assocTechSpecFrame");
            List<GroupUnitsData> GroupUnitDataList = DataObject.GroupUnitData;
            foreach (GroupUnitsData UnitListDetail in GroupUnitDataList)
            {
                Driver.WaitForReady();
                if (UnitListDetail.AddUnitNo)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_groupUntTable, _unitGroupHeader,"", _groupUnitNoId).SetText(UnitListDetail.UnitNo, "UnitNo");
                Driver.WaitForReady();
                if (UnitListDetail.LeadUnit) { _extendedPage.GetTableActionElementByRelatedColumnValue(_groupUntTable, _unitGroupHeader, UnitListDetail.UnitNo, _leadUnitId).SelectCheckBox("Lead Unit Checkbox", UnitListDetail.LeadUnit); }
                else {_extendedPage.GetTableActionElementByRelatedColumnValue(_groupUntTable, _unitGroupHeader, UnitListDetail.UnitNo, _leadUnitId).DeSelectCheckBox("Lead Unit Checkbox"); }
            }
        }

        /// <summary>
        /// Verify Group Unit List
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyGroupUnitList(GroupUnitDetail DataObject)
        {
            List<GroupUnitsData> GroupUnitDataList = DataObject.GroupUnitData;
            Driver.SwitchToFrame(_frameGroupUnits, "_assocTechSpecFrame");
            int UnitListCount = GroupUnitDataList.Count - 1;
            foreach (GroupUnitsData UnitListDetail in GroupUnitDataList)
            {
                string ActualUnitNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_groupUntTable,
               _unitGroupHeader, UnitListDetail.UnitNo, _groupUnitNoId).GetAttribute("value");
                CommonUtil.AssertTrue<string>(UnitListDetail.UnitNo, ActualUnitNo);
                IWebElement LeadCheckbox = _extendedPage.GetTableActionElementByRelatedColumnValue(_groupUntTable,
                _unitGroupHeader, UnitListDetail.UnitNo, _leadUnitId);
                CommonUtil.VerifyCheckboxState(LeadCheckbox, "Lead unit Checkbox", UnitListDetail.LeadUnit);
            }
        }

        /// <summary>
        /// Delete Unit Group
        /// </summary>
        /// <param name="GroupNo"></param>
        /// <param name="DataObject"></param>
        public void DeleteUnitGroup(string GroupNo, GroupUnit DataObject)
        {
            _extendedPage.RefreshAndSetText(_inputGroupNo, GroupNo, "Group No");
            List<GroupUnitsData> GroupUnitDataList = DataObject.GroupUnitDetail.GroupUnitData;
            Driver.SwitchToFrame(_frameGroupUnits, "UnitGroupList");
            foreach (GroupUnitsData UnitListDetail in GroupUnitDataList)
            {
                _leadCheckbox = null;
                _unitNo = null;
                if (!UnitListDetail.LeadUnit)
                {
                    Driver.WaitForReady();
                    _unitNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_groupUntTable, _unitGroupHeader, UnitListDetail.UnitNo, _groupUnitNoId);
                    _unitNo.ClickElement("unitNo", Driver);
                    _extendedPage.DeleteAndSave();
                    Driver.SwitchToFrame(_frameGroupUnits, "chatGroupMaintFrame");
                }
            }
            if (_groupUntNoList.Count > 1)
            {
                Settings.Logger.Info(" Deleting  Unit  Group Unit ");
                int UnitListCount = _groupUntNoList.Count - 1;
                for (int i = 0; i < UnitListCount; i++)
                {
                    _groupUntNoList[i].ClickElement("groupUntNoList", Driver);
                    _extendedPage.DeleteAndSave();
                    Driver.SwitchToFrame(_frameGroupUnits, "frameGroupUnits");
                }
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Deleted Unit from Group unit ");
        }

        /// <summary>
        /// VerifyUnitDeletion
        /// </summary>
        /// <param name="GroupNo"></param>
        public void VerifyUnitDeletion(string GroupNo)
        {
            _extendedPage.RefreshAndSetText(_inputGroupNo, GroupNo, "Group No");
            Driver.SwitchToFrame(_frameGroupUnits, "frameGroupUnits");
            Driver.WaitForReady();
            int ActualCount = _groupUntNoList.Count - 1;
            CommonUtil.AssertTrue<int>(0, ActualCount);
            Settings.Logger.Info(" Successfully Verified Unit deletion in Group Unit  ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Enter unit number having inactive lable flag equal to no in unit group 
        /// </summary>
        /// <param name="GroupNo"></param>
        /// <param name="UnitNo"></param>
        public void SaveUnitNumber(string GroupNo, string UnitNo)
        {
            _extendedPage.RefreshAndSetText(_inputGroupNo, GroupNo, "Group No");
            Driver.WaitForReady();
            _inputUnitNo.SetText(UnitNo, "Unit No", Driver, _frameGroupUnits, "Group Units frame");
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
        }

        /// Add unit in the group and click on save without select the lead unit checkbox
        /// </summary>
        /// <param name="GroupNo"></param>
        public void SaveDetailsWithoutLeadUnitCheckbox(string GroupNo, string UnitNo)
        {
            _extendedPage.RefreshAndSetText(_inputGroupNo, GroupNo, "Group No");
            Driver.SwitchToFrame(_frameGroupUnits, "frameGroupUnits");
            Driver.WaitForReady();
            _unitNoInUnitGroupRow1.SetText(UnitNo,"Unit No");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }
        
        /// Enter unit group details
        /// </summary>
        /// <param name="GroupNo"></param>
        public void EnterUnitGroupName(string GroupNo)
        {
            _extendedPage.RefreshAndSetText(_inputGroupNo, GroupNo, "Group No");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Enter units in the group
        /// </summary>
        /// <param LeadUnit="unitNumbers"></param>
        public void SelectMultipleUnitsInGroupAndSave(LeadUnit unitNumbers)
        {
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameGroupUnits, "frameGroupUnits");
            _unitNoInUnitGroupRow1.SendKeys(unitNumbers.UnitsInTheGroup.UnitOne);
            _unitNoInUnitGroupRow1.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            _unitNoCheckbox1.Click();
            _unitNoInUnitGroupRow2.SendKeys(unitNumbers.UnitsInTheGroup.UnitTwo);
            _unitNoInUnitGroupRow2.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            _unitNoCheckbox2.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Error Messages 
        /// </summary>
        /// <param LeadUnit="leadUnit"></param>     
        public void VerifyErrorMessage(UnitGroup unitGroup)
        {
            Assert.True(_ErrorMessage1.Text.ToString().Equals(unitGroup.ErrorMessage1));
            Assert.True(_ErrorMessage2.Text.ToString().Equals(unitGroup.ErrorMessage2));
        }

        /// <summary>
        /// Verify error message
        /// </summary>
        /// <param name="leadUnit"></param>
        public void VerifyErrorMessage(LeadUnit leadUnit)
        {
            Assert.True(_ErrorMessage1.Text.ToString().Equals(leadUnit.ErrorMessage1));
            Assert.True(_ErrorMessage2.Text.ToString().Equals(leadUnit.ErrorMessage2));
        }

        /// <summary>
        /// Enter units in the group and validate error
        /// </summary>
        /// <param LeadUnit="unitno"></param>
        public void VerifyGroupUnitErrorMsg(LeadUnit leadUnit)
        {
            _extendedPage.SwitchToContentFrame();
            _inputGroupNo.SetText(leadUnit.UnitGroup, "UnitGroup");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameGroupUnits, "frameGroupUnits");
            _unitNoInUnitGroupRow1.SetText(leadUnit.UnitNo, "Unit Number");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            string actualerrormsg = _extendedPage.GetErrorMessage();
            Assert.True(actualerrormsg.Equals(leadUnit.ErrorMessage2));
        }

        /// <summary>
        /// Open Unit Group
        /// </summary>
        /// <param name="UnitGroupNo"></param>
        public void OpenUnitGroup(string UnitGroupNo)
        {
            Settings.Logger.Info(" Verify Cannot Delete Unit Group Wit hAssigned Units ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputGroupNo.SetText(UnitGroupNo, " Unit Group ");
            _inputGroupNo.Click();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify unit group deletion
        /// </summary>
        /// <param name="UnitGroupNo"></param>
        public void VerifyCannotDeleteUnitGroupWithAssignedUnits(string UnitGroupNo)
        {
            Settings.Logger.Info(" Verify Cannot Delete Unit Group Wit hAssigned Units ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputGroupNo.SetText(UnitGroupNo, " Unit Group ");
            _inputGroupNo.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            Settings.Logger.Info(" Verifying warning message ");
            string actualErrorMessage = _extendedPage.GetErrorMessage();
            CommonUtil.AssertTrue(CommonUtil.DataForKey("ExpectedErrorMessage"), actualErrorMessage);
        }

        /// <summary>
        /// Add Unit sInExisting Unit Group
        /// </summary>
        /// <param name="DataObject"></param>
        public void AddUnitsInExistingUnitGroup(GroupUnit DataObject)
        {
            _extendedPage.RefreshAndSetText(_inputGroupNo, DataObject.UnitGroupName, "Group No");
            Driver.WaitForReady();
            FillGruopUnitListDetail(DataObject.GroupUnitDetail);
            _extendedPage.Save();
        }
    }
}

