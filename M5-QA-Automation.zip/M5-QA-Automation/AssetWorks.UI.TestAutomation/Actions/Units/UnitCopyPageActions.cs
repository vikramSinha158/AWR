﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitCopyPageActions : UnitCopyPage
    {
        public UnitCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// CreateUnitCopy
        /// </summary>
        /// <param name="UnitNo"></param>
        /// <returns></returns>
        public (UnitMainPageActions, string) CreateUnitCopy(string UnitNo = "random")
        {
            Settings.Logger.Info(" Creating new unit copy");
            if (UnitNo.ToLower().Equals("random"))
                _newUnitNo = CommonUtil.GetRandomStringWithSpecialChars(8, false, false).ToUpper();
            else
                _newUnitNo = UnitNo.ToUpper();
            string _unitNo = CommonUtil.DataObjectForKey("ReqUnitNo").ToString();
            string _copies = CommonUtil.DataObjectForKey("ReqCopies").ToString();
            string _addNew = CommonUtil.DataObjectForKey("IsAddNew").ToString();
            _extendedPage.SwitchToContentFrame();
            _inputUnitNo.SetText(_unitNo, "Unit No");
            Driver.WaitForReady();
            _inputNoOfCopies.SetText(_copies, "No of Copies");
            Driver.WaitForReady();
            _inputNewUnitNo.SetText(_newUnitNo, "New Unit No");
            Driver.WaitForReady();
            if (_addNew.ToLower() == "yes")
            {
                _buttonAddNew.Click();
                Settings.Logger.Info(" Clicked on Add New button");
                Driver.WaitForReady();
            }
            _checkboxCopyUnitDesc.Click();
            Settings.Logger.Info(" Clicked on copy unit Description checkbox ");
            Driver.WaitForReady();
            _checkboxCopyUnitPurchPrice.Click();
            Settings.Logger.Info(" Clicked on copy unit Total Purchase price checkbox ");
            Driver.WaitForReady();
            _checkboxCopyAttachments.Click();
            Settings.Logger.Info(" Clicked on copy Attachments checkbox ");
            Driver.WaitForReady();
            _checkboxCopyCustomer.Click();
            Settings.Logger.Info(" Clicked on copy Customer checkbox ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForInvisibility(By.Id("NewUnitNo"), " New Unit No ");
            _newUnitNo = _newUnitNo + "1";
            return (new UnitMainPageActions(Driver), _newUnitNo);
        }
    }
}
