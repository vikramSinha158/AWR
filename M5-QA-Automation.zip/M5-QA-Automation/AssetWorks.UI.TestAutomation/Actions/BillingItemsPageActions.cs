﻿using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingItemsPageActions : BillingItemsPage
    {
        public BillingItemsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Set And Unset BillCharge
        /// </summary>
        /// <param name="BillingItem"></param>
        /// <param name="BillCharge"></param>
        public void SetAndUnsetBillCharge(string BillingItem,bool BillCharge)
        {
            _extendpage.SwitchToTableFrame(_billItemFrame);
             IWebElement BillChargeCheckBox= _extendpage.GetTableActionElementByRelatedColumnValue(_billItemTable, _billItemHeader, BillingItem, _billchargesId);
            _extendpage.SetCheckBox(BillChargeCheckBox, "BillChange", BillCharge);
            _extendpage.Save();
            Settings.Logger.Info($" Set And Unset BillCharge { BillingItem}");
        }

        /// <summary>
        /// Verify Set And Unset BillCharge
        /// </summary>
        /// <param name="BillingItem"></param>
        /// <param name="BillCharge"></param>
        public void VerifySetAndUnsetBillCharge(string BillingItem, bool BillCharge)
        {
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToTableFrame(_billItemFrame);
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_billItemTable, _billItemHeader, BillingItem, _billchargesId), "BillCharge", BillCharge);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($" Successfully Verified  Set And Unset BillCharge  { BillingItem}");
        }
    }
}
