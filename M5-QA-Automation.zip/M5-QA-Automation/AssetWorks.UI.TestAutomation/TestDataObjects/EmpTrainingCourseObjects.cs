﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class TrainingCourseSetUp
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public List<string> CodeList { get; set; }
        public List<string> DescriptionList { get; set; }
        public string DaysValid { get; set; }
        public bool LOVResourceType { get; set; }
        public string ResourceType { get; set; }
        public string VendorNo { get; set; }
        public bool Disabled { get; set; }
        public bool DeSelectDisabled { get; set; }
    }

}
