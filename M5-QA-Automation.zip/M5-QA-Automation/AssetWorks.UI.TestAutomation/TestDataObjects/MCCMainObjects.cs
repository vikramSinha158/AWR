﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class MCCMainObjects
    {
        public static string MCCCodeDesCription { get; set; }

        public static string MCCCode { get; set; }

        public static string AddDataForMCCMian = "AddDataForMCCMian";
        public static string EditDataForMCCMian = "EditDataForMCCMian";
        public static string MEUFirstType = "MEUFirstType";
        public static string MEUFirstMin = "MEUFirstMin";
        public static string MEUFirstMax = "MEUFirstMax";
        public static string MEUFirstLength = "MEUFirstLength";
        public static string MEUSecondType = "MEUSecondType";
        public static string MEUSecondMin = "MEUSecondMin";
        public static string MEUSecondMax = "MEUSecondMax";
        public static string MEUSecondLength = "MEUSecondLength";
        public static string DataMCCode = "DataMCCode";
        public static string SeasonCode = "SeasonCode";

    }
}
