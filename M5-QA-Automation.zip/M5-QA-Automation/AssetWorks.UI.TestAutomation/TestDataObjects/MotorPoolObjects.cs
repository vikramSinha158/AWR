﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class MotorPoolObjects
    {
    }

    public class ManagerTicket
    {
        public string TicketNo { get; set; }
        public string MPStatus { get; set; }
        public ReservationTab reservationTab { get; set; }
        public PickupReturnTab pickupReturnTab { get; set; }
    }

    public class PickupReturnTab
    {
        public bool IsPickup { get; set; }
        public string LocationOut { get; set; }
        public string Meter1Out { get; set; }
        public string Meter2Out { get; set; }
        public bool IsReturn { get; set; }
        public string LocationIn { get; set; }
        public string Meter1In { get; set; }
        public string Meter2In { get; set; }
        public bool MeterInOvr { get; set; }
        public string WhereIn { get; set; }
        public string LicPermNo { get; set; }
        public string State { get; set; }
        public string CityLicenseNo { get; set; }
        public bool MovingViolations { get; set; }
        public bool Damage { get; set; }
        public string ReturnedBy { get; set; }
        public string PRNotes { get; set; }
        public string BillingMethod { get; set; }
        public string AdjHours { get; set; }
        public string FreeHours { get; set; }
        public string RateHours { get; set; }
        public string AdjDays { get; set; }
        public string FreeDays { get; set; }
        public string RateDays { get; set; }
        public string AdjWeeks { get; set; }
        public string FreeWeeks { get; set; }
        public string RateWeeks { get; set; }
        public string AdjMonths { get; set; }
        public string FreeMonths { get; set; }
        public string RateMonths { get; set; }
        public string RateUsage { get; set; }
        public string QuantityFuel { get; set; }
        public string RateFuel { get; set; }
        public string ChargeDesc { get; set; }
        public string ChargeAmt { get; set; }
    }

    public class ReservationTab
    {
        public string PickupLocation { get; set; }
        public string PickupDateTime { get; set; }
        public string ReturnLocation { get; set; }
        public string ReturnDateTime { get; set; }
        public string RentalClass { get; set; }
        public string EquipUnitNo { get; set; }
        public string ReservedFor { get; set; }
        public string DepartmentNo { get; set; }
        public string PhoneNo { get; set; }
        public string Destination { get; set; }
        public string RequestedBy { get; set; }
        public string Reason { get; set; }
        public string AccountNo { get; set; }
    }
}
