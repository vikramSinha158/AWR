﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class VendorMainObjects
    {
      
        public static string ServiceCode = "servCode$";
        public static string Description = "description$";
        public static string Location = "loc$";
        public static string priority = "priority$";
        public static string qualifier = "qual$";
        public static string InvLOc = "invLoc$";
        public static string StartDate = "startDt$";
        public static string DistNUm = "distNumber$";
        public static string DistName = "name$";
        public static string VendInvLoc = "VendInvLoc$";
        public static string MonDay = "day1$";
        public static string TuesDay = "day2$";
        public static string WedDay = "day3$";
        public static string ThursDay = "day4$";
        public static string FriDay = "day5$";
        public static string SatDay = "day6$";
        public static string SunDay = "day7$";
        public static string Symptom = "symptom$";
        public static string SymptomDesc = "symptomdesc$";
        public static string VendorTask = "venTask$";
        public static string VendorTaskDesc = "vendtaskdesc$";
        public static string StartDateVal = string.Empty;

        public class DistributorsTab
        {
            public string InvLoc { get; set; }
            public string StartDate { get; set; }
            public string DistributorNumber { get; set; }
            public string DistributorName { get; set; }
        }

        public class GeneralTab
        {
            public string MailingName { get; set; }
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string Country { get; set; }
            public string Zip { get; set; }
            public string Region { get; set; }
            public string County { get; set; }
            public string Contact { get; set; }
            public string Phone { get; set; }
            public string PhoneExt { get; set; }
            public string PartsContact { get; set; }
            public string PartsPhone { get; set; }
            public string PartsPhoneExt { get; set; }
            public string ServiceContact { get; set; }
            public string ServicePhone { get; set; }
            public string ServicePhoneExt { get; set; }
            public string CellPhone { get; set; }
            public string Fax { get; set; }
            public string EmailAddress { get; set; }
            public string WebAddress { get; set; }
            public string HubLocation { get; set; }
            public string HubLocationDesc { get; set; }
            public string InventoryLocationDesc { get; set; }
            public string InventoryLocation { get; set; }
            public string CommWOContact { get; set; }
            public string WOPhone { get; set; }
            public string WOPhoneEx { get; set; }
            public string WOAuthAmt { get; set; }
        }

        public class LocationsTab
        {
            public List<string> LocationsData { get; set; }
            public List<string> RemoveLocation { get; set; }
        }

        public class NotesTab
        {
            public string Notes { get; set; }
        }

        public class PayableTab
        {
            public string BillingType { get; set; }
            public bool RequireContracts { get; set; }
            public string SeparateCoreCharge { get; set; }
            public string TaxScheme { get; set; }
            public string FinanceApproved { get; set; }
            public string ExcludeInvoice { get; set; }
            public string NetTerms { get; set; }
            public string Discount { get; set; }
            public string For { get; set; }
            public string EEOCStatus { get; set; }
            public string CustomerAccountNumber { get; set; }
            public bool SameAsMailingAddress { get; set; }
            public string BillingName { get; set; }
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string Zip { get; set; }
            public string BillCountry { get; set; }
            public string Region { get; set; }
            public string County { get; set; }
            public string Contact { get; set; }
            public string Phone { get; set; }
            public string PhoneExt { get; set; }
            public string EmailAddress { get; set; }
            public string EmailPO { get; set; }
            public string SendPOTo { get; set; }
            public string VendorPOEmail { get; set; }
        }

        public class ReorderTab
        {
            public List<ReorderTabDatum> ReorderTabData { get; set; }
            public string ClearRow { get; set; }
            public bool ClearAll { get; set; }
        }

        public class ReorderTabDatum
        {
            public string InvLoc { get; set; }
            public bool Monday { get; set; }
            public bool Tuesday { get; set; }
            public bool Wednesday { get; set; }
            public bool Thursday { get; set; }
            public bool Friday { get; set; }
            public bool Saturday { get; set; }
            public bool Sunday { get; set; }
        }
        public class ServiceCodesTab
        {
            public string ServiceCode { get; set; }
            public string Description { get; set; }
            public string Location { get; set; }
            public string Priority { get; set; }
            public string Qualifier { get; set; }
        }

        public class VendorGatewayTab
        {
            public bool VendorTicket { get; set; }
            public string Variance { get; set; }
            public string JobLocation { get; set; }
            public List<VendorGateWayTableDatum> VendorGateWayTableData { get; set; }
        }

        public class VendorGateWayTableDatum
        {
            public string Symptom { get; set; }
            public string Description { get; set; }
            public string VendorTaskCode { get; set; }
            public string VendorTaskDesc { get; set; }
        }

        public class VendorMain
        {
            public List<string> VenNumberList { get; set; }         
            public List<string> VenNameList { get; set; }
            public string VenNumber { get; set; }
            public bool CopyVendor { get; set; }
            public string VenName { get; set; }
            public string Status { get; set; }
            public GeneralTab GeneralTab { get; set; }
            public PayableTab PayableTab { get; set; }
            public NotesTab NotesTab { get; set; }
            public List<ServiceCodesTab> ServiceCodesTab { get; set; }
            public LocationsTab LocationsTab { get; set; }
            public List<DistributorsTab> DistributorsTab { get; set; }
            public ReorderTab ReorderTab { get; set; }
            public ReorderTab VerifyReorderTab { get; set; }
            public VendorGatewayTab VendorGatewayTab { get; set; }
        }

        public class ChangeVendorNumber
        {
            public string ExistingVendorNo { get; set; }
            public string NewVendorNo { get; set; }
        }
       
    }
}
