﻿
namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class CustomerTypeCode
    {
        public  string CustomerType { get; set; }
        public  string CustomerDescription { get; set; }
        public  bool Disable { get; set; }


    }
}
