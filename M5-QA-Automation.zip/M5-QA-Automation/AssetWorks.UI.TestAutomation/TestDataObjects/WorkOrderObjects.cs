﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class WorkOrderObjects
    {
        public static string JobCode = "JobCode";

        public static string StockPartJobCode = "StockPartJobCode";

        public static string EmployeeCode = "EmployeeCode";

        public static string PartNo = "PartNo";

        public static string PartQty = "PartQty";

        public static string FailCode = "FailCode";

        public static string Position = "Position";

        public static string PRONumber = "PRONumber";

        public static string ExpectedPRONumber = "ExpectedPRONumber";

        public static string Vendor = "Vendor";

        public static string AddNonStockPartData = "AddNonStockPart";

        public static string EditNonStockPart = "EditNonStockPart";

        public static string AddCommercialCharge = "AddCommercialCharge";

        public static string EditCommercialCharge = "EditCommercialCharge";

        public static string FluidRecords = "FluidRecords";

        public static string WorkOrderClosed = "CLOSED";

        public static string WorkOrderOpen = "OPEN";

    }

    public class AddFluidRecord
    {
        public string UnitNo { get; set; }
        public string FluidJobCode { get; set; }
        public string HoseNo { get; set; }
        public string Quantity { get; set; }
        public string EmployeeCode { get; set; }
    }

    public class FluidData
    {
        public static string UnitNo = "UnitNo";    
        public FluidRecords FluidRecords { get; set; }
        public FluidEditRecords FluidEditRecords { get; set; }
    }

    public class FluidRecords
    {
        public List<AddFluidRecord> AddFluidRecords { get; set; }
    }

    public class FluidEditRecords
    {
        public List<AddFluidRecord> AddFluidRecords { get; set; }
    }

    public class Root1
    {
        public FluidData FluidData { get; set; }
    }


}
