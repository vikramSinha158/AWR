﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    public class EmployeeCourseQueryData
    {
        public string Course { get; set; }
        public string Location { get; set; }
        public string Employee { get; set; }
        public string ResourseType { get; set; }       
        public string AttPlanNext { get; set; }      
        public string VendorNo { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }    

    public class EmployeeCourseQuery
    {
        public EmpDetails EmployeeData { get; set; }
        public List<TrainingCourseDatum> TrainingCourseData { get; set; }
        public EmployeeCourseQueryData EmployeeCourseQueryData { get; set; }
        public List<VerifyQueryResult> VerifyQueryResult { get; set; }
    }

    public class VerifyQueryResult
    {
        public string Course { get; set; }
        public string Location { get; set; }
        public string Employee { get; set; }
        public string ResourseType { get; set; }  
        public string VendorNo { get; set; }
        public string DatePlanned { get; set; }
        public string DateAttended { get; set; }
        public string NextDate { get; set; }
        public string Result { get; set; }
        public string Mark { get; set; }
        public string Certificate { get; set; }
    }

}
