﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class WorkRequestIncident
    {
        public string WRType { get; set; }
        public string WRUnitNo { get; set; }
        public string WorkRequestNo { get; set; }
        public bool IsNewTicket { get; set; }
        public string Status { get; set; }
        public string Notes { get; set; }
        public string ReportedBy { get; set; }
        public string ContactNo { get; set; }
        public string FaildAtState { get; set; }       
        public string OpenDateTime { get; set; }
        public string LastIncidentStatusChange { get; set; }
        public string LastStatusChange { get; set; }
        public string ParkingLoc { get; set; }
        public string ServiceDate { get; set; }
        public string MaintLoc { get; set; }

        public AdditionalInfo AdditionalInfo { get; set; }
    }

    public class AdditionalInfo
    {
        public string Source { get; set; }
        public string Symptom { get; set; }
        public string Priority { get; set; }
        public string Zone { get; set; }
        public string Component { get; set; }
        public string Condition { get; set; }
        public string Run { get; set; }
        public string Block { get; set; }
    }
}
