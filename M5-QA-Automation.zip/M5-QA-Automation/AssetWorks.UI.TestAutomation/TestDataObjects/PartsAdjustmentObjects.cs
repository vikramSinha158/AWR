﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class PartsAdjustmentObjects
    {
        public string Number { get; set; }
        public string ReasonCode { get; set; }
        public string EmployeeNumber { get; set; }
        public string AdjustQty { get; set; }
        public string AdjustPrice { get; set; }
        public string Notes { get; set; }

        public string QtyOnHand { get; set; }
    }
}
