﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class EmpPlannedAbsences
    {
        public string EmployeeNo { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeStatus { get; set; }
        public string ShiftCode { get; set; }
        public string ShiftCodeDesc { get; set; }
        public string StartingPeriod { get; set; }
        public List<AbsencesDetails> AbsencesDetails { get; set; }
    }

    public class AbsencesDetails
    {
        public string IndirectAccount { get; set; }
        public string AccountDescription { get; set; }
        public string StartDate { get; set; }
        public string StartTime { get; set; }
        public string EndDate { get; set; }
        public string EndTime { get; set; }
        public string Description { get; set; }
        public string TimeType { get; set; }
        public string Union { get; set; }
        public string PayClass { get; set; }
        public string PayStep { get; set; }
        public bool IgnorePlannedAbsences { get; set; }
    }

}
