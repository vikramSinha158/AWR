﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class PositionCodeObjects
    {       
        public class CreatePositionCode
        {
            public string Code { get; set; }
            public string Desc { get; set; }
        }

        public class CreatePositionCodeWithAssociatesSystemPosition
        {
            public string Code { get; set; }
            public string Desc { get; set; }
            public string SystemCode { get; set; }
            public string ExpectedError { get; set; }            
        }

        public class PositionCodes
        {
            public PositionCodesData PositionCodesData { get; set; }
        }

        public class PositionCodesData
        {
            public CreatePositionCode CreatePositionCode { get; set; }
            public UpdatePositionCode UpdatePositionCode { get; set; }
            public CreatePositionCodeWithAssociatesSystemPosition CreatePositionCodeWithAssociatesSystemPosition { get; set; }
        }         

        public class UpdatePositionCode
        {
            public string Code { get; set; }
            public string Desc { get; set; }
        }
    }

    public class DirectAccountInformation
    {
        public List<string> DirectAccountList { get; set; }
        public string DirectAccount { get; set; }
        public string Description { get; set; }
        public string Disabled { get; set; }
    }

    public class IndirectAccountInfo
    {
        public List<string> IndirectAccountList { get; set; }
        public string AccountNo { get; set; }
        public string Description { get; set; }
        public string Disabled { get; set; }
        public Characteristics Characteristics { get; set; }
    }

    public class Characteristics
    {
        public bool CommercialChargesAllowed { get; set; }
    }
}
