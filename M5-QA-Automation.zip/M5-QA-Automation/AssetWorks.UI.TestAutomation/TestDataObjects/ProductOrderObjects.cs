﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class ProductOrderObjects
    {
        public string PONumber { get; set; }
        public string VendorNo { get; set; }
        public string ContractNo { get; set; }
        public List<ProductOrderDetail> ProductOrderDetail { get; set; }    
    }

    public class ProductOrderDetail
    {
        public string Product { get; set; }
        public string Tank { get; set; }
        public string UnitCost { get; set; }
        public string OrderQuantity { get; set; }
        public string ReceivedQuantity { get; set; }
        public bool CompleteLineCheck { get; set; }
        public bool TotalInvoiceVerification { get; set; }
    }
}
