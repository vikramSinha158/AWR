﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    public class ServiceOrderObjects
    {
        public string PONo { get; set; }
        public string PORefNo { get; set; }
        public string VendorNo { get; set; }
        public IList<ServiceOrderDetail> ServiceOrderDetail { get; set; }
    }

    public class ServiceOrderDetail
    {
        public string Service { get; set; }
        public string POCost { get; set; }
        public string NeededBy { get; set; }
        public string ResvCode { get; set; }
        public string ResvRefNo { get; set; }
        public string Note { get; set; }
    }

    public class ServiceOrderQueryDetail
    {
        public string Location { get; set; }
        public string VendorNo { get; set; }
        public string Status { get; set; }
        public string ServiceOrder { get; set; }
        public string ServiceCode { get; set; }
        public string ResvCode { get; set; }
        public string PoFromDate { get; set; }
        public string PoToDate { get; set; }
        public IList<SOList> SOList { get; set; }
    }

    public class SOList
    {
        public string Location { get; set; }
        public string ServiceOrderNo { get; set; }
        public string ServicePOAmt { get; set; }
        public string Status { get; set; }
        public string Vendor { get; set; }
        public string PORef { get; set; }
    }

    public class ServiceOrderReceiptDetail
    {
        public string Location { get; set; }
        public string OrderNo { get; set; }
        public string VendorNo { get; set; }
        public string InvoiceNo { get; set; }
        public string EffectiveDate { get; set; }
        public IList<ServicesDetail> ServicesDetail { get; set; }
    }

    public class ServicesDetail
    {
        public string Service { get; set; }
        public string POCost { get; set; }
        public string ReceivingCost { get; set; }
        public string ResvCode { get; set; }
        public string ResvRefNo { get; set; }
        public string Job { get; set; }
        public bool CompCheck { get; set; }
    }
}
