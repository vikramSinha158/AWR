﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class SystemAdminObjects
    {       
        public static string MaintenanceRole { get; set; }

        public static string MaintenanceRoleDesc { get; set; }

        public static string POLineValue = "POLineValue";

        public static string TotalPOValue = "TotalPOValue";

        public static string CommWOAuthAmount = "CommWOAuthAmount";

        public static string ApprovalAmount = "ApprovalAmount";

        public static string ServiceApprovalAmount = "ServiceApprovalAmount";

        public static string AddRoleMaintenance = "AddRoleMaintenance";

        public static string DatabaseUserId = "DatabaseUserId";

        public static string EditRoleMaintenance = "EditRoleMaintenance";

        public static string FillLocationsOperational = "FillLocationsOperational";

        public static string LocationsOperational = "LocationsOperational";

        public static string MenusKpi = "MenusKpi";

        public static string FillMenusKpi = "FillMenusKpi";

        public static string FillPrivileges = "FillPrivileges";

        public static string Privileges = "Privileges";

        public static string FillReporting = "FillReporting";

        public static string Reporting = "Reporting";

        public static string DepartmentsAndChatGrp = "DepartmentsAndChatGrp";

        public static string FillDepartmentsAndChatGrp = "FillDepartmentsAndChatGrp";

        public static string vGState = "vGState";

        public static string FillvGState = "FillvGState";

        public static string IndiractAccounts = "IndiractAccounts";

        public static string FillIndiractAccounts = "FillIndiractAccounts";

    }
}
