﻿using System.Collections.Generic;

public class CommercialMarkUp
{
    public string KindOfTransaction { get; set; }
    public string MarkUpPercent { get; set; }
    public string MarkUpLimit { get; set; }
}

public class LaborMarkUp
{
    public string KindOfTransaction { get; set; }
    public string MarkUpPercent { get; set; }
    public string LaborRate { get; set; }
    public string MarkUpLimit { get; set; }
}

public class PartMarkUp
{
    public string KindOfTransaction { get; set; }
    public string MarkUpPercent { get; set; }
    public string MarkUpLimit { get; set; }
}

public class CreateMarkUpScheme
{
    public string Scheme { get; set; }
    public string SchemeDesc { get; set; }
    public string DisableScheme { get; set; }
    public string EffectiveDate { get; set; }
    public string JobReason { get; set; }    
    public string FilltMarkUpMainData { get; set; }
    public string FillPartMarkUp { get; set; }
    public string FIllLaborMarkUp { get; set; }
    public string FIllCommercialMarkUp { get; set; }  
    public List<PartMarkUp> PartMarkUp { get; set; }
    public List<LaborMarkUp> LaborMarkUp { get; set; }
    public List<CommercialMarkUp> CommercialMarkUp { get; set; }
}

public class CopyMarkUpScheme
{
    public string ExistingScheme { get; set; }
    public bool CopyAllDate { get; set; }
    public bool CopyAllReasons { get; set; }
    public string EffectiveDate { get; set; }
    public string JobReason { get; set; }
    public string NewScheme { get; set; }
    public string NewSchemeDesc { get; set; }
    public string NewJobReason { get; set; }
    public bool NewDate { get; set; }
    public string NewEffectiveDate { get; set; }

}
