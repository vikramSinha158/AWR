﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    public class CreateEmployee
    {
        public CreateEmployeeMoreParameters CreateEmployeeMoreParameters { get; set; }
        public CreateEmployeeRequiredParameters CreateEmployeeRequiredParameters { get; set; }
    }

    public class CreateEmployeeMoreParameters
    {
        public Flags Flags { get; set; }
        public List<SystemFlag> SystemFlags { get; set; }
        public EmployeeData EmployeeData { get; set; }
    }

    public class CreateEmployeeRequiredParameters
    {
        public Flags Flags { get; set; }
        public List<SystemFlag> SystemFlags { get; set; }
        public EmployeeData EmployeeData { get; set; }
    }
    public class SystemFlag
    {
        public string FlagNo { get; set; }
        public string Value { get; set; }
    }
    public class EmployeeData
    {
        public List<string> EmployeeID { get; set; }
        public string EmpName { get; set; }
        public string Status { get; set; }
        public string Title { get; set; }
        public string SkillLevel { get; set; }
        public string ShiftCode { get; set; }
        public string ShiftCodeDesc { get; set; }
        public string AuthChargeTime { get; set; }
        public bool UsePayrollRates { get; set; }
        public bool MarkUpScheme { get; set; }
        public string EffectiveDate { get; set; }
        public bool Unit { get; set; }
        public bool WorkOrder { get; set; }
        public bool IndAcct { get; set; }
        public bool DiAcct { get; set; }
        public bool Department { get; set; }
        public string TripCardPin { get; set; }
        public bool StartDate { get; set; }
        public bool TermDate { get; set; }
        public string Phone { get; set; }
        public bool PhoneToVerify { get; set; }
        public string PhonExt { get; set; }
        public string Email { get; set; }
        public string Pin { get; set; }
        public string Suprvisor { get; set; }
        public string Contractor { get; set; }
        public string DeptContact { get; set; }
        public string Exempt { get; set; }
        public string Driver { get; set; }
        public string Technician { get; set; }
        public string AddJobsLabor { get; set; }
        public string TimeKeper { get; set; }
        public string MPAppReq { get; set; }
        public string InvEmp { get; set; }
        public string Temporary { get; set; }
        public string EmpNotes { get; set; }
        public string PrimaryPayClass { get; set; }
        public string PrimaryPaystep { get; set; }
        public string PrimaryDescription { get; set; }
        public string SecPayClass { get; set; }
        public string SecPaystep { get; set; }
        public string SecondaryDescription { get; set; }
        public string TerPayClass { get; set; }
        public string TerPaystep { get; set; }
        public string TertiaryDescription { get; set; }
        public string SupervisorID { get; set; }
        public string DeptNO { get; set; }
        public string DepartmentDesc { get; set; }
        public string VendorNO { get; set; }
        public string VendorDesc { get; set; }
        public string GroupNO { get; set; }
        public string GroupDescription { get; set; }
        public string TimeType { get; set; }
        public bool ResourceType { get; set; }
        public string ExpireDate { get; set; }
        public string DriverNo { get; set; }
        public string TaxformOnFile { get; set; }
        public string LicenseNo { get; set; }
        public bool LicenseExpiry { get; set; }
        public string DriverStatus { get; set; }
        public string DriverStatusDesc { get; set; }
        public string DriverClass { get; set; }
        public string DriverClassDesc { get; set; }
        public string DriverType { get; set; }
        public string DriverTypeDesc { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Region { get; set; }
        public string Municipality { get; set; }
        public string Country { get; set; }
        public string Mobile { get; set; }
        public bool MobileVerify { get; set; }
        public string Usage { get; set; }
        public string BusinessUsage { get; set; }
        public bool RestMPReservation { get; set; }
        public string HomeLocation { get; set; }
        public string HomeLocationDescription { get; set; }
        public string SupervisorIDAfterTransfer { get; set; }
        public bool CreateMotolPoolClass { get; set; }
    }   
    public class Flags
    {
        public string FillPayrollTab { get; set; }
        public string FillResourceTypeTab { get; set; }
        public string FillDriverInformationTab { get; set; }
        public string FillMotorPoolTab { get; set; }
        public string VerifySubordinatesTab { get; set; }
    }

    public class SupervisorInformation
    {
        public string Supervisor1 { get; set; }
        public string Supervisor2 { get; set; }
        public List<string> Supervisor1EmpID { get; set; }
        public List<string> Supervisor2EmpID { get; set; }
        public List<string> Supervisor1OneEmpID { get; set; }
        public List<string> Supervisor2OneEmpID { get; set; }
        public List<string> Supervisor1ActEmpID { get; set; }
        public List<string> Supervisor2ActEmpID { get; set; }
    }

    public class EmployeeTransfer
    {
        public SupervisorInformation SupervisorInformation { get; set; }
    }

    public class EmployeeShiftAssign
    {
        public List<ShiftDatum> ShiftData { get; set; }
    }
    public class ShiftDatum
    {
        public string ShiftCode { get; set; }
        public string EffectiveDate { get; set; }

    }
    public class EmployeeCopyID
    {
        public string EmployeeIDToCopy { get; set; }
        public string NewEmployeeID { get; set; }
    }

    public class EmployeeItems
    {
        public string EmployeeID { get; set; }

        public IList<ItemInformation> ItemInformation { get; set; }
    }

    public class ItemInformation
    {
        public string Item { get; set; }
        public string Type { get; set; }
        public string Value { get; set; }
    }
}


