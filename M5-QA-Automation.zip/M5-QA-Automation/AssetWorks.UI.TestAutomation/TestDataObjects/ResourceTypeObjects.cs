﻿

using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class ResourceType
    {
        public string Resource { get; set; }
        public List<string> ResourceList { get; set; }
        public string Description { get; set; }
        public List<string> DescriptionList { get; set; }
        public string MarkupScheme { get; set; }
        public bool Disable { get; set; }        
    }

}
