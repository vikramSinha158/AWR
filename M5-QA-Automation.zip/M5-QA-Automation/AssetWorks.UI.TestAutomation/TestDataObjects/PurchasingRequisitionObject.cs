﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class PurchasingRequisitionObject
    {
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class PartDetail
    {
        public string PRVendor { get; set; }
        public bool PRQuoted { get; set; }
        public bool NotesToVendo { get; set; }
        public string  ApprovalResvRefNo { get; set; }
        public bool QuotedCheckBox { get; set; }
        public bool VendorCheckBox { get; set; }
        public List<PartRequisitionData> PartRequisitionData { get; set; }
    }

    public class PartPurchaseRequisition
    {
        public PartDetail PartDetail { get; set; }
    }

    public class PartRequisitionData
    {
        public string PartNo { get; set; }
        public string Quantity { get; set; }
        public string UnitCost { get; set; }
        public string NeededBy { get; set; }
        public string ReservationCode { get; set; }
        public string ResvRefNo { get; set; }
        public string RefNo { get; set; }      
        public bool Approval { get; set; }
        public string RejectionReason { get; set; }
        public bool AddNote { get; set; }
        public string AddNoteDetail { get; set; }
        public bool PRQuoted { get; set; }
        public string PartDesc { get; set; }
        public string Unitinv { get; set; }
    }

    public class PurchaseRequisition
    {
        public PartPurchaseRequisition PartPurchaseRequisition { get; set; }
    }
}
