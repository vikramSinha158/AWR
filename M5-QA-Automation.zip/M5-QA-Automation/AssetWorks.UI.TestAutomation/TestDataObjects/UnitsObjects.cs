﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class UnitsObjects
    {
        public static string DeptKeyword = "DeptKeyword";

        public static string DeptOwning = "DeptOwning";

        public static string DeptUsing = "DeptUsing";
    }

    public class UnitMain
    {
        public bool IsAddNew { get; set; }
        
        public string UnitNo { get; set; }

        public string UnitDescription { get; set; }

        public string UnitStatus { get; set; }

        public string AlternateUnitNo { get; set; }

        public AssetCodesTab AssetCodesTab { get; set; }

        public DeptLocationsTab DeptLocationsTab { get; set; }

        public ClassTab ClassTab { get; set; }

        public MeterAccountingTab MeterAccountingTab { get; set; }

        public LicenseNotesTab LicenseNotesTab { get; set; }
    }

    public class AssetCodesTab
    {
        public string MCC { get; set; }
        public string ActivityCode { get; set; }
        public string TechSpecNo { get; set; }
        public string AssetType { get; set; }
        public string EquipmentType { get; set; }
        public string LicenseClassCode { get; set; }
        public string Retrofitted { get; set; }
        public string RetrofittedDesc { get; set; }
        public string BillingCode { get; set; }
        public string HighPriority { get; set; }
        public string Telematics { get; set; }
        public string TelematicsMeter { get; set; }
        public string ConditionCode { get; set; }
        public string CalibrationDate { get; set; }
        public string CalibrationExpiresDate { get; set; }
        public string EmployeeOwned { get; set; }
        public string EmployeeNumber { get; set; }
        public string AttSerialNo { get; set; }
        public string AttTechSpecNo { get; set; }
        public string SerialNumber { get; set; }
    }

    public class ClassTab
    {
        public string ShiftCode1 { get; set; }
        public string ShiftCode2 { get; set; }
        public string ShiftCode3 { get; set; }
        public string ShiftCode4 { get; set; }
        public string ShiftCode5 { get; set; }
        public string Class1 { get; set; }
        public string Class2 { get; set; }
        public string Class3 { get; set; }
        public string Class4 { get; set; }
        public string Class5 { get; set; }
    }

    public class DeptLocationsTab
    {
        public string Customer { get; set; }
        public string Owning { get; set; }
        public string Using { get; set; }
        public string Parking { get; set; }
        public string Maintenance { get; set; }
        public string Fueling { get; set; }
        public string Delivery { get; set; }
        public string Current { get; set; }
        public string BinNo { get; set; }
        public string Operator { get; set; }
        public string SharePool { get; set; }
        public string MotorPoolClass { get; set; }
        public string MotorPoolLocation { get; set; }
    }

    public class LicenseNotesTab
    {
        public string LicenseNo { get; set; }
        public string VEDClass { get; set; }
        public string UnitNotes { get; set; }
        public string UnitWONotes { get; set; }
        public string CustomerNotes { get; set; }
    }

    public class MeterAccountingTab
    {
        public string AcqPrimaryMeter { get; set; }
        public string AcqSecondaryMeter { get; set; }
        public string AcquisitionDate { get; set; }
        public string ArrivalDate { get; set; }
        public string SerPrimaryMeter { get; set; }
        public string SerSecondaryMeter { get; set; }
        public string InServiceDate { get; set; }
        public string ManufactureDate { get; set; }
        public string MarkupScheme { get; set; }
        public string PONumber { get; set; }
        public string TotalPurchasePrice { get; set; }
        public string TaxExemption { get; set; }
    }

    public class NonCompanyUnit
    {
        public string NCUnitNo { get; set; }
        public string NCUStatus { get; set; }
        public string NCUStatusChangeDate { get; set; }
        public string NCUDesc { get; set; }
        public string NCUYear { get; set; }
        public string NCUManufacturer { get; set; }
        public string NCUMake { get; set; }
        public string NCUModel { get; set; }
        public string NCUCategoryNo { get; set; }
        public string NCUCategoryNumDesc { get; set; }
        public string NCUGPW { get; set; }
        public string NCUMeter { get; set; }
        public string NCUMeterDate { get; set; }
        public string NCUUsingDept { get; set; }
        public string NCUUsingDeptDesc { get; set; }
        public string NCUParkingLocation { get; set; }
        public string NCUParkingLocDesc { get; set; }
        public string NCULicenseClass { get; set; }
        public string NCULicenseClassDesc { get; set; }
        public string NCULicenseCategory { get; set; }
        public string NCUColor { get; set; }
        public string NCUSeatingCap { get; set; }
        public string NCUFuelProduct { get; set; }
        public string NCUFuelProductName { get; set; }
        public string NCUVehicleRef { get; set; }
        public string NCUVehicleOwner { get; set; }
        public string NCUDriverType { get; set; }
        public string NCUDriverNo { get; set; }
        public string NCUDriverDesc { get; set; }
        public string NCURegistrationRef { get; set; }
        public string NCURegExpiry { get; set; }
        public string NCUInspectionCert { get; set; }
        public string NCUInspExpiry { get; set; }
        public string NCUInspectionRef { get; set; }
        public string NCUServiceRef { get; set; }
        public string NCULastServiceDt { get; set; }
        public string NCUServiceDueDt { get; set; }
        public string NCUInsuranceCo { get; set; }
        public string NCUInsurancePolicy { get; set; }
        public string NCUInsuranceRef { get; set; }
        public string NCUInsuranceExpiry { get; set; }
    }

    public class UnitPurchaseOrder
    {
        public string PONo { get; set; }
        public string PODesc { get; set; }
        public string POStatus { get; set; }
        public string ErrorMessage { get; set; }
        public PODetail PODetail { get; set; }
        public List<POUnit> POUnits { get; set; }
        public List<POPayment> POPayments { get; set; }
        public List<PONonUnitCharge> PONonUnitCharges { get; set; }
    }

    public class PODetail
    {
        public string POVendorNo { get; set; }
        public string POVendorName { get; set; }
        public string POTenderNo { get; set; }
        public string POAddress { get; set; }
        public string POPhone { get; set; }
        public string POPhoneEx { get; set; }
        public string POCity { get; set; }
        public string POState { get; set; }
        public string POLimit { get; set; }
        public string POTechSpecNo { get; set; }
        public string POTechSpecDesc { get; set; }
        public string POCreation { get; set; }
        public string POExpiration { get; set; }
        public string PONotes { get; set; }
    }

    public class POUnit
    {
        public bool addNew { get; set; }
        public string POUnitNo { get; set; }
        public string PODeliveryDate { get; set; }
        public string POOriginalAmt { get; set; }
        public string POChangeAmt { get; set; }
        public string POTotalAmt { get; set; }
        public string POStatus { get; set; }
    }

    public class POPayment
    {
        public bool addNew { get; set; }
        public string POInvoiceNo { get; set; }
        public string POPaymentDate { get; set; }
        public string POUnitNo { get; set; }
        public string POPaymentAmt { get; set; }
        public string POCheckNo { get; set; }
        public string POVoucherNo { get; set; }
        public string POPackingSlip { get; set; }
        public string PONote { get; set; }
    }

    public class PONonUnitCharge
    {
        public bool addNew { get; set; }
        public string POInvoiceNo { get; set; }
        public string POPaymentDate { get; set; }
        public string POPaymentAmt { get; set; }
        public string POCheckNo { get; set; }
        public string PONote { get; set; }
    }

    public class GroupUnit
    {
        public string UnitGroupName { get; set; }
        public List<string> GroupUnitList { get; set; }
        public GroupUnitDetail GroupUnitDetail { get; set; }
    }

    public class GroupUnitsData
    {
        public string UnitNo { get; set; }
        public bool LeadUnit { get; set; }
        public bool AddUnitNo { get; set; }
    }

    public class GroupUnitDetail
    {     
        public string UnitNo { get; set; }
    
        public List<GroupUnitsData> GroupUnitData { get; set; }
    }

    public class UnitPurchaseRequisition
    {
        public string UnitNo { get; set; }
        public string UnitDesc { get; set; }
        public bool IsAddNew { get; set; }
        public bool IsCancel { get; set; }
        public UPRDetailTab DetailTab { get; set; }
        public UPRPOListTab POListTab { get; set; }
        public UPRCategoryOptionsTab CategoryOptionsTab { get; set; }
    }

    public class UPRDetailTab
    {
        public string RequisitionNo { get; set; }
        public string BudgetYear { get; set; }
        public string Requested { get; set; }
        public string ExpectedDelivery { get; set; }
        public string ReplacementFund { get; set; }
        public string OwnerDept { get; set; }
        public string UsingDept { get; set; }
        public string DeliveryLocation { get; set; }
        public string CustomerNotes { get; set; }
    }

    public class UPRPOListTab
    {
        public List<POList> POList { get; set; }
    }

    public class POList
    {
        public bool FromLOV { get; set; }
        public string PONumber { get; set; }
        public bool PrimaryPO { get; set; }
        public string PurchaseAmount { get; set; }
        public string ChangeOrder { get; set; }
        public string Vendor { get; set; }
    }

    public class UPRCategoryOptionsTab
    {
        public string CategoryCode { get; set; }
        public bool OptionSelections { get; set; }
    }

    public class UnitRequest
    {
        public List<string> RequestNoList { get; set; }
        public string RequestNo { get; set; }
        public string ReqUnitNo { get; set; }
        public string ReqStatus { get; set; }
        public bool NewRequest { get; set; }
        public bool NewUnit { get; set; }
        public string ReqType { get; set; }
        public string Requestor { get; set; }
        public string ReqOwnership { get; set; }
        public string ReqDeliveryDate { get; set; }
        public string ReqApprover { get; set; }
        public string ReqRejectReason { get; set; }
        public string ReqLeaseType { get; set; }
        public ReqDetail ReqDetail { get; set; }
        public ReqCategoryOptions ReqCategoryOptions { get; set; }
        public ReqClass ReqClass { get; set; }
    }

    public class ReqDetail
    {
        public string ReqReplacesUnit { get; set; }
        public string ReqDisposalStatus { get; set; }
        public string ReqOwnerDept { get; set; }
        public string ReqEstimatedDate { get; set; }
        public string ReqUsingDept { get; set; }
        public string ReqDisposalReason { get; set; }
        public string ReqParkingLoc { get; set; }
        public string ReqEmployee { get; set; }
        public string ReqMaintLoc { get; set; }
        public string ReqFuelLoc { get; set; }
        public string ReqDelLoc { get; set; }
        public string ReqActivity { get; set; }
        public string ReqTechSpec { get; set; }
        public string ReqMcc { get; set; }
        public string ReqOperator { get; set; }
        public string ReqNotes { get; set; }
    }

    public class ReqCategoryOptions
    {
        public string ReqCategoryCode { get; set; }
        public bool ReqOptionSelection { get; set; }
    }

    public class ReqClass
    {
        public string ReqClass1 { get; set; }
        public string ReqClass2 { get; set; }
        public string ReqClass3 { get; set; }
        public string ReqClass4 { get; set; }
        public string ReqClass5 { get; set; }
    }
    
    public class UnitRequestApprove
    {
        public string ParkingLoc { get; set; }
        public string MaintenanceLoc { get; set; }
        public string UsingDept { get; set; }
        public string OwningDept { get; set; }
        public string Requestor { get; set; }
        public string RequestNo { get; set; }
        public string UnitNo { get; set; }
        public string Approver { get; set; }
    }
    
    public class LeadUnit
    {
        public string UnitGroup { get; set; }
        public string UnitNo { get; set; }
        public string ErrorMessage1 { get; set; }
        public string ErrorMessage2 { get; set; }
        public UnitsInTheGroup UnitsInTheGroup { get; set; }
        public string SearchText { get; set; }

    }

    public class QA445CannotAddUnitWithoutCheckingLeadUnitCheckbox
    {
        public LeadUnit LeadUnit { get; set; }
        public UnitGroup UnitGroup { get; set; }
    }
    
    public class UnitsInTheGroup
    {
        public string UnitOne { get; set; }
        public string UnitTwo { get; set; }
    }

    public class UnitGroup
    {
        public string UnitGroupNumber { get; set; }
        public string UnitNumber { get; set; }
        public string ErrorMessage1 { get; set; }
        public string ErrorMessage2 { get; set; }

    }
}
