﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class BillingAppointmentObjects
    {       
        public static string JobCode = "bjJob$r";
        public static string JobDesc= "bjJob_Desc$r";       
        public static string JobReason = "bjJob_Reason$r";
        public static string JobQty = "bjJob_Qty$r";
        public static string TotalCost = "bjJob_Total_Cost$r";
        public static string LaborCost = "bjJob_Labor_Cost$r";
        public static string PartCost = "bjJob_Part_Cost$r";
        public static string LaborTime = "bjLabor_Time$r";
        public static string ShopTime = "bjShop_Time$r";
        public static string BillFixed = "bjBill_Fixed$r";
        public static string DateAdded = "bjDate_Added$r";
        public static string RequestedDate;
    }

    public class JobInfo
    {      
        public string JobCode { get; set; }
        public string JobDesc { get; set; }
        public string Status { get; set; }
        public string ChangeStatus { get; set; }
        public string Reason { get; set; }
        public string JobQuantity { get; set; }
        public string LaborTime { get; set; }
        public string ShopTime { get; set; }
        public bool BillFixed { get; set; }
        public string TotalCost { get; set; }
        public string LaborCost { get; set; }
        public string PartCost { get; set; }
        public string DateAdded { get; set; }
        public string AuthorizedBy { get; set; }
        public string AuthorizedOn { get; set; }
    }

    public class BookingAppointment
    {
        public bool NewBooking { get; set; }
        public string UnitNO { get; set; }
        public string UnitDesc { get; set; }
        public string CustNO { get; set; }
        public string CustDesc { get; set; }
        public string BookingStatus { get; set; }
        public string BookingNumber { get; set; }
        public string Location { get; set; }
        public string EquipProfile { get; set; }
        public string BookingReference { get; set; }
        public string BookingSource { get; set; }
        public string BookingType { get; set; }
        public List<JobInfo> JobInfo { get; set; }
        public string RequestedDate { get; set; }
        public string RequestPeriod { get; set; }
        public string BookingDate { get; set; }
        public string BookingPeriod { get; set; }
    }
}
