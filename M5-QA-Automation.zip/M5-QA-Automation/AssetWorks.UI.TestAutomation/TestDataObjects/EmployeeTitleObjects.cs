﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{   
    public class CreateEmployeeTitle
    {
        public string Title { get; set; }
        public int Productivity { get; set; }
        public bool Disabled { get; set; }        
    }

    public class EmployeeTitle
    {
        public EmployeeTitleData EmployeeTitleData { get; set; }
    }

    public class EmployeeTitleData
    {
        public CreateEmployeeTitle CreateEmployeeTitle { get; set; }
        public CreateEmployeeTitle UpdateEmployeeTitle { get; set; }
        public List<SystemFlag> SystemFlags { get; set; }
        public string EmployeeID { get; set; }

    }

}


