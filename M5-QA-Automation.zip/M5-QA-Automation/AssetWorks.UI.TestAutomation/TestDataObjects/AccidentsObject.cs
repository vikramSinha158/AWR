﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.UnitsObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class AccidentType
    {
        public string ATName { get; set; }
        public string ATDescription { get; set; }
        public bool ATDisabled { get; set; }
        public bool Reauthenticate { get; set; }
        public string Password { get; set; }
    }

    public class AccidentCategory
    {
        public string CategoryCode { get; set; }
        public string CategoryDescription { get; set; }
  
        public bool CategoryEnable { get; set; }

        public bool CategoryDisable { get; set; }
    }

    public class AccidentCause
    {
        public string CauseNo { get; set; }
        public string CauseDescription { get; set; }
        public bool CauseEnable { get; set; }
    }

    public class CreateAccidentType
    {
        public string TypeName { get; set; }
        public string TypeDescription { get; set; }
    }

    public class AccidentEntry
    {
        public bool IsAddNew { get; set; }
        public string AccidentNo { get; set; }
        public string UnitNo { get; set; }     
        public UnitInformationTab UnitInformationTab { get; set; }
        public VendorEstimateTab VendorEstimateTab { get; set; }
        public WorkRequestTab WorkRequestTab { get; set; }
        public IList<InsuranceClaims> insuranceClaimsTab { get; set; }
        public IList<Payments> paymentsTab { get; set; }
        public AccidentDetailTab accidentDetailTab { get; set; }
        public UnitDamageTab unitDamageTab { get; set; }
    }

    public class VendorEstimateTab
    {
        public string VendorNo { get; set; }
        public string RefNo { get; set; }
        public string LaborHours { get; set; }
        public string LaborCost { get; set; }
        public string PartCost { get; set; }
        public string CommCost { get; set; }
        public string MiscCost { get; set; }
        public string Tax { get; set; }
    }

    public class WorkRequestTab
    {
        public string WRJobCode { get; set; }
        public string WRJobDesc { get; set; }
        public string WRJobReason { get; set; }
        public string WRShift { get; set; }
        public string WRLocation { get; set; }
        public string WROccurence { get; set; }
        public string WRVisitReason { get; set; }
        public string WREarliestDate { get; set; }
        public string WRDueDate { get; set; }
        public string WRLatestDate { get; set; }
        public string WRHrs { get; set; }
        public string WRCost { get; set; }
    }

    public class UnitInformationTab
    {
        public string Operator { get; set; }

        public string Name { get; set; }

        public string DriverLicense { get; set; }

        public string Country { get; set; }

        public string State { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public string Supervisor { get; set; }

        public string InsuranceCompany { get; set; }

        public string PolicyNo { get; set; }

        public string ExpiryDate { get; set; }

        public string ContactPhone { get; set; }

        public string ValidateContactPhone { get; set; }

        public string TripOrig { get; set; }

        public string Destination { get; set; }

        public string StartTime { get; set; }
        public string Purpose { get; set; }
        public bool Scope { get; set; }
        public bool Route { get; set; }
        public bool Activity { get; set; }
        public bool WorkHours { get; set; }
        public bool OnDuty { get; set; }
    }

    public class InsuranceClaims
    {
        public string Order { get; set; }
        public string InsuranceClaim { get; set; }
        public string InsurantName { get; set; }
        public string Phone { get; set; }
        public string Policy { get; set; }
        public string Fax { get; set; }
        public string EmailAddress { get; set; }
        public string RepName { get; set; }
        public string SentDate { get; set; }
        public string ReceiptConfirmDate { get; set; }
        public string OfferAmt { get; set; }
        public string DateTo { get; set; }
        public string ApprovalDate { get; set; }
        public string PDClaim { get; set; }
        public string ComptrollerClaim { get; set; }
        public string ClaimAmt { get; set; }
        public string ThirdPartySettlement { get; set; }
    }

    public class Payments
    {
        public string Order { get; set; }
        public string Claim { get; set; }
        public string PayDate { get; set; }
        public string CheckNo { get; set; }
        public string PaidBy { get; set; }
        public string AmountReceived { get; set; }
        public string PaymentNo { get; set; }
        public string PaymentType { get; set; }
    }

    public class AccidentDetailTab
    {
        public string AccidentDate { get; set; }
        public string Address1 { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string AccidentType { get; set; }
        public string AccidentCause { get; set; }
        public string WeatherCondition { get; set; }
        public string RoadCondition { get; set; }
        public string Visibility { get; set; }
        public bool SeatBeltUsed { get; set; }
        public bool PersonalInjury { get; set; }
        public bool Fatalities { get; set; }
        public bool PoliceReport { get; set; }
        public string ReportNo { get; set; }
        public string PoliceDept { get; set; }
        public string OfficerName { get; set; }
        public string PoliceAddress { get; set; }
        public string PoliceCity { get; set; }
        public string PoliceState { get; set; }
        public string PoliceZip { get; set; }
        public string PoliceCountry { get; set; }
        public bool DrugFlag { get; set; }
        public string Sobriety { get; set; }
        public string DateCleared { get; set; }
        public List<WitnessDetails> witnessDetails { get; set; }
    }

    public class WitnessDetails
    {
        public string SeqNo { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Phone { get; set; }
        public bool Victim { get; set; }
        public bool Witness { get; set; }
        public bool Passenger { get; set; }
        public string Age { get; set; }
        public string Sex { get; set; }
        public string DateOfBirth { get; set; }
        public string VehicleOccupied { get; set; }
        public string PositionInVehicle { get; set; }
        public bool SafetyEquipUsed { get; set; }
        public string Injury { get; set; }
        public string Rank { get; set; }
        public string TransportedBy { get; set; }
        public string TransportedTo { get; set; }
        public string DateOfDeath { get; set; }
    }

    public class UnitDamageTab
    {
        public string ClaimNo { get; set; }
        public string ClaimStatus { get; set; }
        public string EstimateRepair { get; set; }
        public string OtherPartyActual { get; set; }
        public string WriteOff { get; set; }
        public string BuyBackAmt { get; set; }
        public string SubrogationAmount { get; set; }
    }

}