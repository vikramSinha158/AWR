﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking
{
    public class CustomerMainObjects
    {

        public static string CustomerMainNumber { get; set; }
        public static string AddDataForCustomerMain = "AddDataForCustomerMain";
        public static string AddDataForCustomerMainActive = "AddDataForCustomerMainActive";
        public static string EditDataForCustomerMain = "EditDataForCustomerMain";
        public static string Address1 = "Address1";
        public static string City = "City";
        public static string State = "State";
        public static string Zip = "Zip";
        public static string Country = "Country";
        public static string BillingFrequency = "BillingFrequency";
        public static string OwningDepartment = "OwningDepartment";
        public static string InitialJobStatus = "InitialJobStatus";
        public static string CustomerType = "CustomerType";
        public static string Status = "Status";

        public class CustomerMain
        {
            public string CustomerID { get; set; }
            public string CustomerDesc { get; set; }
            public List<string> CustomerIDList { get; set; }
            public List<string> CustomerDescList { get; set; }
            public string CustomerStatus { get; set; }
            public GeneralTab GeneralTab { get; set; }
            public UnitsTab UnitsTab { get; set; }
            public bool CheckLOVstatus { get; set; }
        }

        public class GeneralTab
        {
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public string City { get; set; }
            public string Zip { get; set; }
            public string Country { get; set; }
            public string State { get; set; }
            public string Phone { get; set; }
            public string PhoneExt { get; set; }
            public string MobilePhone { get; set; }
            public string Email { get; set; }
            public string OwningDepartment { get; set; }
            public string InitialJobStatus { get; set; }
            public string BillingFrequency { get; set; }
            public string CustomerType { get; set; }
        }

        public class UnitsTab
        {
        }


        public class CreateCustomerContract
        {
            public string Status { get; set; }
            public string StartDate { get; set; }
            public string AwardDate { get; set; }
            public string AwardAmount { get; set; }

            public string ContractNotes { get; set; }
            public string BookingNotes { get; set; }
            public List<JobsTabData> JobsTab { get; set; }
            public List<PartsMatrixData> PartsMatrixTab { get; set; }

            public List<LaborMatrixData> LaborMatrixTab { get; set; }

            public List<Fluids> Fluids { get; set; }

            public List<FixedPriceParts> FixedPriceParts { get; set; }
        }

        public class CreateCustomerContractCopy
        {
            public string contract { get; set; }
            public string CustomerNumber { get; set; }

            public string NewCustomerNumber { get; set; }

            public string StartDate { get; set; }

        }

        public class JobsTabData
        {
            public string Job { get; set; }
            public string JobDescription { get; set; }
            public string FixedPrice { get; set; }

        }

        public class PartsMatrixData
        {
            public string Manufacturer { get; set; }
            public string Vendor { get; set; }
            public string SystemCode { get; set; }
        }

        public class LaborMatrixData
        {
            public string Location { get; set; }

            public string AssetClass { get; set; }

            public string LaborRateHour { get; set; }
        }

        public class Fluids
        {
            public string Product { get; set; }

            public string Description { get; set; }

            public string Markup { get; set; }
        }

        public class FixedPriceParts
        {
            public string Part { get; set; }

            public string Manufacturer { get; set; }

            public string Description { get; set; }

            public string FixedPrice { get; set; }
        }
    }
}
