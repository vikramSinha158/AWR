﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class FuelProducts
    {
            public string productNumber { get; set; }
            public string Description { get; set; }
            public string Type { get; set; }
            public string UnitIssue { get; set; }
            public string UnitIssueDesc { get; set; }
            public string Markup { get; set; }
            public string AssociatedPart { get; set; }
            public string AssociatedPartDesc { get; set; }
            public string FuelType { get; set; }
            public string FuelTypeDesc { get; set; }
            public string FuelInsideBillItem { get; set; }
            public string FuelInsideBillItemDesc { get; set; }
            public string FuelOutsideBillItem { get; set; }
            public string FuelOutsideBillItemDesc  { get; set; }
            public string FuelMarkupBillItem { get; set; }
            public string FuelMarkupBillItemDesc { get; set; }
            public string FuelUnitPrice { get; set; }           
            public string FuelFlatMarkup { get; set; }
            public string FuelMarkup { get; set; }
            public string JobReason { get; set; }
            public string JobReasonDesc { get; set; }
            public string JobCode { get; set; }
            public string JobCodeDesc { get; set; }
            public bool CarWebProduct { get; set; }
            public string ApplyTax { get; set; }
    }
}
