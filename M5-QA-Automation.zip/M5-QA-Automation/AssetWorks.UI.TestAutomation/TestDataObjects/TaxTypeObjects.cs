﻿
namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    public class AddTaxTypeRecord
    {      
        public bool Disabled { get; set; }
    }

    public class CreateTaxType
    {
        public AddRecords AddRecord { get; set; }
        public EditRecord EditRecord { get; set; }

    }

    public class EditTaxTypeRecord
    {
        public bool Disabled { get; set; }
    }    
   
}