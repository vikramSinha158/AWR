﻿using System;
using AssetWorks.UI.M5.TestAutomation.Common;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Utils;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class StandardJobMCCObjects
    {

        public static string StandardMCCCode { get; set; }

        public static string StandardMCCJobCodeKey = "AddDataForStandardMCCJobCode";

        public static string MCCJOobCode = "MCCJobCode";

        public static string RecurringIntervalDays = "RecurringIntervalDays";

        public static string SchedulingBasis = "SchedulingBasis";

        public const string SeasonalRestriction = "SeasonalRestriction";

        public static string VisitReason = "VisitReason";

        public static string Priority = "Priority";

        public static string OverduePriority = "OverduePriority";

        public static string EditDataForStandardMCCJobCode = "EditDataForStandardMCCJobCode";

    }
} 
