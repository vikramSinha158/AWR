﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    public class EmpLaborWedge
    {
        public string EmployeeNo { get; set; }
        public string NWOUnitNo { get; set; }
        public string NWOIndCode { get; set; }
        public string NewJobCode { get; set; }
        public string NewPosition { get; set; }
        public string WoTimeType { get; set; }
        public string WoPayClass { get; set; }
        public string WoPayStep { get; set; }
        public string NewPunchTime { get; set; }
        public string JobStatus { get; set; }
    }
}
