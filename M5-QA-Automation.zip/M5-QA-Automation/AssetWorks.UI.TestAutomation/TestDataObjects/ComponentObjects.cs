﻿namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    internal class ComponentObjects
    {
    }

    public class Component
    {
        public ComponentMain ComponentMain { get; set; }
    }

    public class ComponentMain
    {
        public string TechSpecnumber { get; set; }
        public string MCC { get; set; }
        public string LocationShared { get; set; }
        public string SystemCode { get; set; }
        public string FillOtherComponentFields { get; set; }
        public string BinNumber { get; set; }
        public string Maintenance { get; set; }
        public string  PartNumber { get; set; }
        public string OwningDepartment { get; set; }
        public string ComponentDesc { get; set; }
        public string ServiceDate { get; set; }
        public string SerialNumber { get; set; }
        public string PrimaryMeterValue { get; set; }
        public string SecondaryMeterValue { get; set; }
        public string ComponentNoteDesc { get; set; }
        public string Location { get; set; }
    }

    public class ComponentItem
    {
        public string Item { get; set; }
        public string Value { get; set; }
    }

    public class Item
    {
        public string Target { get; set; }
        public string ItemNo { get; set; }
        public string ItemType { get; set; }
        public string MandatoryItem { get; set; }
        public string ValidateValue { get; set; }
        public string DefaultValue { get; set; }
        public string Disable { get; set; }
        public string Value { get; set; }
        public bool EditRequired { get; set; }
    }

}
