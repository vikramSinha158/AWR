﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class WorkRequestParameter
    {
        public string CampaignDesc { get; set; }
        public string WRJobCode { get; set; }
        public string WRJobReason { get; set; }
        public string CampaignNo {get;set;}
        public string EarliestDate { get; set; }
        public string PreferredDate { get; set; }        
        public string LatestDate { get; set; }
        public GeneralInfo GeneralInfo { get; set; }
        public string Status { get; set; }
        public string WRUnitNo { get; set; }
        public InclusionsInfo InclusionsInfo { get; set; }
    }
     public enum WorkRequestStatus
    {
        [Description("Build")]
        Build,
        [Description("Saved")]
        Saved,
        [Description("Preview")]
        Preview,
        [Description("Update")]
        Update,
        [Description("Customize")]
        Customize,
        [Description("Finalized")]
        Finalized,
        [Description("Unlock")]
        Unlock
    }
    public class WorkRequestStateAndStatus    {
        public string WRStatus { get; set; }
        public string ElementName { get; set; }
        public bool IsPreviewEnabled { get; set; }
        public bool IsCustomizeEnabled { get; set; }
        public bool IsFinalizedEnabled { get; set; }
        public bool IsUpdateEnabled { get; set; }
        public bool IsUnlockEnabled { get; set; }
    }
    public class GeneralInfo
    {
        public string ReportedBy { get; set; }
        public string ContactPhone { get; set; }
        public string ReqRef { get; set; }
        public string DirectAcc { get; set; }
        public string MaintLoc { get; set; }
        public string CrewSize { get; set; }
        public string Notes { get; set; }
        public string ComplaintNote { get; set; }
        public string CauseNote { get; set; }
        public string CorrectNote { get; set; }
        public bool SpanShift { get; set; }
        public bool SpreadDueDt { get; set; }
        public bool SendToVendor { get; set; }
    }
    public class InclusionsInfo
    {
        public bool Enabled { get; set; }
        public string UnitNumberValue { get; set; }
        public string FieldName { get; set; }
        public string Operator { get; set; }
    }
}
