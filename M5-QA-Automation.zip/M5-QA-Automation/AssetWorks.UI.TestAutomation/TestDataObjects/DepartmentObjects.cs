﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    /// <summary>
    /// Department Test Data Objects
    /// </summary>
    public class DepartmentObjects
    {

        public static string DeptNumber { get; set; }

        public static string DeptGroupNo { get; set; }

        public static string WoDeptReqNo { get; set; }

        public static string DeptMainScreen = "DeptMainScreen";

        public static string DeptDescription = "DeptDescription";

        public static string DeptBillingCode = "DeptBillingCode";

        public static string DeptBillingCodeDesc = "DeptBillingCodeDesc";

        public static string DeptStatus = "DeptStatus";

        public static string DeptUpdatedStatus = "DeptUpdatedStatus";

        public static string WoDeptReqScreen = "WODeptReqScreen";

        public static string WoDeptReqDesc = "WODeptReqDesc";

        public static string WoDeptReqStatus = "WODeptReqStatus";

        public static string WoDeptReqUpdatedStatus = "WODeptReqUpdatedStatus";

        public static string WoDeptReqDeptNo = "WODeptReqDeptNo";

        public static string WoDeptReqDirectAccNo = "WODeptReqDirectAccNo";

        public static string WoDeptReqOpenCount = "WODeptReqOpenCount";

        public static string DeptKeyword = "DeptKeyword";

        public static string DeptOwning = "DeptOwning";

        public static string DeptUsing = "DeptUsing";

        public static string DeptRoleId = "DeptRoleId";

        public static string InDeptNo = "InDeptNo";

        public static string ExDeptNo = "ExDeptNo";

        public static string ReDeptNo = "ReDeptNo";


    }

    public class DepartmentMain
    {
        public string DepartmentNo { get; set; }
        public List<string> DepartmentList { get; set; }
        public string DeptDescription { get; set; }
        public string DeptStatus { get; set; }
        public GeneralTab GeneralTab { get; set; }
        public OrgHierarchyTab OrgHierarchyTab { get; set; }
        public QuoteRulesTab QuoteRulesTab { get; set; }
        public MotorPoolTab MotorPoolTab { get; set; }
    }

    public class GeneralTab
    {
        public string DeptBillingCode { get; set; }
        public string DeptContact { get; set; }
        public string DeptPhone { get; set; }
        public string DeptPhoneEx { get; set; }
        public string DeptEmail { get; set; }
        public string DeptMCC { get; set; }
        public string DeptTechSpec { get; set; }
        public string DeptDeliveryLoc { get; set; }
        public string DeptMaintenanceLoc { get; set; }
        public string DeptInventoryLoc { get; set; }
        public string DeptPriorityKick { get; set; }
        public string DeptMaxWO { get; set; }
        public string DeptMarkupScheme { get; set; }
        public bool DeptTaxExemption { get; set; }
        public bool DeptOutsideOrg { get; set; }
        public string DeptWorkOrderNotes { get; set; }
    }

    public class OrgHierarchyTab
    {
        public List<OrganizationalHierarchy> OrganizationalHierarchy { get; set; }
    }

    public class OrganizationalHierarchy
    {
        public string LevelTitle { get; set; }
        public string LevelValue { get; set; }
        public string Description { get; set; }
    }

    public class QuoteRulesTab
    {
        public string DeptApproval1 { get; set; }
        public string DeptApproval2 { get; set; }
        public List<DeptQuotationRule> DeptQuotationRule { get; set; }
    }

    public class DeptQuotationRule
    {
        public string Reason { get; set; }
        public string SpendingLimit { get; set; }
        public string RuleDescription { get; set; }
    }

    public class MotorPoolTab
    {
        public List<AssignedEmployee> AssignedEmployees { get; set; }
    }

    public class AssignedEmployee
    {
        public string EmployeeNo { get; set; }
        public string EmployeeName { get; set; }
    }
}
