﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class TechSpecObjects
    {
        public static string TechSpecNumber { get; set; }
        public static string TechSpecMainKey = "TechSpecMain";
        public static string TechSpecCopKey = "TechSpecCopy";
        public static string UpdateTechSpecMainKey = "UpdateTechSpecMain";
        public static string StandardJobTechSpecKey = "StandardJobTechSpec";
    }


    public class DetailTab
    {
        public string FillTechSpecDetail { get; set; }
        public string Year { get; set; }
        public string Manufacturer { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Trim { get; set; }
        public string Reference { get; set; }
        public string LicenseClassCode { get; set; }
        public string CategoryNumber { get; set; }
        public string Replacement { get; set; }
        public string GrossVehicleWeight { get; set; }
        public string OffRoadUse { get; set; }
        public string TestSuite { get; set; }
    }

    public class Product
    {
        public string ProducCode { get; set; }
        public string ProducCapacity { get; set; }
        public string Fuelings { get; set; }
        public string MaxDailyQty { get; set; }
        public bool PriStatus { get; set; }
        public bool SecStatus { get; set; }
    }

    public class ProductsTab
    {
        public string FillProductsTab { get; set; }
        public string VehicleType { get; set; }
        public string FuelClass { get; set; }
        public string FuelEconomyCity { get; set; }
        public string FuelEconomyHighway { get; set; }
        public string FuelEconomyCombined { get; set; }
        public string LicenseClassCode { get; set; }
        public string CategoryNumber { get; set; }
        public string TestSuite { get; set; }
        public List<Product> Products { get; set; }
    }

    public class TechSpec
    {
        public TechSpecMain TechSpecMain { get; set; }
    }

    public class TechSpecMain
    {
        public List<string> TechSpecList { get; set; }
        public DetailTab DetailTab { get; set; }
        public ProductsTab ProductsTab { get; set; }
        public ExceptionTab ExceptionTab { get; set; }
        public AssocTechSpecTab AssocTechSpecTab { get; set; }
        public DocumentTypesTab DocumentTypesTab { get; set; }
        public ZonesTab ZonesTab { get; set; }
        public string TechSpecNo { get; set; }
        public string DeleteMessageAssociatedTS { get; set; }
    }

    public class ExceptionTab
    {
        public string FillExceptionTab { get; set; }
        public string TotalWOCost { get; set; }
        public string MaintenanceCost { get; set; }
        public string LTDMaintenanceCost { get; set; }
        public List<ReasonException> ReasonExceptions { get; set; }
        public List<SystemException> SystemExceptions { get; set; }
    }

    public class ReasonException
    {
        public string ReasonCode { get; set; }
        public string EstimatePrompt { get; set; }
        public string JobMaxCost { get; set; }
        public string JobMaxHrs { get; set; }
        public string LTDMaxCost { get; set; }
    }

    public class SystemException
    {
        public string SystemExceptionCode { get; set; }
        public string SysEstimatePrompt { get; set; }
        public string SysJobMaxCost { get; set; }
        public string SysJobMaxHrs { get; set; }
        public string SysLTDMaxCost { get; set; }
    }

    public class AssocTechSpecTab
    {
        public string FillAssocTechSpecTab { get; set; }
        public List<AssocTechSpecRecord> AssocTechSpecRecord { get; set; }
    }

    public class AssocTechSpecRecord
    {
        public string AssocSpecNo { get; set; }
        public string MaxNoAssoc { get; set; }
        public string MaxNoAssocPosn { get; set; }
        public string MinNoAssoc { get; set; }
        public string AssocJob { get; set; }
        public string MinNoAssocSale { get; set; }
    }

    public class DocumentTypesTab
    {
        public string FillDocumentTypesTab { get; set; }
        public List<DocumentTypesRecord> DocumentTypesRecords { get; set; }
    }

    public class DocumentTypesRecord
    {
        public string DocType { get; set; }
        public bool ExpDate { get; set; }
        public bool AttachFile { get; set; }
    }

    public class ZonesTab
    {
        public string FillZonesTab { get; set; }
        public string EmissionsRating { get; set; }
        public string MaxRange { get; set; }
        public string BatteryRange { get; set; }
        public string BatteryDensity { get; set; }
        public string ZonesLicenseClass { get; set; }
        public string VisionStarRating { get; set; }
        public bool DirectVisionPermit { get; set; }
        public bool Camera { get; set; }
        public string CameraDetails { get; set; }
        public string ComplianceYear { get; set; }
        public string COEmissions { get; set; }
        public string CO2Emissions { get; set; }
        public string CO2AEmissions { get; set; }
        public string HCEmissions { get; set; }
        public string NOxEmissions { get; set; }
        public string PMEmissions { get; set; }
        public string PM10Emissions { get; set; }
    }

    public class DependentJobsTab
    {
        public string DependentJobsFill { get; set; }
        public string DependentJob { get; set; }
        public string DependentLocation { get; set; }
        public string DependentReason { get; set; }
        public bool DependentJobIdNotExist { get; set; }
        public bool CheckDependentJobsTable { get; set; }
    }

    public class StandardJobTechSpec
    {
        public string StandJobNo { get; set; }
        public string TechSpecNo { get; set; }
        public DetailTab DetailTab { get; set; }
        public ProductsTab ProductsTab { get; set; }
        public DependentJobsTab DependentJobsTab { get; set; }
        public StandardJobDetailTab StandardJobDetailTab { get; set; }
        public PartJobTab PartJobTab { get; set; }
        public TestSuitesTab TestSuitesTab { get; set; }
        public EstimatesTab EstimatesTab { get; set; }
        public DeptFixedCostsTab DeptFixedCostsTab { get; set; }
    }

    public class StandardJobDetailTab
    {
        public string PreferredShift { get; set; }
        public bool JobSpan { get; set; }
        public bool AddToWOFl { get; set; }
        public bool VendorFl { get; set; }
        public bool ExcludeFl { get; set; }
        public bool AddToWOExpFl { get; set; }
        public bool FixPriceFl { get; set; }
        public bool CategoryNumber { get; set; }
        public string DefJobReason { get; set; }
        public string Note { get; set; }
        public string ComplaintNote { get; set; }
        public string CauseNote { get; set; }
        public string correctNote { get; set; }
        public bool ChangeAssocFl { get; set; }
        public bool ChangeBaseFl { get; set; }
    }

    public class PartJobDataList
    {
        public string PartNo { get; set; }
        public string Quantity { get; set; }
        public bool RequiredInfo { get; set; }
        public bool PartNoLOV { get; set; }
        public bool FillPartNo { get; set; }
    }

    public class PartJobTab
    {
        public List<PartJobDataList> PartJobDataList { get; set; }
    }

    public class AssignedLaborResource
    {
        public string Resource { get; set; }
        public string Quantity { get; set; }
        public bool PrimaryFL { get; set; }
        public bool ResourceLOV { get; set; }
        public bool AddResourceField { get; set; }
    }

    public class EstimatesTab
    {
        public bool Estlaborfl { get; set; }
        public bool Estpartfl { get; set; }
        public bool Esttotalfl { get; set; }
        public bool AllowCchangefl { get; set; }
        public string LaborTime { get; set; }
        public string LborCost { get; set; }
        public string ShopTime { get; set; }
        public string PartCost { get; set; }
        public string ContingencyTime { get; set; }
        public string CommCost { get; set; }
        public string BookTime { get; set; }
        public string EstCost { get; set; }
        public string IndStdTime { get; set; }
        public string BookTimeMin { get; set; }
        public string BookTimeMax { get; set; }
        public List<AssignedLaborResource> AssignedLaborResources { get; set; }
    }

    public class TestSuitesTab
    {
        public string BrakeTest { get; set; }
        public string Brake { get; set; }
        public bool BrakeTestFl { get; set; }
        public bool BrakeFl { get; set; }
        public string BriBreaks { get; set; }
        public string CerysTest { get; set; }
        public bool BriBreaksFl { get; set; }
        public bool CerysTestFl { get; set; }
    }

    public class WarrantyTechSpec
    {
        public string TechSpecNo { get; set; }
        public WholeUnitTab WholeUnitTab { get; set; }
        public WarrantyPartTab WarrantyPartTab { get; set; }
        public WarrantySubUnitTab WarrantySubUnitTab { get; set; }
    }

    public class WarrantyPartTab
    {
        public bool FillWarrantyTechSpecPartTable { get; set; }
        public string PartTableKey { get; set; }
    }

    public class WholeUnitTab
    {
        public string VendorNo { get; set; }
        public string Usage { get; set; }
        public string MeterType { get; set; }
        public string ElapsedTime { get; set; }
    }

    public class WarrantySubUnitTab
    {
        public bool FillWarrantyTechSpecSubUnitTable { get; set; }
        public string SubUnitTableKey { get; set; }
        public string VerifySubUnitTableKey { get; set; }
    }

    public class DeptFixedCostsTab
    {
        public bool FillDeptFixedCost { get; set; }
        public string DeptFixedCostsTableKey { get; set; }
    }


}
