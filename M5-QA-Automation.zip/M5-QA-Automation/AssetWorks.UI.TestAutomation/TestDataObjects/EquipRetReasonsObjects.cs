﻿
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects.Equipment
{  

    public class EquipmentReturnReasons
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public bool Default { get; set; }
        public bool Disabled { get; set; }
    }

}
