﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class StatusCodeType
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public bool Inactive { get; set; }
        public bool Default { get; set; }
    }

    public class AllocationReasonsType
    {
        public string Code { get; set; }
        public bool Disabled { get; set; }
        public string Description { get; set; }
    }

    public class DriverTypesCode
    {
        public string Code { get; set; }
        public bool Disabled { get; set; }
        public string Description { get; set; }
    }

    public class DriverEventClass
    {
        public string Class { get; set; }   
        public string Description { get; set; }
        public bool Disabled { get; set; }  
    }

    public class DriverEventTypes
    {
        public string Class { get; set; }
        public string Description { get; set; }
        public string Selected_Notification_Frequency { get; set; }
        public Notification_Frequency Notification_Frequency { get; set; }
        public string Code { get; set; }
        public bool Enquiry { get; set; }
        public bool Pre_Enquiry { get; set; }
        public bool Disabled { get; set; }
    }

    public class Notification_Frequency
    {
        public string None { get; set; }
        public string One_week { get; set; }
        public string Two_Weeks { get; set; }
        public string One_Month { get; set; }
        public string Two_Months { get; set; }
    }

    public class DriverEventItem
    {
        public string Class { get; set; }
        public string Type { get; set; }
        public string EventItem { get; set; }
        public bool Disabled { get; set; }
    }

    public class DriverLicenseClasses
    {
        public string Issuing_Authority { get; set; }
        public string Restrictions { get; set; }
        public string LicenceType { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string Note { get; set; }
        public bool Disabled { get; set; }
    }

    public class DriverMain
    {
        public string Employee_ID { get; set; }
        public string Employee_Name { get; set; }
        public string Employee_Status { get; set; }
        public DriverMainGeneralInfo GeneralTab { get; set; }
        public DriverMainLicenseTab LicenseTab { get; set; }
        public DriverMainMotorPoolTab MotorPoolTab { get; set; }
        public DriverAttachments Attachments { get; set; }
    }

    public class DriverMainGeneralInfo
    {
        public string DriverNumber { get; set; }
        public string LicenseNo { get; set; }
        public string TaxFormOnFile { get; set; }
        public string License_Expiry { get; set; }
        public string Home_Location { get; set; }
        public string Department { get; set; }
        public string Driver_Status { get; set; }
        public string Driver_Type { get; set; }
        public string Driver_Class { get; set; }
        public string Shift_Code { get; set; }
        public string Shift_EffectiveDate { get; set; }
        public string Address { get; set; }
        public string Town { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Region { get; set; }
        public string Municipality { get; set; }
        public string Country { get; set; }
        public string Telephone { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string DOB { get; set; }
        public string PlaceOfBirth { get; set; }
        public string DateOfJoined { get; set; }
        public string Tax_Reference { get; set; }
        public string Call_Sign { get; set; }
        public string Driver_Ref { get; set; }
        public string Contact_Details { get; set; }
        public string Pin { get; set; }
        public string NextOfKin { get; set; }
        public string Employee_Note { get; set; }
    }

    public class DriverMainLicenseTab
    {
        public string Authority { get; set; }
        public string Type { get; set; }
        public string Valid_From { get; set; }
        public string Expiry { get; set; }
        public string LicenceNo { get; set; }
        public string Issue { get; set; }
        public string Passed { get; set; }
        public string Renewal { get; set; }
        public string Serial_No { get; set; }
        public string Ref_No { get; set; }
        public string Attachment { get; set; }
        public string Note { get; set; }
        public LicenseClasses licenseClasses  { get; set; }
    }

    public class LicenseClasses 
    {
        public string Code { get; set; }
        public string Restrictions { get; set; }
        public string Permit_Exp { get; set; }
    }

    public class DriverMainMotorPoolTab
    {
        public bool Restrict_MP_Reservations { get; set; }
        public string Motor_Pool_Class { get; set; }
    }

    public class DriverAttachments
    {
        public string InputFile { get; set; }
        public string NewAttachment_Dec { get; set; }
        public string WebAddress { get; set; }
        public string WebAddress_Dec { get; set; }
        public string PreviouslyAttachedDoc { get; set; }
    }
}
