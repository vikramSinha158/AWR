﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class TableItemsObjects
    {
    }

    public class Table
    {
        public List<TableRowsList> TableRowsList { get; set; }
    }

    public class TableData
    {
        public Table Table { get; set; }
    }

    public class TableItemsList
    {
        public bool DateField { get; set; }
        public bool DropDown { get; set; }
        public bool LOV { get; set; }
        public bool SetText { get; set; }
        public bool SelectCheckBox { get; set; }
        public bool SetCheckBox { get; set; }
        public bool VeriFyDescription { get; set; }
        public string HeaderName { get; set; }
        public string SearchValue { get; set; }
        public string Attribute { get; set; }
        public string ItemName { get; set; }
        public string ItemValue { get; set; }
        public int NoOfDaysForDate { get; set; }
    }

    public class TableRowsList
    {
        public List<TableItemsList> TableItemsList { get; set; }
    }


}
