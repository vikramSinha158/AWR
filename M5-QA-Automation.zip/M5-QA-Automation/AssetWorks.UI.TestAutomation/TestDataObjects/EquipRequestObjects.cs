﻿
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class EquipmentRequestTable
    {
        public string EquipmentType { get; set; }
        public string SKU { get; set; }
        public string Qty { get; set; }
        public string PickUpBy { get; set; }
        public string EstCheckOut { get; set; }
        public string EstReturn { get; set; }
        public string Status { get; set; }
        public string StatusDate { get; set; }
        public string Notes { get; set; }
    }

    public class EquipmentRequest
    {
        public string ReqNo { get; set; }
        public string RequestEmployee { get; set; }
        public string RequestEmployeeName { get; set; }
        public string FromLocation { get; set; }
        public string FromLocDesc { get; set; }
        public string To { get; set; }
        public string TargetType { get; set; }
        public string TargetTypeName { get; set; }
        public List<string> ToList { get; set; }
        public List<string> TargetTypeList { get; set; }
        public List<string> TargetTypeNameList { get; set; }
        public List<EquipmentRequestTable> EquipmentRequestTable { get; set; }
    }



}
