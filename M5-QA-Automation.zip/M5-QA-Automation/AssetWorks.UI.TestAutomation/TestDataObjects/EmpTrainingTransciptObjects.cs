﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class EmpDetails
    {
        public string EmpNo { get; set; }
        public string EmpName { get; set; }
        public string EmpStatus { get; set; }
    }
    public class EmpTrainingTranscipt
    {
        public EmpDetails EmployeeData { get; set; }
        public List<TrainingCourseDatum> TrainingCourseData { get; set; }  
        
    }
   
    public class TrainingCourseDatum
    {
        public string Course { get; set; }
        public string CourseDesp { get; set; }
        public string VendorNo { get; set; }
        public string Planned { get; set; }
        public string Attended { get; set; }
        public string Result { get; set; }
        public string Grade { get; set; }
        public string ValidUntil { get; set; }
        public string CertificateNO { get; set; }
        public  AttachDoc AttachmentData { get; set; }
        public string Notes { get; set; }
        public int TotalAttachments { get; set; }
    }

    public class AttachDoc
    {
        public List<NewFile> NewFile { get; set; }
        public List<WebAddress> WebAddress { get; set; }
        public List<PreviouslyAttachedDoc> PreviouslyAttachedDoc { get; set; }
     
    }

    public class NewFile
    {
        public string InputFile { get; set; }
        public string FileDesc { get; set; }
    }

    public class PreviouslyAttachedDoc
    {
        public string FileAddress { get; set; }
    }

    public class WebAddress
    {
        public string Address { get; set; }
        public string Desc { get; set; }
    }

}


