﻿using MongoDB.Bson.Serialization.IdGenerators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class ProductTank
    {
        public string FuelLocation { get; set; }
        public List<UpdateProductTank> UpdateProductTank { get; set; }
    }

    public class UpdateProductTank
    {
        public string TankNo { get; set; }
        public string ProductNo { get; set; }
        public string ProductDescription { get; set; }
        public string Type { get; set; }
        public string Adj_Account { get; set; }
        public string AccountDescription { get; set; }
    }

}
