﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class CommercialDatum
    {
        public string Line { get; set; }
        public bool ServiceCodeLOV { get; set; }
        public string ServiceCode { get; set; }
        public string VendorLineNo { get; set; }
        public string SKU { get; set; }
        public bool JobCodeLOV { get; set; }
        public string WACode { get; set; }
        public string SysCode { get; set; }
        public string CompCode { get; set; }
        public string JobCode { get; set; }
        public string JobReasonDesc { get; set; }
        public bool JobReasonLOV { get; set; }
        public string JobReason { get; set; }
        public string LaborHour { get; set; }
        public string LaborCost { get; set; }
        public string PartCost { get; set; }
        public string MiscCost { get; set; }
        public string TotalCost { get; set; }
        
    }

    public class VendorContractData
    {
        public string ContractNo { get; set; }
        public string VendorNo { get; set; }
        public bool NewContract { get; set; }
        public string VendorDesc { get; set; }
        public bool Parts { get; set; }
        public bool Fuel { get; set; }
        public bool Commercial { get; set; }
        public string Status { get; set; }
        public string StartDate { get; set; }
        public string AwardDate { get; set; }
        public string StatusDate { get; set; }
        public string EndDate { get; set; }
        public string RenewalTerms { get; set; }
        public string AwardAmount { get; set; }
        public string CTCOrderAmount { get; set; }
        public string CTDRcvdAmount { get; set; }
        public string BalanceAmount { get; set; }
        public string WarnAtAmount { get; set; }
        public bool FillPartsData { get; set; }
        public bool FillCommercialData { get; set; }
        public string Notes { get; set; }    
        public List<PartsDatum> PartsData { get; set; }
        public List<CommercialDatum> CommercialData { get; set; }
    }

    public class PartsDatum
    {
        public string LineNO { get; set; }
        public string Type { get; set; }
        public bool PartNoLOV { get; set; }
        public string PartNo { get; set; }
        public string Desc { get; set; }
        public bool PriceTypeLOV { get; set; }
        public string PriceType { get; set; }
        public string AdjPct { get; set; }
        public string DiscPct { get; set; }
        public string DiscDays { get; set; }
        public bool ShipTermsLOV { get; set; }
        public string ShipTerms { get; set; }
        public string Qty { get; set; }
        public string UnitOfOrder { get; set; }
        public string UnitPrice { get; set; }
        public string Notes { get; set; }
        public string PartRowToEdit { get; set; }
        
    }
}