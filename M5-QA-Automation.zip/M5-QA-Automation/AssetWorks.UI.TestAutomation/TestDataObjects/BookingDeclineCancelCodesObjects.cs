﻿

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class BookingDeclineCancelCodes
    {
        public class BookingCodeDetails
        {
            public string BookingCode { get; set; }
            public string BookingDescription { get; set; }
            public bool Cancelflag { get; set; }
            public bool Declineflag { get; set; }
            public bool Disableflag { get; set; }
            
        }

        

    }


}
