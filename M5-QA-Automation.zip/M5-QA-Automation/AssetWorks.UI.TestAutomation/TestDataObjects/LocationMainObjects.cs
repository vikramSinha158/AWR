﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class ConfigurationTab
    {
        public bool FuelLocation { get; set; }
        public bool DeliveryLocation { get; set; }
        public bool ParkingLocation { get; set; }
        public bool MotorPoolLocation { get; set; }
        public string LTDUsageFactor { get; set; }
        public string ReservationDuration { get; set; }
    }

    public class GeneralInfoTab
    {
        public string MarkupScheme { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string TimeZone { get; set; }
    }

    public class HierarchyTab
    {
        public string Department { get; set; }
    }

    public class InventoryTab
    {
        public bool InventoryLocation { get; set; }
        public string CarryingCost { get; set; }
        public string OverheadCost { get; set; }
        public bool ManualReq { get; set; }
        public bool AutoReq { get; set; }
        public string Supervisor { get; set; }
    }

    public class MaintenanceTab
    {
        public bool MaintLocation { get; set; }
        public bool JobsSpanShifts { get; set; }
        public bool IncludeNotes { get; set; }
        public string NotifyTime { get; set; }
        public string DowntimeStatus { get; set; }
        public bool SendWONotify { get; set; }
        public bool SendJobAttach { get; set; }
        public string TimeReporting { get; set; }
        public string TimeRounding { get; set; }
     
    }

    public class LocationMain
    {
        public string Location { get; set; }
        public string LocationDesc { get; set; }
        public List<string> LocationList { get; set; }
        public List<string> LocationDescList { get; set; }
        public string Disabled { get; set; }
        public GeneralInfoTab GeneralTab { get; set; }
        public ConfigurationTab ConfigurationTab { get; set; }
        public HierarchyTab HierarchyTab { get; set; }
        public InventoryTab InventoryTab { get; set; }
        public MaintenanceTab MaintenanceTab { get; set; }
    }

}
