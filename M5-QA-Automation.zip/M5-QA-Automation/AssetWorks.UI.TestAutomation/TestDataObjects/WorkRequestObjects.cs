﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class WorkRequestObjects
    {
    }

    public class WorkRequestMain
    {
        public string WRType { get; set; }
        public string WRUnitNo { get; set; }
        public string WorkRequestNo { get; set; }
        public bool IsNewTicket { get; set; }
        public string WRJobCode { get; set; }
        public string WRJobCodeDesc { get; set; }
        public string WRJobReason { get; set; }
        public string WRJobReasonDesc { get; set; }
        public string WRShift { get; set; }
        public string WRShiftDesc { get; set; }
        public string WRReportedBy { get; set; }
        public string WRContact { get; set; }
        public string WRDeptNo { get; set; }
        public string WRCompNo { get; set; }
        public General General { get; set; }
        public PartsInfo PartsInfo { get; set; }
    }
    public class General
    {
        public string ReportedBy { get; set; }
        public string ContactPhone { get; set; }
        public string ReqRef { get; set; }
        public string DirectAcc { get; set; }
        public string MaintLoc { get; set; }
        public string Notes { get; set; }
        public string WarrentyCorrectionNote { get; set; }
        public string Employee { get; set; }
        public string VendorNo { get; set; }
        public string EarliestDate { get; set; }
        public string PreferredDate { get; set; }
        public string LatestDate { get; set; }
        public string Source { get; set; }
        public string Symptom { get; set; }

    }
    public class PartsInfo
    {
        public string PartsNo { get; set; }
        public string UnitOfInventory { get; set; }
        public string Description { get; set; }
        public string Quantity { get; set; }
        public string UnitCost { get; set; }
        public string TotalQuantity { get; set; }
        public string TotalCost { get; set; }
    }
}

