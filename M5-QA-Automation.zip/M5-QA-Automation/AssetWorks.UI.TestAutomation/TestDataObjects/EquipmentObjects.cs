﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    public class AddRecords
    {
        public string ECode { get; set; }
        public string EDescription { get; set; }
        public bool Default { get; set; }
        public bool Disabled { get; set; }
    }

    public class EditRecord
    {
        public bool Default { get; set; }
        public bool Disabled { get; set; }
    }

    public class EquipmentTypeSKU
    {
        public string EquipmentTypeNo { get; set; }
        public string Description { get; set; }
        public EquipmentType EquipmentTypes { get; set; }
    }

    public class EquipmentType
    {
        public string SKU { get; set; }
        public string SKUDesc { get; set; }
        public bool IsSerial { get; set; }
        public bool Disabled { get; set; }
    }

    public class EquipmentCondition
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string DisallowCheckOut { get; set; }
        public string JobCode { get; set; }
        public string JobReason { get; set; }
        public string JobPriority { get; set; }
        public string Disabled { get; set; }
    }

    public class EquipmentProfileeData
    {
        public string EquipmentProfileID { get; set; }
        public string EquipmentProfileDescription { get; set; }
        public string EquipmentProfileStatus { get; set; }
        public PrimaryEquipmentProfile PrimaryEquipmentProfile { get; set; }
        public SecondaryEquipmentProfile SecondaryEquipmentProfile { get; set; }
        public List<CreateACC> CreateACC { get; set; }
    }

    public class EquipmentProfileMaintenance
    {
        public EquipmentProfileeData EquipmentProfileeData { get; set; }
    }

    public class PrimaryEquipmentProfile
    {
        public List<string> PrimaryAssetClassCodes { get; set; }
        public List<string> PrimaryCategoryCodes { get; set; }
    }

    public class Root
    {
        public EquipmentProfileMaintenance EquipmentProfileMaintenance { get; set; }
    }

    public class SecondaryEquipmentProfile
    {
        public List<string> SecondaryAssetClassCodes { get; set; }
        public List<string> SecondaryCategoryCodes { get; set; }
    }



}