﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{

    public class BinInformation
    {
        public string Bin { get; set; }
        public string Description { get; set; }
        public bool Disabled { get; set; }
    }

    public class CreatePartPin
    {
        public string BinCode { get; set; }
        public List<BinInformation> BinInformation { get; set; }
        public List<BinInformation> UpdateBinInformation { get; set; }
        
    }

    public class PartBin
    {
        public CreatePartPin CreatePartPin { get; set; }
    }
    public  class PartValue
    {
        public  string Description { get; set; }
        public  bool Disabled { get; set; }
    }


}