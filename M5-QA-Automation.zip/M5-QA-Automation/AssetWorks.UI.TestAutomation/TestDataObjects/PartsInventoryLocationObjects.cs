﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public  class PartsInventoryLocationObjects
    {
        public string Number { get; set; }
        public string StockType { get; set; }
        public string ReorderAllowed { get; set; }
        public string IssueToDepartment { get; set; }
        public string IssueToAccount { get; set; }
        public string CoreTracking { get; set; }
        public string CoreCharge { get; set; }
        public string Standard { get; set; }
        public string BinPrimaryLocation { get; set; }
        public string VendorPartNo { get; set; }
        public string MaximumInvQty { get; set; }
        public string MinimumInvQty { get; set; }
        public string MarkupScheme { get; set; }
        public string CategoryCost { get; set; }

        public string ChargeCode { get; set; }
    }
}
