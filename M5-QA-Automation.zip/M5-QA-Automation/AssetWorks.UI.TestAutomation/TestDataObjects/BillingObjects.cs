﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class BillingObjects
    {
        public static string BillingDesCription { get; set; }
        public static string BillingCode { get; set; }
        public static string BillingType { get; set; }
        public static string EffectiveDate { get; set; }
    }

    public class AddBillingInformation
    {
        public List<string> BillingCodeList { get; set; }
        public string BillingType { get; set; }
        public string BillingCode { get; set; }
        public string Description { get; set; }
        public string BillingEffectiveDate { get; set; }
        public DetailsInformationTab DetailsInformationTab { get; set; }
        public BillingMotorPoolTab BillingMotorPoolTab { get; set; }
        public FixedTab FixedTab { get; set; }
        public string ExistingBillingCode { get; set; }
        public string NewBillingEffectiveDate { get; set; }
        public string NotBillingDeletionMessage { get; set; }
        public string BillingCodeDisabled { get; set; }
        public string BillingCodeEnabled { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsReadOnly { get; set; }
    }

    public class Billing
    {
        public AddBillingInformation AddBillingInformation { get; set; }
        public BillingAdjustment BillingAdjustment { get; set; }
    }

    public class BillingAdjustment
    {
        public string UnitDeptNo { get; set; }
        public AdjustmentItems AdjustmentItems { get; set; }
        public string BillItem { get; set; }
        public bool BillItemLOV { get; set; }
    }

    public class AdjustmentItems
    {
        public string Description { get; set; }
        public string Amount { get; set; }
        public string TotalPeriods { get; set; }
        public string TotalAmount { get; set; }
        public string FirstPeriod { get; set; }
        public string Location { get; set; }
        public string ExpUsing { get; set; }
        public string RevOwning { get; set; }
        public string Department { get; set; }
        public bool BillingLOV { get; set; } 
        public bool CheckBillingAdjustmentTable { get; set; }
    }

    public class DetailsInformationTab
    {
        public string LeaseRate { get; set; }
        public string LeaseRatePer { get; set; }
        public bool ShiftLOv { get; set; }
        public string Shift { get; set; }
        public bool SeasonLOV { get; set; }
        public string Season { get; set; }
        public bool TaxableFl { get; set; }
        public bool TaxSchemeLOV { get; set; }
        public string TaxScheme { get; set; }
        public string FixedBids { get; set; }
        public bool BillItemLOV { get; set; }
        public string BillItem { get; set; }
        public string LaborBilling { get; set; }
        public string PartBilling { get; set; }
        public string CommBilling { get; set; }
        public string FlatPerPeriod { get; set; }
        public string ChargePerUsage { get; set; }
        public string HowToCharge { get; set; }
        public string RecordingMethod { get; set; }
        public string IFuelProducts { get; set; }
        public string OFuelProducts { get; set; }
        public string ChargePerGal { get; set; }
    }

    public class BillingMotorPoolTab
    {
        public string FuelCharge { get; set; }
        public string TimeType { get; set; }
        public string EmpTime { get; set; }
        public string Overtime { get; set; }
        public string Doubletime { get; set; }
        public string BillingMethod { get; set; }
        public bool BillWeekends { get; set; }
        public bool BillHolidays { get; set; }
        public string HourlyRate { get; set; }
        public string HourlyUsage { get; set; }
        public string DailyRate { get; set; }
        public string DailyUsage { get; set; }
        public string WeeklyRate { get; set; }
        public string WeeklyUsage { get; set; }
        public string MonthlyRate { get; set; }
        public string MonthlyUsage { get; set; }
        public bool TimeTypeLOV { get; set; }
    }

    public class FixedTab
    {
        public bool FillFixedTableTab { get; set; }
        public string BillingCodeFixedTableTableKey { get; set; }
    }

    public class BillingFixedCharge
    {
        public List<string> BillingItemList { get; set; }
        public string BillingItem { get; set; }
        public string Description { get; set; }
        public string BillingLimit { get; set; }
        public bool Billtax { get; set; }
    }

    public class BillingItemSource
    {
        public string BillingItemName { get; set; }
        public string DepartmentBill { get; set; }
        public string RevenueAccountsSource { get; set; }
        public string ExpenseAccountSource { get; set; }
    }

    public class BillingItemSourceDetail
    {
        public List<string> BillingItemSourceList { get; set; }
        public List<BillingItemSource> BillingItemSource { get; set; }
        public string BillingCodeSource { get; set; }
    }

    public class BillIndirectAccountsBillItems
    {
        public string IndirectAccountsBillItemsTableKey { get; set; }
    }

    public class BillingIndirectItems
    {
        public string BillCode { get; set; }
        public BillIndirectAccountsBillItems BillIndirectAccountsBillItems { get; set; }
    }

    public class UpdateUnitAccountDetails
    {
        public string UnitNo { get; set; }
        public string BillItem { get; set; }
        public string EffectiveDate { get; set; }
        public string ExpenseAccount { get; set; }
        public string RevenueEffectiveDate { get; set; }
        public string RevenueAccount { get; set; }

    }
    public class UnitAccountDetails
    {
        public List<string> BillingItemList { get; set; }
        public string UnitNo { get; set; }
        public string BillItem { get; set; }
        public List<UnitAccountExpenseTable> UnitAccountExpenseTable { get; set; }
        public List<ExpenseAccountAllocationTable> ExpenseAccountAllocationTable { get; set; }
        public string ExpenseAcct { get; set; }

    }
    public class UnitAccountExpenseTable
    {
        public string EffectiveDate { get; set; }
        public string ExpenseAccount { get; set; }
    }
    public class ExpenseAccountAllocationTable
    {
        public string ExpenseAccount { get; set; }
        public string Allocation { get; set; }
    }

    
    public class BillingAccountInfoTable
    {
        public string BillingItemName { get; set; }
        public string ExpenseAccounts { get; set; }
    }

    public class BillingDepartment
    {
        public string DepartmentNo { get; set; }
        public List<string> BillItemlist { get; set; }
        public List<BillingAccountInfoTable> BillingAccountInfoTable { get; set; }
        public List<BillingAccountRevTable> BillingAccountRevTable { get; set; }
      
    }
    public class BillingAccountRevTable 
    {
        public string BillingItemName { get; set; }
       public string RevenueAccounts { get; set; }
    }
    public class SingleDepartmentDetails
    {
        public string Department { get; set; }
        public string ExpenseAccount { get; set; }
        public string RevenueAccount { get; set; }
        public bool SingleDepartmentLOV { get; set; }
    }

    public class BillSingleUnitExpenseAccount
    {
        public List<ExpenseAccountAllocation> ExpenseAccountAllocation { get; set; }
    }

    public class BillingUnitAccountDetail
    {
        public string UnitNo { get; set; }
        public string BillItem { get; set; }
        public string EffectiveDate { get; set; }
        public string ExpenseAccount { get; set; }
        public string RevenueEffectiveDate { get; set; }
        public string RevenueAccount { get; set; }
    }

    public class BillSingleUnitRevenueAccount
    {
        public List<RevenueAccountAllocation> RevenueAccountAllocation { get; set; }
    }

    public class BillSingleUnitDetail
    {
        public string UnitNo { get; set; }
        public int NoOfDays { get; set; }
        public string ExpenseEffectiveDate { get; set; }
        public BillSingleUnitExpenseAccount BillSingleUnitExpenseAccount { get; set; }
        public BillSingleUnitRevenueAccount BillSingleUnitRevenueAccount { get; set; }
        public bool CheckExpenseAccountTable { get; set; }
        public bool CheckRevenueAccountTable { get; set; }
    }

    public class ExpenseAccountAllocation
    {
        public string ExpenseAccount { get; set; }
        public string Allocation { get; set; }
    }

    public class RevenueAccountAllocation
    {
        public string RevenueEffectiveDate { get; set; }
        public string RevenueAccount { get; set; }
        public int RevnueNoOfDays { get; set; }
    }
}
