﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class ActiveUserDisplay
    {
        public string ExpectedLicCount { get; set; }
        public string ExpectedActiveUser { get; set; }
        public string ExpectedLastFrame { get; set; }
        public string Appuser { get; set; }
    }

    public class MenuMaintenanceSetting
    {
        public string FlagName { get; set; }
        public List<string> FilePath { get; set; }
        public bool IsEnabled { get; set; }
    }
}
