﻿using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class PartsClassCodesObjects
    {
        public List<string> CodeList { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public bool Disabled { get; set; }

    }
}
