﻿using MongoDB.Bson.Serialization.IdGenerators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class CardsInformation
    {
        public string CardNo { get; set; }
        public string EffectiveDate { get; set; }
        public string ExpirationDate { get; set; }
        public string VendorNo { get; set; }
        public string PromptId { get; set; }
        public string Pin { get; set; }
        public string MessageText { get; set; }
        public string DeviceSerialNumber { get; set; }
        public string DisableCard { get; set; }
        public string CardNotes { get; set; }
        public string UserData1 { get; set; }
        public string UserData2 { get; set; }
    }

    public class PINManagement
    {
        public bool PINRequired { get; set; }
        public bool ICUSupervisor { get; set; }
        public bool UnitNumberRequired { get; set; }
        public bool RestrictedToShift { get; set; }
        public string UnitNumber { get; set; }
    }

    public class ProductInformation
    {
        public string Product { get; set; }
        public string Description { get; set; }
    }

    public class ProductSetUpEmployees
    {
        public string EmployeeId { get; set; }
        public SetUpEmployeeDetails SetUpEmployeeDetails { get; set; }
    }

    public class EmployeeSetup
    {
        public ProductSetUpEmployees productSetUpEmployees { get; set; }
    }

    public class SetUpEmployeeDetails
    {
        public PINManagement PINManagement { get; set; }
        public List<ProductInformation> ProductInformation { get; set; }
        public List<CardsInformation> CardsInformation { get; set; }
    }
}