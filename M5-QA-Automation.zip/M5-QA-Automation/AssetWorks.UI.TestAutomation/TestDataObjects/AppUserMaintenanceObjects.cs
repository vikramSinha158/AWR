﻿
namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class AddApplicationUser
    {
        public string Password { get; set; }
        public string UserRole { get; set; }
    }

    public class CopyApplicationUser
    {
        public string Password { get; set; }
    }

}
