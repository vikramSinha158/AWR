﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class BookingSourceCodeObjects
    {
        public class BookingSourceCode
        {
            public string BookingCode { get; set; } 
            public bool Disable { get; set; }
        }
    }
}
