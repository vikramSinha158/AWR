﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class PartsMainCatalog
    {
        public List<string> PartNumberList { get; set; }
        public string PartNumber { get; set; }

        public string PartDesc { get; set; }

        public string StandardPrice { get; set; }

        public string AveragePrice { get; set; }

        public string RetailPrice { get; set; }

        public string DiscountCode { get; set; }

        public string UnitOfInventory { get; set; }

        public string Commodity { get; set; }

        public string ChargeCode { get; set; }

        public string CostCategory { get; set; }

        public string PartClass { get; set; }

        public string Sys { get; set; }

        public string Assembly { get; set; }

        public string Part { get; set; }

        public string StockType { get; set; }

        public string PrimaryVendor { get; set; }

        public string SecondaryVendor { get; set; }

        public string SeasonCode { get; set; }
      
        public string ExtDescription { get; set; }
        
        public string Manufacturer { get; set; }
        public string Serialized { get; set; }
        public string AutoGenerateSerial { get; set; }
        public string ReusableSerial { get; set; }
        public string Lotted { get; set; }
        public string CoreCharge { get; set; }
        public string CoreTracking { get; set; }
    }
}
