﻿using MongoDB.Bson.Serialization.IdGenerators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class ProductSetUpLocation
    {
            public string Location { get; set; }
            public string ProductNo { get; set; }
            public string TankNo { get; set; }
            public string MethodOfTrackingStock { get; set; }
            public string IssueQuantityCalculation { get; set; }
            public string MaximumQuantity { get; set; }
            public string MinimumQuantity { get; set; }
            public string UnitCost { get; set; }
            public string PerTransactionCharge { get; set; }
    }

    public class ProductLocation
    {
        public ProductSetUpLocation ProductSetUpLocation{ get; set; }
    }
}
