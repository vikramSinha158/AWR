﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    public class CreateTaxScheme
    {
        public string TaxScheme { get; set; }
        public string TaxSchemeDesc { get; set; }
        public string DisableTax { get; set; }
        public string EffectiveDate { get; set; }
        public List<string> AppliedTo { get; set; }
        public string TaxCalculus { get; set; }
        public List<TaxRateData> TaxRateData { get; set; }
    }

    public class TaxRateData
    {
        public string Line { get; set; }
        public string TopOFLine { get; set; }
        public string TaxType { get; set; }
        public string TaxRate { get; set; }
        public string FlatRate { get; set; }
        public string AlternateFlatRate { get; set; }
    }

    public class TaxScheme
    {
        public CreateTaxScheme CreateTaxScheme { get; set; }
        public CreateTaxScheme UpdateTaxScheme { get; set; }
    }



}