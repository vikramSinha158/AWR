﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{
    internal class SystemCodesObjects
    {
    }

    public class CreateACC
    {
        public string Code { get; set; }
        public string Desc { get; set; }
    }

    public class AssetClassCode
    {
        public List<CreateACC> CreateACC { get; set; }
    }
}
