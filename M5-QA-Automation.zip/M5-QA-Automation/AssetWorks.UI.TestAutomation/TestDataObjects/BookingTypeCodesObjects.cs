﻿
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.TestDataObjects
{


    public class BookingTypeCodes
    {
        public class BookingCodeDetails
        {
            public string BookingType { get; set; }
            public bool AddressRequired { get; set; }
            public bool Disabled { get; set; }
        }
    }

}
