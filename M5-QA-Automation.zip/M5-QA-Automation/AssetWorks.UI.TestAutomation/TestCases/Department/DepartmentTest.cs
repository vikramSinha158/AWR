﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Department
{
    /// <summary>
    /// Test scenarios for Department
    /// </summary>
    [TestFixture]
    internal class DepartmentTest : Hooks
    {
        [TestCase("DepartmentTestdata.json", "QA222_CreateDepartment",
            TestName = "QA222_CreateADepartment", Description = "M5-Tests that you can Delete a Department")]
        public void QA222_CreateADepartment(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage();
            DepartmentMain department = CommonUtil.DataObjectForKey("DeptDetails").ToObject<DepartmentMain>();
            department.DepartmentNo = CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment(department);
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentInformation(department);
        }

        [TestCase("DepartmentTestdata.json", "QA357_DepartmentDeactivate",
            Description = "M5-To test that you can deactivate a Department")]
        public void QA357_DeactivateAnExistingDepartment(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment();
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentDescription();
            CurrentPage.As<DepartmentMainPageActions>().UpdateDepartmentStatusValue(DepartmentObjects.DeptStatus);
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentStatusValue(DepartmentObjects.DeptNumber, DepartmentObjects.DeptStatus);
        }

        [TestCase("DepartmentTestdata.json", "QA358_DepartmentDelete",
            Description = "M5-Tests that you can Delete a Department")]
        public void QA358_DeleteADepartment(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment();
            CurrentPage.As<DepartmentMainPageActions>().DeleteADepartment();
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentDoesNotExist(DepartmentObjects.DeptNumber);
        }

        [TestCase("DepartmentTestdata.json", "QA248_CreateDeptReq",
            Description = "M5-Create a Department Requisition")]
        public void QA248_CreateADepartmentRequisition(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToWODepartmentRequisitionsMainPage();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().CreateNewWorkOrderDepartmentRequisition();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionCreatedDate();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqStatus);
        }

        [TestCase("DepartmentTestdata.json", "QA438_CloseDeptReq",
            Description = "M5-Tests that a Department Requisition is closed")]
        public void QA438_CloseDepartmentRequisition(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToWODepartmentRequisitionsMainPage();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().CreateNewWorkOrderDepartmentRequisition();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqStatus);
            CurrentPage.As<WODepartmentRequisitionsPageActions>().UpdateRequisitionStatusValue(DepartmentObjects.WoDeptReqUpdatedStatus);
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqUpdatedStatus);
        }

        [TestCase("DepartmentTestdata.json", "QA466_ViewDeptReqWorkOrders",
            Description = "M5-Test that you can view Work Orders in the Department Requisition")]
        public void QA466_ViewDepartmentRequisitionWorkOrders(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToWODepartmentRequisitionsMainPage();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().CreateNewWorkOrderDepartmentRequisition();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqStatus);
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().CreateWorkOrderWithDeptReq(DepartmentObjects.WoDeptReqDeptNo, DepartmentObjects.WoDeptReqNo);
            CurrentPage = homepage.NavigateToWODepartmentRequisitionsMainPage();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqStatus);
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyOpenWorkOrderCount(DepartmentObjects.WoDeptReqOpenCount);
            CurrentPage.As<WODepartmentRequisitionsPageActions>().UpdateRequisitionStatusValue(DepartmentObjects.WoDeptReqUpdatedStatus);
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqUpdatedStatus);
            CurrentPage = homepage.NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().EnterAndDeleteWorkOrder();
        }

        [TestCase("DepartmentTestdata.json", "QA286_DeptNumberChange",
            Description = "M5-Change the Department Number")]
        public void QA286_DepartmentNumberChange(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment();
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateToDepartmentNumberChangePage();
            CurrentPage.As<DepartmentNumberChangePageActions>().SearchForDepartmentNumber(DepartmentObjects.DeptNumber);
            CurrentPage = CurrentPage.As<DepartmentNumberChangePageActions>().UpdateNewDepartmentNumber();
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentNumberValue(DepartmentNumberChangePage.NCDepartmentNumber);
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentDescriptionValue(DepartmentNumberChangePage.NCDepartmentDescription);
            CurrentPage.As<DepartmentMainPageActions>().DeleteADepartment();
        }

        [TestCase("DepartmentTestdata.json", "QA278_DepartmentCopy",
            Description = "M5-Making a Department Copy")]
        public void QA278_CopyADepartment(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment();
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateToDepartmentCopyPage();
            CurrentPage.As<DepartmentCopyPageActions>().EnterDepartmentNumberAndPressTab(DepartmentObjects.DeptNumber);
            CurrentPage = CurrentPage.As<DepartmentCopyPageActions>().UpdateNewDepartmentNumber();
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentNumberValue(DepartmentCopyPage.NewDeptNumber);
            CurrentPage.As<DepartmentMainPageActions>().VerifyBillingCodeDescriptionValue(CommonUtil.DataForKey(DepartmentObjects.DeptBillingCodeDesc));
            CurrentPage.As<DepartmentMainPageActions>().EnterDepartmentDescAndTabKey(CommonUtil.DataForKey(DepartmentObjects.DeptDescription));
            CurrentPage.As<DepartmentMainPageActions>().UpdateOrganizationalHierarchyValues();
            CurrentPage.As<DepartmentMainPageActions>().DeleteAndVerifyDepartment(DepartmentCopyPage.NewDeptNumber);
            CurrentPage.As<DepartmentMainPageActions>().DeleteAndVerifyDepartment(DepartmentObjects.DeptNumber);
        }

        [TestCase("DepartmentTestdata.json", "QA289_UnitDeptChange",
            Description = "M5-Making a Unit Department Change")]
        public void QA289_UnitDepartmentChange(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitDepartmentChangePage();
            CurrentPage.As<UnitDepartmentChangePageActions>().SearchUnitNoByUsingDepartment(DepartmentObjects.DeptKeyword);
            CurrentPage.As<UnitDepartmentChangePageActions>().VerifyDepartmentDetails(DepartmentObjects.DeptKeyword, DepartmentObjects.DeptKeyword);
            CurrentPage.As<UnitDepartmentChangePageActions>().UpdateUnitDepartments(DepartmentObjects.DeptOwning, DepartmentObjects.DeptUsing);
            CurrentPage.As<UnitDepartmentChangePageActions>().RefreshAndVerifyUnitDepartmentDetails(DepartmentObjects.DeptOwning, DepartmentObjects.DeptUsing);
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().LoadUnitAndOpenDeptLocTab(UnitDepartmentChangePage._unitNumber);
            CurrentPage.As<UnitMainPageActions>().VerifyDepartmentDetails(DepartmentObjects.DeptOwning, DepartmentObjects.DeptUsing);
        }

        [TestCase("DepartmentTestdata.json", "QA480_CreateDeptGroup",
            Description = "M5-Create new Department Group"),Order(1)]
        public void QA480_QA484_CreateAndUpdateDepartmentGroup(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentGroupsPage();
            CurrentPage.As<DepartmentGroupsPageActions>().CreateNewDepartmentGroup();
            CurrentPage.As<DepartmentGroupsPageActions>().AssignDepartmentsInGroup(DepartmentObjects.InDeptNo);
            CurrentPage.As<DepartmentGroupsPageActions>().AssignRoleToDepartmentGroup(DepartmentObjects.DeptRoleId);
            CurrentPage.As<DepartmentGroupsPageActions>().SaveDepartmentGroupInfo();
            CurrentPage.As<DepartmentGroupsPageActions>().RefreshAndVerifyDepartmentGroupDetails(DepartmentObjects.InDeptNo);
            Settings.Logger.Info("--------Execution completed for test ' QA480 Create new Department Group (assign departments to group)' -----------");
            CurrentPage.As<DepartmentGroupsPageActions>().UnassignDepartmentsFromGroup(DepartmentObjects.ExDeptNo);
            CurrentPage.As<DepartmentGroupsPageActions>().SaveDepartmentGroupInfo();
            CurrentPage.As<DepartmentGroupsPageActions>().RefreshAndVerifyDepartmentGroupDetails(DepartmentObjects.ReDeptNo);
            CommonUtil.AddPassedTestCase("QA484");
            Settings.Logger.Info("--------Execution completed for test ' QA484 Update Department Group (unassign departments from group)' -----------");
        }

        [Test, Description("M5-Update Department Group, Merged with- QA480_QA484_CreateAndUpdateDepartmentGroup ")]
         public void QA484_UpdateDepartmentGroup()
        {
            CommonUtil.VerifyPassedTestCase("QA484");

        }


        [TestCase("DepartmentTestdata.json", "QA364_DeptPartListDisposal",
            TestName = "QA364_DepartmentPartListDisposal",
            Description = "M5-Tests that a Department Disposal record is saved.")]
        public void QA364_DepartmentPartListDisposal(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment();
            CurrentPage = CurrentPage.As<DepartmentMainPageActions>().NavigateToPartListDisposal();
            CurrentPage.As<PartListDisposalPageActions>().LoadDepartmentInformation(DepartmentObjects.DeptNumber);
            CurrentPage.As<PartListDisposalPageActions>().InstallNewPartForDisposal();
        }

    }
}
