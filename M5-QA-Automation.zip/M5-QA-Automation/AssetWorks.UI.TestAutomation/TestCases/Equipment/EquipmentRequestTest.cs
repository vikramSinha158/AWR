﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Equipment
{
    /// <summary>
    /// Test scenarios for Equipment Request
    /// </summary>
    [TestFixture]
    internal class EquipmentRequestTest : Hooks
    {

        [TestCase("EquipmentRequestTestData.json", "EquipmentRequest",
          TestName = "QA1236_QA1237_CreateDeleteEquipmentRequestDepartment", Description = "M5-Equipment Check Request-Department")]
        public void QA1236_QA1237_CreateDeleteEquipmentRequestDepartment(object[] testParameter)
        {
            EquipmentRequest EqipRequestObj = CommonUtil.DataObjectForKey("QA1236_EquipCheckReqDept").ToObject<EquipmentRequest>();                  
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateEquipmentRequest();
            EqipRequestObj = CurrentPage.As<EquipmentRequestPageActions>().EquipmentRequest(EqipRequestObj);
            CurrentPage.As<EquipmentRequestPageActions>().VerifyEquipmentRequest(EqipRequestObj);
            CurrentPage.As<EquipmentRequestPageActions>().DeleteEquipmentRequest(EqipRequestObj.ReqNo);
            CurrentPage.As<EquipmentRequestPageActions>().VerifyEquipmentRequestDeletion(EqipRequestObj.ReqNo);
         }

        [TestCase("EquipmentRequestTestData.json", "EquipmentRequest",
        TestName = "QA1238_CreateEquipmentRequestDifferentTypes", Description = "M5 -Equipment Request-Different Types")]
        public void QA1238_CreateEquipmentRequestDifferentTypes(object[] testParameter)
        {
            EquipmentRequest EqipRequestObj = CommonUtil.DataObjectForKey("QA1238_EquipCheckDiffertTypes").ToObject<EquipmentRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateEquipmentRequest();
            int i=0;
            foreach (string Request in EqipRequestObj.ToList)
            {
                EqipRequestObj.To= EqipRequestObj.ToList[i];
                EqipRequestObj.TargetType= EqipRequestObj.TargetTypeList[i];
                EqipRequestObj.TargetTypeName= EqipRequestObj.TargetTypeNameList[i];
                EqipRequestObj = CurrentPage.As<EquipmentRequestPageActions>().EquipmentRequest(EqipRequestObj);
                CurrentPage.As<EquipmentRequestPageActions>().VerifyEquipmentRequest(EqipRequestObj);
                CurrentPage.As<EquipmentRequestPageActions>().DeleteEquipmentRequest(EqipRequestObj.ReqNo);
                i++;
            }         
          }

    }
}
