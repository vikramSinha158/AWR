﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.Actions.Equipment;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Equipment
{
    /// <summary>
    /// Test scenarios for Equipment Profile Type
    /// </summary>
    [TestFixture]
    internal class EquipmentTest : Hooks
    {

        [TestCase("EquipmentTestdata.json", "CreateEquipmentProfileType",
          TestName = "QA815_QA816_QA817_QA820_Create_Disable_Enable_Delete_EquipmentProfileType", Description = "M5-Create,Disable,Enable,Delete Equipment Profile Type"),Order(1)]
        public void QA815_QA816_QA817_QA820_Create_Disable_Enable_Delete_EquipmentProfileType(object[] testParameter)
        {
            AddRecords RecordData = CommonUtil.DataObjectForKey("AddRecords").ToObject<AddRecords>();
            AddRecords DummyRecordData = CommonUtil.DataObjectForKey("DummyRecord").ToObject<AddRecords>();          
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEquipmentProfileTypePage();
            EquipProfileTypesMainPage.ECode = CurrentPage.As<EqipProfileTypesPageActions>().CreateEquipmentProfileType(RecordData, DummyRecordData);
            CurrentPage.As<EqipProfileTypesPageActions>().VerifyEquipmentRecord(RecordData, EquipProfileTypesMainPage.ECode);
            Settings.Logger.Info("QA815 - Create Equipment Profile Type Completed Successfully.!");
            AddRecords EditDisableRecordData = CommonUtil.DataObjectForKey("DisableRecord").ToObject<AddRecords>();              
            CurrentPage.As<EqipProfileTypesPageActions>().EditEquipmentRecord(EditDisableRecordData, EquipProfileTypesMainPage.ECode);
            EditDisableRecordData.EDescription = RecordData.EDescription;
            CurrentPage.As<EqipProfileTypesPageActions>().VerifyEquipmentRecord(EditDisableRecordData, EquipProfileTypesMainPage.ECode);
            CommonUtil.AddPassedTestCase("QA816");
            Settings.Logger.Info("QA816 - Disable Equipment Profile Type Completed Successfully.!");
            AddRecords EditEnableRecordData = CommonUtil.DataObjectForKey("EnableRecord").ToObject<AddRecords>();
            CurrentPage.As<EqipProfileTypesPageActions>().EditEquipmentRecord(EditEnableRecordData, EquipProfileTypesMainPage.ECode);
            EditEnableRecordData.EDescription = RecordData.EDescription;
            CurrentPage.As<EqipProfileTypesPageActions>().VerifyEquipmentRecord(EditEnableRecordData, EquipProfileTypesMainPage.ECode);
            CommonUtil.AddPassedTestCase("QA817");
            Settings.Logger.Info("QA817 - Enable Equipment Profile Type Completed Successfully.!");
            CurrentPage.As<EqipProfileTypesPageActions>().DeleteEquipmentProfileType(EquipProfileTypesMainPage.ECode);
            CurrentPage.As<EqipProfileTypesPageActions>().VerifyDeletedEquipmentProfileType(EquipProfileTypesMainPage.ECode);
            CommonUtil.AddPassedTestCase("QA820");
            Settings.Logger.Info("QA820 - Delete Equipment Profile Type Completed Successfully.!");
        }

        [TestCase("EquipmentTestdata.json", "EquipmentType",
          TestName = "QA983_CreateEquipmentType", Description = "M5-Create Equipment Type")]
        public void QA983_CreateEquipmentType(object[] testParameter)
        {
            EquipmentTypeSKU EquipmentTypeObject = CommonUtil.DataObjectForKey("CreateEquipmentType").ToObject<EquipmentTypeSKU>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEquipmentTypesSKUPage();
            string EType = CurrentPage.As<EquipmentTypesSKUPageActions>().CreateNewEquipmentType(EquipmentTypeObject);
            CurrentPage.As<EquipmentTypesSKUPageActions>().VerifyEquipmentTypeInfo(EquipmentTypeObject);
        }

        [TestCase("EquipmentTestdata.json", "CreateEquipmentCondition",
          TestName = "QA984_CreateEquipmentCondition", Description = "M5-Create Equipment Condition")]
        public void QA984_CreateEquipmentCondition(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEquipmentConditionsPage();
            string Code = CurrentPage.As<EquipmentConditionsPageActions>().CreateNewEquipmentCondition();
            CurrentPage.As<EquipmentConditionsPageActions>().UpdateEquipmentCondition(Code, "UpdateCode");
            CurrentPage.As<EquipmentConditionsPageActions>().VerifyEquipmentCondition(Code, "UpdateCode");
            CurrentPage.As<EquipmentConditionsPageActions>().DeleteEquipmentCondition(Code);
        }

        [Test, Description("M5-Verifying work order page display")]
        public void QA822_CreateNewEquipmentProfile()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPurcEquipmentProfile();
            string EquipmentProfile = CurrentPage.As<EquipmentProfileMaintenancePageActions>().CreateNewEquipmentProfile("", "Inactive");
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().VerifyEquipmentProfile(EquipmentProfile);
        }

        [TestCase("EquipmentTestdata.json", "EquipmentProfileMaintenance", Description = "Edit Equipment profile (Primary nand Secondary)"),Order(1)]
        public void QA823_QA824_EditEquipmentprofilePrimarySecondary(object[] testParameter)
        {            
            EquipmentProfileeData? DataObject = CommonUtil.DataObjectForKey("EquipmentProfileeData").ToObject<EquipmentProfileeData>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAssetClassCodesPage();
            List<string> AssetClassCodeList = CurrentPage.As<AssetClassCodesPageActions>().GetAssectcodeList("EquipmentProfileeData");
            CurrentPage = _pageNavigate.NavigateToPurcEquipmentProfile();
            string EquipmentProfile = CurrentPage.As<EquipmentProfileMaintenancePageActions>().CreateNewEquipmentProfile(DataObject.EquipmentProfileID, DataObject.EquipmentProfileStatus);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().MovePrimaryEquipmentProfileCodes(DataObject, AssetClassCodeList[0]);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().VerifyPrimaryEquipmentProfileCodesTransfer(EquipmentProfile, AssetClassCodeList[0], DataObject);
            Settings.Logger.Info("QA823 - Edit Equipment Profile (Primary) Completed Successfully.!");
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().MoveSecondaryEquipmentProfileCodes(DataObject, AssetClassCodeList[1]);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().VerifySecondaryEquipmentProfileCodesTransfer(EquipmentProfile, AssetClassCodeList[1], DataObject);
            CommonUtil.AddPassedTestCase("QA824");
            Settings.Logger.Info("QA824 - Edit Equipment Profile (Secondary) Completed Successfully.!");
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().ResetSecondaryEquipmentProfileCodes(EquipmentProfile, DataObject);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().ResetPrimaryEquipmentProfileCodes(EquipmentProfile, DataObject);
            CurrentPage = _pageNavigate.NavigateToAssetClassCodesPage();
            CurrentPage.As<AssetClassCodesPageActions>().DeleteAssetClassCode(AssetClassCodeList[0]);
            CurrentPage = _pageNavigate.NavigateToAssetClassCodesPage();
            CurrentPage.As<AssetClassCodesPageActions>().DeleteAssetClassCode(AssetClassCodeList[1]);
        }

        [Test, Description("M5-Verifying Edit Equipment profile Secondary")]       
        public void QA824_EditEquipmentprofileSecondary()
        {
            CommonUtil.VerifyPassedTestCase("QA824");
        }

        [TestCase("EquipmentTestdata.json", "QA827_QA828_EditEquipmentProfile",
       TestName = "QA827_QA828_Disable_Enable_EquipmentProfile", Description = "M5-Disable_Enable_EquipmentProfile"),Order(1)]
        public void QA827_QA828_Disable_Enable_EquipmentProfile(object[] testParameter)     
        {
            EquipmentProfileeData? AddActiveEquipProfile = CommonUtil.DataObjectForKey("AddEquipmentProfile").ToObject<EquipmentProfileeData>();
            EquipmentProfileeData? EditEquipProfileInactive = CommonUtil.DataObjectForKey("EditEquipmentProfile").ToObject<EquipmentProfileeData>();
            CurrentPage = _pageNavigate.NavigateToPurcEquipmentProfile();
            EditEquipProfileInactive.EquipmentProfileID = CurrentPage.As<EquipmentProfileMaintenancePageActions>().CreateNewEquipmentProfile(AddActiveEquipProfile.EquipmentProfileID, AddActiveEquipProfile.EquipmentProfileStatus);
            Settings.Logger.Info("Pre Data SetUp Completed Successfully.!");
            //Set Equipment Profile status as Inactive
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().EditEquipmentProfileData(EditEquipProfileInactive);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().VerifyEquipmentProfile(EditEquipProfileInactive.EquipmentProfileID);
            Settings.Logger.Info("QA827 - Disable Equipment Profile Type Completed Successfully.!");
            //Set Equipment Profile Status to Active again
            AddActiveEquipProfile.EquipmentProfileID = EditEquipProfileInactive.EquipmentProfileID;
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().EditEquipmentProfileData(AddActiveEquipProfile);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().VerifyEquipmentProfile(AddActiveEquipProfile.EquipmentProfileID);
            CommonUtil.AddPassedTestCase("QA828");
            Settings.Logger.Info("QA828 - Enable Equipment Profile Type Completed Successfully.!");
        }

        [Test, Description("M5-Enable Equipment Profile")]    
        public void QA828_EnableEquipmentProfile()
        {
            CommonUtil.VerifyPassedTestCase("QA828");
        }

        [Test, Description("M5-Disable Equipment Profile Type")] 
        public void QA816_DisableEquipmentProfileType()
        {
            CommonUtil.VerifyPassedTestCase("QA816");
        }

        [Test, Description("M5-Enable Equipment Profile Type")]       
        public void QA817_EnableEquipmentProfileType()
        {
            CommonUtil.VerifyPassedTestCase("QA817");
        }

        [Test, Description("M5-Delete Equipment Profile Type")]
        public void QA820_DeleteEquipmentProfileType()
        {
            CommonUtil.VerifyPassedTestCase("QA820");
        }

        [TestCase("EquipmentTestdata.json", "EquipmentProfileMaintenance", Description = "M5-Booking-Equipment Profile Maintenance-Delete Equipment Profile")]
        public void QA830_DeleteEquipmentProfile(object[] testParameter)
        {
            EquipmentProfileeData? DataObject = CommonUtil.DataObjectForKey("EquipmentProfileeData").ToObject<EquipmentProfileeData>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAssetClassCodesPage();
            CurrentPage = _pageNavigate.NavigateToPurcEquipmentProfile();
            string EquipmentProfile=CurrentPage.As<EquipmentProfileMaintenancePageActions>().CreateNewEquipmentProfile(DataObject.EquipmentProfileID, DataObject.EquipmentProfileStatus);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().DeleteEquipmentProfile(EquipmentProfile);
            CurrentPage.As<EquipmentProfileMaintenancePageActions>().VerifyDeletedEquipmentProfile(EquipmentProfile);
        }
    }
}
