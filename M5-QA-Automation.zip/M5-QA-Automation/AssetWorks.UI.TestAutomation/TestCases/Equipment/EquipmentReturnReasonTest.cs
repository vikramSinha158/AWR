﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects.Equipment;
using AssetWorks.UI.M5.TestAutomation.Actions.Equipment;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Equipment
{
    /// <summary>
    /// Test scenarios for Equipment Return Reason
    /// </summary>
    [TestFixture]
    internal class EquipmentReturnReasonTest : Hooks
    {
        [TestCase("EquipRetReasonsTestData.json", "EquipmentReturnReasons",
          TestName = "QA1265_QA1266_CreateUpdateDeleteEquipmentReturnReason", Description = "M5-Create,Update,Delete Equipment Return Reasons"),Order(1),Author("Varsha")]
        public void QA1265_QA1266_CreateUpdateDeleteEquipmentReturnReason(object[] testParameter)
        {
            List<EquipmentReturnReasons> EqipRetReasonObj = CommonUtil.DataObjectForKey("QA1265_CreateEquipmentReturnReasons").ToObject<List<EquipmentReturnReasons>>();                  
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEquipmentReturnReasonPage();
            EqipRetReasonObj = CurrentPage.As<EqipRetReasonsPageActions>().CreateEquipmentReturnReasons(EqipRetReasonObj);
            CurrentPage.As<EqipRetReasonsPageActions>().VerifyEquipmentReturnReasons(EqipRetReasonObj);
            Settings.Logger.Info(" QA1265 - Create Equipment Return Reason Completed Successfully");
            List<EquipmentReturnReasons> UpdateEqipRetReasonObj = CommonUtil.DataObjectForKey("QA1266_UpdateEquipmentReturnReasons").ToObject<List<EquipmentReturnReasons>>();
            int record = 0;
            foreach (EquipmentReturnReasons reason in UpdateEqipRetReasonObj)
            {
                reason.Code = EqipRetReasonObj[record].Code;
                record++;
            }
            CurrentPage.As<EqipRetReasonsPageActions>().EditEquipmentReturnReasons(UpdateEqipRetReasonObj);
            CurrentPage.As<EqipRetReasonsPageActions>().VerifyEquipmentReturnReasons(UpdateEqipRetReasonObj);           
            CurrentPage.As<EqipRetReasonsPageActions>().DeleteEquipmentReturnReasons(UpdateEqipRetReasonObj);
            CurrentPage.As<EqipRetReasonsPageActions>().VerifyDeletedEquipmentReturnReasons(UpdateEqipRetReasonObj);
            CommonUtil.AddPassedTestCase("QA1266");
            Settings.Logger.Info(" QA1266 - Update,Delete Equipment Return Reason Completed Successfully");
        }

        [Test, Description("M5 - Update, Delete Equipment Return Reasons"), Author("Varsha")]
        public void QA1266_UpdateDeleteEquipmentReturnReasons()
        {
            Settings.Logger.Info("QA-1266 is merged with QA1265_QA1266_CreateUpdateDeleteEquipmentReturnReason");
            CommonUtil.VerifyPassedTestCase("QA1266");  
        }
    }
}
