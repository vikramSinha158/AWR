﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Employee
{
    [TestFixture]
    internal class EmployeeTransfersTest : Hooks
    {
        [Order(1)]
        [TestCase("EmployeeTransferTestData.json", "EmployeeTransfers",true,
        Description = "M5-Create Employee Required Parameters")]
        public void QA292_EmployeeTransfersRetrieveEmployeesAssigned(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().CreateEmployeeForTransfer();
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().CheckAndResetSupervisorList("EmployeeTransfersReset");
            CurrentPage.As<EmployeeTransfersPageActions>().VerifyRetrieveEmployeesDispaly();
        }

        [Order(2)]
        [TestCase("EmployeeTransferTestData.json", "EmployeeTransfers", true,
        Description = "M5-Transfer All Employees Firs tSupervisor To Second Superviso")]
        public void QA931_TransferAllEmployeesFirstSupervisorToSecondSupervisor(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().CreateEmployeeForTransfer();
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().CheckAndResetSupervisorList("EmployeeTransfersReset");
            CurrentPage.As<EmployeeTransfersPageActions>().VerifyRetrieveEmployeesDispaly();
            CurrentPage.As<EmployeeTransfersPageActions>().TransferAllEmployeesFromLeftToRight();
            List<string> Supervisor1EmpList=CurrentPage.As<EmployeeTransfersPageActions>().VerifyEmployeesTranferLeftToRight("EmployeeTransfersData");
            CurrentPage = _pageNavigate.NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().VerifySupervisorNameintransferedEmployee("EmployeeSupervisor1", Supervisor1EmpList);
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().ResetFirstSupervisorEmployee();
        }

        [Order(3)]
        [TestCase("EmployeeTransferTestData.json", "EmployeeTransfers", true,
        Description = "M5-Transfer All Employees Second Supervisor To First Supervisor")]
        public void QA933_TransferAllEmployeesSecondSupervisorToFirstSupervisor(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().CreateEmployeeForTransfer();
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().CheckAndResetSupervisorList("EmployeeTransfersReset");
            CurrentPage.As<EmployeeTransfersPageActions>().VerifyRetrieveEmployeesDispaly();
            CurrentPage.As<EmployeeTransfersPageActions>().TransferAllEmployeesFromRightToLeft();
            List<string> Supervisor2EmpList = CurrentPage.As<EmployeeTransfersPageActions>().VerifyEmployeesTransferRightToLeft("EmployeeTransfersData");
            CurrentPage = _pageNavigate.NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().VerifySupervisorNameintransferedEmployee("EmployeeSupervisor2", Supervisor2EmpList);
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().ResetSecondSupervisorEmployee();
        }

        [Order(4)]
        [TestCase("EmployeeTransferTestData.json", "EmployeeTransfers", true,
           Description = "M5-Transfer One Employees First Supervisor To Second Supervisor")]
        public void QA930_TransferOneEmployeesFirstSupervisorToSecondSupervisor(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().CreateEmployeeForTransfer();
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().CheckAndResetSupervisorList("EmployeeTransfersReset");
            CurrentPage.As<EmployeeTransfersPageActions>().VerifyRetrieveEmployeesDispaly();
            CurrentPage.As<EmployeeTransfersPageActions>().TranferOneEmployeeFromrLeftToRight();
            List<string> Supervisor1EmpList = CurrentPage.As<EmployeeTransfersPageActions>().VerifyTranferOneEmployeeFromeLeftToRight("EmployeeTransfersData");
            CurrentPage = _pageNavigate.NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().VerifySupervisorNameintransferedEmployee("EmployeeSupervisor1", Supervisor1EmpList);
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().ResetFirstSupervisorOneEmployee();
        }

        [Order(5)]
        [TestCase("EmployeeTransferTestData.json", "EmployeeTransfers", true,
        Description = "M5-Transfer One Employees Second Supervisor To First Supervisor")]
        public void QA932_TransferOneEmployeeSecondSupervisorToFirstSupervisor(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().CreateEmployeeForTransfer();
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().CheckAndResetSupervisorList("EmployeeTransfersReset");
            CurrentPage.As<EmployeeTransfersPageActions>().VerifyRetrieveEmployeesDispaly();
            CurrentPage.As<EmployeeTransfersPageActions>().TranferOneEmployeeFromrRightToLeft();
            List<string> Supervisor2EmpList = CurrentPage.As<EmployeeTransfersPageActions>().VerifyTranferOneEmployeeFromeRightToLeft("EmployeeTransfersData");
            CurrentPage = _pageNavigate.NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().VerifySupervisorNameintransferedEmployee("EmployeeSupervisor2", Supervisor2EmpList);
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().ResetSecondSupervisorOneEmployee();
        }

        [Order(6)]
        [TestCase("EmployeeTransferTestData.json", "EmployeeTransfers", true,
        Description = "M5-Transfer One Employees First Supervisor To Second Supervisor Double Click")]
        public void QA942_TransferOneEmployeesFirstSupervisorToSecondSupervisoDoubleClick(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().CreateEmployeeForTransfer();
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().CheckAndResetSupervisorList("EmployeeTransfersReset");
            CurrentPage.As<EmployeeTransfersPageActions>().VerifyRetrieveEmployeesDispaly();
            CurrentPage.As<EmployeeTransfersPageActions>().TranferOneEmployeeLeftToRightByDoubleClick();
            List<string> Supervisor1EmpList = CurrentPage.As<EmployeeTransfersPageActions>().VerifyTranferOneEmployeeFromeLeftToRight("EmployeeTransfersData");
            CurrentPage = _pageNavigate.NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().VerifySupervisorNameintransferedEmployee("EmployeeSupervisor1", Supervisor1EmpList);
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().ResetFirstSupervisorOneEmployee();
        }

        [Order(7)]
        [TestCase("EmployeeTransferTestData.json", "EmployeeTransfers", true,
        Description = "M5-Transfer One Employees second Supervisor To first Supervisor Double Click")]
        public void QA943_TransferOneEmployeeSecondSupervisorToFirstSupervisoDoubleClick(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().CreateEmployeeForTransfer();
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().CheckAndResetSupervisorList("EmployeeTransfersReset");
            CurrentPage.As<EmployeeTransfersPageActions>().VerifyRetrieveEmployeesDispaly();
            CurrentPage.As<EmployeeTransfersPageActions>().TranferOneEmployeeRightToLeftByDoubleClick();
            List<string> Supervisor2EmpList = CurrentPage.As<EmployeeTransfersPageActions>().VerifyTranferOneEmployeeFromeRightToLeft("EmployeeTransfersData");
            CurrentPage = _pageNavigate.NavigateToEmployeeMainPage();
            CurrentPage.As<EmployeeMainPageActions>().VerifySupervisorNameintransferedEmployee("EmployeeSupervisor2", Supervisor2EmpList);
            CurrentPage = _pageNavigate.NavigateToEmployeeTransfersPage();
            CurrentPage.As<EmployeeTransfersPageActions>().SetSupervisorInformation("EmployeeTransfersData");
            CurrentPage.As<EmployeeTransfersPageActions>().ResetSecondSupervisorOneEmployee();
        }
    }
}
