﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Employee
{
    /// <summary>
    /// Test scenarios for Employee
    /// </summary>
    [TestFixture]
    internal class EmployeeTest : Hooks
    {
        Dictionary<string, string>? flags =new Dictionary<string, string>();

        [TestCase("EmployeeMainTestdata.json", "CreateEmployee",
           Description = "M5-Create Employee Required Parameters")]
        public void QA841_CreateEmployeeRequiredParameters(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            string EmployeeID = CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeRequiredParameters");
            CurrentPage.As<EmployeeMainPageActions>().VerifyEmployeeMainInfo("CreateEmployeeRequiredParameters", EmployeeID);
        }

        [TestCase("EmployeeMainTestdata.json", "CreateEmployee",
            Description = "M5-Create Employee More Parameters")]
        public void QA839_CreateEmployeeMoreParameters(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            string EmployeeID = CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeMoreParameters");
            CurrentPage.As<EmployeeMainPageActions>().VerifyEmployeeMainInfo("CreateEmployeeMoreParameters", EmployeeID);
        }

        [TestCase("EmployeeMainTestdata.json", "QA840_CreateEmployeeWithSystemFlagsChanges",
          Description = "M5-CreateEmployeeWithSystemFlagsChanges")]
        public void QA840_CreateEmployeeWithSystemFlagsChanges(object[] testParameter)
        {           
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            CurrentPage = _pageNavigate.NavigateToEmployeeMainPage();
            string EmployeeID = CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeWithSystemFlags");
            CurrentPage.As<EmployeeMainPageActions>().VerifyEmployeeMainInfo("CreateEmployeeWithSystemFlags", EmployeeID);
            CurrentPage.As<EmployeeMainPageActions>().DeleteAndVerifyEmployeeDeletion(EmployeeID);           
        }

        [TestCase("EmployeeMainTestdata.json", "CreateEmployee",
            Description = "M5-Create Employee Required Parameters")]
        public void QA846_DeleteEmployee(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            string EmployeeID = CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeRequiredParameters");
            CurrentPage.As<EmployeeMainPageActions>().DeleteAndVerifyEmployeeDeletion(EmployeeID);
        }

        [TestCase("EmployeeTitleTestData.json", "EmployeeTitle", Description = "M5-Create,Update and Delete Employee Title")]
        public void QA919_CreateUpdateDeleteEmployeeTitle(object[] testParameter)
        {
            string DataObjectKey = "QA919_EmployeeTitleData";
            EmployeeTitleData empTitleObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<EmployeeTitleData>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeTitlePage();
            string EmployeeTitle = CurrentPage.As<EmployeeTitlePageActions>().CreateEmployeeTitle(empTitleObjectValues.CreateEmployeeTitle.Title, empTitleObjectValues.CreateEmployeeTitle.Productivity, empTitleObjectValues.CreateEmployeeTitle.Disabled);
            CurrentPage.As<EmployeeTitlePageActions>().VerifyEmployeeTitleData(EmployeeTitle, empTitleObjectValues.CreateEmployeeTitle.Productivity, empTitleObjectValues.CreateEmployeeTitle.Disabled);
            CurrentPage.As<EmployeeTitlePageActions>().UpdateAndVerifyEmployeeTitleData(EmployeeTitle, empTitleObjectValues.UpdateEmployeeTitle.Productivity, empTitleObjectValues.UpdateEmployeeTitle.Disabled);
            CurrentPage.As<EmployeeTitlePageActions>().DeleteEmployeeTitle(EmployeeTitle);
            CurrentPage.As<EmployeeTitlePageActions>().VerifyDeletedEmployeeTitle(EmployeeTitle);
        }

        [TestCase("EmployeeTitleTestData.json", "QA921_DisableEmployeeTitle", Description = "M5-Disable Employee Title")]
        public void QA921_DisableEmployeeTitle(object[] testParameter)
        {
            Dictionary<string, string> SystemFlagResetData = new Dictionary<string, string>();
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;           
            EmployeeTitleData empTitleObjectValues = CommonUtil.DataObjectForKey("DisableEmployeeTitle").ToObject<EmployeeTitleData>();           
            //Creating New Employee Title            
            string EmployeeTitle = _pageNavigate.NavigateToEmployeeTitlePage().CreateEmployeeTitle(empTitleObjectValues.CreateEmployeeTitle.Title, empTitleObjectValues.CreateEmployeeTitle.Productivity, empTitleObjectValues.CreateEmployeeTitle.Disabled);
            //Verify Disabled  Title not exist on Employee Main  
            _pageNavigate.NavigateToEmployeeMainPage().VerifyDataNotExistsInTitleLOV(empTitleObjectValues.EmployeeID, EmployeeTitle);
            //Deleting Employee Title
            _pageNavigate.NavigateToEmployeeTitlePage().DeleteEmployeeTitle(EmployeeTitle);            
        }

        [TestCase("EmployeeMainTestdata.json", "CreateEmployeeGroup", TestName = "QA862_QA863_QA864_QA865_QA869_EmployeeGroup",
            Description = "M5-Create, Retrieve, Include Employees, Verify Employee Link and Delete Employee Group"),Order(1)]
        public void QA862_QA863_QA864_QA865_QA869_EmployeeGroup(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeGroupPage();
            string EmpGroup = CurrentPage.As<EmployeeGroupPageActions>().CreateEmployeeGroup(CommonUtil.DataForKey("Location"));
            CurrentPage.As<EmployeeGroupPageActions>().VerifyAssignedEmployeeInGroup(CommonUtil.DataForKey("EmpName"), CommonUtil.DataForKey("EmpTitle"));
            Settings.Logger.Info("QA862 - Create Employee Group completed successfully.!");
            CurrentPage.As<EmployeeGroupPageActions>().RetrieveEmployeeGroup(CommonUtil.DataForKey("Location"), EmpGroup);
            CommonUtil.AddPassedTestCase("QA863");
            Settings.Logger.Info("QA863 - Retrieve Employee Group completed successfully.!");
            CurrentPage.As<EmployeeGroupPageActions>().IncludeAssignedEmployeeInGroup(CommonUtil.DataForKey("EmpName"));
            CommonUtil.AddPassedTestCase("QA864");
            Settings.Logger.Info("QA864 - Include Employees to Employee Group completed successfully.!");
            CurrentPage.As<EmployeeGroupPageActions>().VerifyEmployeeLink(CommonUtil.DataForKey("EmpId"), CommonUtil.DataForKey("EmpName"));
            CommonUtil.AddPassedTestCase("QA865");
            Settings.Logger.Info("QA865 - Verify Employee Link is Active in Employee Group completed successfully.!");
            CurrentPage.As<EmployeeGroupPageActions>().DeleteEmployeeGroup(CommonUtil.DataForKey("Location"), EmpGroup);
            CommonUtil.AddPassedTestCase("QA869");
            Settings.Logger.Info("QA869 - Delete Employee Group completed successfully.!");
        }

        [Test, Description("M5-Retrieve Employee Group")] 
        public void QA863_RetrieveEmployeeGroup()
        {
            CommonUtil.VerifyPassedTestCase("QA863");
        }

        [Test, Description("M5-Include Employees to Employee Group")] 
        public void QA864_IncludeAssignedEmployeeGroup()
        {
            CommonUtil.VerifyPassedTestCase("QA864");
        }

        [Test, Description("M5-Verify Employee Link Employee Group")]
    
        public void QA865_VerifyEmployeeLinkEmployeeGroup()
        {
            CommonUtil.VerifyPassedTestCase("QA865");
        }

        [Test, Description("M5-Delete Employee Group")]    
        public void QA869_DeleteEmployeeGroup()
        {
            CommonUtil.VerifyPassedTestCase("QA869");
        }

        [TestCase("EmployeeMainTestdata.json", "QA928_EmployeeShiftAssign",
       Description = "M5-Assign ,Delete Employee Shift Code"),Order(1)]
        public void QA928_QA927_EmployeeShiftAsignment(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            string EmployeeID = _pageNavigate.NavigateToEmployeeMainPage().CreateNewEmployee("CreateEmployeeRequiredParameters");
            CurrentPage = _pageNavigate.NavigateToEmployeeShiftAssignmentPage();
            string CurrentassignShift=CurrentPage.As<EmployeeShiftAssignPageActions>().AssignShifts(EmployeeID, "EmployeeShiftAssign");
            CurrentPage.As<EmployeeShiftAssignPageActions>().VerifyAssignShifts(EmployeeID, "EmployeeShiftAssign");
            _pageNavigate.NavigateToEmployeeMainPage().VerifyShiftCode(EmployeeID, CurrentassignShift);
            Settings.Logger.Info("QA928 - Assign Shift Code to Employee  completed successfully.!");
            CurrentPage = _pageNavigate.NavigateToEmployeeShiftAssignmentPage();
            CurrentPage.As<EmployeeShiftAssignPageActions>().DeleteAssignShifts(EmployeeID, "EmployeeShiftAssign");
            CurrentPage.As<EmployeeShiftAssignPageActions>().VerifyDeletedAssignShifts(EmployeeID, "EmployeeShiftAssign");
            CommonUtil.AddPassedTestCase("QA927");
            Settings.Logger.Info("QA927 - Delete Assigned Shift Code to Employee completed successfully.!");          
        }

        [Test, Description("M5 - Employee - Employee Shift Assignment - Delete Assigned to Employee Shift")]
        public void QA927_DeleteAssignedShiftCodeEmployee()
        {
            CommonUtil.VerifyPassedTestCase("QA927");
        }

        [TestCase("EmployeeCopyTestData.json", "EmployeeCopy",
            Description = "M5-Create Employee Required Parameters")]
        public void QA847_EmployeeCopy(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeCopyPage();
            string EmpID=CurrentPage.As<EmployeeMainPageActions>().CopyEmployee("QA847_EmployeeCopyID");
            CurrentPage.As<EmployeeMainPageActions>().VerifyEmployeeMainInfo("QA847_EmployeeDataToVerify", EmpID,true);
            CurrentPage.As<EmployeeMainPageActions>().DeleteAndVerifyEmployeeDeletion(EmpID);
        }

        [TestCase("EmployeeMainTestdata.json", "CreateEmployee",
            Description = "M5 - Employee - Employee ID Change")]
        public void QA848_ChangeEmployeeId(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            string EmployeeID = CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeRequiredParameters");
            CurrentPage.As<EmployeeMainPageActions>().VerifyEmployeeMainInfo("CreateEmployeeRequiredParameters", EmployeeID);
            CurrentPage = _pageNavigate.NavigateToEmployeeNumberChange();
            _extendedpage.OpenAndCloseHelp(true);
            (string newEmployeeId, CurrentPage) = CurrentPage.As<EmployeeNumberChangeActions>().ChangeEmployeeId(EmployeeID);
            CurrentPage.As<EmployeeMainPageActions>().VerifyEmployeeIdChange(newEmployeeId);
            CurrentPage.As<EmployeeMainPageActions>().DeleteAndVerifyEmployeeDeletion(newEmployeeId);
        }

        [TestCase("EmployeeMainTestdata.json", "CreateEmployee",
        Description = "M5-Set Active Employee to NOT EMPLOYED Status")]
        public void QA845_SetEmployeeStatusToNotEmployed(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            string EmployeeID = CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeRequiredParameters");
            CurrentPage.As<EmployeeMainPageActions>().EditAndVerifyEmployeeStatus("QA845_EditEmployeeStatus", EmployeeID);
        }

        [TestCase("EmployeeMainTestdata.json", "CreateEmployee", TestName = "QA843_UpdateEmployeeInformation",
         Description = "M5 - Employee - Employee Main - Update Employee")]
        public void QA843_UpdateEmployeeInformation(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            string EmployeeID = CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee("CreateEmployeeMoreParameters");
            CurrentPage.As<EmployeeMainPageActions>().UpdateEmployeeInformation("QA843_UpdateEmployee", EmployeeID);
            CurrentPage.As<EmployeeMainPageActions>().VerifyEmployeeMainInfo("QA843_UpdateEmployee", EmployeeID);
            CurrentPage.As<EmployeeMainPageActions>().DeleteAndVerifyEmployeeDeletion(EmployeeID);
        }

        [TestCase("EmployeeMainTestdata.json", "QA849_AssignItemToEmployee", TestName = "QA849_QA851_AssignItemToEmployee",
           Description = "M5-Employee - Items Employees - Update Assigned Item to Employee"), Order(1)]
        public void QA849_QA851_AssignItemToEmployee(object[] testParameter)
        {
            EmployeeItems empItem = CommonUtil.DataObjectForKey("EmpInfo").ToObject<EmployeeItems>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeItems();
            CurrentPage.As<EmployeeItemsPageActions>().AssignItemsToEmployee(empItem);
            CurrentPage.As<EmployeeItemsPageActions>().VerifyAssignedItemsToEmployee(empItem);
            CommonUtil.AddPassedTestCase("QA849");
            Settings.Logger.Info("-----Execution completed for test ' QA849 Items Employees - Assign Item to Employee ' -------");
            EmployeeItems empItemU = CommonUtil.DataObjectForKey("EmpInfoUpdate").ToObject<EmployeeItems>();
            CurrentPage.As<EmployeeItemsPageActions>().UpdateAssignedItemsToEmployee(empItemU);
            CurrentPage.As<EmployeeItemsPageActions>().VerifyAssignedItemsToEmployee(empItemU);
            CurrentPage.As<EmployeeItemsPageActions>().RemoveAssignedItemsToEmployee(empItemU);
            Settings.Logger.Info("-----Execution completed for test ' QA851 Items Employees - Update Assigned Item ' -------");
        }

        [Test, Description("M5-Employee - Items Employees - Assign Item to Employee")]
        public void QA849_AssignItemToEmployee()
        {
            CommonUtil.VerifyPassedTestCase("QA849");
        }

        [TestCase("EmployeeMainTestdata.json", "QA850_AssignItemsToEmployee", TestName = "QA850_QA853_DeleteAssignedMultipleItemsToEmployee",
           Description = "M5-Employee - Items Employees - Assign Multiple Items to Employee & Delete Assigned Items"), Order(1)]
        public void QA850_QA853_DeleteAssignedMultipleItemsToEmployee(object[] testParameter)
        {
            EmployeeItems empItem = CommonUtil.DataObjectForKey("EmpInfo").ToObject<EmployeeItems>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeItems();
            CurrentPage.As<EmployeeItemsPageActions>().AssignItemsToEmployee(empItem);
            CurrentPage.As<EmployeeItemsPageActions>().VerifyAssignedItemsToEmployee(empItem);
            CommonUtil.AddPassedTestCase("QA850");
            Settings.Logger.Info("-----Execution completed for test ' QA850 Assign Multiple Items to Employee ' -------");
            CurrentPage.As<EmployeeItemsPageActions>().RemoveAssignedItemsToEmployee(empItem);
            CurrentPage.As<EmployeeItemsPageActions>().VerifyAssignedItemsDeletedFromEmployee(empItem);
            Settings.Logger.Info("-----Execution completed for test ' QA853 Items Employees - Delete Assigned Item ' -------");
        }

        [Test, Description("M5-Employee - Items Employees - Assign Multiple Items to Employee")]
        public void QA850_AssignMultipleItemsToEmployee()
        {
            CommonUtil.VerifyPassedTestCase("QA850");
        }
    }
}
