using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Employee
{
    [TestFixture]
    internal class EmployeeTrainingTranscriptTest : Hooks
    {
        [TestCase("EmpTrainingTranscriptTestData.json", "EmployeeTrainingTranscript", true, TestName = "QA887_QA889_QA1146_AddTrainingCoursePassResult_AddMoreCourses_DeleteCourse",
        Description = "M5- Employee - Employee Training Transcript - Add Training Course for Employee with Pass result and Delete Course"), Order(1)]
        public void QA887_QA889_QA1146_AddTrainingCoursePassResult_AddMoreCourses_DeleteCourse(object[] testParameter)
        {
            EmpTrainingTranscipt empTTObject = CommonUtil.DataObjectForKey("QA887_TrainingCoursePassResult").ToObject<EmpTrainingTranscipt>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmpTrainingTransciptPage();
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empTTObject.EmployeeData.EmpNo);
            Settings.Logger.Info("Pre Execution Data Clean Up Completed Successfully ");
            empTTObject = CurrentPage.As<EmployeeTrainingTransciptPageActions>().AddTrainingCourse(empTTObject);
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().VerifyEmployeeTrainingTranscript(empTTObject);
            Settings.Logger.Info("QA887 - Add Training Course Pass Result Completed Successfully.!");
            EmpTrainingTranscipt empAddMoreCourseObject = CommonUtil.DataObjectForKey("QA889_AddMoreTrainingCourse").ToObject<EmpTrainingTranscipt>();
            empAddMoreCourseObject.EmployeeData = empTTObject.EmployeeData;
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().AddTrainingCourse(empAddMoreCourseObject);
            for (int i = 0; i < empTTObject.TrainingCourseData.Count; i++)
            {
                empAddMoreCourseObject.TrainingCourseData.Add(empTTObject.TrainingCourseData[i]);
            }
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().VerifyEmployeeTrainingTranscript(empAddMoreCourseObject);
            CommonUtil.AddPassedTestCase("QA889");
            Settings.Logger.Info("QA889 - Add More Training Courses Completed Successfully.!");
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empAddMoreCourseObject.EmployeeData.EmpNo);
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().VerifyTrainingCourseDeletion(empTTObject);
            CommonUtil.AddPassedTestCase("QA1146");
            Settings.Logger.Info("QA1146 - Delete Training Course Completed Successfully.!");
        }

        [Test, Description("M5-Employee Training Transcript- Add More Training Course")]
        public void QA889_AddMoreTrainingCourse()
        {
            CommonUtil.VerifyPassedTestCase("QA889");
        }

        [Test, Description("M5-Employee Training Transcript- Delete Training Course")]
        public void QA1146_DeleteTrainingCourse()
        {
            CommonUtil.VerifyPassedTestCase("QA1146");
        }

        [TestCase("EmpTrainingTranscriptTestData.json", "EmployeeTrainingTranscript", true, TestName = "QA890_QA893_AddTrainingCourseFailResult_UpdateTrainingCourse",
        Description = "M5- Employee - Employee Training Transcript - Add Training Course for Employee with Fail result ,Update Course"), Order(1)]
        public void QA890_QA893_AddTrainingCourseFailResult_UpdateTrainingCourse(object[] testParameter)
        {
            EmpTrainingTranscipt empCourseObject = CommonUtil.DataObjectForKey("QA890_TrainingCourseFailResult").ToObject<EmpTrainingTranscipt>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmpTrainingTransciptPage();
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empCourseObject.EmployeeData.EmpNo);
            Settings.Logger.Info("Pre Execution Data Clean Up Completed Successfully ");
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().AddTrainingCourse(empCourseObject);
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().VerifyEmployeeTrainingTranscript(empCourseObject);
            Settings.Logger.Info("QA890 - Add Training Course Fail Result Completed Successfully.!");
            EmpTrainingTranscipt empCourseUpdateObject = CommonUtil.DataObjectForKey("QA893_UpdateTrainingCourse").ToObject<EmpTrainingTranscipt>();
            empCourseUpdateObject.EmployeeData = empCourseObject.EmployeeData;
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().EditCourseData(empCourseUpdateObject);
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().VerifyEmployeeTrainingTranscript(empCourseUpdateObject);
            CommonUtil.AddPassedTestCase("QA893");
            Settings.Logger.Info("QA893 - Update Training Course Completed Successfully.!");
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empCourseUpdateObject.EmployeeData.EmpNo);
            Settings.Logger.Info("Post Execution Data Clean Up Completed Successfully ");
        }

        [Test, Description("M5-Employee Training Transcript- Update Training Course")]
        public void QA893_UpdateTrainingCourse()
        {
            CommonUtil.VerifyPassedTestCase("QA893");
        }

        [TestCase("EmpTrainingTranscriptTestData.json", "EmployeeTrainingTranscript", true, TestName = "QA891_QA892_Add_Detach_Attachments_EmployeeTrainingCourse",
        Description = "M5- Employee - Employee Training Transcript - Add and Detach Attachments Employee Training Course "), Order(1)]
        public void QA891_QA892_Add_Detach_Attachments_EmployeeTrainingCourse(object[] testParameter)
        {
            EmpTrainingTranscipt empCourseObject = CommonUtil.DataObjectForKey("QA891_TrainingCourseAttachment").ToObject<EmpTrainingTranscipt>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmpTrainingTransciptPage();
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DetachAllAttachments(empCourseObject.EmployeeData.EmpNo);
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empCourseObject.EmployeeData.EmpNo);            
            Settings.Logger.Info("Pre Execution Data Clean Up Completed Successfully ");
            //Add Training Course and Add Attachments
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().AddTrainingCourse(empCourseObject);
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().VerifyTotalAttachedDocs(empCourseObject.TrainingCourseData);            
            Settings.Logger.Info("QA891 - Add Attachments Employee Training Course Completed Successfully.!");
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DetachAllAttachments(empCourseObject.EmployeeData.EmpNo);
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().VerifyDetachDocs(empCourseObject.TrainingCourseData);
            CommonUtil.AddPassedTestCase("QA892");
            Settings.Logger.Info("QA892 - Detach Attachments Employee Training Course Completed Successfully.!");
        }

        [Test, Description("M5- Employee - Employee Training Transcript -Detach Attachments Employee Training Course ")]
        public void QA892_DetachAttachmentsEmployeeTrainingCourse()
        {
            CommonUtil.VerifyPassedTestCase("QA893");
        }

    }
    }
