using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Employee
{
    [TestFixture]
    internal class EmployeeCourseQueryTest : Hooks
    {
        [TestCase("EmpCourseQueryTestData.json", "EmployeeCourseQuery", true, TestName = "QA900_RetrieveTrainingCourseRecordAllFields",
        Description = "M5 - Employee - Employee Training Course Query - Retrieve Training Course Record by entering data for all fields")]
        public void QA900_RetrieveTrainingCourseRecordAllFields(object[] testParameter)
        {
            EmployeeCourseQuery empCQObject = CommonUtil.DataObjectForKey("QA900_EmployeeCourseQuery").ToObject<EmployeeCourseQuery>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmpTrainingTransciptPage();
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empCQObject.EmployeeData.EmpNo);
            EmpTrainingTranscipt empTrainScint = CurrentPage.As<EmployeeTrainingTransciptPageActions>().GetUpdatedTrainingTranscriptObject(empCQObject);
            empTrainScint = CurrentPage.As<EmployeeTrainingTransciptPageActions>().AddTrainingCourse(empTrainScint);            
            Settings.Logger.Info("Pre Execution Data SetUp Completed Successfully ");       
            CurrentPage=_pageNavigate.NavigateToEmpCourseQueryPage();
            empCQObject.VerifyQueryResult = CurrentPage.As<EmployeeCourseQueryPageActions>().GetUpdatedVerifyQueryResultObject(empTrainScint,null, empCQObject.VerifyQueryResult);
            Settings.Logger.Info("QA-900 Execution Started.... ");
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            Settings.Logger.Info("QA-900 Execution Completed.");
        }


        [TestCase("EmpCourseQueryTestData.json", "EmployeeCourseSetUpAndTrainingCourseQuery",
        Description = "M5 - Employee - Employee Training Course Query - Retrieve Training Course Record based on Filters"),Order(1)]
        public void QA910_QA911_QA913_QA914_QA918_QA912_RetrieveTrainingCourseBasedOnFilters(object[] testParameter)
        {
            TrainingCourseSetUp courseObjectValues = CommonUtil.DataObjectForKey("TrainingCourseSetUp").ToObject<TrainingCourseSetUp>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmpCourseSetUpPage();
            courseObjectValues.Code = CurrentPage.As<EmpCoureSetUpPageActions>().CreateEmployeeTrainingCourse(courseObjectValues);
            EmployeeCourseQuery empCQObject = CommonUtil.DataObjectForKey("QA910_RetrieveTrainingCourseAllFields").ToObject<EmployeeCourseQuery>();
            empCQObject.TrainingCourseData[0].Course = courseObjectValues.Code;
            CurrentPage = _pageNavigate.NavigateToEmpTrainingTransciptPage();
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empCQObject.EmployeeData.EmpNo);       
            EmpTrainingTranscipt empTrainScint = CurrentPage.As<EmployeeTrainingTransciptPageActions>().GetUpdatedTrainingTranscriptObject(empCQObject);
            empTrainScint = CurrentPage.As<EmployeeTrainingTransciptPageActions>().AddTrainingCourse(empTrainScint);
            Settings.Logger.Info("Pre Execution Data SetUp Completed Successfully ");           
            CurrentPage = _pageNavigate.NavigateToEmpCourseQueryPage();            
            empCQObject.VerifyQueryResult = CurrentPage.As<EmployeeCourseQueryPageActions>().GetUpdatedVerifyQueryResultObject(empTrainScint, courseObjectValues.Code, empCQObject.VerifyQueryResult);
            empCQObject.EmployeeCourseQueryData.Course = courseObjectValues.Code;
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            Settings.Logger.Info("QA-910 Retrieve Planned Training Course Record (AllFields) Execution Completed.");
            EmployeeCourseQuery empCQObject911 = CommonUtil.DataObjectForKey("QA911_RetrieveTrainingCourseCourseField").ToObject<EmployeeCourseQuery>();
            empCQObject911.EmployeeCourseQueryData.Course = courseObjectValues.Code;
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject911.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            CommonUtil.AddPassedTestCase("QA911");
            Settings.Logger.Info("QA-911 Retrieve Training Course( Course Field) Execution Completed.");
            EmployeeCourseQuery empCQObject913 = CommonUtil.DataObjectForKey("QA913_RetrieveTrainingCourseEmployeeField").ToObject<EmployeeCourseQuery>();
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject913.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            CommonUtil.AddPassedTestCase("QA913");
            Settings.Logger.Info("QA-913 Retrieve Training Course( Employee Field) Execution Completed.");     
            EmployeeCourseQuery empCQObject914 = CommonUtil.DataObjectForKey("QA914_RetrieveTrainingCourseResourceField").ToObject<EmployeeCourseQuery>();
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject914.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            CommonUtil.AddPassedTestCase("QA914");
            Settings.Logger.Info("QA-914 Retrieve Training Course( Resource Type Field) Execution Completed.");
            EmployeeCourseQuery empCQObject918 = CommonUtil.DataObjectForKey("QA918_RetrieveTrainingCourseNextDate").ToObject<EmployeeCourseQuery>();
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject918.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            CommonUtil.AddPassedTestCase("QA918");
            Settings.Logger.Info("QA-918 Retrieve Training Course( Next Date) Execution Completed.");
            EmployeeCourseQuery empCQObject912Vendor = CommonUtil.DataObjectForKey("QA912_RetrieveTrainingCourseVendor").ToObject<EmployeeCourseQuery>();
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject912Vendor.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            EmployeeCourseQuery empCQObject912Loc = CommonUtil.DataObjectForKey("QA912_RetrieveTrainingCourseLocation").ToObject<EmployeeCourseQuery>();
            CurrentPage.As<EmployeeCourseQueryPageActions>().EnterCourseQueryData(empCQObject912Loc.EmployeeCourseQueryData);
            CurrentPage.As<EmployeeCourseQueryPageActions>().VerifyCourseAttendQueryHistory(empCQObject.VerifyQueryResult, empCQObject.TrainingCourseData.Count);
            CommonUtil.AddPassedTestCase("QA912");
            Settings.Logger.Info("QA-912 Retrieve Training Course( Location and Vendor) Execution Completed.");
            CurrentPage = _pageNavigate.NavigateToEmpTrainingTransciptPage();
            CurrentPage.As<EmployeeTrainingTransciptPageActions>().DeleteAllTrainingCourse(empCQObject.EmployeeData.EmpNo);
            CurrentPage = _pageNavigate.NavigateToEmpCourseSetUpPage();
            CurrentPage.As<EmpCoureSetUpPageActions>().DeleteTrainingCourse(courseObjectValues.Code);
            Settings.Logger.Info("Post Execution Data CleanUp Completed Successfully ");
        }

        [Test, Description("M5-Retrieve Training Course-Course Field")]   
        public void QA911_RetrieveTrainingCourse_CourseField()
        {
            Settings.Logger.Info("QA911 is merged with QA910_QA911_QA913_QA914_QA918_QA912_RetrieveTrainingCourseBasedOnFilters");
            CommonUtil.VerifyPassedTestCase("QA911");
        }

        [Test, Description("M5-Retrieve Training Course-Employee Field")]
        public void QA913_RetrieveTrainingCourse_EmployeeField()
        {
            Settings.Logger.Info("QA913 is merged with QA910_QA911_QA913_QA914_QA918_QA912_RetrieveTrainingCourseBasedOnFilters");
            CommonUtil.VerifyPassedTestCase("QA913");
        }

        [Test, Description("M5-Retrieve Training Course-Resource Type Field")]
        public void QA914_RetrieveTrainingCourse_ResourceTypeField()
        {
            Settings.Logger.Info("QA914 is merged with QA910_QA911_QA913_QA914_QA918_QA912_RetrieveTrainingCourseBasedOnFilters");
            CommonUtil.VerifyPassedTestCase("QA914");
        }

        [Test, Description("M5-Retrieve Training Course-Next Date Field")]
        public void QA918_RetrieveTrainingCourse_NextDateField()
        {
            Settings.Logger.Info("QA918 is merged with QA910_QA911_QA913_QA914_QA918_QA912_RetrieveTrainingCourseBasedOnFilters");
            CommonUtil.VerifyPassedTestCase("QA918");
        }

        [Test, Description("M5-Retrieve Training Course-Location and Vendor Field")]
        public void QA912_RetrieveTrainingCourse_LocationAndVendor()
        {
            Settings.Logger.Info("QA912 is merged with QA910_QA911_QA913_QA914_QA918_QA912_RetrieveTrainingCourseBasedOnFilters");
            CommonUtil.VerifyPassedTestCase("QA912");
        }
    }
    
}
