﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Labor;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Employee
{
    /// <summary>
    /// Test scenarios for Employee Planned Absences
    /// </summary>
    [TestFixture]
    internal class EmpPlannedAbsencesTest : Hooks
    {

        [TestCase("EmpPlannedAbsencesTestData.json", "EmployeePlannedAbsences",
        TestName = "QA898_QA872_QA873_QA877_Create_Update_AddMore_Delete_EmployeePlannedAbsences", Description = "M5-Employee-Create,Update,AddMore,Delete-Employee Planned Absences"),Order(1)]
        public void QA898_QA872_QA873_QA877_Create_Update_AddMore_Delete_EmployeePlannedAbsences(object[] testParameter)
        {
            EmpPlannedAbsences Absences = CommonUtil.DataObjectForKey("QA898_EmployeePlannedAbsences").ToObject<EmpPlannedAbsences>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeePlannedAbsences();
            CurrentPage.As<EmployeePlannedAbsencesPageActions>().DeleteAllPlannedAbsences(Absences.EmployeeNo);
            Settings.Logger.Info("Pre Execution Data CleanUp Completed Successfully.!");
            Absences =CurrentPage.As<EmployeePlannedAbsencesPageActions>().AddEmployeePlannedAbsences(Absences);
            CurrentPage.As<EmployeePlannedAbsencesPageActions>().VerifyEmployeePlannedAbsences(Absences);
            Settings.Logger.Info("QA898 - Create Employee Planned Absences Completed Successfully.!");
            EmpPlannedAbsences UpdateAbsences = CommonUtil.DataObjectForKey("QA872_UpdateEmployeePlannedAbsences").ToObject<EmpPlannedAbsences>();
            UpdateAbsences=CurrentPage.As<EmployeePlannedAbsencesPageActions>().UpdateEmployeePlannedAbsences(UpdateAbsences);
            EmpPlannedAbsences VerifyUpdatedAbsences = CommonUtil.DataObjectForKey("QA872_VerifyUpdatedEmployeePlannedAbsences").ToObject<EmpPlannedAbsences>();
            VerifyUpdatedAbsences.AbsencesDetails[0].StartDate = UpdateAbsences.AbsencesDetails[0].StartDate;
            VerifyUpdatedAbsences.AbsencesDetails[0].EndDate = UpdateAbsences.AbsencesDetails[0].EndDate;                       
            CurrentPage.As<EmployeePlannedAbsencesPageActions>().VerifyEmployeePlannedAbsences(VerifyUpdatedAbsences);
            CommonUtil.AddPassedTestCase("QA872");
            Settings.Logger.Info("QA872 -Update Employee Planned Absences Completed Successfully.!");          
            EmpPlannedAbsences AddMoreAbsences = CommonUtil.DataObjectForKey("QA873_AddMoreEmployeePlannedAbsences").ToObject<EmpPlannedAbsences>();
            AddMoreAbsences = CurrentPage.As<EmployeePlannedAbsencesPageActions>().AddEmployeePlannedAbsences(AddMoreAbsences);
            AddMoreAbsences.AbsencesDetails.Add(UpdateAbsences.AbsencesDetails[0]);
            CurrentPage.As<EmployeePlannedAbsencesPageActions>().VerifyEmployeePlannedAbsences(AddMoreAbsences);
            CommonUtil.AddPassedTestCase("QA873");
            Settings.Logger.Info("QA873 - Add More Employee Planned Absences Completed Successfully.!");
            CurrentPage.As<EmployeePlannedAbsencesPageActions>().DeleteEmployeePlannedAbsences(AddMoreAbsences);
            CurrentPage.As<EmployeePlannedAbsencesPageActions>().VerifyDeleteEmployeePlannedAbsences(AddMoreAbsences);
            CommonUtil.AddPassedTestCase("QA877");
            Settings.Logger.Info("QA877 - Delete Employee Planned Absences Completed Successfully.!");
        }

        [Test, Description("M5-Update Employee Planned Absences")]    
        public void QA872_UpdateEmployeePlannedAbsences()
        {
            Settings.Logger.Info("QA872 merged with QA898_QA872_QA877_Create_Update_Delete_EmployeePlannedAbsences");
            CommonUtil.VerifyPassedTestCase("QA872");
           
        }

        [Test, Description("M5-Delete Employee Planned Absences")]
        public void QA877_DeleteEmployeePlannedAbsences()
        {
            Settings.Logger.Info("QA877 merged with QA898_QA872_QA877_Create_Update_Delete_EmployeePlannedAbsences");
            CommonUtil.VerifyPassedTestCase("QA877");
           
        }

        [Test, Description("M5-Add More Employee Planned Absences")]
        public void QA873_AddMoreEmployeePlannedAbsences()
        {
            CommonUtil.VerifyPassedTestCase("QA873");
        }
       
    }
}
