﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using Newtonsoft.Json.Linq;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Employee
{
    /// <summary>
    /// Test scenarios for Employee
    /// </summary>
    [TestFixture]
    internal class EmpTrainingCourseSetUpTest : Hooks
    {       

        [TestCase("EmpTrainingCourseTestData.json", "EmployeeTrainingCourseSetup",
           Description = "M5-Create,Update and Delete Employee Training Course"),Order(1)]
        public void QA883_QA884_QA886_Create_Update_Delete_EmployeeTrainingCourse(object[] testParameter)
        {
            TrainingCourseSetUp courseObjectValues = CommonUtil.DataObjectForKey("AddTrainingCourse").ToObject<TrainingCourseSetUp>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmpCourseSetUpPage();
            courseObjectValues.Code = CurrentPage.As<EmpCoureSetUpPageActions>().CreateEmployeeTrainingCourse(courseObjectValues);
            CurrentPage.As<EmpCoureSetUpPageActions>().VerifyEmployeeTrainingCourse(courseObjectValues);
            Settings.Logger.Info("QA883 - Create Employee Training Course Completed Successfully.!");
            TrainingCourseSetUp editCourseObjectValues = CommonUtil.DataObjectForKey("EditTrainingCourse").ToObject<TrainingCourseSetUp>();
            editCourseObjectValues.Code = courseObjectValues.Code;
            CurrentPage.As<EmpCoureSetUpPageActions>().EditEmployeeTrainingCourse(editCourseObjectValues);
            CurrentPage.As<EmpCoureSetUpPageActions>().VerifyEmployeeTrainingCourse(editCourseObjectValues);
            CommonUtil.AddPassedTestCase("QA884");
            Settings.Logger.Info("QA884 - Update Employee Training Course Completed Successfully.!");
            CurrentPage.As<EmpCoureSetUpPageActions>().DeleteTrainingCourse(editCourseObjectValues.Code);
            CurrentPage.As<EmpCoureSetUpPageActions>().VerifyDeletedTrainingCourse(editCourseObjectValues.Code);
            CommonUtil.AddPassedTestCase("QA886");
            Settings.Logger.Info("QA886 - Delete Employee Training Course Completed Successfully.!");
        }

        [Test, Description("M5-Update Employee Training Course")]    
        public void QA884_UpdateEmployeeTrainingCourse()
        {
            CommonUtil.VerifyPassedTestCase("QA884");
        }

        [Test, Description("M5-Delete Employee Training Course")]   
        public void QA886_DeleteEmployeeTrainingCourse()
        {
            CommonUtil.VerifyPassedTestCase("QA886");
        }
    }
}
