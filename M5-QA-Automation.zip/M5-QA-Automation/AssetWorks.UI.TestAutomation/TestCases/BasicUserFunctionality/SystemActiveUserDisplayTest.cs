﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.BasicUserFunctionality
{
    [TestFixture]
    internal class SystemActiveUserDisplayTest : Hooks
    {
        [TestCase("BasicUserFuncTestData.json", "ActiveUser",
        Description = "M5-Basic User Functionality-Active User Display")]
        public void QA723_CheckActiveUserDisplayFrame(object[] testParameter)
        {          
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemActiveUserDsiplay();              
            CurrentPage.As<SystemActiveUserDisplayAction>().VerifyActiveUserDetails("QA723_CheckActiveUserDisplayFrame");           
        }
    }
}
