﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;
using AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.WorkRequest
{
    [TestFixture]
    internal class WorkRequestTest : Hooks
    {
        [TestCase("WorkRequestTestData.json", "QA874_CreateWorkRequestByUnit",
            TestName = "QA874_QA875_QA876_CreateEditDeleteWorkRequestByUnit",
            Description = "M5-Work Request-Creating, Editing and Deleting a Work Request by Unit"), Order(1)]
        public void QA874_QA875_QA876_CreateEditDeleteWorkRequestByUnit(object[] testParameter)
        {
            UnitMain unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            WorkRequestMain request = CommonUtil.DataObjectForKey("WorkRequest").ToObject<WorkRequestMain>();
            WorkRequestMain requestE = CommonUtil.DataObjectForKey("EditWorkRequest").ToObject<WorkRequestMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            requestE.WRUnitNo = request.WRUnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);
            CurrentPage = _pageNavigate.NavigateToWorkRequestMainPage();
            requestE.WorkRequestNo = CurrentPage.As<WorkRequestMainPageActions>().CreateWorkRequest(request);
            CurrentPage.As<WorkRequestMainPageActions>().VerifyWorkRequestDetails(request);
            CommonUtil.AddPassedTestCase("QA874");
            Settings.Logger.Info("------------Finishing executing test ' QA874 Creating a new Work Request by Unit' -------------------");
            CurrentPage.As<WorkRequestMainPageActions>().UpdateWorkRequestDetails(requestE);
            CurrentPage.As<WorkRequestMainPageActions>().VerifyWorkRequestDetails(requestE);
            CommonUtil.AddPassedTestCase("QA875");
            Settings.Logger.Info("------------Finishing executing test ' QA875 Editing a Work Request by Unit' -------------------");
            CurrentPage.As<WorkRequestMainPageActions>().DeleteWorkRequest(requestE);
            Settings.Logger.Info("------------Finishing executing test ' QA876 Deleting a Work Request by Unit' -------------------");
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(request.WRUnitNo);
        }

        [Test, Description("M5-Work Request-Creating a new Work Request by Unit")]
        public void QA874_CreateWorkRequestByUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA874");
        }

        [Test, Description("M5-Work Request-Editing a Work Request by Unit")]
        public void QA875_EditingWorkRequestByUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA875");
        }

        [TestCase("WorkRequestTestData.json", "QA881_CreateWorkRequestByDepartment",
            TestName = "QA881_CreateWorkRequestByDepartment",
            Description = "M5-Work Request-Creating a new Work Request by Department")]
        public void QA881_CreateWorkRequestByDepartment(object[] testParameter)
        {
            DepartmentMain department = CommonUtil.DataObjectForKey("DeptDetails").ToObject<DepartmentMain>();
            WorkRequestMain request = CommonUtil.DataObjectForKey("WorkRequest").ToObject<WorkRequestMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage(); ;
            request.WRUnitNo = request.WRDeptNo = CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment(department);
            CurrentPage = _pageNavigate.NavigateToWorkRequestMainPage();
            CurrentPage.As<WorkRequestMainPageActions>().CreateWorkRequest(request);
            CurrentPage.As<WorkRequestMainPageActions>().VerifyWorkRequestDetails(request);
            CurrentPage.As<WorkRequestMainPageActions>().DeleteWorkRequest(request);
            CurrentPage = _pageNavigate.NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentDeletion(request.WRDeptNo);
        }

        [TestCase("WorkRequestTestData.json", "QA882_CreateWorkRequestByComponent",
            TestName = "QA882_CreateWorkRequestByComponent",
            Description = "M5-Work Request-Creating a new Work Request by Component")]
        public void QA882_CreateWorkRequestByComponent(object[] testParameter)
        {
            WorkRequestMain request = CommonUtil.DataObjectForKey("WorkRequest").ToObject<WorkRequestMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateComponentMainPage(); ;
            request.WRUnitNo = request.WRCompNo = CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentMain");
            CurrentPage = _pageNavigate.NavigateToWorkRequestMainPage();
            CurrentPage.As<WorkRequestMainPageActions>().CreateWorkRequest(request);
            CurrentPage.As<WorkRequestMainPageActions>().VerifyWorkRequestDetails(request);
            CurrentPage.As<WorkRequestMainPageActions>().DeleteWorkRequest(request);
            CurrentPage = _pageNavigate.NavigateComponentMainPage();
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentDeletion(request.WRCompNo);
        }


        [TestCase("WorkRequestTestData.json", "QA874_CreateWorkRequestByUnit",
            TestName = "QA899_AddingPartToWorkRequest",
            Description = "M5-Work Request-Creating, Adding a Part to an existing Work Request")]
        public void QA899_AddingPartToWorkRequest(object[] testParameter)
        {
            UnitMain unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            WorkRequestMain request = CommonUtil.DataObjectForKey("WorkRequestWithExtendedInfo").ToObject<WorkRequestMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            request.WRUnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);
            CurrentPage = _pageNavigate.NavigateToWorkRequestMainPage();
            CurrentPage.As<WorkRequestMainPageActions>().CreateWorkRequest(request);
            CurrentPage.As<WorkRequestMainPageActions>().VerifyWorkRequestDetails(request);
            CurrentPage.As<WorkRequestMainPageActions>().DeleteWorkRequest(request);
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(request.WRUnitNo);

        }
    }
}
