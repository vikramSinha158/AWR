﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.WorkRequest
{
    [TestFixture]
    internal class WorkRequestIncidentTest : Hooks
    {
        [TestCase("WorkRequestIncidentTestData.json", "QA901_CreateWorkRequestIncident",
            TestName = "QA901_QA902_QA903VerifyCreateEditDeleteWorkRequestIncident", Description = "M5-Work Request-Creating a new Work Request Incident"), Order(1)]
        public void QA901_QA902_QA903VerifyCreateEditDeleteWorkRequestIncident(object[] testParameter)
        {
            WorkRequestIncident request = CommonUtil.DataObjectForKey("WorkRequest").ToObject<WorkRequestIncident>();
            WorkRequestIncident requestE = CommonUtil.DataObjectForKey("EditWorkRequest").ToObject<WorkRequestIncident>();

            UnitMain unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            request.WRUnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);
            CurrentPage = _pageNavigate.NavigateToWorkRequestIncidentPage();
            CurrentPage.As<WorkRequestIncidentPageActions>().CreateAndUpdateWorkRequestIncident(request);
            CurrentPage.As<WorkRequestIncidentPageActions>().VerifyCreatedWorkRequestIncident(request);
            Settings.Logger.Info("QA901 - Finished verifying Creating a new Work Request Incident Successfully.!");
            Settings.Logger.Info("QA902 - Starting verifying Editing an existing  Work Request Incident");
            CurrentPage.As<WorkRequestIncidentPageActions>().CreateAndUpdateWorkRequestIncident(requestE);
            CurrentPage.As<WorkRequestIncidentPageActions>().VerifyCreatedWorkRequestIncident(requestE);
            CommonUtil.AddPassedTestCase("QA902");
            Settings.Logger.Info("QA902 - Finished verifying Editing an existing Work Request Incident Successfully.!");
            Settings.Logger.Info("QA903 - Starting verifying Deleting an existing  Work Request Incident");
            CurrentPage.As<WorkRequestIncidentPageActions>().DeleteWorkRequestIncident(request.WorkRequestNo);
            CurrentPage.As<WorkRequestIncidentPageActions>().VerifyDeleteCreatedWorkRequestIncident(request.WorkRequestNo);
            CommonUtil.AddPassedTestCase("QA903");
            Settings.Logger.Info("QA903 - Finished verifying Creating an existing Work Request Incident Successfully.!");
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(request.WRUnitNo);
        }

        [Test, Description("M5-Work Request-Edit an existing Work Request Incident, Merged with QA901")]
        public void QA902_EditWorkRequestIncident()
        {
            CommonUtil.VerifyPassedTestCase("QA902");
        }

        [Test, Description("M5-Work Request-Deleting an existing Work Request Incident, Merged with QA901")]
        public void QA903_DeleteWorkRequestIncident()
        {
            CommonUtil.VerifyPassedTestCase("QA903");
        }

    }
}
