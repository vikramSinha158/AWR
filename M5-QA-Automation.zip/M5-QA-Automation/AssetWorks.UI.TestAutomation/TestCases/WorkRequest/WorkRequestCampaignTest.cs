﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest;
using AssetWorks.UI.M5.TestAutomation.Common;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.UnitsObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.WorkRequest
{
    [TestFixture]
    internal class WorkRequestCampaignTest : Hooks
    {

        [TestCase("WorkRequestCampaignTestData.json", "CreateWorkRequestCampaign",
            TestName = "QA878_QA879_QA880VerifyCreateEditDeleteWorkRequestCampaign", Description = "M5-Work Request-Creating a new Work Request Campaign"), Order(1)]
        public void QA878_QA879_QA880VerifyCreateEditDeleteWorkRequestCampaign(object[] testParameter)
        {
            WorkRequestParameter parameter = CommonUtil.DataObjectForKey("WorkRequestParameter").ToObject<WorkRequestParameter>();

            WorkRequestParameter editparameter = CommonUtil.DataObjectForKey("WorkRequestParameterEdit").ToObject<WorkRequestParameter>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToWorkRequestCampaignPage();
            CurrentPage.As<WorkRequestCampaignPageActions>().CreateWorkRequestCampaign(parameter);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyCreatedWorkRequestCampaign(parameter);
            Settings.Logger.Info("QA878 - Finished verifying Creating a new Work Request Campaign Successfully.!");
            CurrentPage.As<WorkRequestCampaignPageActions>().CreateWorkRequestCampaign(editparameter, false);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyCreatedWorkRequestCampaign(editparameter);
            Settings.Logger.Info("QA879 - Finished verifying Editing an existing Work Request Campaign Successfully.!");
            CommonUtil.AddPassedTestCase("QA879");            
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyDeleteWorkRequestCampaign(parameter.CampaignNo);
            CommonUtil.AddPassedTestCase("QA880");
            Settings.Logger.Info("QA880 - Finished verifying Deleteing an existing Work Request Campaign Successfully.!");
        }

        [Test, Description("M5-Work Request-Deleting an existing Work Request Campaign")]
        public void QA880_VerifyDeleteWorkRequestCampaign()
        {
            CommonUtil.VerifyPassedTestCase("QA880");
        }

        [Test, Description("M5-Work Request-Editing an existing Work Request Campaign")]
        public void QA879_VerifyEditWorkRequestCampaign()
        {
            CommonUtil.VerifyPassedTestCase("QA879");
        }

        [TestCase("WorkRequestCampaignTestData.json", "CreateWorkRequestCampaign",
            TestName = "QA923_VerifyAddGeneralInfoToWorkRequestCampaign", Description = "M5-Work Request-Adding General Information to an existing Work Request Campaign"), Order(1)]
        public void QA923_VerifyAddGeneralInfoToWorkRequestCampaign(object[] testParameter)
        {
            WorkRequestParameter parameter = CommonUtil.DataObjectForKey("WorkRequestParameterWithGeneralInfo").ToObject<WorkRequestParameter>();

            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToWorkRequestCampaignPage();
            CurrentPage.As<WorkRequestCampaignPageActions>().CreateWorkRequestCampaign(parameter);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyCreatedWorkRequestCampaign(parameter);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyDeleteWorkRequestCampaign(parameter.CampaignNo);
        }

        [TestCase("WorkRequestCampaignTestData.json", "CreateWorkRequestCampaign",
            TestName = "QA934_QA935_QA937VerifyWorkRequestStatus", Description = "M5-Work Request-Setting an existing Work Request Campaign to Preview status"), Order(1)]
        public void QA934_VerifyWorkRequestStatusToPreview(object[] testParameter)
        {
            WorkRequestParameter parameter = CommonUtil.DataObjectForKey("WorkRequestParameterWithGeneralInfo").ToObject<WorkRequestParameter>();
            WorkRequestParameter parameterE = CommonUtil.DataObjectForKey("WorkRequestParameterEditGeneralInfo").ToObject<WorkRequestParameter>();
            WorkRequestStateAndStatus workRequestPreviewStateStatus = CommonUtil.DataObjectForKey("PreviewStatus").ToObject<WorkRequestStateAndStatus>();
            WorkRequestStateAndStatus workRequestCustomizeStateStatus = CommonUtil.DataObjectForKey("CustomizeStatus").ToObject<WorkRequestStateAndStatus>();
            WorkRequestStateAndStatus workRequestFinalizedStateStatus = CommonUtil.DataObjectForKey("FinalizedStatus").ToObject<WorkRequestStateAndStatus>();
            WorkRequestStateAndStatus workRequestUpdateStateStatus = CommonUtil.DataObjectForKey("UpdateStatus").ToObject<WorkRequestStateAndStatus>();
            WorkRequestStateAndStatus workRequestUnlockStateStatus = CommonUtil.DataObjectForKey("UnlockStatus").ToObject<WorkRequestStateAndStatus>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToWorkRequestCampaignPage();
            CurrentPage.As<WorkRequestCampaignPageActions>().CreateWorkRequestCampaign(parameter);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyCreatedWorkRequestCampaign(parameter);
            CurrentPage.As<WorkRequestCampaignPageActions>().ClickOnButtonAndVerifyStateAndStatus(workRequestPreviewStateStatus);
            Settings.Logger.Info("QA934 - Finished verifying Setting an existing Work Request Campaign to Preview status Successfully.!");
            Settings.Logger.Info("QA935 - Starting verifying Setting an existing Work Request Campaign to Customize status Then Finalized status To Unlock (Customize status) Successfully.!");
            CurrentPage.As<WorkRequestCampaignPageActions>().ClickOnButtonAndVerifyStateAndStatus(workRequestCustomizeStateStatus);
            CurrentPage.As<WorkRequestCampaignPageActions>().ClickOnButtonAndVerifyStateAndStatus(workRequestFinalizedStateStatus);
            CurrentPage.As<WorkRequestCampaignPageActions>().ClickOnButtonAndVerifyStateAndStatus(workRequestUnlockStateStatus);
            Settings.Logger.Info("QA935 - Finished verifying Setting an existing Work Request Campaign to Customize status Then Finalized status To Unlock (Customize status) Successfully.!");
            CommonUtil.AddPassedTestCase("QA935");
            Settings.Logger.Info("QA937 - Starting verifying Setting an existing Work Request Campaign to Update status And Update All the Fields Successfully.!");
            CurrentPage.As<WorkRequestCampaignPageActions>().ClickOnButtonAndVerifyStateAndStatus(workRequestFinalizedStateStatus);
            CurrentPage.As<WorkRequestCampaignPageActions>().ClickOnButtonAndVerifyStateAndStatus(workRequestUpdateStateStatus);
            CurrentPage.As<WorkRequestCampaignPageActions>().CreateWorkRequestCampaign(parameterE, false);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyCreatedWorkRequestCampaign(parameterE);
            Settings.Logger.Info("QA937 - Finished verifying Setting an existing Work Request Campaign to Update status And Update All the Fields Successfully.!");
            CommonUtil.AddPassedTestCase("QA937");

            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyDeleteWorkRequestCampaign(parameter.CampaignNo);
        }

        [Test, Description("QA935:M5-Work Request-Setting an existing Work Request Campaign to Customize status Then Finalized status To Unlock (Customize status)," +
            "Merged with QA934")]
        public void QA935_VerifyWorkRequestStatusToCustomizeAndFinalized()
        {
            CommonUtil.VerifyPassedTestCase("QA935");
        }

        [Test, Description("QA937:M5-Work Request-Setting an existing Work Request Campaign to Update status And Update All the Fields," +
            "Merged with QA934")]
        public void QA937_VerifyWorkRequestStatusToUpdate()
        {
            CommonUtil.VerifyPassedTestCase("QA937");
        }


        [TestCase("WorkRequestCampaignTestData.json", "CreateWorkRequestCampaign",
            TestName = "QA924_VerifyAddInclusionsInfoToWorkRequestCampaign", Description = "M5-Work Request-Adding General Information to an existing Work Request Campaign"), Order(1)]
        public void QA924_VerifyAddInclusionsInfoToWorkRequestCampaign(object[] testParameter)
        {
            WorkRequestParameter parameter = CommonUtil.DataObjectForKey("WorkRequestParameterWithExtendedInfo").ToObject<WorkRequestParameter>();
            UnitMain unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            parameter.InclusionsInfo.UnitNumberValue = parameter.WRUnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);            
            CurrentPage = _pageNavigate.NavigateToWorkRequestCampaignPage();
            CurrentPage.As<WorkRequestCampaignPageActions>().CreateWorkRequestCampaign(parameter);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyCreatedWorkRequestCampaign(parameter);
            CurrentPage.As<WorkRequestCampaignPageActions>().VerifyDeleteWorkRequestCampaign(parameter.CampaignNo);
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(parameter.WRUnitNo);
        }
    }
}
