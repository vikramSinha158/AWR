﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.ServiceOrder;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.ServiceOrder
{
    [TestFixture]
    internal class ServiceOrderTest : Hooks
    {
        [TestCase("ServiceOrderTestData.json", "QA1282_ServiceOrderWithUnit", TestName = "QA1282_QA1302_CreateServiceOrderWithUnit",
            Description = "M5- Service Order-Create Service Order with Unit & Service Query Status Cancelled and Resv Code unit"), Order(1)]
        public void QA1282_QA1302_CreateServiceOrderWithUnit(object[] testParameter)
        {
            ServiceOrderObjects SOrder = CommonUtil.DataObjectForKey("ServiceOrder").ToObject<ServiceOrderObjects>();
            ServiceOrderQueryDetail SOQueryO = CommonUtil.DataObjectForKey("ServiceOrderQueryO").ToObject<ServiceOrderQueryDetail>();
            ServiceOrderQueryDetail SOQueryC = CommonUtil.DataObjectForKey("ServiceOrderQueryC").ToObject<ServiceOrderQueryDetail>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToServiceOrderPage();
            SOrder.PONo = CurrentPage.As<ServiceOrderPageActions>().CreateServiceOrder(SOrder);
            CurrentPage.As<ServiceOrderPageActions>().VerifyServiceOrderDetails(SOrder);
            CommonUtil.AddPassedTestCase("QA1282");
            Settings.Logger.Info("------------Finishing executing test ' QA1282 Create Service Order with Unit' -------------------");
            SOQueryO.ServiceOrder = SOQueryC.ServiceOrder = SOQueryO.SOList[0].ServiceOrderNo = SOQueryC.SOList[0].ServiceOrderNo = SOrder.PONo;
            CurrentPage = _pageNavigate.NavigateToServiceOrderQueryPage();
            CurrentPage.As<ServiceOrderQueryPageActions>().CreateServiceOrderQuery(SOQueryO);
            CurrentPage.As<ServiceOrderQueryPageActions>().VerifyServiceOrderList(SOQueryO.SOList);
            Settings.Logger.Info("------------Finish executing 'QA1302 Create Service Order Query with status = ORDERED' -------------------");
            CurrentPage = _pageNavigate.NavigateToServiceOrderPage();
            CurrentPage.As<ServiceOrderPageActions>().DeleteOrderLines(SOrder);
            CurrentPage = _pageNavigate.NavigateToServiceOrderQueryPage();
            CurrentPage.As<ServiceOrderQueryPageActions>().CreateServiceOrderQuery(SOQueryC);
            CurrentPage.As<ServiceOrderQueryPageActions>().VerifyServiceOrderList(SOQueryC.SOList);
            Settings.Logger.Info("------------Finish executing 'QA1302 Create Service Order Query with status = CANCELED' -------------------");
        }

        [TestCase("ServiceOrderTestData.json", "QA1291_ServiceOrderWithDepartment", TestName = "QA1291_QA1300_QA1301_CreateServiceOrderWithDepartment", 
            Description = "M5- Service Order-Create Service Order with Department, Create Service Query & Check Clear Button"), Order(1)]
        public void QA1291_QA1300_QA1301_CreateServiceOrderWithDepartment(object[] testParameter)
        {
            ServiceOrderObjects SOrder = CommonUtil.DataObjectForKey("ServiceOrder").ToObject<ServiceOrderObjects>();
            ServiceOrderQueryDetail SOQuery = CommonUtil.DataObjectForKey("ServiceOrderQuery").ToObject<ServiceOrderQueryDetail>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToServiceOrderPage();
            SOQuery.ServiceOrder = SOrder.PONo = CurrentPage.As<ServiceOrderPageActions>().CreateServiceOrder(SOrder);
            CurrentPage.As<ServiceOrderPageActions>().VerifyServiceOrderDetails(SOrder);
            CommonUtil.AddPassedTestCase("QA1291");
            Settings.Logger.Info("------------Finishing executing test ' QA1291 Create Service Order with Department' -------------------");
            CurrentPage = _pageNavigate.NavigateToServiceOrderQueryPage();
            CurrentPage.As<ServiceOrderQueryPageActions>().CreateServiceOrderQuery(SOQuery);
            SOQuery.SOList[0].ServiceOrderNo = SOQuery.ServiceOrder;
            CurrentPage.As<ServiceOrderQueryPageActions>().VerifyServiceOrderList(SOQuery.SOList);
            CommonUtil.AddPassedTestCase("QA1301");
            Settings.Logger.Info("------------Finishing executing test ' QA1301 Create Service Order Query ' -------------------");
            CurrentPage.As<ServiceOrderQueryPageActions>().VerifyClearOnServiceOrderQuery();
            Settings.Logger.Info("------------Finishing executing test ' QA1300 Create Service Query Check Clear Button' -------------------");
        }

        [TestCase("ServiceOrderTestData.json", "QA1309_ServiceOrderReceipt", TestName = "QA1309_CreateServiceOrderWithWorkOrderAndServiceOrderReceipt",
            Description = "M5- Service Order-Create Service Order with Work Order & Create Service Order Receipt")]
        public void QA1309_CreateServiceOrderWithWorkOrderAndServiceOrderReceipt(object[] testParameter)
        {
            ServiceOrderObjects SOrder = CommonUtil.DataObjectForKey("ServiceOrder").ToObject<ServiceOrderObjects>();
            ServiceOrderReceiptDetail SOReceipt = CommonUtil.DataObjectForKey("ServiceOrderReceipt").ToObject<ServiceOrderReceiptDetail>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _extendedpage.VerifyCreatedUnitWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyAddedActionWorkOrder(Settings.UnitNumber);
            CurrentPage.As<WorkOrderMainPageActions>().OpenExitingWorkOrder();
            SOrder.ServiceOrderDetail[0].ResvRefNo = PagesObject.WorkOrderMainPage.WONumber;
            Settings.Logger.Info($"------------Finished creating WorkOrder - ' {SOrder.ServiceOrderDetail[0].ResvRefNo} ' -------------------");
            CurrentPage = _pageNavigate.NavigateToServiceOrderPage();
            SOReceipt.OrderNo = CurrentPage.As<ServiceOrderPageActions>().CreateServiceOrder(SOrder);
            CurrentPage.As<ServiceOrderPageActions>().VerifyServiceOrderDetails(SOrder);
            Settings.Logger.Info("------------Finishing executing test ' QA1291 Create Service Order with Work Order' -------------------");
            CurrentPage = _pageNavigate.NavigateToServiceOrderReceiptPage();
            CurrentPage.As<ServiceOrderReceiptPageActions>().CreateServiceOrderReceipt(SOReceipt);
            CurrentPage.As<ServiceOrderReceiptPageActions>().VerifyServiceOrderMessage(SOReceipt.OrderNo);
            Settings.Logger.Info("------------Finishing executing test ' QA1309 Create Service Order Receipt' -------------------");
        }

        [Test, Description("M5-Service Order-Create Service Order with Unit")]
        public void QA1282_CreateServiceOrderWithUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA1282");
        }

        [Test, Description("M5-Service Order-Create Service Order with Department")]
        public void QA1291_CreateServiceOrderWithDepartment()
        {
            CommonUtil.VerifyPassedTestCase("QA1291");
        }

        [Test, Description("M5-Service Order-Craete Service Query with status All and Resv Code All")]
        public void QA1301_CreateServiceOrderQuery()
        {
            CommonUtil.VerifyPassedTestCase("QA1301");
        }
    }
}
