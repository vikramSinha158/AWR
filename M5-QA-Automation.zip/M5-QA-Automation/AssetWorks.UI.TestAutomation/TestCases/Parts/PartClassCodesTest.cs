﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Parts
{
    [TestFixture]
    internal class PartClassCodesTest : Hooks
    {
        [TestCase("PartsClassCodesTestData.json", "CreatePartClassCodes",
        TestName = "QA1296_VerifyCreateUpdateDeletePartClassCode", Description = "M5 - Parts - Part Class Code-Create, update, verify and delete")]
        public void QA1296_VerifyCreateUpdateDeletePartClassCode(object[] testParameter)
        {
            PartsClassCodesObjects partsClassCodesObject = CommonUtil.DataObjectForKey("PartsClassCodes").ToObject<PartsClassCodesObjects>();
            PartsClassCodesObjects updatePartsClassCodesObject = CommonUtil.DataObjectForKey("UpdatePartsClassCodes").ToObject<PartsClassCodesObjects>();

            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartClassCodesPage();
            updatePartsClassCodesObject.Code = partsClassCodesObject.Code = CurrentPage.As<PartClassCodesPageActions>().CreateNewPartClassCode(partsClassCodesObject);
            CurrentPage.As<PartClassCodesPageActions>().VerifyPartClassCode(partsClassCodesObject);
            CurrentPage.As<PartClassCodesPageActions>().UpdatePartClassCode(updatePartsClassCodesObject);
            CurrentPage.As<PartClassCodesPageActions>().VerifyPartClassCode(updatePartsClassCodesObject);
            CurrentPage.As<PartClassCodesPageActions>().VerifyDeletePartClassCode(partsClassCodesObject.Code);
        }
    }
}
