﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Parts
{
    [TestFixture]
    internal class PartBinTest : Hooks
    {
        [TestCase("PartBinTestData.json", "PartBin", TestName = "QA904_QA908VerifyCreateDeletePartBin", Description = "M5-Create Part Bin")]
        public void QA904_QA908VerifyCreateDeletePartBin(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartBinPage();
            CurrentPage.As<PartBinPageActions>().CreatePartBin("CreatePartPin");
            foreach (KeyValuePair<string, PartValue> PartBinInfo in PartBinPageActions.BinInfoDict)
            {                
                CurrentPage.As<PartBinPageActions>().VerifyPartBinData(PartBinInfo.Key, PartBinInfo.Value.Description, PartBinInfo.Value.Disabled);
            }
            Settings.Logger.Info("QA904 - Finished verifying Create part bin Successfully.!");
            Settings.Logger.Info("QA908 - Starting verifying Delete part bin");
            CurrentPage.As<PartBinPageActions>().VerifyDeletePartBin(PartBinPageActions.BinInfoDict);
            Settings.Logger.Info("QA908 - Finished verifying Delete part bin Successfully.!");
            CommonUtil.AddPassedTestCase("QA908");
        }

        [TestCase("PartBinTestData.json", "PartBin", Description = "M5-Update Part Bin")]
        public void QA906_UpdatePartBin(object[] testParameter)
        {
            string Datakey = "QA906_UpdatePartPin";
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartBinPage();
            CurrentPage.As<PartBinPageActions>().CreatePartBin(Datakey);
            int i = 0;
            foreach (KeyValuePair<string, PartValue> PartBinInfo in PartBinPageActions.BinInfoDict)
            {                
                CurrentPage.As<PartBinPageActions>().UpdateAndVerifyPartBinData(i,PartBinInfo.Key, Datakey);
                i++;                
            }
        }

        [Test, Description("QA908:M5 - Parts - Delete Part Bin, Merged with QA904")]
        public void QA908_VerifyDeletePartBin()
        {
            CommonUtil.VerifyPassedTestCase("QA908");
        }
    }
}
