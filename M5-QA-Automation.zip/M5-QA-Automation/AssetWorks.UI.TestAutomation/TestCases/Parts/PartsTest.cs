﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium.DevTools.V85.DOM;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Parts
{
    [TestFixture]
    internal class PartsTest : Hooks
    {
        [TestCase("PartsTestdata.json", "CreatePartMainCatalog",
        TestName = "QA916_QA1246_QA1247_CreateUpdateDeleteStockPart", Description = "M5-Parts Create Part"),Order(1)]
        public void QA916_CreateStockPart(object[] testParameter)
        {
            PartsMainCatalog partsObject = CommonUtil.DataObjectForKey("PartsMainInfo").ToObject<PartsMainCatalog>();
            PartsMainCatalog partsObjectUpdate = CommonUtil.DataObjectForKey("UpdatePartsMainInfo").ToObject<PartsMainCatalog>();

            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
            partsObjectUpdate.PartNumber = partsObject.PartNumber = CurrentPage.As<PartMainCatalogPageActions>().CreateNewPart(partsObject);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(partsObject);
            Settings.Logger.Info("QA1246 - Starting Verify Update Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().UpdatePartSettingsValue(partsObjectUpdate);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(partsObjectUpdate);
            CommonUtil.AddPassedTestCase("QA1246");
            Settings.Logger.Info("QA-1246- Finished Verify Update Stock Part successfully");
            
            Settings.Logger.Info("QA-1247 - Starting Verify Delete Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().VerifyDeletedStockPart(partsObject.PartNumber);
            CommonUtil.AddPassedTestCase("QA1247");
            Settings.Logger.Info("QA-1247- Finished Verify Delete Stock Part successfully");
        }

        [Test, Description("M5-Parts Update Stock Part, Merged with QA916_CreatePart")]
        public void QA1246_UpdateStockPart()
        {
            CommonUtil.VerifyPassedTestCase("QA1246");
        }

        [Test, Description("M5-Parts Delete Stock Part, Merged with QA916_CreatePart")]
        public void QA1247_DeleteStockPart()
        {
            CommonUtil.VerifyPassedTestCase("QA1247");
        }

        [TestCase("PurchasingRequisitionTestData.json", "QA1011_PurchaseRequisition",
        Description = "M5-Part Purchasing Requisition")]
        public void QA1011_PartPurchasingRequisition(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPurchaseRequisitions();
            string partRequisitionsNo = CurrentPage.As<PurchaseRequisitionsPageActions>().CreatePartPurchaseRequisition("PartPurchaseRequisition");
            CurrentPage.As<PurchaseRequisitionsPageActions>().ApprovePartRequisition("PartPurchaseRequisition", PurchaseRequisitionsPage.UnitReserveRefNO);
            CurrentPage.As<PurchaseRequisitionsPageActions>().VerifyPartRequisitions("PartPurchaseRequisition", partRequisitionsNo);
        }

        [TestCase("PartsInventoryLocation.json", "QA1134_CreateInventoryLocation", TestName = "QA1134_CreatePartInventoryLocation",
        Description = "M5-Part Inventory Location")]
        public void QA1134_CreatePartInventoryLocation(object[] testParameter)
        {
            PartsInventoryLocationObjects partsInventory = CommonUtil.DataObjectForKey("CreatePartsInventoryLocation").ToObject<PartsInventoryLocationObjects>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartInventoryLocationManager();
            CurrentPage.As<PartInventoryLocationPageActions>().CreateNewPartInventoryLocation(partsInventory);
            CurrentPage.As<PartInventoryLocationPageActions>().VerifyPartsInventoryData(partsInventory);
        }

        [TestCase("PartsTestdata.json", "QA1135_CreatePartInventoryAdjustment", TestName = "QA1135_QA1217_CreateValidatePartAdjustment",
        Description = "M5-Part Adjustment"),Order(1)]
        public void QA1135_QA1217_CreateValidatePartAdjustment(object[] testParameter)
        {
            PartsAdjustmentObjects partsAdjustment= CommonUtil.DataObjectForKey("CreatePartInventoryAdjustment").ToObject<PartsAdjustmentObjects>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartAdjustment();
            CurrentPage.As<PartsAdjustmentPageActions>().CreateNewPartAdjustment(partsAdjustment);         
            Settings.Logger.Info("QA-1135-Created new part adjustment successfully");
            CurrentPage =_pageNavigate.NavigateToPartInventoryLocationManager();
            CurrentPage.As<PartInventoryLocationPageActions>().VerifyPartAjustment(partsAdjustment);
            CommonUtil.AddPassedTestCase("QA1217");
            Settings.Logger.Info("QA-1217-Verified new part adjustment successfully");
        }

        [Test, Description("M5-Verify PartAdjustment,Merged with- QA1135_QA1217_CreateValidatePartAdjustment")]
        
        public void QA1217_VerifyPartAdjustment()
        {
            CommonUtil.VerifyPassedTestCase("QA1217");
        }

        [TestCase("PartsTestdata.json", "CreatePartMainCatalog",
       TestName = "QA1245_VerifyCreateUpdateDeleteNonStockPart", Description = "M5-Parts Create Non-Stock Part"), Order(1)]
        public void QA1245_VerifyCreateUpdateDeleteNonStockPart(object[] testParameter)
        {
            PartsMainCatalog partsObject = CommonUtil.DataObjectForKey("PartsMainNonStockInfo").ToObject<PartsMainCatalog>();
            PartsMainCatalog partsObjectUpdate = CommonUtil.DataObjectForKey("UpdatePartsMainInfo").ToObject<PartsMainCatalog>();

            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
            partsObjectUpdate.PartNumber = partsObject.PartNumber = CurrentPage.As<PartMainCatalogPageActions>().CreateNewPart(partsObject);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(partsObject);
            Settings.Logger.Info("Starting Verify Update Non-Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().UpdatePartSettingsValue(partsObjectUpdate);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(partsObjectUpdate);
            Settings.Logger.Info("Finished Verify Update Non-Stock Part successfully");
            Settings.Logger.Info(" Starting Verify Delete Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().VerifyDeletedStockPart(partsObject.PartNumber);
            Settings.Logger.Info("Finished Verify Delete Stock Part successfully");
        }

        [TestCase("PartsTestdata.json", "CreatePartMainCatalog",
        TestName = "QA1250_VerifyCreateUpdateDeleteOptionalSerializedStockPart", Description = "M5 - Parts - Create Update and Delete Optional Serialized Stock Part with data for most fields.")]
        public void QA1250_VerifyCreateUpdateDeleteOptionalSerializedStockPart(object[] testParameter)
        {
            PartsMainCatalog partsObject = CommonUtil.DataObjectForKey("PartsMainOptionalSerializedStockInfo").ToObject<PartsMainCatalog>();
            PartsMainCatalog serializedPartsObjectUpdate = CommonUtil.DataObjectForKey("UpdatePartsMainOptionalSerializedStockInfo").ToObject<PartsMainCatalog>();
            PartsMainCatalog mandatoryPartsObjectUpdate = CommonUtil.DataObjectForKey("UpdatePartsMainMandatorySerializedStockInfo").ToObject<PartsMainCatalog>();

            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
            mandatoryPartsObjectUpdate.PartNumber = serializedPartsObjectUpdate.PartNumber = partsObject.PartNumber = CurrentPage.As<PartMainCatalogPageActions>().CreateNewPart(partsObject);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(partsObject);
            Settings.Logger.Info("Starting Verify Update Optional Serialized Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().UpdatePartSettingsValue(serializedPartsObjectUpdate);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(serializedPartsObjectUpdate);
            Settings.Logger.Info("Finished Verify Update Optional Serialized Stock Part successfully");
            Settings.Logger.Info("Starting Verify Update Mandatory Serialized Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().UpdatePartSettingsValue(mandatoryPartsObjectUpdate);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(mandatoryPartsObjectUpdate);
            Settings.Logger.Info("Finished Verify Update Mandatory Serialized Stock Part successfully");
            Settings.Logger.Info("Starting Verify Delete Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().VerifyDeletedStockPart(partsObject.PartNumber);
            Settings.Logger.Info("Finished Verify Delete Stock Part successfully");
        }

        [TestCase("PartsTestdata.json", "CreatePartMainCatalog",
        TestName = "QA1254_VerifyCreateUpdateDeleteLottedStockPart", Description = "M5 - Parts - Create Update and Delete Lotted Stock Part with data for most fields.")]
        public void QA1254_VerifyCreateUpdateDeleteLottedStockPart(object[] testParameter)
        {
            PartsMainCatalog partsObject = CommonUtil.DataObjectForKey("PartsMainLottedStockInfo").ToObject<PartsMainCatalog>();
            PartsMainCatalog lottedPartsObjectUpdate = CommonUtil.DataObjectForKey("UpdatePartsMainLottedStockInfo").ToObject<PartsMainCatalog>();
           
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
            lottedPartsObjectUpdate.PartNumber = partsObject.PartNumber = CurrentPage.As<PartMainCatalogPageActions>().CreateNewPart(partsObject);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(partsObject);
            Settings.Logger.Info("Starting Verify Update Lotted Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().UpdatePartSettingsValue(lottedPartsObjectUpdate);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(lottedPartsObjectUpdate);
            Settings.Logger.Info("Finished Verify Update Lotted Stock Part successfully");
            Settings.Logger.Info("Starting Verify Delete Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().VerifyDeletedStockPart(partsObject.PartNumber);
            Settings.Logger.Info("Finished Verify Delete Stock Part successfully");
        }

        [TestCase("PartsTestdata.json", "CreatePartMainCatalog",
        TestName = "QA1257_VerifyCreateUpdateDeleteCoreStockPart", Description = "M5 - Parts - Create Update and Delete Core Stock Part with data for most fields.")]
        public void QA1257_VerifyCreateUpdateDeleteCoreStockPart(object[] testParameter)
        {
            PartsMainCatalog partsObject = CommonUtil.DataObjectForKey("PartsMainCoreStockInfo").ToObject<PartsMainCatalog>();
            PartsMainCatalog corePartsObjectUpdate = CommonUtil.DataObjectForKey("UpdatePartsMainCoreStockInfo").ToObject<PartsMainCatalog>();

            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
            corePartsObjectUpdate.PartNumber = partsObject.PartNumber = CurrentPage.As<PartMainCatalogPageActions>().CreateNewPart(partsObject);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(partsObject);
            Settings.Logger.Info("Starting Verify Update Lotted Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().UpdatePartSettingsValue(corePartsObjectUpdate);
            CurrentPage.As<PartMainCatalogPageActions>().VerifyPartValues(corePartsObjectUpdate);
            Settings.Logger.Info("Finished Verify Update Lotted Stock Part successfully");
            Settings.Logger.Info("Starting Verify Delete Stock Part");
            CurrentPage.As<PartMainCatalogPageActions>().VerifyDeletedStockPart(partsObject.PartNumber);
            Settings.Logger.Info("Finished Verify Delete Stock Part successfully");
        }
    }
}
