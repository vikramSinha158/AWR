﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;
using AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.WorkOrder
{
    [TestFixture]
    internal class WorkOrderTest : Hooks
    {
        private ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        private HomePageActions _homePage => new HomePageActions(Driver);
        private ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [Test, Description("M5-Verifying work order page display")]
        public void QA196_VerifyWorkOrderScreen()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyWorkOrderTitle();
        }

        [Test, Description("M5-Verifying opening of existing work order")]
        public void QA201_OpenAnExistingWorkOrder()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyWorkOrderTitle();
            CurrentPage.As<WorkOrderMainPageActions>().SearchForWorkOrder();    
            _lov.SearchAndSelectFirstRowData();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyWorkOrderInformation();
        }

        [TestCase("WorkOrderTestData.json", "QA199_QA205_CreateUnitWorkOrderAddingWorkRequest",
            TestName = "QA199_QA205_CreateUnitWorkOrderAddingWorkRequest",
            Description = "M5-Verifying unit work order creation and adding working request verification"), Order(1)]
        public void QA199_QA205_CreateUnitWorkOrderAddingWorkRequest(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _extendpage.VerifyCreatedUnitWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyAddedActionWorkOrder(Settings.UnitNumber);
            Settings.Logger.Info("------------Finishing executing test ' QA199 Create Unit WorkOrder ' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().OpenExitingWorkOrder();
            WorkRequestMain request = CommonUtil.DataObjectForKey("WorkRequest").ToObject<WorkRequestMain>();
            request.WRUnitNo = Settings.UnitNumber;
            CurrentPage = _homePage.NavigateToWorkRequestMainPage();
            CurrentPage.As<WorkRequestMainPageActions>().CreateWorkRequest(request);
            CurrentPage = _homePage.NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().AddWorkRequestInJob();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyAddedWorkRequest();
            CommonUtil.AddPassedTestCase("QA205");
            Settings.Logger.Info("------------Finishing executing test ' QA205 Adding Work Request' -------------------");
        }

        [Test, Description("M5-Verifying Adding Work Request")]
        public void QA205_AddingWorkRequest()
        {
            CommonUtil.VerifyPassedTestCase("QA205");
        }

        [TestCase("WorkOrderTestData.json", "QA197_QA333_CreateComponentWorkOrder", Description = "M5-Verifying component work order creation and delete existing work work order"),Order(1)]
        public void QA197_QA333_CreateComponentWorkOrderAndDeleteWorkOrder(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateComponentMainPage();
            Settings.ComponentNumber=CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentMain");
            CurrentPage = _homePage.NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().SearchForComponent();
            _lov.EnterSearchField(Settings.ComponentNumber);
            CurrentPage.As<WorkOrderMainPageActions>().CreateAndVerifyWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyAddedActionWorkOrder(Settings.ComponentNumber);
            Settings.Logger.Info("------------Finishing executing test ' QA197 Create Component WorkOrder' -------------------");
            Driver.SwitchTo().DefaultContent();
            CurrentPage.As<WorkOrderMainPageActions>().DeleteWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().RefreshAndVerifyWOCompleteDates();
            CommonUtil.AddPassedTestCase("QA333");
            Settings.Logger.Info("------------Finishing executing test ' QA333 Delete WorkOrder' -------------------");
        }

        [Test, Description("M5-Verifying Delete WorkOrder")]
        public void QA333_DeleteWorkOrder()
        {
            CommonUtil.VerifyPassedTestCase("QA333");
        }

        [Test, Description("M5-Verifying add and delete job in work order"), Order(1)]
        public void QA204_QA202_AddAndDeleteJobToWorkOrder()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _extendpage.VerifyCreatedUnitWorkOrder();
            Settings.Logger.Info("------------Finishing executing test ' QA204 Add Job WorkOrder' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().AddJobToWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyCreatedWorkorderJob();
            CurrentPage.As<WorkOrderMainPageActions>().veifyWorkorderJobDeletion();
            CommonUtil.AddPassedTestCase("QA202");
            Settings.Logger.Info("------------Finishing executing test ' QA202 Delete Job WorkOrder' -------------------");
        }

        [Test, Description("M5-Verifying Delete Job WorkOrder")]
        public void QA202_DeleteJobWorkOrder()
        {
            CommonUtil.VerifyPassedTestCase("QA202");
        }

        [Test, Description("M5-Verifying add,edit and delete labor in work order"),Order(1)]
        public void QA221_QA242_QA244_AddEditAndDeleteLaborToWorkOrder()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _extendpage.VerifyCreatedUnitWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().AddJobToWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyCreatedWorkorderJob();
            Settings.Logger.Info("------------Finishing executing test ' QA221 Add Labor WorkOrder' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().AddLaborInWorkOrder(Settings.JobCode, Settings.EmployeeCode, Settings.EmployeePosition);
            CurrentPage.As<WorkOrderMainPageActions>().VerifyLaborInformation();
            CurrentPage.As<WorkOrderMainPageActions>().EditTimoutHour();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyLaborInformation();
            CommonUtil.AddPassedTestCase("QA242");
            Settings.Logger.Info("------------Finishing executing test ' QA242 Edit Labor WorkOrder' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().LaborRecordDeletion();
            CommonUtil.AddPassedTestCase("QA244");
            Settings.Logger.Info("------------Finishing executing test ' QA244 Delete Labor WorkOrder' -------------------");
        }

        [Test, Description("M5-Verifying Edit Labor WorkOrder")]
        public void QA242_EditLaborWorkOrder()
        {
            CommonUtil.VerifyPassedTestCase("QA242");
        }

        [Test, Description("M5-Verifying Delete Labor WorkOrder")]
        public void QA244_DeleteLaborWorkOrder()
        {
            CommonUtil.VerifyPassedTestCase("QA244");
        }

        [TestCase("WorkOrderTestData.json", "QA245_QA257_QA268_AddEditDelteStockPartEntry", 
            Description="M5-Verifying Add ,Edit and Delete Stock Part entry in work order"), Order(1)]
        public void QA245_QA257_QA268_AddEditDelteStockPartEntry(object[] testParameter)
        {
            var StockPartRecords = CommonUtil.DataObjectForKey("StockPartRecords");
            var JobRecords = CommonUtil.DataObjectForKey("JobRecords");
            var EdiPartRecordData = CommonUtil.DataObjectForKey("EditStockPartRecords");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _extendpage.VerifyCreatedUnitWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().AddJobRecords(2, JobRecords);
            CurrentPage.As<WorkOrderMainPageActions>().AddStockPartRecords(2,StockPartRecords);
            Settings.Logger.Info("------------Finishing executing test ' QA244 Add StockPartEntryr' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().EditAndVerifyStockPartRecord(0, EdiPartRecordData);
            CommonUtil.AddPassedTestCase("QA257");
            Settings.Logger.Info("------------Finishing executing test ' QA257 Edit StockPartEntryr' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().DeleteAndVerifyStockPartRecord();
            CommonUtil.AddPassedTestCase("QA268");
            Settings.Logger.Info("------------Finishing executing test ' QA268 Delete StockPartEntryr' -------------------");
        }

        [Test, Description("M5-Verifying Edit Stock PartEntryr")]
        public void QA257_EditStockPartEntry()
        {
            CommonUtil.VerifyPassedTestCase("QA257");
        }

        [Test, Description("M5-Verifying Delete Stock PartEntry")]
        public void QA268_DeleteStockPartEntry()
        {
            CommonUtil.VerifyPassedTestCase("QA268");
        }

        [TestCase("WorkOrderTestData.json", "DepartmentWorkOrder",
         Description = "M5-Test to create department work order and verify work order general tab  "),Order(1)]
        public void QA200_QA975_CreateNewDepartmentWorkOrder(object[] testParameter)
        {            
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToWODepartmentRequisitionsMainPage();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().CreateNewWorkOrderDepartmentRequisition();
            CurrentPage.As<WODepartmentRequisitionsPageActions>().VerifyRequisitionStatusValue(DepartmentObjects.WoDeptReqStatus);
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().CreateWorkOrderWithDeptReq(DepartmentObjects.WoDeptReqDeptNo, DepartmentObjects.WoDeptReqNo);
            CurrentPage.As<WorkOrderMainPageActions>().VerifyDepartmentWorkOrder();
            //Close WO and Department Requisition
            CurrentPage.As<WorkOrderMainPageActions>().CloseWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyWorkOrderStatusAsClosed();
            Settings.Logger.Info("------------Finishing executing test ' QA200 Work Order Status As Closed' -------------------");
            CurrentPage = homepage.NavigateToWODepartmentRequisitionsMainPage(); 
            CurrentPage.As<WODepartmentRequisitionsPageActions>().UpdateAndVerifyWODeptRequisitionStatus();
            CommonUtil.AddPassedTestCase("QA975");
            Settings.Logger.Info("------------Finishing executing test ' QA975 department requisition As Closed' -------------------");
        }

        [Test, Description("M5-Verifying WODept equisition Status")]
        public void QA975_VerifyWODeptRequisitionStatus()
        {
            CommonUtil.VerifyPassedTestCase("QA975");
        }

        [TestCase("WorkOrderTestData.json", "QA271_NonStockPartRecords", Description = "M5-Verifying Add ,Edit and Delete non Stock Part entry in work order"),Order(1)]
        public void QA271_QA283_QA285_AddEditDeleteNonStockPartEntry(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _extendpage.VerifyCreatedUnitWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().AddJobToWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyCreatedWorkorderJob();
            CurrentPage.As<WorkOrderMainPageActions>().AddNonStockPartRecords(1, WorkOrderObjects.AddNonStockPartData);
            Settings.Logger.Info("------------Finishing executing test 'QA271 Add NonStockPartEntryr' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().EditAndVerifyNonStockPartRecord(0, WorkOrderObjects.EditNonStockPart);
            CommonUtil.AddPassedTestCase("QA283");
            Settings.Logger.Info("------------Finishing executing test ' QA283 Edit NonStockPartEntryr' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().DeleteNonStockPart();
            CommonUtil.AddPassedTestCase("QA285");
            Settings.Logger.Info("------------Finishing executing test ' QA285 Delete NonStockPartEntryr' -------------------");
        }

        [Test, Description("M5-Verifying Non Edit Stock PartEntryr")]
        public void QA283_EditNonStockPartEntry()
        {
            CommonUtil.VerifyPassedTestCase("QA283");
        }

        [Test, Description("M5-Verifying Delete Non Stock PartEntry")]
        public void QA285_DeleteNonStockPartEntry()
        {
            CommonUtil.VerifyPassedTestCase("QA285");
        }

        [TestCase("WorkOrderTestData.json", "QA291_AddCommercialCharge", Description = "M5-Verifying Add and Delete Add Commercial Charge entry in work order"),Order(1)]
        public void QA291_QA292_QA295_AddCommercialChargeEntry(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _extendpage.VerifyCreatedUnitWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().AddJobToWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyCreatedWorkorderJob();
            CurrentPage.As<WorkOrderMainPageActions>().AddCommercialChargeRecords(1, WorkOrderObjects.AddCommercialCharge);
            CurrentPage.As<WorkOrderMainPageActions>().VerifyCommercialChargeInformation(0, WorkOrderObjects.AddCommercialCharge);
            CommonUtil.AddPassedTestCase("QA291");
            Settings.Logger.Info("------------Finishing executing test ' QA291 for Add CommercialChargeEntry' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().EditCommercialChargeInformation(0, WorkOrderObjects.EditCommercialCharge);
            CommonUtil.AddPassedTestCase("QA292");
            Settings.Logger.Info("------------Finishing executing test ' QA292 for edit CommercialChargeEntry' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().DeleteCommercialChargeInformation();
            CommonUtil.AddPassedTestCase("QA285");
            Settings.Logger.Info("------------Finishing executing test ' QA295 for Delete CommercialChargeEntry' -------------------");
        }

        [Test, Description("M5-Verifying Non Edit CommercialChargeEntry")]
        public void QA291_AddCommercialChargeEntry()
        {
            CommonUtil.VerifyPassedTestCase("QA291");
        }

        [Test, Description("M5-Verifying Delete CommercialChargeEntry")]
        public void QA295_DeleteCommercialChargeEntryy()
        {
            CommonUtil.VerifyPassedTestCase("QA295");
        }

        [TestCase("WorkOrderTestData.json", "FluidData", Description = "M5-Verifying Add ,Edit and Delete fluid in work order")]
        public void QA296_QA302_QA300_AddAndDeleteFluidWorkOrder(object[] testParameter)
        {
            var FluidunitNo = CommonUtil.DataObjectForKey(FluidData.UnitNo);
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().CloseOpenedWorkOrder(FluidunitNo);
            CurrentPage.As<WorkOrderMainPageActions>().CreateWorkOrder(FluidunitNo);
            CurrentPage.As<WorkOrderMainPageActions>().AddJobToWorkOrder();
            CurrentPage.As<WorkOrderMainPageActions>().VerifyCreatedWorkorderJob();
            CurrentPage.As<WorkOrderMainPageActions>().AddFluidRecords(WorkOrderObjects.FluidRecords);
            CurrentPage.As<WorkOrderMainPageActions>().VerifyFluidInformation(WorkOrderObjects.FluidRecords);
            Settings.Logger.Info(" Successfully Verified QA296 for Add Fluid WorkOrder");
            Settings.Logger.Info("------------Finishing executing test ' QA296 for Add Fluid WorkOrder' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().DeleteFluidInformation();
            Settings.Logger.Info(" Successfully Verified QA302 for DElete  Fluid WorkOrder");
            CommonUtil.AddPassedTestCase("QA302");
            Settings.Logger.Info("------------Finishing executing test ' QA302 for DElete  Fluid WorkOrder' -------------------");
            CurrentPage.As<WorkOrderMainPageActions>().AddFluidRecords(WorkOrderObjects.FluidRecords);
            CurrentPage.As<WorkOrderMainPageActions>().VerifyFluidInformation(WorkOrderObjects.FluidRecords);
            CommonUtil.AddPassedTestCase("QA300");
            Settings.Logger.Info("------------Finishing executing test ' QA300 Update Fluid WorkOrder' -------------------");
        }

        [Test, Description("M5-Verifying Delete Fluid WorkOrder")]
        public void QA302_DeleteFluidWorkOrder()
        {
            CommonUtil.VerifyPassedTestCase("QA302");
        }

        [Test, Description("M5-Verifying Delete Fluid WorkOrder")]
        public void QA300_EditFluidWorkOrder()
        {
            CommonUtil.VerifyPassedTestCase("QA300");
        }

        [TearDown]
        public void WorkOrderTearDown()
        {
            Driver.SwitchTo().DefaultContent();
            CurrentPage = _homePage.NavigateWorkOrderMainPage();
            CurrentPage.As<WorkOrderMainPageActions>().CloseWorkOrder();
        }
    }
}
