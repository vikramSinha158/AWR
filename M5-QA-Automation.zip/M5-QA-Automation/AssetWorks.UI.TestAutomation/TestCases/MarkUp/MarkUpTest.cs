﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.MarkUp;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.MarkUp
{
    /// <summary>
    /// Test scenarios for MarkUp 
    /// </summary>
    [TestFixture]
    internal class MarkUpTest : Hooks
    {

        [TestCase("MarkUpSchemeTestData.json", "MarkUpScheme", Description = "M5-Markup-Create,Edit,Delete Markup Scheme"),Order(1)]
        public void QA706_QA708_QA715_CreateEditDeleteMarkUpScheme(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMarkUpScheme();
            string schemeID = CurrentPage.As<MarkUpSchemePageActions>().CreateMarkUpScheme("QA706_CreateMarkUpScheme");
            CurrentPage.As<MarkUpSchemePageActions>().VerifyMarkupScheme(schemeID, "QA706_CreateMarkUpScheme");
            Settings.Logger.Info("QA706 - Create a new Markup Scheme completed successfully.!");
            CurrentPage.As<MarkUpSchemePageActions>().EditMarkUpScheme(schemeID, "QA708_EditMarkUpScheme");
            CurrentPage.As<MarkUpSchemePageActions>().VerifyMarkupScheme(schemeID, "QA708_EditMarkUpScheme");
            CommonUtil.AddPassedTestCase("QA708");
            Settings.Logger.Info("QA708 - Edit an existing Markup Scheme completed successfully.!");
            CurrentPage.As<MarkUpSchemePageActions>().DeleteMarkUpScheme(schemeID);
            CurrentPage.As<MarkUpSchemePageActions>().VerifyMarkUpSchemeDeletion(schemeID);
            CommonUtil.AddPassedTestCase("QA715");
            Settings.Logger.Info("QA715 - Delete an existing Markup Scheme completed successfully.!");
        }

        [Test, Description("M5-Edit Markup Scheme,Merged with- QA706_QA708_QA715_CreateEditDeleteMarkUpScheme")]    
        public void QA708_EditMarkUpScheme()
        {
            CommonUtil.VerifyPassedTestCase("QA708");
        }

        [Test, Description("M5-Delete Markup Scheme,Merged with- QA706_QA708_QA715_CreateEditDeleteMarkUpScheme")]
        public void QA715_DeleteMarkUpScheme()
        {
            CommonUtil.VerifyPassedTestCase("QA715");
        }

        [TestCase("MarkUpSchemeTestData.json", "MarkUpScheme", Description = "M5-Copy Markup Scheme")]
        public void QA716_CopyMarkUpScheme(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMarkUpScheme();
            string schemeID = CurrentPage.As<MarkUpSchemePageActions>().CreateMarkUpScheme("QA706_CreateMarkUpScheme");
            CurrentPage = _pageNavigate.NavigateToCopyMarkUpScheme();
            CopyMarkUpScheme copyMarupObjectValues = CommonUtil.DataObjectForKey("QA716_CopyMarkUpScheme").ToObject<CopyMarkUpScheme>();
            string NewschemeID = CurrentPage.As<MarkUpSchemePageActions>().CopyMarkUpScheme(schemeID, "QA716_CopyMarkUpScheme");
            CurrentPage = _pageNavigate.NavigateToMarkUpScheme();           
            CurrentPage.As<MarkUpSchemePageActions>().VerifyMarkupScheme(NewschemeID, "QA706_CreateMarkUpScheme", copyMarupObjectValues.NewSchemeDesc);
            Settings.Logger.Info("QA716 - Copy Markup Scheme completed successfully.!");
            Settings.Logger.Info("Data CleanUp Started");
            CurrentPage.As<MarkUpSchemePageActions>().DeleteMarkUpScheme(NewschemeID);
            CurrentPage.As<MarkUpSchemePageActions>().DeleteMarkUpScheme(schemeID);
            Settings.Logger.Info("Data CleanUp Completed");
        }
    }
}
