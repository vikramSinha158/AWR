﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.TechSpec
{
    [TestFixture]
    internal class TechSpecTest : Hooks
    {
        internal HomePageActions _homePage => new HomePageActions(Driver);

        [TestCase("TechSpecTestData.json", "TechSpec", Description = "M5-Verifying Add ,Copy and update Tech spec "),Order(1)]
        public void QA345_QA348_QA363_CreateCopyAndUpdateTechSpec(object[] testParameter)
        {
            TechSpecMain TechSpecObject = CommonUtil.DataObjectForKey("TechSpecMain").ToObject<TechSpecMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTechSpecMainPage();
            TechSpecObjects.TechSpecNumber = CurrentPage.As<TechSpecMainPageActions>().CreateTechSpec(TechSpecObject);
            CurrentPage.As<TechSpecMainPageActions>().VerifyTechSpecInformation(TechSpecObjects.TechSpecMainKey, TechSpecObjects.TechSpecNumber);
            Settings.Logger.Info("------------Finishing executing test ' QA345 Create Tech Spec' -------------------");
            CurrentPage = _homePage.NavigateToTechSpecCopyPage();
            string NewTechSpechNo = CurrentPage.As<TechSpecCopyPageActions>().CopyExistingTechSpec(TechSpecObjects.TechSpecNumber);
            CurrentPage = _homePage.NavigateToTechSpecMainPage();
            CurrentPage.As<TechSpecMainPageActions>().VerifyTechSpecInformation(TechSpecObjects.TechSpecCopKey, NewTechSpechNo);
            CommonUtil.AddPassedTestCase("QA363");
            Settings.Logger.Info("------------Finishing executing test ' QA363 Tech Spec Copy' -------------------");
            CurrentPage.As<TechSpecMainPageActions>().UpdateTechSpec("UpdateTechSpecMain");
            CurrentPage.As<TechSpecMainPageActions>().VerifyTechSpecInformation(TechSpecObjects.UpdateTechSpecMainKey, TechSpecObjects.TechSpecNumber);
            Settings.Logger.Info(" Successfully Verified QA348 Update Tech Spec");
            CommonUtil.AddPassedTestCase("QA348");
            Settings.Logger.Info("------------Finishing executing test ' QA348 Update Tech Spec' -------------------");
        }

        [Test, Description("M5-Verifying update Tech spec ")]
        public void QA348UpdateTechSpe()
        {
            CommonUtil.VerifyPassedTestCase("QA348");
        }

        [Test, Description("M5-Verifying update Tech spec ")]
        public void QA363TechSpecCopy()
        {
            CommonUtil.VerifyPassedTestCase("QA363");
        }

        [TestCase("TechSpecTestData.json", "TechSpec", Description = "M5-Verifying Add ,Copy and update Tech spec "),Order(1)]
        public void QA545_QA1160_CreateAndUpdateStandardJobTechSpecwithWithDependentJobs(object[] testParameter)
        {
            StandardJobTechSpec StandardTechSpec = CommonUtil.DataObjectForKey("QA545_StandardJobTechDependentJob").ToObject<StandardJobTechSpec>();
            StandardJobTechSpec EditStandardTechSpec = CommonUtil.DataObjectForKey("QA1160_StandardJobTechDependentJob").ToObject<StandardJobTechSpec>();
            CurrentPage = _homePage.NavigateToStandardJobTechSpecPage();
            CurrentPage.As<StandardJobTechSpecPageActions>().CreateStandardJobTechSpec(StandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(StandardTechSpec);
            Settings.Logger.Info("------------Finishing executing test ' QA545 Create Standard Job Tech Spec with DependentJobs Tab' -------------------");
            CurrentPage.As<StandardJobTechSpecPageActions>().UpdateStandardJobTechSpec(EditStandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(EditStandardTechSpec);
            CommonUtil.AddPassedTestCase("QA1160");
            Settings.Logger.Info("------------Finishing executing test ' QA1160 Update Standard Job Tech Spec with DependentJobs Tab' -------------------");          
            CurrentPage.As<StandardJobTechSpecPageActions>().DeleteStandardJobTechSpec(StandardTechSpec.StandJobNo);
        }

        [TestCase("TechSpecTestData.json", "TechSpec", Description = "M5-Verifying Delete Tech Spec Not Associated To Other Records ")]
        public void QA515_DeleteTechSpecNotAssociatedToOtherRecords(object[] testParameter)
        {
            TechSpecMain TechSpecObject = CommonUtil.DataObjectForKey("TechSpecMiData").ToObject<TechSpecMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTechSpecMainPage();
            string TechSpecNumber = CurrentPage.As<TechSpecMainPageActions>().CreateTechSpec(TechSpecObject);
            CurrentPage.As<TechSpecMainPageActions>().VerifyTechSpecNumbereDeletion(TechSpecNumber);
        }

        [TestCase("TechSpecTestData.json", "TechSpec", Description = "M5-Verifying Delete Tech Spec Not Associated To Other Records ")]
        public void QA516_VerifyTechSpecDoNotAllowDeleteWhenAssociatedToAnotherRecord(object[] testParameter)
        {
            TechSpecMain TechSpecObject = CommonUtil.DataObjectForKey("QA516_TechSpecDoNotAllowDelete").ToObject<TechSpecMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTechSpecMainPage();
            CurrentPage.As<TechSpecMainPageActions>().VerifyAssociatedTechSpecNotDeleted(TechSpecObject.TechSpecNo, TechSpecObject.DeleteMessageAssociatedTS);
        }

        [TestCase("TechSpecTestData.json", "TechSpec", Description = "M5-Verifying Add ,Copy and update Tech spec "),Order(1)]
        public void QA546_QA566_QA1150_CreateUpdateAndDeleteStandardJobTechSpecJobWithDetailTabAndPartTab(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            StandardJobTechSpec StandardTechSpec = CommonUtil.DataObjectForKey("QA546_StandardJobTechSpec").ToObject<StandardJobTechSpec>();
            StandardJobTechSpec EditStandardTechSpec = CommonUtil.DataObjectForKey("QA1150_StandardJobTechSpec").ToObject<StandardJobTechSpec>();
            CurrentPage = _homePage.NavigateToStandardJobTechSpecPage();
            CurrentPage.As<StandardJobTechSpecPageActions>().CreateStandardJobTechSpec(StandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(StandardTechSpec);
            Settings.Logger.Info("------------Finishing executing test ' QA546 Create Standard Job Tech Spec with Detail Tab And Part Tab' -------------------");
            CurrentPage.As<StandardJobTechSpecPageActions>().UpdateStandardJobTechSpec(EditStandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(EditStandardTechSpec);
            CommonUtil.AddPassedTestCase("QA1150");
            Settings.Logger.Info("------------Finishing executing test ' QA1150 Update Standard Job Tech Spec with Detail Tab And Part Tab' -------------------");         
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpecDeletion(StandardTechSpec.StandJobNo, StandardTechSpec.TechSpecNo);
            CommonUtil.AddPassedTestCase("QA566");
            Settings.Logger.Info("------------Finishing executing test ' QA566 Delete Standard Job Tech Spec with Detail Tab And Part Tab' -------------------");        
        }

        [TestCase("TechSpecTestData.json", "TechSpec", Description = "M5-Verifying Add ,Copy and update Tech spec "), Order(1)]
        public void QA1096_QA1156_QA1158_CreateUpdateAndDeleteStandardJobTechSpecJobWithTestSuitesTabAndEstimatesTab(object[] testParameter)
        {
            StandardJobTechSpec StandardTechSpec = CommonUtil.DataObjectForKey("QA1096_StandardJobTech").ToObject<StandardJobTechSpec>();
            StandardJobTechSpec EditStandardTechSpec = CommonUtil.DataObjectForKey("EditTestSuitAndEstimatesStandardJobTech").ToObject<StandardJobTechSpec>();
            CurrentPage = _homePage.NavigateToStandardJobTechSpecPage();
            CurrentPage.As<StandardJobTechSpecPageActions>().CreateStandardJobTechSpec(StandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(StandardTechSpec);
            Settings.Logger.Info("------------Finishing executing test ' QA1096 Create Standard Job Tech Spec with Test Suites Tab And Estimates Tab' -------------------");
            CurrentPage.As<StandardJobTechSpecPageActions>().UpdateStandardJobTechSpec(EditStandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(EditStandardTechSpec);
            CommonUtil.AddPassedTestCase("QA1156");
            CommonUtil.AddPassedTestCase("QA1158");
            Settings.Logger.Info("------------Finishing executing test ' QA1156 and QA1158 Update Standard Job Tech Spec with Test Suites Tab and EstimatesTab ' -------------------");
            CurrentPage.As<StandardJobTechSpecPageActions>().DeleteStandardJobTechSpecTable(EditStandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().DeleteStandardJobTechSpec(StandardTechSpec.StandJobNo);        
        }

        [TestCase("TechSpecTestData.json", "TechSpecWarranty", Description = "M5-Verifying Add ,Copy and update Tech spec "), Order(1)]
        public void QA1138_QA1141_CreateAndDeleteWarrantyTechSpecParts(object[] testParameter)
        {
            TableData TableData = CommonUtil.DataObjectForKey("WarrantyTechSpecPartTable").ToObject<TableData>();
            WarrantyTechSpec WarrantyTechSpec = CommonUtil.DataObjectForKey("QA1138_CreateWarrantyTechSpecParts").ToObject<WarrantyTechSpec>();
            CurrentPage = _homePage.NavigateWarrantyTechSpec();
            CurrentPage.As<TechSpecWarrantyPageActions>().CreateWarrantyTechSpec(WarrantyTechSpec);
            CurrentPage.As<TechSpecWarrantyPageActions>().VerifyWarrantyTechSpec(WarrantyTechSpec);
            Settings.Logger.Info("------------Finishing executing test ' QA1138 Create Tech Spec Parts' -------------------");
            CurrentPage.As<TechSpecWarrantyPageActions>().DeleteWarrantyTechSpec(WarrantyTechSpec);
            CurrentPage.As<TechSpecWarrantyPageActions>().VerifyDeleteWarrantyTechSpec(WarrantyTechSpec);
            CommonUtil.AddPassedTestCase("QA1141");
            Settings.Logger.Info("------------Finishing executing test ' QA1141 Delete Tech Spec Parts' -------------------");
        }

        [Test, Description("M5-Verify Delete Tech Spec Parts")]
        public void QA1141_VerifyDeleteTechSpecParts()
        {
            CommonUtil.VerifyPassedTestCase("QA1141");
        }

        [Test, Description("M5-Verify Standard Job TechSpec Deletion ")]
        public void QA566_VerifyStandardJobTechSpecDeletion()
        {
            CommonUtil.VerifyPassedTestCase("QA566");
        }

        [TestCase("TechSpecTestData.json", "TechSpecWarranty", Description = "M5-Verifying CreateWarrantyTechSpecSubUnit"), Order(1)]
        public void QA620_QA1147_CreateWarrantyTechSpecSubUnit(object[] testParameter)
        {
            TableData TableData = CommonUtil.DataObjectForKey("WarrantyTechSpecSubUnitTable").ToObject<TableData>();
            WarrantyTechSpec WarrantyTechSpec = CommonUtil.DataObjectForKey("QA620_CreateWarrantySubUnitTechSpec").ToObject<WarrantyTechSpec>();
            CurrentPage = _homePage.NavigateWarrantyTechSpec();
            CurrentPage.As<TechSpecWarrantyPageActions>().CreateWarrantyTechSpec(WarrantyTechSpec);
            CurrentPage.As<TechSpecWarrantyPageActions>().VerifyWarrantyTechSpec(WarrantyTechSpec);
            Settings.Logger.Info("------------Finishing executing test ' QA620 Create Tech Spec sub unit ' -------------------");
            CurrentPage.As<TechSpecWarrantyPageActions>().DeleteWarrantyTechSpec(WarrantyTechSpec);
            CurrentPage.As<TechSpecWarrantyPageActions>().VerifyDeleteWarrantyTechSpec(WarrantyTechSpec);
            CommonUtil.AddPassedTestCase("QA1147");
            Settings.Logger.Info("------------Finishing executing test ' QA1147 Delete sub unit  Tech Spec ' -------------------");
        }

        [Test, Description("M5-Verify Delete Tech Spec Sub unit")]
        public void QA1147_VerifyDeleteTechSpecParts()
        {
            CommonUtil.VerifyPassedTestCase("QA1147");
        }

        [TestCase("TechSpecTestData.json", "TechSpec", Description = "M5-Verifying Dept Fixed Costs"), Order(1)]
        public void QA1097_QAA1159_CreateUpdateAndDeleteStandardJobTechSpecJobWithDeptFixedCostsTab(object[] testParameter)
        {
            StandardJobTechSpec StandardTechSpec = CommonUtil.DataObjectForKey("QA1097_StandardJobTechSpec").ToObject<StandardJobTechSpec>();
            StandardJobTechSpec EditStandardTechSpec = CommonUtil.DataObjectForKey("QA1159_StandardJobTechSpecDeptCosts").ToObject<StandardJobTechSpec>();
            CurrentPage = _homePage.NavigateToStandardJobTechSpecPage();
            CurrentPage.As<StandardJobTechSpecPageActions>().CreateStandardJobTechSpec(StandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(StandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().UpdateStandardJobTechSpec(EditStandardTechSpec);
            Settings.Logger.Info("------------Finishing executing test 'QA1097 Create Tech Fixed Costs Tab' -------------------");
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyStandardJobTechSpec(EditStandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().DeleteStandardJobTechSpecTable(StandardTechSpec);
            CommonUtil.AddPassedTestCase("QA1159");
            Settings.Logger.Info("------------Finishing executing test 'QAA1159 Update Tech Fixed Costs Tab' -------------------");
            CurrentPage.As<StandardJobTechSpecPageActions>().DeleteStandardJobTechSpec(StandardTechSpec.StandJobNo);
        }

        [Test, Description("M5-Verify UpdateStandardJobTechSpec")]
        public void QA562_UpdateStandardJobTechSpec()
        {
            CommonUtil.VerifyPassedTestCase("QA1158");
            Settings.Logger.Info(" QA1158 Merged with  'QA1096_QA1156_QA1158_CreateUpdateAndDeleteStandardJobTechSpecJobWithTestSuitesTabAndEstimatesTab'");
            CommonUtil.VerifyPassedTestCase("QA1159");
            Settings.Logger.Info(" QA1159 Merged with  'QA1097_QAA1159_CreateUpdateAndDeleteStandardJobTechSpecJobWithDeptFixedCostsTa");
            CommonUtil.VerifyPassedTestCase("QA1160");
            Settings.Logger.Info(" QA1160 Merged with  'QA545_QA1160_CreateAndUpdateStandardJobTechSpecwithWithDependentJobs'");
        }

        [Test, Description("M5-Verify UpdateStandardJobTechSpec")]
        public void QA1145_UpdateStandardJobTechSpec()
        {
            CommonUtil.VerifyPassedTestCase("QA1156");
            Settings.Logger.Info(" QA1156 Merged with  'QA1096_QA1156_QA1158_CreateUpdateAndDeleteStandardJobTechSpecJobWithTestSuitesTabAndEstimatesTab'");
            CommonUtil.VerifyPassedTestCase("QA1150");
            Settings.Logger.Info(" QA1150 Merged with 'QA546_QA566_QA1150_CreateUpdateAndDeleteStandardJobTechSpecJobWithDetailTabAndPartTab'");
        }

        [TestCase("TechSpecTestData.json", "TechSpecWarranty", Description = "M5-Verifying CreateWarrantyTechSpec With Exclude Checkbox"), Order(1)]
        public void QA1149_CreateWarrantyTechSpecSubUnitWithExcludeCheckbox(object[] testParameter)
        {
            WarrantyTechSpec WarrantyTechSpec = CommonUtil.DataObjectForKey("QA1149_CreateWarrantySubUnitTechSpecExcludCheckBox").ToObject<WarrantyTechSpec>();
            CurrentPage = _homePage.NavigateWarrantyTechSpec();
            CurrentPage.As<TechSpecWarrantyPageActions>().CreateWarrantyTechSpec(WarrantyTechSpec);
            CurrentPage.As<TechSpecWarrantyPageActions>().VerifyWarrantyTechSpec(WarrantyTechSpec);
            Settings.Logger.Info("------------Finishing executing test ' QA1149 Create Tech Spec sub unit With Exclude Checkbox' -------------------");
            CurrentPage.As<TechSpecWarrantyPageActions>().DeleteWarrantyTechSpec(WarrantyTechSpec);
            Settings.Logger.Info("------------Finishing executing test ' Delete sub unit  Tech Spec ' -------------------");
        }

        [TestCase("StandardJobTechSpecTestData.json", "StandardJobTechSpec", Description = "M5-Verifying Delete tandard JobE timates,Delete Standard Job Tech Spec and Parts and Dept Fixed Code Table"), Order(1)]
        public void QA1157_QA1222_DeleteStandardJobEstimatesPartsAndDeptFixedCodeTable(object[] testParameter)
        {
            StandardJobTechSpec StandardTechSpec = CommonUtil.DataObjectForKey("QA1157_StandardJobTech").ToObject<StandardJobTechSpec>();
            CurrentPage = _homePage.NavigateToStandardJobTechSpecPage();
            CurrentPage.As<StandardJobTechSpecPageActions>().CreateStandardJobTechSpec(StandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().DeleteStandardJobTechSpecTable(StandardTechSpec);
            CurrentPage.As<StandardJobTechSpecPageActions>().VerifyDeletionStandardJobTechSpecTable(StandardTechSpec);     
            CurrentPage.As<StandardJobTechSpecPageActions>().DeleteStandardJobTechSpec(StandardTechSpec.StandJobNo);
            CommonUtil.AddPassedTestCase("QA1222");
            Settings.Logger.Info("------------Finishing executing test 'Merged  QA1157 and QA1222 ,Delete StandardJob Estimate Parts And DeptFixedCodeTable ' -------------------");
        }

        [Test, Description("M5-Verify Delete Standard Job Tech Spec and Parts")]
        public void QA1222_DeleteStandardJobTechSpecParts()
        {
            CommonUtil.VerifyPassedTestCase("QA1222");
        }

    }
}
