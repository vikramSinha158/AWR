﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Units;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Units
{
    [TestFixture]
    internal class UnitRequestTest : Hooks
    {
        [TestCase("UnitRequestTestData.json", "QA561_ApproveReopenApproveReplaceUnitRequest",
            TestName = "QA561_QA563_QA573_ApproveReopenUpdateApproveReplaceUnitRequest",
            Description = "M5-Approve Reopen Update Approve Replace Unit Request with status REQUEST"),Order(1)]
        public void QA561_QA563_QA573_ApproveReopenUpdateApproveReplaceUnitRequest(object[] testParameter)
        {
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            UnitRequest UpdatedUnitReq = CommonUtil.DataObjectForKey("UpdatedUnitRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitReq.ReqDetail.ReqReplacesUnit = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            CurrentPage = _pageNavigate.NavigateToUnitRequestPage();
            UpdatedUnitReq.RequestNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().ReopenApproveUnitRequest(UpdatedUnitReq.RequestNo, UnitReq.ReqApprover);
            Settings.Logger.Info("------------Execution completed for test ' QA561 Approve Replace Unit Request with status REQUEST' -------------------");
            CurrentPage.As<UnitRequestPageActions>().UpdateUnitRequest(UpdatedUnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(UpdatedUnitReq.RequestNo, UpdatedUnitReq);
            CommonUtil.AddPassedTestCase("QA563");
            Settings.Logger.Info("------------Execution completed for test ' QA563 Re-Open and Update Approved Replace Unit Request' -------------------");
            CurrentPage.As<UnitRequestPageActions>().ReopenApproveUnitRequest(UpdatedUnitReq.RequestNo, UnitReq.ReqApprover);
            CommonUtil.AddPassedTestCase("QA573");
            Settings.Logger.Info("------------Execution completed for test ' QA573 Approve Re-Opened Updated Replace Unit Request' -------------------");
        }

        [Test, Description("M5-Re-Open and Update Approved Replace Unit Request,Merged with- QA561_QA563_QA573_ApproveReopenUpdateApproveReplaceUnitRequest")]
        public void QA563_ReopenUpdateApproveReplaceUnitRequest() 
        {
            CommonUtil.VerifyPassedTestCase("QA563");
        }

        [Test, Description("M5-Approve Re-Opened Updated Replace Unit Request,Merged with- QA561_QA563_QA573_ApproveReopenUpdateApproveReplaceUnitRequest")]
        public void QA573_ApproveReopenUpdatedReplaceUnitRequest() 
        {
            CommonUtil.VerifyPassedTestCase("QA573");
        }


        [TestCase("UnitRequestTestData.json", "QA657_UpdateApproveReplaceUnitRequestOnUnitPurchaseRequisition",
            TestName = "QA657_UpdateApproveReplaceUnitRequestOnUnitPurchaseRequisition",
            Description = "M5-Update Unit Request for Unit Replace Type with APPROVED Status on the Unit Purchase Requisition frame")]
        public void QA657_UpdateApproveReplaceUnitRequestOnUnitPurchaseRequisition(object[] testParameter)
        {
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            UnitPurchaseRequisition uprUpdated = CommonUtil.DataObjectForKey("EditReqDetails").ToObject<UnitPurchaseRequisition>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitReq.ReqDetail.ReqReplacesUnit = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            CurrentPage = _pageNavigate.NavigateToUnitRequestPage();
            UnitReq.RequestNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().ReopenApproveUnitRequest(UnitReq.RequestNo, UnitReq.ReqApprover);
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseRequisitionsPage();
            uprUpdated.UnitNo = UnitReq.ReqUnitNo;
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().UpdateUnitPurchaseRequisition(uprUpdated);
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().VerifyUnitPurchaseRequisitionInformation(uprUpdated.UnitNo, uprUpdated);
        }
    }
}
