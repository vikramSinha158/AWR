using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.Actions.Units;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.UnitsObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Units
{
    [TestFixture]
    internal class UnitsTest : Hooks
    {
        [TestCase("UnitsTestData.json", "QA314_CreateUnit", true,
            TestName = "QA314_CreateNewUnit", Description = "M5-Create New Unit")]
        public void QA314_CreateNewUnit(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            string _unitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitInformation(_unitNo, Unit);
        }

        [TestCase("UnitsTestData.json", "QA695_CreateUnitWithSystemFlags", true, TestName = "QA695_CreateUnitWithSystemFlags",
            Description = "M5-Verify able to create Unit with data for required field only with specific system flags setting.")]
        public void QA695_CreateUnitWithSystemFlags(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitInfo").ToObject<UnitMain>();
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            string _unitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitInformation(_unitNo, Unit);
        }

        [TestCase("UnitsTestData.json", "QA697_CreateUnitUsingAddNewWithSystemFlags", true, 
            TestName = "QA697_CreateUnitUsingAddNewWithSystemFlags",
            Description = "Create Unit using Add New button with data for required fields ONLY upon System Flags setting")]
        public void QA697_CreateUnitUsingAddNewWithSystemFlags(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitInfo").ToObject<UnitMain>();
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            string _unitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitInformation(_unitNo, Unit);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(_unitNo);
        }

        [TestCase("UnitsTestData.json", "QA343_UpdateUnit", true,
            TestName = "QA343_UpdateUnit", Description = "M5-Update Unit")]
        public void QA343_UpdateUnit(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitMain UnitC = CommonUtil.DataObjectForKey("UnitInfo").ToObject<UnitMain>();
            UnitMain UnitE = CommonUtil.DataObjectForKey("EditUnit").ToObject<UnitMain>();
            UnitE.UnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(UnitC);
            CurrentPage.As<UnitMainPageActions>().UpdateUnitInfo(UnitE);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitInformation(UnitE.UnitNo, UnitE);
        }

        [Test, Description("M5-Verifying unit no deletion ")]
        public void QA354_DeleteUnitNo()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().CreateUnit();
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(Settings.UnitNumber);
        }

        [TestCase("UnitsTestData.json", "QA355_CreateUnitCopy",
            TestName = "QA355_CreateUnitCopy", Description = "M5-Create Unit Copy")]
        public void QA355_CreateUnitCopy(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitCopyPage();
            (CurrentPage, string _unitNo) = CurrentPage.As<UnitCopyPageActions>().CreateUnitCopy();
            CurrentPage.As<UnitMainPageActions>().VerifyCopyUnitInformation(_unitNo);
        }

        [TestCase("UnitsTestData.json", "QA512_CreateUnitCopyUsingAddNew",
            TestName = "QA512_CreateUnitCopyUsingAddNew", Description = "M5-Create Unit Copy Using Add New button")]
        public void QA512_CreateUnitCopyUsingAddNew(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitCopyPage();
            (CurrentPage, string _unitNo) = CurrentPage.As<UnitCopyPageActions>().CreateUnitCopy();
            CurrentPage.As<UnitMainPageActions>().VerifyCopyUnitInformation(_unitNo);
        }

        [TestCase("UnitsTestData.json", "QA659_CreateNewUnitRequest",
            TestName = "QA659_CreateNewUnitRequest", Description = "M5-Create New Unit Request with data for required fields only")]
        public void QA659_CreateNewUnitRequest(object[] testParameter)
        {
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA529_CreateNewUnitRequestWithLeasedOwnership",
            TestName = "QA529_CreateNewUnitRequestWithLeasedOwnership", Description = "M5-Create New Request for New Unit with Leased Ownership")]
        public void QA529_CreateNewUnitRequestWithLeasedOwnership(object[] testParameter)
        {
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA524_CreateNewUnitRequestWithLeasedOwnership",
            TestName = "QA524_CreateNewUnitRequestWithLeasedOwnership", Description = "M5 - Unit - Create New Request for New Unit with OwnerShip = Leased")]
        public void QA524_CreateNewUnitRequestWithLeasedOwnership(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = _pageNavigate.NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA532_CreateNewUnitRequestWithRentedOwnership", TestName = "QA532_CreateNewUnitRequestWithRentedOwnership",
            Description = "M5 - Unit - Create New Request for New Unit with Rented Ownership")]
        public void QA532_CreateNewUnitRequestWithRentedOwnership(object[] testParameter)
        {
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA535_CreateNewUnitRequestWithOwnedOwnership", TestName = "QA535_CreateNewUnitRequestWithOwnedOwnership",
            Description = "M5 - Unit - Create New Request with system generated Request No and Unit No for Type = New Unit and Ownership = Owned")]
        public void QA535_CreateNewUnitRequestWithOwnedOwnership(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = _pageNavigate.NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA539_CreateNewUnitRequestWithRentedOwnership", TestName = "QA539_CreateNewUnitRequestWithRentedOwnership",
            Description = "M5 - Unit - Create New Request with system generated Request No and Unit No for Type = New Unit and Ownership = Rented")]
        public void QA539_CreateNewUnitRequestWithRentedOwnership(object[] testParameter)
        {
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA560_CreateNewReplaceTypeUnitRequest",
            TestName = "QA560_CreateNewReplaceTypeUnitRequest", Description = "M5-Create New Request for New Unit with Replace Type")]
        public void QA560_CreateNewReplaceTypeUnitRequest(object[] testParameter)
        {
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitReq.ReqDetail.ReqReplacesUnit = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA662_CreateUnitRequestCopy",
            TestName = "QA662_CreateUnitRequestCopy", Description = "M5-Create Unit Request Copy")]
        public void QA662_CreateUnitRequestCopy(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestCopyPage();
            (CurrentPage, string _reqNo) = CurrentPage.As<UnitRequestCopyPageActions>().CreateUnitRequestCopy();
            CurrentPage.As<UnitRequestPageActions>().VerifyCopyUnitRequestInformation(_reqNo);
        }

        [TestCase("UnitsTestData.json", "QA663_CreateUnitRequestCopyUsingAddNew",
            TestName = "QA663_CreateUnitRequestCopyUsingAddNew", Description = "M5-Create Unit Request Copy using Add New button")]
        public void QA663_CreateUnitRequestCopyUsingAddNew(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestCopyPage();
            (CurrentPage, string _reqNo) = CurrentPage.As<UnitRequestCopyPageActions>().CreateUnitRequestCopy();
            CurrentPage.As<UnitRequestPageActions>().VerifyCopyUnitRequestInformation(_reqNo);
        }

        [TestCase("UnitsTestData.json", "QA356_GroupUnitData", true, Description = "M5-Create Unit Group "), Order(1)]
        public void QA356_QA359_CreateDeleteUnitGroup(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            GroupUnit DataObject = CommonUtil.DataObjectForKey("GroupUnit").ToObject<GroupUnit>();
            string _groupNo = CurrentPage.As<UnitGroupPageActions>().CreateNewUnitGroup(DataObject, DataObject.UnitGroupName);
            CurrentPage.As<UnitGroupPageActions>().VerifyUnitGroup(_groupNo, DataObject);
            CommonUtil.AddPassedTestCase("QA356");
            Settings.Logger.Info("------------Finishing executing test ' QA356 Create Unit Group ' -------------------");
            CurrentPage.As<UnitGroupPageActions>().VerifyUnitGroupDeletion(_groupNo);
        }

        [Test, Description("M5-Create Unit Group")]
        public void QA356_CreateUnitGroup()
        {
            CommonUtil.VerifyPassedTestCase("QA356");
        }

        [TestCase("UnitsTestdata.json", "QA522_UnitUsingDeptChange",
            TestName = "QA522_UnitUsingDeptChange", Description = "M5-Change Using Department for Unit")]
        public void QA522_UnitUsingDeptChange(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitDepartmentChangePage();
            CurrentPage.As<UnitDepartmentChangePageActions>().SearchUnitNoByUsingDepartment(DeptKeyword);
            CurrentPage.As<UnitDepartmentChangePageActions>().VerifyDepartmentDetails(DepartmentObjects.DeptKeyword, DepartmentObjects.DeptKeyword);
            CurrentPage.As<UnitDepartmentChangePageActions>().UpdateUnitDepartments(DeptOwning, DeptUsing);
            CurrentPage.As<UnitDepartmentChangePageActions>().RefreshAndVerifyUnitDepartmentDetails(DeptOwning, DeptUsing);
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().LoadUnitAndOpenDeptLocTab(UnitDepartmentChangePage._unitNumber);
            CurrentPage.As<UnitMainPageActions>().VerifyDepartmentDetails(DeptOwning, DeptUsing);
        }

        [TestCase("UnitGroupData.json", "GroupUnit", true, Description = "M5-Create Unit Group with Unitst"), Order(1)]
        public void QA370_QA430_QA492_CreateAChangeLeadUnitAndDeleteUnitGroupWithUnits(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            GroupUnit DataObject = CommonUtil.DataObjectForKey("QA370_GroupUnitData").ToObject<GroupUnit>();
            GroupUnit EditDataObject = CommonUtil.DataObjectForKey("QA492_GroupUnitData").ToObject<GroupUnit>();
            CurrentPage.As<UnitGroupPageActions>().AddUnitsInExistingUnitGroup(DataObject);
            CurrentPage.As<UnitGroupPageActions>().VerifyUnitGroup(DataObject.UnitGroupName, DataObject);
            Settings.Logger.Info("------------Finishing executing test ' QA370 for Add units in Group Unit' -------------------");
            CurrentPage.As<UnitGroupPageActions>().AddUnitsInExistingUnitGroup(EditDataObject);
            CurrentPage.As<UnitGroupPageActions>().VerifyUnitGroup(EditDataObject.UnitGroupName, EditDataObject);
            CommonUtil.AddPassedTestCase("QA492");
            Settings.Logger.Info("------------Finishing executing test ' QA492 for changing Lead Unit checkbox' -------------------");
            CurrentPage.As<UnitGroupPageActions>().DeleteUnitGroup(EditDataObject.UnitGroupName, EditDataObject);
            CurrentPage.As<UnitGroupPageActions>().VerifyUnitDeletion(DataObject.UnitGroupName);
            CommonUtil.AddPassedTestCase("QA430");
            Settings.Logger.Info("------------Finishing executing test ' QA430 for Delete units from Group Unit' -------------------");
        }

        [Test, Description("M6 - changing Lead Unit checkbox")]
        public void QA492_ChangeLeadUnitAnd()
        {
            CommonUtil.VerifyPassedTestCase("QA492");
        }

        [Test, Description("M6 - Delete units from Group Unit")]
        public void QA430_DeleteunitsfromGroupUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA430");
        }

        [TestCase("UnitsTestData.json", "QA664_CreateUnitPurchaseOrder",
            TestName = "QA664_CreateUnitPurchaseOrder", Description = "M5-Create Unit Purchase Order")]
        public void QA664_CreateUnitPurchaseOrder(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitPurchaseOrdersPage();
            UnitPurchaseOrder upo = CommonUtil.DataObjectForKey("PurchaseOrder").ToObject<UnitPurchaseOrder>();
            string _poNo = CurrentPage.As<UnitPurchaseOrdersPageActions>().CreateUnitPurchaseOrder(upo);
            CurrentPage.As<UnitPurchaseOrdersPageActions>().VerifyUnitPurchaseOrder(_poNo, upo);
        }

        [TestCase("UnitsTestData.json", "QA669_CreateUnitPurchaseOrderWithRequiredFields",
            TestName = "QA669_CreateUnitPurchaseOrderWithRequiredFields",
            Description = "M5-Create Unit Purchase Order with data for required fields only")]
        public void QA669_CreateUnitPurchaseOrderWithRequiredFields(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitPurchaseOrdersPage();
            UnitPurchaseOrder upo = CommonUtil.DataObjectForKey("PurchaseOrder").ToObject<UnitPurchaseOrder>();
            string _poNo = CurrentPage.As<UnitPurchaseOrdersPageActions>().CreateUnitPurchaseOrder(upo);
            CurrentPage.As<UnitPurchaseOrdersPageActions>().VerifyUnitPurchaseOrder(_poNo, upo);
        }

        [TestCase("UnitsTestData.json", "QA683_CreateNonCompanyUnit", TestName = "QA683_CreateNonCompanyUnitWithRequiredFields",
            Description = "M5-Create Non Company Unit with data for required fields only")]
        public void QA683_CreateNonCompanyUnitWithRequiredFields(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToNonCompanyUnitMainPage();
            NonCompanyUnit ncu = CommonUtil.DataObjectForKey("NonCompanyUnit").ToObject<NonCompanyUnit>();
            string _ncUnitNo = CurrentPage.As<NonCompanyUnitMainPageActions>().CreateNonCompanyUnit(ncu);
            CurrentPage.As<NonCompanyUnitMainPageActions>().VerifyNonCompanyUnit(_ncUnitNo, ncu);
        }

        [TestCase("UnitsTestData.json", "QA690_DeleteNonCompanyUnit", TestName = "QA675_QA688_QA690_RetrieveDeactivateDeleteNonCompanyUnit",
            Description = "M5-Retrieve, Deactivate and Delete Non Company Unit"), Order(1)]
        public void QA675_QA688_QA690_RetrieveDeactivateDeleteNonCompanyUnit(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToNonCompanyUnitMainPage();
            NonCompanyUnit ncu = CommonUtil.DataObjectForKey("NonCompanyUnit").ToObject<NonCompanyUnit>();
            string _ncUnitNo = CurrentPage.As<NonCompanyUnitMainPageActions>().CreateNonCompanyUnit(ncu);
            CurrentPage.As<NonCompanyUnitMainPageActions>().RetrieveNonCompanyUnit(_ncUnitNo);
            CommonUtil.AddPassedTestCase("QA675");
            Settings.Logger.Info("------------Execution completed for test ' QA675 Retrieve Non Company Unit' -------------------");
            CurrentPage.As<NonCompanyUnitMainPageActions>().DeactivateNonCompanyUnit(_ncUnitNo);
            CommonUtil.AddPassedTestCase("QA688");
            Settings.Logger.Info("------------Execution completed for test ' QA688 Deactivate Non Company Unit' -------------------");
            CurrentPage.As<NonCompanyUnitMainPageActions>().VerifyNonCompanyUnitDeletion(_ncUnitNo);
            Settings.Logger.Info("------------Execution completed for test ' QA690 Delete Non Company Unit' -------------------");
        }

        [Test, Description("M5-Retrieve Non Company Unit")]
        public void QA675_RetrieveNonCompanyUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA675");
        }

        [Test, Description("M5-Deactivate Non Company Unit")]
        public void QA688_DeactivateNonCompanyUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA688");
        }

        [TestCase("UnitsTestData.json", "QA650_CreateUnitPurchaseRequisition", TestName = "QA650_CreateUnitPurchaseRequisition",
         Description = "M5 - Unit - Create new Unit Purchase Requisition using the Add New button to generate a unit number")]
        public void QA650_CreateUnitPurchaseRequisition(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateToUnitPurchaseRequisitionsPage();
            UnitPurchaseRequisition upr = CommonUtil.DataObjectForKey("RequisitionDetails").ToObject<UnitPurchaseRequisition>();
            string _unitNo = CurrentPage.As<UnitPurchaseRequisitionsPageActions>().CreateUnitPurchaseRequisition(upr);
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().VerifyUnitPurchaseRequisitionInformation(_unitNo, upr);
        }

        [TestCase("UnitsTestData.json", "QA651_CreateUnitPurchaseRequisition", TestName = "QA651_CreateUnitPurchaseRequisitionRequiredFieldsOnly",
            Description = "M5 - Unit - Create Unit Purchase Requisition with a manually entered New Unit number that does not exist. Enter data for required fields only")]
        public void QA651_CreateUnitPurchaseRequisitionRequiredFieldsOnly(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateToUnitPurchaseRequisitionsPage();
            UnitPurchaseRequisition upr = CommonUtil.DataObjectForKey("RequisitionDetails").ToObject<UnitPurchaseRequisition>();
            string _unitNo = CurrentPage.As<UnitPurchaseRequisitionsPageActions>().CreateUnitPurchaseRequisition(upr);
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().VerifyUnitPurchaseRequisitionInformation(_unitNo, upr);
        }

        [TestCase("UnitsTestData.json", "QA652_UpdateUnitPurchaseRequisition", TestName = "QA652_UpdateUnitPurchaseRequisition",
            Description = "M5 - Update Unit Purchase Requisition that was created with a manually entered New Unit number and with a minimum data")]
        public void QA652_UpdateUnitPurchaseRequisition(object[] testParameter)
        {
            int count = 0;
            UnitPurchaseRequisition upr = CommonUtil.DataObjectForKey("ReqDetails").ToObject<UnitPurchaseRequisition>();
            UnitPurchaseRequisition uprUpdated = CommonUtil.DataObjectForKey("EditReqDetails").ToObject<UnitPurchaseRequisition>();
            List<UnitPurchaseOrder> pos = CommonUtil.DataObjectForKey("PurchaseOrders").ToObject<List<UnitPurchaseOrder>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitPurchaseOrdersPage();
            foreach (UnitPurchaseOrder order in pos)
            {
                uprUpdated.POListTab.POList[count].PONumber = CurrentPage.As<UnitPurchaseOrdersPageActions>().CreateUnitPurchaseOrder(order);
                count++;
            }
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseRequisitionsPage();
            uprUpdated.UnitNo = CurrentPage.As<UnitPurchaseRequisitionsPageActions>().CreateUnitPurchaseRequisition(upr);
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().UpdateUnitPurchaseRequisition(uprUpdated);
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().VerifyUnitPurchaseRequisitionInformation(uprUpdated.UnitNo, uprUpdated);
        }

        [TestCase("UnitsTestData.json", "QA692_CreateUnitWithSystemFlags", true, TestName = "QA692_CreateUnitWithSystemFlags",
            Description = "M5-erify able to create Unit with data for required field only with specific system flags setting")]
        public void QA692_CreateUnitWithSystemFlags(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateUnitMainPage();
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            string _unitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitInformation(_unitNo, Unit);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(_unitNo);
        }

        [TestCase("UnitsTestData.json", "QA685_CreateNonCompanyUnitWithAllFieldsData",
            TestName = "QA685_CreateNonCompanyUnitWithAllFields", Description = "M5-Create Non Company Unit with data for all fields")]
        public void QA685_CreateNonCompanyUnitWithAllFields(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToNonCompanyUnitMainPage();
            NonCompanyUnit ncu = CommonUtil.DataObjectForKey("NonCompanyUnit").ToObject<NonCompanyUnit>();
            string _ncUnitNo = CurrentPage.As<NonCompanyUnitMainPageActions>().CreateNonCompanyUnit(ncu);
            CurrentPage.As<NonCompanyUnitMainPageActions>().VerifyNonCompanyUnit(_ncUnitNo, ncu);
            CurrentPage.As<NonCompanyUnitMainPageActions>().VerifyNonCompanyUnitDeletion(_ncUnitNo);
        }

        [TestCase("UnitsTestData.json", "QA445_CannotAddUnitWithoutCheckingLeadUnitCheckbox",
            TestName = "QA445_CannotAddUnitWithoutCheckingLeadUnitCheckbox", Description = "M5 - Unit - Cannot add Unit to the created Unit Group without checking Lead Unit checkbox")]
        public void QA445_CannotAddUnitWithOutLeadUnitCheckbox(object[] testParameter)
        {
            GroupUnit DataObject = CommonUtil.DataObjectForKey("GroupUnit").ToObject<GroupUnit>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            LeadUnit LeadUnit = CommonUtil.DataObjectForKey("LeadUnit").ToObject<LeadUnit>();
            string _groupNo = CurrentPage.As<UnitGroupPageActions>().CreateNewUnitGroup(DataObject);
            UnitGroup unitGroup = CommonUtil.DataObjectForKey("UnitGroup").ToObject<UnitGroup>();
            CurrentPage.As<UnitGroupPageActions>().SaveDetailsWithoutLeadUnitCheckbox(_groupNo, LeadUnit.SearchText);
            CurrentPage.As<UnitGroupPageActions>().VerifyErrorMessage(unitGroup);
        }

        [TestCase("UnitsTestData.json", "QA635_RetrieveRecordFilteredByRequestor", true,
            TestName = "QA635_RetrieveRecordFilteredByRequestor", Description = "M5 Unit Retrieve record filtered by Requestor on Unit Request Approve frame")]
        public void QA635_RetrieveRecordFilteredByRequestor(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitRequestApprovePage();
            UnitRequestApprove UnitReqApprove = CommonUtil.DataObjectForKey("UnitRequestApprove").ToObject<UnitRequestApprove>();
            CurrentPage.As<UnitRequestApprovePageActions>().RetriveUnitRequests(UnitReqApprove);
            CurrentPage.As<UnitRequestApprovePageActions>().VerifyUnitRequestApproveRetriveDetails(UnitReqApprove);
        }


        [TestCase("UnitsTestData.json", "QA452_ErrorIfLeadUnitCheckboxCheckedOfAnotherUnit",
           TestName = "QA452_ErrorIfLeadUnitCheckboxCheckedOfAnotherUnit", Description = "M5 - Unit - Cannot update record if the Lead Unit checkbox is checked for one more unit in existing Unit Group with Units")]
        public void QA452_ErrorIfLeadUnitCheckboxCheckedOfAnotherUnit(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            LeadUnit leadUnit = CommonUtil.DataObjectForKey("LeadUnit").ToObject<LeadUnit>();
            CurrentPage.As<UnitGroupPageActions>().EnterUnitGroupName(leadUnit.UnitGroup);
            CurrentPage.As<UnitGroupPageActions>().SelectMultipleUnitsInGroupAndSave(leadUnit);
            CurrentPage.As<UnitGroupPageActions>().VerifyErrorMessage(leadUnit);
        }

        [TestCase("UnitsTestData.json", "QA653_DeleteUnitPurchaseRequisition", Description = "M5 - Unit - Create new Unit Purchase Requisition using the Add New button to generate a unit number")]
        public void QA653_DeleteUnitPurchaseRequisition(object[] testParameter)
        {
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseRequisitionsPage();
            UnitPurchaseRequisition upr = CommonUtil.DataObjectForKey("RequisitionDetails").ToObject<UnitPurchaseRequisition>();
            string _unitNo = CurrentPage.As<UnitPurchaseRequisitionsPageActions>().CreateUnitPurchaseRequisition(upr);
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().VerifyCancelUnitRequisitionInDeletion(_unitNo);
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().VerifyUnitRequisitionInDeletion(_unitNo);
        }

        [TestCase("UnitsTestData.json", "QA670_DeleteUnitPurchaseOrder", Description = "M5-Create Unit Purchase Order")]
        public void QA670_DeleteUnitPurchaseOrder(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitPurchaseOrdersPage();
            UnitPurchaseOrder upo = CommonUtil.DataObjectForKey("PurchaseOrder").ToObject<UnitPurchaseOrder>();
            string _poNo = CurrentPage.As<UnitPurchaseOrdersPageActions>().CreateUnitPurchaseOrder(upo);
            CurrentPage.As<UnitPurchaseOrdersPageActions>().VerifyUnitPurchaseOrderDeletion(_poNo);
        }
        
        [TestCase("UnitsTestData.json", "QA470_UnitGroup",
            TestName = "QA470_CannotDeleteUnitGroupWithAssignedUnits", Description = "M5 - Unit - Cannot delete Unit Group with assigned Units")]
        public void QA470_CannotDeleteUnitGroupWithAssignedUnits(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            CurrentPage.As<UnitGroupPageActions>().OpenUnitGroup(CommonUtil.DataForKey("UnitGroup"));
            CurrentPage.As<UnitGroupPageActions>().VerifyCannotDeleteUnitGroupWithAssignedUnits(CommonUtil.DataForKey("UnitGroup"));
        }
        
        [TestCase("UnitsTestData.json", "QA513_CannotAddUnitForWorkRequestUnitGroup",
            TestName = "QA513_CannotAddUnitForWorkRequestUnitGroup", Description = "M5 - Unit - Cannot Add Unit if Unit Status is Workrequest status to Unit Group")]
        public void QA513_CannotAddUnitForWorkRequestUnitGroup(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            UnitGroup unitGroup = CommonUtil.DataObjectForKey("UnitGroup").ToObject<UnitGroup>();
            CurrentPage.As<UnitGroupPageActions>().SaveUnitNumber(unitGroup.UnitGroupNumber, unitGroup.UnitNumber);
            CurrentPage.As<UnitGroupPageActions>().VerifyErrorMessage(unitGroup);
        }

        [TestCase("UnitsTestData.json", "QA477_CreateUnitWithOperationalclass", true,
            TestName = "QA477_CreateUnitWithOperationalclass", Description = "M5 Unit Cannot Add Unit without assigned an operational class to Unit Group")]
        public void QA477_CreateUnitWithOperationalclass(object[] testParameter)
        {
            CurrentPage = _pageNavigate.NavigateToUnitGroupPage();
            LeadUnit leadUnit = CommonUtil.DataObjectForKey("LeadUnit").ToObject<LeadUnit>();
            CurrentPage.As<UnitGroupPageActions>().VerifyGroupUnitErrorMsg(leadUnit);
        }


        [TestCase("UnitsTestData.json", "QA686_UpdateNonCompanyUnit",
            TestName = "QA686_UpdateNonCompanyUnit", Description = "M5-Update Non-Company Unit record")]
        public void QA686_UpdateNonCompanyUnit(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToNonCompanyUnitMainPage();
            NonCompanyUnit ncu = CommonUtil.DataObjectForKey("NonCompanyUnit").ToObject<NonCompanyUnit>();
            NonCompanyUnit ncuEdit = CommonUtil.DataObjectForKey("NonCompanyUnitEdit").ToObject<NonCompanyUnit>();
            ncuEdit.NCUnitNo = CurrentPage.As<NonCompanyUnitMainPageActions>().CreateNonCompanyUnit(ncu);
            CurrentPage.As<NonCompanyUnitMainPageActions>().UpdateNonCompanyUnit(ncuEdit);
            CurrentPage.As<NonCompanyUnitMainPageActions>().VerifyNonCompanyUnit(ncuEdit.NCUnitNo, ncuEdit);
        }

		[TestCase("UnitsTestData.json", "QA612_CreateNewUnitRequestWithReplaceUnitType",
			TestName = "QA612_CreateNewUnitRequestWithReplaceUnitType", Description = "M5-Create New Request for New Unit with Replace Type")]
		public void QA612_CreateNewUnitRequestWithReplaceUnitType(object[] testParameter)
		{
			Settings.Logger.Info("Updating System Flags");
			Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
			CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
			OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
			IsFlagsChanged = true;
			UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
			UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
			CurrentPage = _pageNavigate.NavigateUnitMainPage();
			UnitReq.ReqDetail.ReqReplacesUnit = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
			CurrentPage = _pageNavigate.NavigateToUnitRequestPage();
			string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
			CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(_unitReqNo, UnitReq);
		}

		[TestCase("UnitsTestData.json", "QA579_ReopenAndRejectApprovedReplaceUnitRequest",
			TestName = "QA579_ReopenAndRejectApprovedReplaceUnitRequest", Description = "M5-Re Open and Reject Approved Replace Unit Request")]
		public void QA579_ReopenAndRejectApprovedReplaceUnitRequest(object[] testParameter)
		{
			UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
			UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
			CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
			UnitReq.ReqDetail.ReqReplacesUnit = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
			HomePageActions homepage = new HomePageActions(Driver);
			CurrentPage = homepage.NavigateToUnitRequestPage();
			string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
			CurrentPage.As<UnitRequestPageActions>().ReopenApproveUnitRequest(_unitReqNo, UnitReq.ReqApprover);
			CurrentPage.As<UnitRequestPageActions>().RejectUnitRequest(_unitReqNo, UnitReq.ReqRejectReason);
		}
        [TestCase("UnitsTestData.json", "QA525_ApproveUnitRequest", TestName = "QA525_ApproveUnitRequest",
            Description = "M5 - Unit - Approve Unit Request on Unit Request Approve frame")]
        public void QA525_ApproveUnitRequest(object[] testParameter)
        {
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            UnitRequestApprove UnitReqApprove = CommonUtil.DataObjectForKey("UnitRequestApprove").ToObject<UnitRequestApprove>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            UnitReqApprove.RequestNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            UnitReqApprove.UnitNo = UnitReq.ReqUnitNo;
            CurrentPage = _pageNavigate.NavigateUnitRequestApprovePage();
            CurrentPage.As<UnitRequestApprovePageActions>().RetriveUnitRequests(UnitReqApprove);
            CurrentPage.As<UnitRequestApprovePageActions>().OpenRequestNumber(UnitReqApprove.UnitNo);
            CurrentPage.As<UnitRequestApprovePageActions>().ApproveUnitRequest(UnitReqApprove);
            CurrentPage = _pageNavigate.NavigateToUnitRequestPage();
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(UnitReqApprove.RequestNo, UnitReq);
        }

        [TestCase("UnitsTestData.json", "QA603_ReOpenAndRejectApprovedNewUnitRequest",
           TestName = "QA603_ReOpenAndRejectApprovedNewUnitRequest", Description = "M5 - Unit - Re-Open and Reject Approved New Unit Request")]
        public void QA603_ReOpenAndRejectApprovedNewUnitRequest(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            string unitRequestNo = CommonUtil.DataForKey("UnitRequestNo");
            //Approve and Verify Approve Unit Request
            CurrentPage.As<UnitRequestPageActions>().ReopenApproveUnitRequest(unitRequestNo, CommonUtil.DataForKey("Approver") );
            //Reopen and Reject and also Verify Reject Unit Request
            CurrentPage.As<UnitRequestPageActions>().RejectUnitRequest(unitRequestNo, CommonUtil.DataForKey("ReqRejectReason"));            
        }

        [TestCase("UnitsTestData.json", "QA667_UnitPurchaseOrderWithUnitPurchaseRequisitionAssociated",
            TestName = "QA667_QA671_UpdateDeleteUnitPurchaseOrderWithUnitPurchaseRequisitionAssociated",
            Description = "M5 - Unit - Update & Delete Unit Purchase Order that has Unit Purchase Requisition associated to it"), Order(1)]
        public void QA667_QA671_UpdateDeleteUnitPurchaseOrderWithUnitPurchaseRequisitionAssociated(object[] testParameter)
        {
            UnitPurchaseOrder upo = CommonUtil.DataObjectForKey("PurchaseOrder").ToObject<UnitPurchaseOrder>();
            UnitPurchaseOrder upoEdit = CommonUtil.DataObjectForKey("UpdatedPODetails").ToObject<UnitPurchaseOrder>();
            UnitPurchaseRequisition upr = CommonUtil.DataObjectForKey("RequisitionDetails").ToObject<UnitPurchaseRequisition>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitPurchaseOrdersPage();
            upoEdit.PONo = CurrentPage.As<UnitPurchaseOrdersPageActions>().CreateUnitPurchaseOrder(upo);
            upr.POListTab.POList[0].PONumber = upoEdit.PONo;
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseRequisitionsPage();
            upoEdit.POUnits[0].POUnitNo = CurrentPage.As<UnitPurchaseRequisitionsPageActions>().CreateUnitPurchaseRequisition(upr);
            upoEdit.POPayments[0].POUnitNo = upoEdit.POUnits[0].POUnitNo;
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseOrdersPage();
            string error = upoEdit.ErrorMessage.Replace("(PONumber)", upoEdit.PONo);
            CurrentPage.As<UnitPurchaseOrdersPageActions>().VerifyUnitPurchaseOrderDeletion(upoEdit.PONo, error);
			CommonUtil.AddPassedTestCase("QA671");
            Settings.Logger.Info("------------Execution completed for test ' QA671 Cannot delete Unit Purchase Order that has Unit Purchase Requisition associated to it' -------------------");
            CurrentPage.As<UnitPurchaseOrdersPageActions>().UpdateUnitPurchaseOrder(upoEdit);
            CurrentPage.As<UnitPurchaseOrdersPageActions>().VerifyUnitPurchaseOrder(upoEdit.PONo, upoEdit);
            Settings.Logger.Info("------------Execution completed for test ' QA667 Update Unit Purchase Order that has Unit Purchase Requisition associated to it' -------------------");
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseRequisitionsPage();
            CurrentPage.As<UnitPurchaseRequisitionsPageActions>().VerifyUnitRequisitionInDeletion(upr.UnitNo);
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseOrdersPage();
            CurrentPage.As<UnitPurchaseOrdersPageActions>().VerifyUnitPurchaseOrderDeletion(upoEdit.PONo);
        }

        [Test, Description("M5 - Unit - Cannot delete Unit Purchase Order that has Unit Purchase Requisition associated to it")]
        public void QA671_CannotDeleteUnitPurchaseOrderWithUnitPurchaseRequisitionAssociated() 
		{
			CommonUtil.VerifyPassedTestCase("QA671");
		}
        
        [TestCase("UnitsTestData.json", "QA579_ReopenAndRejectApprovedReplaceUnitRequest",
            TestName = "QA579_QA585_ApproveReopenAndRejectApprovedReplaceUnitRequest",
            Description = "M5-Re Open and Reject Approved Replace Unit Request"), Order(1)]
        public void QA579_QA585_ApproveReopenAndRejectApprovedReplaceUnitRequest(object[] testParameter)
        {
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            UnitRequest UnitReq = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitReq.ReqDetail.ReqReplacesUnit = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateToUnitRequestPage();
            string _unitReqNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReq);
            CurrentPage.As<UnitRequestPageActions>().ReopenApproveUnitRequest(_unitReqNo, UnitReq.ReqApprover);
            CurrentPage.As<UnitRequestPageActions>().RejectUnitRequest(_unitReqNo, UnitReq.ReqRejectReason);
            CommonUtil.AddPassedTestCase("QA579");
            Settings.Logger.Info("-----Execution completed for test ' QA579 Reopen & Reject Approved Replace Unit Request ' -------");
            CurrentPage.As<UnitRequestPageActions>().ReopenApproveUnitRequest(_unitReqNo, UnitReq.ReqApprover);
            Settings.Logger.Info("-----Execution completed for test ' QA585 Approve Rejected Replace Unit Request ' -------");
        }

        [Test, Description("M5-Reopen & Reject Approved Replace Unit Request")]
        public void QA579_ApproveRejectedReplaceUnitRequest()
        {
            CommonUtil.VerifyPassedTestCase("QA579");
        }

        [TestCase("UnitsTestData.json", "QA665_UpdateUnitPurchaseOrder",
            TestName = "QA665_UpdateUnitPurchaseOrder", Description = "M5-Update Unit Purchase Order")]
        public void QA665_UpdateUnitPurchaseOrder(object[] testParameter)
        {
            UnitPurchaseOrder upo = CommonUtil.DataObjectForKey("PurchaseOrder").ToObject<UnitPurchaseOrder>();
            UnitPurchaseOrder upoEdit = CommonUtil.DataObjectForKey("EditPurchaseOrder").ToObject<UnitPurchaseOrder>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitPurchaseOrdersPage();
            upoEdit.PONo = CurrentPage.As<UnitPurchaseOrdersPageActions>().CreateUnitPurchaseOrder(upo);
            CurrentPage.As<UnitPurchaseOrdersPageActions>().UpdateUnitPurchaseOrder(upoEdit);
            CurrentPage.As<UnitPurchaseOrdersPageActions>().VerifyUnitPurchaseOrder(upoEdit.PONo, upoEdit);
        }

        [TestCase("UnitsTestData.json", "QA673_UpdateUnitCreatedOnUnitPurchaseRequisition",
            TestName = "QA673_UpdateUnitCreatedOnUnitPurchaseRequisition",
            Description = "M5 - Unit - Update Unit created on Unit Purchase Requisition to Status Active")]
        public void QA673_UpdateUnitCreatedOnUnitPurchaseRequisition(object[] testParameter)
        {
            UnitMain UnitE = CommonUtil.DataObjectForKey("EditUnit").ToObject<UnitMain>();
            UnitPurchaseOrder upo = CommonUtil.DataObjectForKey("PurchaseOrder").ToObject<UnitPurchaseOrder>();
            UnitPurchaseRequisition upr = CommonUtil.DataObjectForKey("RequisitionDetails").ToObject<UnitPurchaseRequisition>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitPurchaseOrdersPage();
            upr.POListTab.POList[0].PONumber = CurrentPage.As<UnitPurchaseOrdersPageActions>().CreateUnitPurchaseOrder(upo);
            CurrentPage = _pageNavigate.NavigateToUnitPurchaseRequisitionsPage();
            UnitE.UnitNo = CurrentPage.As<UnitPurchaseRequisitionsPageActions>().CreateUnitPurchaseRequisition(upr);
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().UpdateUnitInfo(UnitE);
            CurrentPage.As<UnitMainPageActions>().VerifyUnitInformation(UnitE.UnitNo, UnitE);
        }
		
		[TestCase("UnitsTestData.json", "QA658_UpdateNewUnitRequest",
            TestName = "QA658_UpdateNewUnitRequest", Description = "M5-Update New Unit Request")]
        public void QA658_UpdateNewUnitRequest(object[] testParameter)
        {
            UnitRequest UnitReqC = CommonUtil.DataObjectForKey("UnitRequest").ToObject<UnitRequest>();
            UnitRequest UnitReqE = CommonUtil.DataObjectForKey("EditRequest").ToObject<UnitRequest>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            UnitReqE.RequestNo = CurrentPage.As<UnitRequestPageActions>().CreateNewUnitRequest(UnitReqC);
            CurrentPage.As<UnitRequestPageActions>().UpdateUnitRequest(UnitReqE);
            CurrentPage.As<UnitRequestPageActions>().VerifyUnitRequestInformation(UnitReqE.RequestNo, UnitReqE);
        }
    }
}