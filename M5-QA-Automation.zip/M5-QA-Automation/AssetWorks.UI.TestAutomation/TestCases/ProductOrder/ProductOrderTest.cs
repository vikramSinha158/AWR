﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.ProductLocationReceive;
using AssetWorks.UI.M5.TestAutomation.Actions.ProductOrder;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.ProductOrder
{
    [TestFixture]
    internal class ProductOrderTest : Hooks
    {
        [TestCase("ProductOrderTestData.json", "QA1273_CreateProductOrder",
        TestName = "QA1273_QA1275_QA_1276_CreateProductOrder", Description = "M5-Create Product Order"),Order(1)]
        public void QA1273_QA_1275_QA_1276_CreateProductOrder(object[] testParameter)
        {
            Settings.Logger.Info($"------------Started Executing QA1273_CreateProductOrder -------------------");
            ProductOrderObjects productOrderObjects = CommonUtil.DataObjectForKey("ProductOrder").ToObject<ProductOrderObjects>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToProductOrderPage();
            string ProductNumber=CurrentPage.As<ProductOrderActions>().CreateNewProductOrders(productOrderObjects);
            CurrentPage.As<ProductOrderActions>().VerifyCreatedProductOrder(productOrderObjects, ProductNumber);
            Settings.Logger.Info($"------------Ended Executing QA1273_CreateProductOrder -------------------");
            Settings.Logger.Info($"------------Started Executing QA_1275_CheckProductReceived -------------------");
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage=homepage.NavigateToProductReceivePage();
            CurrentPage.As<ProductLocationReceiveActions>().VerifyCheckProductReceived(productOrderObjects, ProductNumber);
            Settings.Logger.Info($"------------Ended Executing QA_1275_CheckProductReceived -------------------");
            CommonUtil.AddPassedTestCase("QA_1275");
            Settings.Logger.Info($"------------Started Executing QA1276_CheckProductReceivedWithToggleOn -------------------");
            CurrentPage.As<ProductLocationReceiveActions>().VerifyCheckProductRecievedWithToggleOn(productOrderObjects, ProductNumber);
            Settings.Logger.Info($"------------Ended Executing QA1276_CheckProductReceivedWithToggleOn -------------------");
            CommonUtil.AddPassedTestCase("QA_1276");
        }

        [Test, Description("M5-Check Product Received,Merged in QA1273_CreateProductOrder ")]
        public void QA_1275_CheckProductReceived()
        {
            CommonUtil.VerifyPassedTestCase("QA_1275");
        }

        [Test, Description("M5-CheckProductReceivedWithToggleOn,Merged in QA1273_CreateProductOrder ")]
        public void QA1276_CheckProductReceivedWithToggleOn()
        {
            CommonUtil.VerifyPassedTestCase("QA_1276");
        }

        [TestCase("ProductOrderTestData.json", "QA1273_CreateProductOrder",
       TestName = "QA1274_DeleteProductOrder", Description = "M5-Delete-Product Order")]
        public void QA1274_DeleteProductOrder(object[] testParameter)
        {
            ProductOrderObjects productOrderObjects = CommonUtil.DataObjectForKey("ProductOrder").ToObject<ProductOrderObjects>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToProductOrderPage();
            string ProductNumber = CurrentPage.As<ProductOrderActions>().CreateNewProductOrders(productOrderObjects);
            CurrentPage.As<ProductOrderActions>().DeleteProductOrder(productOrderObjects.ProductOrderDetail,ProductNumber);
            CurrentPage.As<ProductOrderActions>().verifyDeletedProductOrder(ProductNumber);
        }
    }
}
