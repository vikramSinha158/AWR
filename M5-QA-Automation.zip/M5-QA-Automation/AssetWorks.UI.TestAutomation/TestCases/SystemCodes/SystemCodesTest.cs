﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.PositionCodeObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.SystemCodes
{
    [TestFixture]
    internal class SystemCodesTest : Hooks
    {
        private HomePageActions _homePage => new HomePageActions(Driver);

        [TestCase("SystemCodesTestdata.json", "QA960_DirectAccountCodes", true, TestName = "QA960_DirectAccountCodes",
            Description = "M5-Perform create, disable, validate and delete operations on Direct Account Codes")]
        public void QA960_DirectAccountCodes(object[] testParameter)
        {
            DirectAccountInformation dca = CommonUtil.DataObjectForKey("DirectAccountInfo").ToObject<DirectAccountInformation>();
            DirectAccountInformation dcaD = CommonUtil.DataObjectForKey("DADisabled").ToObject<DirectAccountInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDirectAccountCodesPage();
            dcaD.DirectAccount = CurrentPage.As<DirectAccountCodesPageActions>().CreateNewDirectAccountCode(dca);
            CurrentPage.As<DirectAccountCodesPageActions>().VerifyDirectAccountCode(dca);
            CurrentPage.As<DirectAccountCodesPageActions>().UpdateDirectAccountCode(dcaD);
            CurrentPage.As<DirectAccountCodesPageActions>().VerifyDirectAccountCode(dcaD);
            CurrentPage.As<DirectAccountCodesPageActions>().DeleteDirectAccountCode(dcaD.DirectAccount);
        }
        
        [TestCase("SystemCodesTestdata.json", "QA958_AssetClassCodes", TestName = "QA958_AssetClassCodes",
            Description = "M5-Perform create, update, validate and delete operations on asset class codes")]
        public void QA958_AssetClassCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAssetClassCodesPage();
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCodeDescription("Create", "CreateACC");
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCodeDescription("Verify", "CreateACC");
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCodeDescription("Update", "UpdateACC");
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCodeDescription("Verify", "UpdateACC");
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCode("Disable", "DisableACC");
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCode("VerifyDisabled", "DisableACC");
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCode("Delete", "DeleteACC");
            CurrentPage.As<AssetClassCodesPageActions>().OperateMultipleAssetClassCode("VerifyDeleted", "DeleteACC");
        }

        [TestCase("SystemCodesTestdata.json", "QA964_SystemCodes", TestName = "QA964_SystemCodes",
            Description = "M5-Perform create, update, validate and delete operations on system codes")]
        public void QA964_SystemCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemCodesPage();
            string _code = CurrentPage.As<SystemCodesPageActions>().CreateNewSystemCode();
            CurrentPage.As<SystemCodesPageActions>().EditSystemCode(_code, "PartCharge");
            CurrentPage.As<SystemCodesPageActions>().EditSystemCode(_code, "LaborCharge");
            CurrentPage.As<SystemCodesPageActions>().EditSystemCode(_code, "CommCharge");
            CurrentPage.As<SystemCodesPageActions>().EditSystemCode(_code, "UnitAssoc");
            CurrentPage.As<SystemCodesPageActions>().EditSystemCode(_code, "Priority");
            CurrentPage.As<SystemCodesPageActions>().DisableSystemCode(_code);
            CurrentPage.As<SystemCodesPageActions>().DeleteSystemCode(_code);
        }    
            
        [TestCase("SystemCodesTestdata.json", "QA959_CountryStateCodes", TestName = "QA959_CountryStateCodes",
            Description = "M5-Perform create, update, validate and delete operations on state codes")]
        public void QA959_StateCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemStateCountryCodesPage();
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleCountryCodeDescription("Create", "CreateCC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleCountryCodeDescription("Verify", "CreateCC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleStateCodeDescription("Create", "CreateSC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleStateCodeDescription("Verify", "CreateSC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleCountryCodeDescription("Update", "UpdateCC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleCountryCodeDescription("Verify", "UpdateCC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleStateCodeDescription("Update", "UpdateSC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().OperateMultipleStateCodeDescription("Verify", "UpdateSC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().DeleteCountryStateCodes("DeleteCC", "DeleteSC");
            CurrentPage.As<SystemStateCountryCodesPageActions>().VerifyDeletedCountryCode("DeleteCC");
        }

        [TestCase("PositionCodesTestdata.json", "PositionCodes", TestName = "QA966_PositionCodes",
            Description = "M5-Position Codes")]
        public void QA966_PositionCodes(object[] testParameter)
        {
            string Desc = string.Empty;
            string DataKey = "QA966_PositionCodesData";
            PositionCodesData posCodeObjectValues = CommonUtil.DataObjectForKey(DataKey).ToObject<PositionCodesData>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPositionCodePage();
            string Poscode=CurrentPage.As<PositionCodesPageActions>().CreatePositionCode(DataKey, ref Desc);
            CurrentPage.As<PositionCodesPageActions>().VerifyPositionCodeData(Poscode, Desc);            
            CurrentPage.As<PositionCodesPageActions>().UpdateAndVerifyPositionCodeData( Poscode,Desc);
            CurrentPage.As<PositionCodesPageActions>().DeletePositionCode(Poscode);
            CurrentPage.As<PositionCodesPageActions>().VerifyDeletedPositionCode(Poscode);
            //Creating Postion Code and Associating it with System Position, then trying fot Deletion Verifying Error Message
            Poscode = CurrentPage.As<PositionCodesPageActions>().CreatePositionCode(DataKey, ref Desc);
            CurrentPage = _homePage.NavigateToSystemPositionPage();
            CurrentPage.As<SystemPositionPageActions>().AddValidPositionCode(posCodeObjectValues.CreatePositionCodeWithAssociatesSystemPosition.SystemCode, Poscode);
            CurrentPage = _homePage.NavigateToPositionCodePage();
            CurrentPage.As<PositionCodesPageActions>().DeletePositionCode(Poscode);
            CurrentPage.As<PositionCodesPageActions>().VerifyErrorMessage(posCodeObjectValues.CreatePositionCodeWithAssociatesSystemPosition.ExpectedError);
            //DataCleanUp
            CurrentPage = _homePage.NavigateToSystemPositionPage();
            CurrentPage.As<SystemPositionPageActions>().RemovedPositionCode(posCodeObjectValues.CreatePositionCodeWithAssociatesSystemPosition.SystemCode, Poscode);
            CurrentPage = _homePage.NavigateToPositionCodePage();
            CurrentPage.As<PositionCodesPageActions>().DeletePositionCode(Poscode);           
        }

        [TestCase("ResourceTypeTestdata.json", "ResourceType", TestName = "QA1223_CreateDeleteResourceType",
         Description = "M5- Create and Delete Shop Planning Resource Type")]
        public void QA1223_CreateDeleteResourceType(object[] testParameter)
        {
            ResourceType resourceTypeObject = CommonUtil.DataObjectForKey("QA1223_AddResourceType").ToObject<ResourceType>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToResourceTypePage();
            string Resource = CurrentPage.As<ResourceTypePageActions>().AddResourceType(resourceTypeObject);
            CurrentPage.As<ResourceTypePageActions>().VerifyResourceType(resourceTypeObject);           
            CurrentPage.As<ResourceTypePageActions>().DeleteResourceType(Resource);
            CurrentPage.As<ResourceTypePageActions>().VerifyDeletedTrainingCourse(Resource);            
        }

        [TestCase("SystemCodesTestdata.json", "QA1324_IndirectAccountCodes", true, TestName = "QA1324_IndirectAccountCodes",
            Description = "M5-Perform create, disable, validate and delete operations on Indirect Account Codes")]
        public void QA1324_IndirectAccountCodes(object[] testParameter)
        {
            IndirectAccountInfo accInfo = CommonUtil.DataObjectForKey("IndirectAccountInfo").ToObject<IndirectAccountInfo>();
            IndirectAccountInfo accInfoD = CommonUtil.DataObjectForKey("IdADisabled").ToObject<IndirectAccountInfo>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToIndirectAccountCodesPage();
            accInfoD.AccountNo = CurrentPage.As<IndirectAccountCodesPageActions>().CreateIndirectAccountCode(accInfo);
            CurrentPage.As<IndirectAccountCodesPageActions>().UpdateIndirectAccountCode(accInfoD);
            CurrentPage.As<IndirectAccountCodesPageActions>().VerifyIndirectAccountCode(accInfoD);
            CurrentPage.As<IndirectAccountCodesPageActions>().DeleteIndirectAccountCode(accInfoD.AccountNo);
        }
    }
}
