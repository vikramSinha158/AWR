﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;


namespace AssetWorks.UI.M5.TestAutomation.TestCases.Location
{
    [TestFixture]
    internal class LocationMainTest : Hooks
    {     

        [TestCase("LocationMainTestData.json", "LocationMain", Description = "M5 - Create,Delete Location Main "),Order(1)]
        public void QA1220_QA1221_Create_Delete_LocationMain(object[] testParameter)
        {
            LocationMain LocObject = CommonUtil.DataObjectForKey("QA1220_CreateLocation").ToObject<LocationMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToLocationMain();
            LocObject.Location = CurrentPage.As<LocationMainPageActions>().CreateLocation(LocObject);
            CurrentPage.As<LocationMainPageActions>().VerifyLocationMain(LocObject);
            Settings.Logger.Info(" QA1220 - Create Location Main Completed Successfully");
            CurrentPage.As<LocationMainPageActions>().DeleteLocationMain(LocObject.Location);
            CurrentPage.As<LocationMainPageActions>().VerifyLocationDeletion(LocObject.Location);
            CommonUtil.AddPassedTestCase("QA1221");
            Settings.Logger.Info(" QA1221 - Delete Location Main Completed Successfully");
        }

        [Test, Description("M5-Delete Location - Merged with QA1220_QA1221_Create_Delete_LocationMain")]
        public void QA1221_DeleteLocation()
        {
            CommonUtil.VerifyPassedTestCase("QA1221");
        }
    }
}
