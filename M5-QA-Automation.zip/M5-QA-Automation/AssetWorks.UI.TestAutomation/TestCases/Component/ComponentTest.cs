﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Component
{
    [TestFixture]
    internal class ComponentTest : Hooks
    {
        internal HomePageActions _homePage => new HomePageActions(Driver);

        [TestCase("ComponentTestData.json", "Component",
           Description = "M5-Verifying Add And Delete Component"), Order(1)]
        public void QA803_QA806_QA805_AddEditAndDeleteComponent(object[] testParameter)
        {
            ComponentMain? ComponentEditData= CommonUtil.DataObjectForKey("EditComponentData").ToObject<ComponentMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateComponentMainPage();
            Settings.ComponentNumber = CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentMain");
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentFields("ComponentMain",Settings.ComponentNumber);
            Settings.Logger.Info("------------Finishing executing test ' QA803 Create Component' -------------------");
            CurrentPage.As<ComponentMainPageActions>().FillOtherComponentFields(ComponentEditData);
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentFields("EditComponentData", Settings.ComponentNumber);
            CommonUtil.AddPassedTestCase("QA805");
            Settings.Logger.Info("------------Finishing executing test ' QA805 Edit Component' -------------------");
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentDeletion(Settings.ComponentNumber);
            CommonUtil.AddPassedTestCase("QA806");
            Settings.Logger.Info("------------Finishing executing test ' QA806 Delete Component' -------------------");
        }

        [Test, Description("M5-Verifying Delete Component")]
        public void QA806_DeleteComponent()
        {
            CommonUtil.VerifyPassedTestCase("QA806");
        }

        [Test, Description("M5-Verifying Edit Component")]
        public void QA805_EditComponent()
        {
            CommonUtil.VerifyPassedTestCase("QA805");
        }

        [TestCase("ComponentTestData.json", "Component",
        Description = "M5-Verifying Add And ComponentI tems To Existing Componentt"), Order(1)]
        public void QA811_QA813_QA814_AddingEditingAndDeleteComponentItemsToExistingComponent(object[] testParameter)
        {
            ComponentItem ComponentItems = CommonUtil.DataObjectForKey("EditComponentItem").ToObject<ComponentItem>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateComponentMainPage();
            string componentNo = CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentData");
            CurrentPage = _homePage.NavigateToComponentItemsPage();
            CurrentPage.As<ComponentItemsPageActions>().AddComponentItem("ComponentItem", componentNo);
            CurrentPage.As<ComponentItemsPageActions>().VerifyComponentItem("ComponentItem", componentNo);
            Settings.Logger.Info("------------Finishing executing test '  QA811 Adding Component Items' -------------------");
            CurrentPage.As<ComponentItemsPageActions>().FillItemInformation(ComponentItems);
            CurrentPage.As<ComponentItemsPageActions>().VerifyComponentItem("EditComponentItem", componentNo);
            CommonUtil.AddPassedTestCase("QA813");
            Settings.Logger.Info("------------Finishing executing test '  QA813 Editing Component Items' -------------------");
            CurrentPage.As<ComponentItemsPageActions>().VerifyComponentItemDeletion("ComponentItem", componentNo);
            CommonUtil.AddPassedTestCase("QA814");
            Settings.Logger.Info("------------Finishing executing test '  QA-814 Delete Component Items' -------------------");
        }

        [Test, Description("M5-Verifying Edit ComponentItem")]
        public void QA813_EditComponentItem()
        {
            CommonUtil.VerifyPassedTestCase("QA813");
        }

        [Test, Description("M5-Verifying delete ComponentItem")]
        public void QA814_DeleteComponentItem()
        {
            CommonUtil.VerifyPassedTestCase("QA814");
        }

        [TestCase("ComponentTestData.json", "QA1007_ItemMasterDefinition",
        Description = "M5-Item Master definition")]
        public void QA1007_ItemMasterDefinition(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToItemMasterDefinitionPage();
            List<Item> items = CommonUtil.DataObjectForKey("Items").ToObject<List<Item>>();
            Item updatedItem = CommonUtil.DataObjectForKey("UpdatedDetails").ToObject<Item>();
            foreach (Item item in items)
            {
                CurrentPage.As<ItemMasterDefinitionPageActions>().AddItemMasterDefinition(item);
                if (item.EditRequired)
                {
                    updatedItem.ItemNo = item.ItemNo;
                    updatedItem.Target = item.Target;
                    CurrentPage.As<ItemMasterDefinitionPageActions>().UpdateItemInformation(updatedItem);
                    CurrentPage.As<ItemMasterDefinitionPageActions>().VerifyItemInformation(updatedItem);
                }
                CurrentPage.As<ItemMasterDefinitionPageActions>().DeleteItemDefinition(item.Target, item.ItemNo);
            }
        }

        [TestCase("ComponentTestData.json", "Component",Description = "M5-Verifying Copy Component")]
        public void QA808_CopyComponent(object[] testParameter)
        {
            ComponentMain? ComponentEditData = CommonUtil.DataObjectForKey("EditComponentData").ToObject<ComponentMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateComponentMainPage();
            string ComponentNumber = CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentData");
            CurrentPage = _pageNavigate.NavigateToComponentCopy();
            string NewComponentNumber = CurrentPage.As<ComponentCopyActions>().CopyExistingComponent(ComponentNumber, "1");
            CurrentPage = _pageNavigate.NavigateComponentMainPage();
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentFields("ComponentData", NewComponentNumber);
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentDeletion(NewComponentNumber);
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentDeletion(ComponentNumber);
        }

        [TestCase("ComponentTestData.json", "Component", Description = "M5-Verifying Component Number Change")]
        public void QA810_ComponentNumberChange(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateComponentMainPage();
            string ComponentNumber = CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentData");
            CurrentPage = _pageNavigate.NavigateToComponentNumberChange();
            string ChangeComponentNumber = CurrentPage.As<ComponentNumberChangePageActions>().ChangeComponentNumber(ComponentNumber);
            CurrentPage = _pageNavigate.NavigateComponentMainPage();
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentFields("ComponentData", ChangeComponentNumber);
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentDeletion(ChangeComponentNumber);
        }
    }
}
