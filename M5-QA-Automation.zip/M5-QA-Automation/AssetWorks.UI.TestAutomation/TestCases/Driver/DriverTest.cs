﻿using AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.M5.TestAutomation.Actions.Driver;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Driver
{
    [TestFixture]
    internal class DriverTest :Hooks
    {
        [TestCase("DriverTestData.json", "Driver", TestName = "QA1288_QA1290_CreateUpdateDeleteStatusCodes",
         Description = "M5-Driver-CreateStatusCodes"),Order(1)]
        public void QA1288_CreateStatusCodes(object[] testParameter)
        {
            StatusCodeType createStatuscode = CommonUtil.DataObjectForKey("QA1288_CreateStatusCode").ToObject<StatusCodeType>();
            StatusCodeType updateStatuscode = CommonUtil.DataObjectForKey("QA1290_UpdateStatusCode").ToObject<StatusCodeType>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverStatusCodeScreen();
            createStatuscode.Code = CurrentPage.As<DriverStatusCodePageActions>().CreateStatusCode(createStatuscode);
            CurrentPage.As<DriverStatusCodePageActions>().VerifyStatusCode(createStatuscode);
            updateStatuscode.Code = createStatuscode.Code;

            CurrentPage.As<DriverStatusCodePageActions>().UpdateStatusCode(updateStatuscode);
            CurrentPage.As<DriverStatusCodePageActions>().VerifyStatusCode(updateStatuscode);
            CurrentPage.As<DriverStatusCodePageActions>().VerifyDeleteStatusCode(createStatuscode);
            CommonUtil.AddPassedTestCase("QA1290");
            Settings.Logger.Info("QA1290 Updated and Deleted Driver Status code successfully");
        }

        [TestCase(TestName = "QA1290_UpdateDeleteStatusCodes",
        Description = "M5-Driver-CreateStatusCodes, Merged With QA1288_CreateStatusCodes")]
        public void QA1290_UpdateDeleteStatusCodes()
        {
            CommonUtil.VerifyPassedTestCase("QA1290");
        }

        [TestCase("DriverTestData.json", "Driver", TestName = "QA1311_1292_CreateUpdateDeleteDriverAllocationReasons",
        Description = "M5-Driver-CreateUpdateDeleteDriverAllocationReasons"),Order(1)]
        public void QA1311_CreateDriverAllocationReasons(object[] testParameter)
        {
            AllocationReasonsType createAllocation = CommonUtil.DataObjectForKey("QA1311_CreateAllocationReasons").ToObject<AllocationReasonsType>();
            AllocationReasonsType updateAllocation = CommonUtil.DataObjectForKey("QA1292_UpdateAllocationReasons").ToObject<AllocationReasonsType>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverAllocationReasonsScreen();
            createAllocation.Code = CurrentPage.As<DriverAllocationReasonsPageActions>().CreateDriverAllocationReasonCode(createAllocation);
            CurrentPage.As<DriverAllocationReasonsPageActions>().VerifyDriverAllocationReasonCode(createAllocation);
            updateAllocation.Code = createAllocation.Code;
           
            CurrentPage.As<DriverAllocationReasonsPageActions>().UpdateAllocationReasonCode(updateAllocation);
            CurrentPage.As<DriverAllocationReasonsPageActions>().VerifyDriverAllocationReasonCode(updateAllocation);
            CurrentPage.As<DriverAllocationReasonsPageActions>().VerifyDeletedAllocationReasonCode(createAllocation);
            CommonUtil.AddPassedTestCase("QA1292");
            Settings.Logger.Info("QA1292 Updated and Deleted Driver Allocation reasons code successfully");
        }

        [TestCase(TestName = "QA1292_UpdateDeleteAllocationReasons",
        Description = "M5-Driver-UpdateDeleteAllocationReasons, Merged With QA1311_CreateDriverAllocationReasons")]
        public void QA1292_UpdateDeleteAllocationReasons()
        {
            CommonUtil.VerifyPassedTestCase("QA1292");
        }

        [TestCase("DriverTestData.json", "Driver", TestName = "QA1303_QA1304_CreateUpdateDeleteDriverTypes",
        Description = "M5-Driver-CreateDriverType"), Order(1)]
        public void QA1303_CreateDriverTypes(object[] testParameter)
        {
            DriverTypesCode createType = CommonUtil.DataObjectForKey("QA1303_CreateDriverTypes").ToObject<DriverTypesCode>();
            DriverTypesCode updateType = CommonUtil.DataObjectForKey("QA1304_UpdateDriverTypes").ToObject<DriverTypesCode>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverTypesScreen();
            createType.Code = CurrentPage.As<DriverTypesPageActions>().CreateDriverType(createType);
            CurrentPage.As<DriverTypesPageActions>().VerifyDriverType(createType);
            updateType.Code = createType.Code;
            CurrentPage.As<DriverTypesPageActions>().UpdateDriverType(updateType);
            CurrentPage.As<DriverTypesPageActions>().VerifyDriverType(updateType);
            CurrentPage.As<DriverTypesPageActions>().VerifyDeletedDriverType(createType);
            CommonUtil.AddPassedTestCase("QA1304");
            Settings.Logger.Info("QA1304 Updated and Deleted Driver type successfully");
        }

        [TestCase(TestName = "QA1304_UpdateDeleteDriverType",
        Description = "M5-Driver-UpdateDeleteDriverType, Merged With QA1303_CreateDriverTypes")]
        public void QA1304_UpdateDeleteDriverType()
        {
            CommonUtil.VerifyPassedTestCase("QA1304");
        }

        [TestCase("DriverTestData.json", "Driver", TestName = "QA1305_QA1306_CreateUpdateDeleteDriverEventClass",
        Description = "M5-Driver-CreateDriverEventClass"), Order(1)]
        public void QA1305_CreateDriverEventClass(object[] testParameter)
        {
            DriverEventClass createEvent = CommonUtil.DataObjectForKey("QA1305_CreateDriverEventClass").ToObject<DriverEventClass>();
            DriverEventClass updateEvent = CommonUtil.DataObjectForKey("QA1306_UpdateDriverEventClass").ToObject<DriverEventClass>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverEventClasses();
            CurrentPage.As<DriverEventClassesPageActions>().CreateDriverEventClass(createEvent);
            CurrentPage.As<DriverEventClassesPageActions>().VerifyDriverEventClass(createEvent);
            updateEvent.Class = createEvent.Class;

            CurrentPage.As<DriverEventClassesPageActions>().UpdateDriverEventClass(updateEvent);
            CurrentPage.As<DriverEventClassesPageActions>().VerifyDriverEventClass(updateEvent);
            CurrentPage.As<DriverEventClassesPageActions>().VerifyDeletedDriverEventClass(createEvent);
            CommonUtil.AddPassedTestCase("QA1306");
            Settings.Logger.Info("QA1306 Updated and Deleted Driver Event Class successfully");
        }

        [TestCase(TestName = "QA1306_UpdateDeleteDriverEventClass",
        Description = "M5-Driver-UpdateDeleteDriverType, Merged With QA1305_CreateDriverEventClass")]
        public void QA1306_UpdateDeleteDriverEventClass()
        {
            CommonUtil.VerifyPassedTestCase("QA1306");
        }

        [TestCase("DriverTestData.json", "Driver", TestName = "QA1307_QA1308_CreateUpdateDeleteDriverEventType",
        Description = "M5-Driver-CreateDriverEventType"), Order(1)]
        public void QA1307_CreateDriverEventType(object[] testParameter)
        {
            DriverEventClass createEvent = CommonUtil.DataObjectForKey("QA1305_CreateDriverEventClass").ToObject<DriverEventClass>();
            DriverEventTypes createType = CommonUtil.DataObjectForKey("QA1307_CreateEventType").ToObject<DriverEventTypes>();
            DriverEventTypes updateType = CommonUtil.DataObjectForKey("QA1308_UpdateEventType").ToObject<DriverEventTypes>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverEventClasses();
            CurrentPage.As<DriverEventClassesPageActions>().CreateDriverEventClass(createEvent);
            createType.Class = createEvent.Class;
            updateType.Code = createType.Code;
            CurrentPage = _pageNavigate.NavigateToDriverEventTypes();
            CurrentPage.As<DriverEventTypesPageActions>().CreateDriverEventType(createType);
            CurrentPage.As<DriverEventTypesPageActions>().VerifyDriverEventType(createType);
            CurrentPage.As<DriverEventTypesPageActions>().UpdateDriverEventType(updateType);
            CurrentPage.As<DriverEventTypesPageActions>().VerifyDriverEventType(updateType);
            CurrentPage.As<DriverEventTypesPageActions>().VerifyDeleteDriverEventType(createType);
            CommonUtil.AddPassedTestCase("QA1308");
            Settings.Logger.Info("QA1308 Updated and Deleted Driver Event Type successfully");
            CurrentPage = _pageNavigate.NavigateToDriverEventClasses();
            CurrentPage.As<DriverEventClassesPageActions>().VerifyDeletedDriverEventClass(createEvent);
        }

        [TestCase(TestName = "QA1308_UpdateDeleteDriverEventType",
        Description = "M5-Driver-UpdateDeleteDriverEventType, Merged With QA1307_CreateDriverEventType")]
        public void QA1308_UpdateDeleteDriverEventType()
        {
            CommonUtil.VerifyPassedTestCase("QA1308");
        }

        [TestCase("DriverTestData.json", "Driver", TestName = "QA1312_QA1313_CreateUpdateDeleteDriverEventItem",
       Description = "M5-Driver-CreateDriverEventItem"), Order(1)]
        public void QA1312_CreateDriverEventItem(object[] testParameter)
        {
            DriverEventClass createEvent = CommonUtil.DataObjectForKey("QA1305_CreateDriverEventClass").ToObject<DriverEventClass>();
            DriverEventTypes createType = CommonUtil.DataObjectForKey("QA1307_CreateEventType").ToObject<DriverEventTypes>();
            DriverEventItem createItem = CommonUtil.DataObjectForKey("QA1312_CreateDriverEventItem").ToObject<DriverEventItem>();
            DriverEventItem updateItem = CommonUtil.DataObjectForKey("QA1313_UpdateDriverEventItem").ToObject<DriverEventItem>();
            updateItem.Class = createItem.Class = createType.Class = createEvent.Class;
            updateItem.Type = createItem.Type = createType.Code;
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverEventClasses();
            CurrentPage.As<DriverEventClassesPageActions>().CreateDriverEventClass(createEvent);
            CurrentPage = _pageNavigate.NavigateToDriverEventTypes();
            CurrentPage.As<DriverEventTypesPageActions>().CreateDriverEventType(createType);
            CurrentPage = _pageNavigate.NavigateToDriverEventItem();
            CurrentPage.As<DriverEventItemPageActions>().CreateDriverEventItem(createItem);
            CurrentPage.As<DriverEventItemPageActions>().VerifyDriverEventItem(createItem);
            CurrentPage.As<DriverEventItemPageActions>().UpdateDriverEventItem(updateItem);
            CurrentPage.As<DriverEventItemPageActions>().VerifyDriverEventItem(updateItem);
            CurrentPage.As<DriverEventItemPageActions>().VerifyDeleteDriverEventItem(createItem);
            CommonUtil.AddPassedTestCase("QA1313");
            Settings.Logger.Info("QA1313 Updated and Deleted Driver Event Item successfully");
            CurrentPage = _pageNavigate.NavigateToDriverEventTypes();
            CurrentPage.As<DriverEventTypesPageActions>().VerifyDeleteDriverEventType(createType);
            CurrentPage = _pageNavigate.NavigateToDriverEventClasses();
            CurrentPage.As<DriverEventClassesPageActions>().VerifyDeletedDriverEventClass(createEvent);
        }

        [TestCase(TestName = "QA1313_UpdateDeleteDriverEventItem",
        Description = "M5-Driver-UpdateDeleteDriverEventItem, Merged With QA1312_CreateDriverEventItem")]
        public void QA1313_UpdateDeleteDriverEventItem()
        {
            CommonUtil.VerifyPassedTestCase("QA1313");
        }

        [TestCase("DriverTestData.json", "Driver", TestName = "QA1314_QA1315_CreateUpdateDeleteDriverLicenceClasses",
        Description = "M5-Driver-CreateDriverLicenceClasses"), Order(1)]
        public void QA1314_CreateDriverLicenceClasses(object[] testParameter)
        {
            DriverLicenseClasses createLicenceClass = CommonUtil.DataObjectForKey("QA1314_CreateDriverLicenseClasses").ToObject<DriverLicenseClasses>();
            DriverLicenseClasses updateLicenceClass = CommonUtil.DataObjectForKey("QA1315_UpdateDriverLicenseClasses").ToObject<DriverLicenseClasses>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverLicenseClasses();
            updateLicenceClass.Issuing_Authority = createLicenceClass.Issuing_Authority;
            updateLicenceClass.LicenceType = createLicenceClass.LicenceType;
            updateLicenceClass.Code = createLicenceClass.Code;
            CurrentPage.As<DriverLicenceClassesPageActions>().CreateDriverLicenceClasses(createLicenceClass);
            CurrentPage.As<DriverLicenceClassesPageActions>().VerifyDriverLicenceClasses(createLicenceClass);
            CurrentPage.As<DriverLicenceClassesPageActions>().UpdateDriverLicenceClasses(updateLicenceClass);
            CurrentPage.As<DriverLicenceClassesPageActions>().VerifyDriverLicenceClasses(updateLicenceClass);
            CurrentPage.As<DriverLicenceClassesPageActions>().VerifyDeleteDriverLicenceClasses(createLicenceClass);
            CommonUtil.AddPassedTestCase("QA1315");
            Settings.Logger.Info("QA1315 Updated and Deleted Driver Licence Classes successfully");
        }

        [TestCase(TestName = "QA1315_UpdateDeleteDriverLicenceClasses",
        Description = "M5-Driver-UpdateDeleteDriverLicenceClasses, Merged With QA1314_CreateDriverLicenceClasses")]
        public void QA1315_UpdateDeleteDriverLicenceClasses()
        {
            CommonUtil.VerifyPassedTestCase("QA1315");
        }

        [TestCase("DriverTestData.json", "Driver", TestName = "QA1293_QA1294_QA1327_CreateDriverMainWithGeneralTab_LicenseTab_MotorPoolTab",
        Description = "M5-Driver-CreateDriverMainWithGeneralTab"), Order(1)]
        public void QA1293_CreateDriverMainWithGeneralTab(object[] testParameter)
        {
            DriverMain createGeneralTab = CommonUtil.DataObjectForKey("QA1293_CreateDriverMainWithGeneralTab").ToObject<DriverMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverMainScreen();
            CurrentPage.As<DriverMainPageActions>().CreateDriverMain(createGeneralTab);
            CurrentPage.As<DriverMainPageActions>().VerifyDriverMain(createGeneralTab);
            CurrentPage.As<DriverMainPageActions>().VerifyDeleteDriverMain(createGeneralTab);
            CommonUtil.AddPassedTestCase("QA1294");
            Settings.Logger.Info("QA1294 Create Driver Main With LicenseTab successfully");
            CommonUtil.AddPassedTestCase("QA1327");
            Settings.Logger.Info("QA1327 Create Driver Main With Motor Pool Tab successfully");
        }

        [TestCase(TestName = "QA1294_CreateDriverMainWithLicenseTab",
        Description = "M5-Driver-CreateDriverMainWithLicenseTab, Merged with QA1293_CreateDriverMainWithGeneralTab")]
        public void QA1294_CreateDriverMainWithLicenseTab()
        {
            CommonUtil.VerifyPassedTestCase("QA1294");
        }

        [TestCase(TestName = "QA1327_CreateDriverMainWithMotorPoolTab",
       Description = "M5-Driver-CreateDriverMainWithLicenseTab, Merged with QA1293_CreateDriverMainWithGeneralTab")]
        public void QA1327_CreateDriverMainWithMotorPoolTab()
        {
            CommonUtil.VerifyPassedTestCase("QA1327");
        }
    }
}
