﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;
using AssetWorks.UI.M5.TestAutomation.Actions.MotorPool;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.MotorPool
{
    [TestFixture]
    internal class MotorPoolRentalClassTest : Hooks
    {
        [TestCase(TestName = "QA976_MotorPoolRentalClass", Description = "M5 - Motor Pool Rental Class")]
        public void QA976_MotorPoolRentalClass()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMotorPoolRentalClassPage();
            string _mprClass = CurrentPage.As<MotorPoolRentalClassPageActions>().CreateNewMotorPoolRentalClass();
            CurrentPage.As<MotorPoolRentalClassPageActions>().VerifyTableUpdatedWithClass(_mprClass, "description", MotorPoolRentalClassPage._mprDesc);
            CurrentPage.As<MotorPoolRentalClassPageActions>().UpdateMotorPoolRentalClass(_mprClass, "description", "Updated description");
            CurrentPage.As<MotorPoolRentalClassPageActions>().VerifyTableUpdatedWithClass(_mprClass, "description", "Updated description");
            CurrentPage.As<MotorPoolRentalClassPageActions>().UpdateMotorPoolRentalClass(_mprClass, "prep_duration", "0");
            CurrentPage.As<MotorPoolRentalClassPageActions>().VerifyTableUpdatedWithClass(_mprClass, "prep_duration", "0");
            CurrentPage.As<MotorPoolRentalClassPageActions>().DeleteMotorPoolRentalClass(_mprClass);
        }

        [TestCase("MotorPoolTestData.json", "QA1281_CreateMPManagerTicket", TestName = "QA1281_QA1289_CreateUpdateMotorPoolManagerTicket",
            Description = "M5-Motor Pool-Create & Update Motor Pool Manager Ticket"), Order(1)]
        public void QA1281_QA1289_CreateUpdateMotorPoolManagerTicket(object[] testParameter)
        {
            UnitMain UnitC = CommonUtil.DataObjectForKey("UnitDetail").ToObject<UnitMain>();
            UnitMain UnitE = CommonUtil.DataObjectForKey("UnitUpdate").ToObject<UnitMain>();
            ManagerTicket ticket = CommonUtil.DataObjectForKey("ManagerTicket").ToObject<ManagerTicket>();
            ManagerTicket ticketU = CommonUtil.DataObjectForKey("UpdateTicket").ToObject<ManagerTicket>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            ticket.reservationTab.EquipUnitNo = UnitE.UnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(UnitC);
            CurrentPage.As<UnitMainPageActions>().UpdateUnitInfo(UnitE);
            CurrentPage = _pageNavigate.NavigateToMotorPoolManager();
            ticketU.TicketNo = ticket.TicketNo = CurrentPage.As<MotorPoolManagerPageActions>().CreateMotorPoolManagerTicket(ticket);
            CurrentPage.As<MotorPoolManagerPageActions>().VerifyMotorPoolManagerTicket(ticket);
            CommonUtil.AddPassedTestCase("QA1281");
            Settings.Logger.Info("------------Finishing executing test ' QA-1281 Create Motor Pool Manager Ticket' -------------------");
            CurrentPage.As<MotorPoolManagerPageActions>().UpdateMotorPoolManagerTicket(ticketU);
            CurrentPage.As<MotorPoolManagerPageActions>().VerifyMotorPoolManagerTicket(ticketU);
            Settings.Logger.Info("------------Finishing executing test ' QA-1289 Update Motor Pool Manager Ticket' -------------------");
        }

        [Test, Description("M5-Motor Pool-Create Motor Pool Manager Ticket")]
        public void QA1281_CreateMotorPoolManagerTicket()
        {
            CommonUtil.VerifyPassedTestCase("QA1281");
        }
    }
}
