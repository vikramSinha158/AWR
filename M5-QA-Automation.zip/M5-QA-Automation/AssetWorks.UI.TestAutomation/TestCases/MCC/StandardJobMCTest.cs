﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.MCC
{
    internal class StandardJobMCTest : Hooks
    {
        private HomePageActions _homePage => new HomePageActions(Driver);

        [TestCase("StandardJobMCCTestData.json", "QA517_StandardJobMCC", 
            Description = "M5-Verifying Create and Edit Standard Job MCC")]
        public void QA517_CreateAndEditStandardJobMCC(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMCCMainPage();
            StandardJobMCCObjects.StandardMCCCode = CurrentPage.As<MCCMainPageActions>().CreateMCCCode(MCCMainObjects.AddDataForMCCMian);
            CurrentPage = _homePage.NavigateToStandardJobMCCPage();
            CurrentPage.As<StandardJobMCCActions>().CreateStandardJobsMCC(StandardJobMCCObjects.StandardMCCJobCodeKey, StandardJobMCCObjects.StandardMCCCode);
            CurrentPage.As<StandardJobMCCActions>().VerifyStandardJobMCCInfo();
            CurrentPage.As<StandardJobMCCActions>().EditAndVerifyStandardJobMCCInfo(StandardJobMCCObjects.EditDataForStandardMCCJobCode);
        }
    }
}
