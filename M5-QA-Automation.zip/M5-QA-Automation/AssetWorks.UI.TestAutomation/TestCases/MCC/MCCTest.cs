﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.MCC
{
    [TestFixture]
    internal class MCCTest : Hooks
    {
        private HomePageActions _homePage => new HomePageActions(Driver);
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("MCCMainTestData.json", "QA350_CreateMCCMain",true, 
            Description = "M5-Verifying Add ,Edit,Disable and Delete MCCMain")]
        public void QA350_AddEditDisableAndDeleteMCCMain(object[] testParameter)
        {
            string DataMCC = CommonUtil.DataObjectForKey(MCCMainObjects.DataMCCode);
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMCCMainPage();
            MCCMainObjects.MCCCode =CurrentPage.As<MCCMainPageActions>().CreateMCCCode(MCCMainObjects.AddDataForMCCMian);
            CurrentPage.As<MCCMainPageActions>().VerifyMCCMainInfo(MCCMainObjects.AddDataForMCCMian, MCCMainObjects.MCCCode);
            CurrentPage.As<MCCMainPageActions>().EditAndVerifyMCCMain(MCCMainObjects.EditDataForMCCMian);
            CurrentPage.As<MCCMainPageActions>().VerifyMCCDisable("Yes");
            CurrentPage.As<MCCMainPageActions>().VerifyMCCMainDeletion(MCCMainObjects.MCCCode);
        }

        [TestCase("MCCMainTestData.json", "QA973_DeleteAssociatedMCC",
           Description = "M5-Verifying Add ,Delete AssociatedMCC")]
        public void QA973_DeleteAssociatedMCC(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            DepartmentMain department = CommonUtil.DataObjectForKey("DeptDetails").ToObject<DepartmentMain>();
            string _unitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            Settings.Logger.Info($" Created Unit { _unitNo} ");
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _homePage.NavigateToDepartmentMainPage();
            string _deptNumber = CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment(department);
            Settings.Logger.Info($" Created Department { _deptNumber} ");
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _homePage.NavigateComponentMainPage();
            string ComponentNumber = CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentMain");
            Settings.Logger.Info($" Created Component { ComponentNumber} ");
            CurrentPage = _homePage.NavigateToMCCMainPage();
            string MCC4 = CurrentPage.As<MCCMainPageActions>().CreateMCCCode("MCCMian");
            Settings.Logger.Info($" Created MCCMian { MCC4} ");
            CurrentPage = _homePage.NavigateToMCCMainPage();
            CurrentPage.As<MCCMainPageActions>().VerifyAssociatedMCCNotDeleted(Unit.AssetCodesTab.MCC);
            Settings.Logger.Info($" Successfully Verified Asoocited MCC { Unit.AssetCodesTab.MCC } with Unit not deleted ");
            string DeptNo = department.GeneralTab.DeptMCC;
            CurrentPage.As<MCCMainPageActions>().VerifyAssociatedMCCNotDeleted(DeptNo);
            Settings.Logger.Info($" Successfully Verified Asoocited MCC { DeptNo } with Department not deleted ");
            ComponentMain Comp = CommonUtil.DataObjectForKey("ComponentMain").ToObject<ComponentMain>();
            CurrentPage.As<MCCMainPageActions>().VerifyAssociatedMCCNotDeleted(Comp.MCC);
            Settings.Logger.Info($" Successfully Verified Asoocited MCC { Comp.MCC } with Component not deleted ");
            CurrentPage.As<MCCMainPageActions>().MCCMainDeletion(MCC4);
            Settings.Logger.Info($" Successfully Verified Not Asoocited MCC { MCC4 } deleted Successfully");
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _homePage.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(_unitNo);
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _homePage.NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentDeletion(_deptNumber);
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _homePage.NavigateComponentMainPage();
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentDeletion(ComponentNumber);
        }

        [TestCase("MCCMainTestData.json", "QA350_CreateMCCMain",Description = "M5-Verifying MCC  Copy")]
        public void QA351_MCCCopy(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMCCMainPage();
            MCCMainObjects.MCCCode = CurrentPage.As<MCCMainPageActions>().CreateMCCCode(MCCMainObjects.AddDataForMCCMian);
            CurrentPage = _pageNavigate.NavigateToMCCCopy();
            string NewMCCCOde=CurrentPage.As<MCCCopyPageActions>().CopyExistingMCCCopy(MCCMainObjects.MCCCode);
            CurrentPage = _pageNavigate.NavigateToMCCMainPage();
            CurrentPage.As<MCCMainPageActions>().VerifyMCCMainInfo(MCCMainObjects.AddDataForMCCMian, NewMCCCOde);
            CurrentPage.As<MCCMainPageActions>().MCCMainDeletion(NewMCCCOde);
            CurrentPage.As<MCCMainPageActions>().MCCMainDeletion(MCCMainObjects.MCCCode);
        }

        [TestCase("MCCMainTestData.json", "QA352_MCCUnitDisplay", Description = "M5-Create MCCUnitDisplay"),Order(1)]
        public void QA352_QA353_MCCUnitDisplayAndMCCQuery(object[] testParameter)
        {
            string MCCKey = CommonUtil.DataObjectForKey(MCCMainObjects.DataMCCode);
            string MCCJobCode = CommonUtil.DataObjectForKey("MCCJobCode");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            UnitMain Unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            DepartmentMain department = CommonUtil.DataObjectForKey("DeptDetails").ToObject<DepartmentMain>();
            string UnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(Unit);
            Settings.Logger.Info($" Created Unit { UnitNo} ");
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _pageNavigate.NavigateToDepartmentMainPage();
            string DeptNumber = CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment(department);
            Settings.Logger.Info($" Created Department { DeptNumber} ");
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _pageNavigate.NavigateComponentMainPage();
            string ComponentNumber = CurrentPage.As<ComponentMainPageActions>().CreateComponent("ComponentMain");
            Settings.Logger.Info($" Created Component { ComponentNumber} ");
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _pageNavigate.NavigateToMCCQuery();
            CurrentPage.As<MCCQueryPageActions>().VerifyMCCQuery(MCCKey, MCCJobCode, UnitNo, ComponentNumber, DeptNumber);
            CommonUtil.AddPassedTestCase("QA353");
            Settings.Logger.Info("------------Finishing executing test ' QA353 MCC Query' -------------------");
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _pageNavigate.NavigateToMCCUnitDisplay();
            CurrentPage.As<MCCUnitDisplayPageActions>().VerifyMCCUnitDisplay(MCCKey, UnitNo, ComponentNumber);
            Settings.Logger.Info("------------Finishing executing test ' QA352 MCCUnitDisplay' -------------------");
            _extendpage.ClickOnRefreshButton();
            Settings.Logger.Info("--------------Started Data Clean Up ---------------------");         
            CurrentPage = _pageNavigate.NavigateUnitMainPage();
            CurrentPage.As<UnitMainPageActions>().VerifyUnitDeletion(UnitNo);
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _pageNavigate.NavigateComponentMainPage();
            CurrentPage.As<ComponentMainPageActions>().VerifyComponentDeletion(ComponentNumber);
            _extendpage.ClickOnRefreshButton();
            CurrentPage = _homePage.NavigateToDepartmentMainPage();
            CurrentPage.As<DepartmentMainPageActions>().VerifyDepartmentDeletion(DeptNumber);
            Settings.Logger.Info("--------------Completed Data Clean Up ---------------------");
        }

        [Test, Description("M5-Verifying MCCUnitDisplayAndMCCQuer")]
        public void QA353_MCCQuery()
        {
            CommonUtil.VerifyPassedTestCase("QA353");
        }
    }
}
