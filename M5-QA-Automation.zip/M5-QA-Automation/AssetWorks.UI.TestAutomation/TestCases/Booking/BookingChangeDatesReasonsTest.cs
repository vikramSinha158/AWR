﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingChangeDatesReasonsObjects;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingDeclineCancelCodes;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Booking
{
    internal class BookingChangeDatesReasonsTest : Hooks
    {
        [TestCase("BookingChangeDatesReasonsTestData.json", "BookingDateChangeData",
            TestName = "QA774_QA777_QA782_QA785_CreateDisableEnableDeleteBookingDateChangeCode", Description = "M5-Booking Date Change Reasons-Create,Verify, Disable ,Enable and Delete new Booking Change Date Reason"),Order(1)]
        public void QA774_QA777_QA782_QA785_CreateDisableEnableDeleteBookingDateChangeCode(object[] testParameter)
        {
            BookingChangeDateDetails BookingChangeDate = CommonUtil.DataObjectForKey("CreateBookingDateChange").ToObject<BookingChangeDateDetails>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingChangeDateReasonsPage();
            BookingChangeDate.BookingDateCode = CurrentPage.As<BookingChangeDatesReasonsPageActions>().CreateBookingDateChangeReasonCode(BookingChangeDate);
            CurrentPage.As<BookingChangeDatesReasonsPageActions>().VerifyBookingDateChange(BookingChangeDate);
            Settings.Logger.Info("--------Execution completed for test ' QA774 Create Booking Date Change Data' ------");
            BookingChangeDate.BookingDateDisable = true;
            CurrentPage.As<BookingChangeDatesReasonsPageActions>().EditBookingDateChangeReason(BookingChangeDate);
            CurrentPage.As<BookingChangeDatesReasonsPageActions>().VerifyBookingDateChange(BookingChangeDate);
            CommonUtil.AddPassedTestCase("QA777");
            Settings.Logger.Info("--------Execution completed for test ' QA777 Disable Booking Date Change Data' ------");
            BookingChangeDate.BookingDateDisable = false;
            CurrentPage.As<BookingChangeDatesReasonsPageActions>().EditBookingDateChangeReason(BookingChangeDate);
            CurrentPage.As<BookingChangeDatesReasonsPageActions>().VerifyBookingDateChange(BookingChangeDate);
            CommonUtil.AddPassedTestCase("QA782");
            Settings.Logger.Info("--------Execution completed for test ' QA782 Enable Booking Date Change Data' ------");
            CurrentPage.As<BookingChangeDatesReasonsPageActions>().DeleteBookingDateChange(BookingChangeDate.BookingDateCode);
            CurrentPage.As<BookingChangeDatesReasonsPageActions>().VerifyAfterDeletionBookingDateChange(BookingChangeDate.BookingDateCode);
            CommonUtil.AddPassedTestCase("QA785");
            Settings.Logger.Info("--------Execution completed for test ' QA785 Delete Booking Date Change Data' ------");
        }


        [Test, Description("M5-DisableDateChangeCode,Merged with-QA774_QA777_QA782_QA785_CreateDisableEnableDeleteBookingDateChangeCode")]
        public void QA777_DisableDateChangeCode()
        {
            CommonUtil.VerifyPassedTestCase("QA777");
        }

        [Test, Description("M5-EnableDateChangeCode,Merged with-QA774_QA777_QA782_QA785_CreateDisableEnableDeleteBookingDateChangeCode")]
        public void QA782_EnableChangeDateCode()
        {
            CommonUtil.VerifyPassedTestCase("QA782");
        }

        [Test, Description("M5-DeleteDateChangeReason,Merged with-QA774_QA777_QA782_QA785_CreateDisableEnableDeleteBookingDateChangeCode")]
        public void QA785_DeleteDateChangeReason()
        {
            CommonUtil.VerifyPassedTestCase("QA785");
        }

    }
}
