﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking;
using NUnit.Framework;
using System.Diagnostics.Contracts;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking.CustomerMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Booking
{
    [TestFixture]
    internal class CustomerTest : Hooks
    {
        [TestCase("CustomerMainTestData.json", "CreateCustomerMain",
        Description = "M5-Booking-Customer Main-Create and Delete new Customer"),Order(1)]
        public void QA852_QA854_CreateDeleteNewCustomer(object[] testParameter)
        {
            CustomerMain createCustObjectValues = CommonUtil.DataObjectForKey("AddDataForCustomerMain").ToObject<CustomerMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCustomerMainPage();
            createCustObjectValues.CustomerID = CurrentPage.As<CustomerMainPageActions>().CreateCustomer(createCustObjectValues);          
            CurrentPage.As<CustomerMainPageActions>().VerifyCustomerData(createCustObjectValues);
            Settings.Logger.Info("QA852 - Create Customer completed successfully.!");
            CurrentPage.As<CustomerMainPageActions>().DeleteCustomerAndVerify(createCustObjectValues.CustomerID);
            CommonUtil.AddPassedTestCase("QA854");
            Settings.Logger.Info("QA854 -  Delete Customer completed successfully.!");
        }

        [Test, Description("M5- Delete Customer")]
        public void QA854_DeleteCustomer()
        {
            CommonUtil.VerifyPassedTestCase("QA854");
        }

        [TestCase("CustomerMainTestData.json", "CreateCustomerMain",
            TestName = "QA856_QA857_DisableEnableCustomer", Description = "M5-Booking-Customer Main-Disable and Enable Customer"),Order(1)]
        public void QA856_QA857_DisableEnableCustomer(object[] testParameter)
        {
            CustomerMain createDisableCustomer = CommonUtil.DataObjectForKey("QA856_DisableCustomer").ToObject<CustomerMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCustomerMainPage();
            string CustomerNumber = CurrentPage.As<CustomerMainPageActions>().CreateCustomer(createDisableCustomer);
            CurrentPage.As<CustomerMainPageActions>().EditCustomer(createDisableCustomer);
            CurrentPage.As<CustomerMainPageActions>().VerifyCustomerData(createDisableCustomer);
            Settings.Logger.Info("QA856 - Disable status completed successfully.!");
            CustomerMain Enablecustomer = CommonUtil.DataObjectForKey("QA857_EnableCustomer").ToObject<CustomerMain>();
            Enablecustomer.CustomerID= CustomerNumber;
            CurrentPage.As<CustomerMainPageActions>().EditCustomer(Enablecustomer);
            CurrentPage.As<CustomerMainPageActions>().VerifyCustomerData(Enablecustomer);
            CommonUtil.AddPassedTestCase("QA857");
            Settings.Logger.Info("QA857 - Enable status completed successfully.!");
            CurrentPage.As<CustomerMainPageActions>().DeleteCustomerAndVerify(CustomerNumber);
        }

        [Test, Description("M5- Enable Customer")]
        public void QA857_EnableCustomer()
        {
            CommonUtil.VerifyPassedTestCase("QA857");
        }

        [TestCase("CustomerMainTestData.json", "CreateCustomerMain",
        Description = "M5-Booking-Customer Contract-Create,Edit,Delete Customer Contract"),Order(1)]
        public void QA858_QA859_QA860_CreateEditDeleteCustomerContract(object[] testParameter)
        {
            CustomerMain createCustObjectValues = CommonUtil.DataObjectForKey("AddDataForCustomerMain").ToObject<CustomerMain>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCustomerMainPage();
            createCustObjectValues.CustomerID = CurrentPage.As<CustomerMainPageActions>().CreateCustomer(createCustObjectValues);
            CurrentPage  = _pageNavigate.NavigateToCustomerContractPage();
            string ContractNO =CurrentPage.As<CustomerContractPageActions>().CreateCustomerContract(createCustObjectValues.CustomerID, "AddCustomerContract");
            CurrentPage.As<CustomerContractPageActions>().VerifyCustomerContract(ContractNO, createCustObjectValues.CustomerID, createCustObjectValues.CustomerDesc, "AddCustomerContract");
            Settings.Logger.Info("QA858 - Create Customer Contract completed successfully.!");
            CurrentPage.As<CustomerContractPageActions>().EditContract(ContractNO, "EditCustomerContract");
            CurrentPage.As<CustomerContractPageActions>().VerifyCustomerContract(ContractNO, createCustObjectValues.CustomerID, createCustObjectValues.CustomerDesc, "EditCustomerContract");
            CommonUtil.AddPassedTestCase("QA860");
            Settings.Logger.Info("QA860 - Edit Customer Contract completed successfully.!");
            CurrentPage.As<CustomerContractPageActions>().DeleteContract(ContractNO);
            CurrentPage.As<CustomerContractPageActions>().VeriftContractDeletion(ContractNO);
            CommonUtil.AddPassedTestCase("QA859");
            Settings.Logger.Info("QA859 - Delete Customer Contract completed successfully.!");
            _pageNavigate.NavigateToCustomerMainPage().DeleteCustomerAndVerify(createCustObjectValues.CustomerID);
        }

        [Test, Description("M5- Edit Customer Contract")]        
        public void QA860_EditCustomerCntract()
        {
            CommonUtil.VerifyPassedTestCase("QA860");
        }

        [Test, Description("M5- Delete Customer Contract")]      
        public void QA859_DeleteCustomerContract()
        {
            CommonUtil.VerifyPassedTestCase("QA859");
        }

        [TestCase("CustomerMainTestData.json", "CreateCustomerMain",
           TestName = "QA861_CreateCustomerContractCopy", Description = "M5-Booking-Customer Main-Disable Customer")]
        public void QA861_CreateCustomerContractCopy(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCustomerMainPage();
            CreateCustomerContractCopy? copyCustomerData = CommonUtil.DataObjectForKey("CreateCustomerContractCopy").ToObject<CreateCustomerContractCopy>();
            CustomerMain createCustObjectValues = CommonUtil.DataObjectForKey("AddDataForCustomerMain").ToObject<CustomerMain>();
            copyCustomerData.CustomerNumber = CurrentPage.As<CustomerMainPageActions>().CreateCustomer(createCustObjectValues);
            Settings.Logger.Info("QA861 - Predata Setup completed successfully for Create Customer.!");

            CurrentPage = _pageNavigate.NavigateToCustomerContractCopyPage();
            string ContractNumber=CurrentPage.As<CustomerContractCopyPageActions>().CreateCustomerContractCopy(copyCustomerData);
            Settings.Logger.Info("QA861 - Create Customer Contract completed successfully");

            CurrentPage = _pageNavigate.NavigateToCustomerContractPage();
            CurrentPage.As<CustomerContractPageActions>().EditContract(ContractNumber, "EditDataForCustomerMain");
            CurrentPage.As<CustomerContractPageActions>().VerifyCustomerContract(ContractNumber, copyCustomerData.CustomerNumber, CustomerMainPage.Descrption, "EditDataForCustomerMain");
            Settings.Logger.Info("QA861 - Edit and Verify Customer Contract completed successfully");

        }
    }
}
