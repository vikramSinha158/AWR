﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingTypeCodes;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Booking
{
    [TestFixture]
    internal class BookingTypeCodesTest : Hooks
    {
        [TestCase("BookingTypeCodeTestData.json", "BookingTypeCodes"), Description ("M5-Booking-CreateEnableAndDisableBookingTypeCode(no address)"),Order(1)]
        public void QA742_QA748_CreateEnableAndDisableBookingTypeCodes(object[] testParameter)
        {
            BookingCodeDetails BookingTypecode = CommonUtil.DataObjectForKey("QA742_BookingCodeDetail").ToObject<BookingCodeDetails>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingTypeCodesPage();
            BookingTypecode.BookingType=CurrentPage.As<BookingTypeCodesPageActions>().CreateBookingTypeCode(BookingTypecode);
            CurrentPage.As<BookingTypeCodesPageActions>().VerifyBookingTypeCode(BookingTypecode);
            CommonUtil.AddPassedTestCase("QA742");
            Settings.Logger.Info("--------Execution completed for test ' QA742 Create Booking Type Codes' ------");
            BookingTypecode.Disabled = true;
            CurrentPage.As<BookingTypeCodesPageActions>().EditBookingTypeCode(BookingTypecode);
            CurrentPage.As<BookingTypeCodesPageActions>().VerifyBookingTypeCode(BookingTypecode);
            BookingTypecode.Disabled = false;
            CurrentPage.As<BookingTypeCodesPageActions>().EditBookingTypeCode(BookingTypecode);
            CurrentPage.As<BookingTypeCodesPageActions>().VerifyBookingTypeCode(BookingTypecode);
            CommonUtil.AddPassedTestCase("QA748");
            Settings.Logger.Info("--------Execution completed for test ' QA748 Enable Booking Type Codes' ------");
        }

        [TestCase("BookingTypeCodeTestData.json", "BookingTypeCodes",
            TestName = "QA745_Create_BookingTypeCodesRequiredAddress", Description = "M5-Booking-Booking Type Codes-Create New Type Code (address required)")]
        public void QA745_Create_BookingTypeCodesRequiredAddress(object[] testParameter)
        {
            BookingCodeDetails BookingTypecode = CommonUtil.DataObjectForKey("QA745_BookingCodeDetail").ToObject<BookingCodeDetails>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingTypeCodesPage();
            CurrentPage.As<BookingTypeCodesPageActions>().CreateBookingTypeCode(BookingTypecode);
            CurrentPage.As<BookingTypeCodesPageActions>().VerifyBookingTypeCode(BookingTypecode);
        }

        [TestCase("BookingTypeCodeTestData.json", "BookingTypeCodes",
            TestName = "QA747_QA749_Create_DeleteBookingTypeCodesDisable", Description = "M5-Booking-Booking Type Codes-Create-Delete New Type Code (disable checkbox)"),Order(1)]
        public void QA747_QA749_Create_DeleteBookingTypeCodesDisable(object[] testParameter)
        {
            BookingCodeDetails BookingTypecode = CommonUtil.DataObjectForKey("QA747_BookingCodeDetail").ToObject<BookingCodeDetails>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingTypeCodesPage();
            CurrentPage.As<BookingTypeCodesPageActions>().CreateBookingTypeCode(BookingTypecode);
            CurrentPage.As<BookingTypeCodesPageActions>().VerifyBookingTypeCode(BookingTypecode);
            Settings.Logger.Info("Create Booking Type With Disable Checkbox");
            CurrentPage.As<BookingTypeCodesPageActions>().DeleteBookingType(BookingTypecode);
            CurrentPage.As<BookingTypeCodesPageActions>().VerifyDeleteBookingType(BookingTypecode);
            CommonUtil.AddPassedTestCase("QA749");
            Settings.Logger.Info("Delete Booking Type With Disable Checkbox");
        }

        [Test, Description("M5-Booking-Booking Type Codes-Delete New Type Code (disable checkbox)")]       
        public void QA749_DeleteBookingTypeCodesDisable()
        {
            CommonUtil.VerifyPassedTestCase("QA749");
        }

        [Test, Description("M5-Booking-Booking Type-Enable and Disable Booking TypeCodes Merged with,QA742_QA748_CreateEnableAndDisableBookingTypeCodes")]

        public void QA748_EnableDisableBookingTypeCodes()
        {
            CommonUtil.VerifyPassedTestCase("QA748");
        }
    }
}
