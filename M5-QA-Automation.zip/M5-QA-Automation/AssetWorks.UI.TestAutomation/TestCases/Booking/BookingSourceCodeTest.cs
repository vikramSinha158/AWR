﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using NUnit.Framework;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingSourceCodeObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Booking
{
    internal class BookingSourceCodeTest : Hooks
    {
        [TestCase("BookingSourceCodeTestData.json", "CreateNewBookingSourceCode",
            TestName = "QA730_CreateUpdateNewSourceCode", Description = "M5-Booking-Booking Source Code-Create and update New Source Code")]
        public void QA730_CreateUpdateNewSourceCode(object[] testParameter)
        {
            BookingSourceCode bookingSourceCode = CommonUtil.DataObjectForKey("AddDataForBookingSource").ToObject<BookingSourceCode>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingSourceCodesPage();
            bookingSourceCode.BookingCode = CurrentPage.As<BookingSourceCodePageActions>().CreateBookingSourceCode(bookingSourceCode);
            CurrentPage.As<BookingSourceCodePageActions>().VerifyBookingSourceCode(bookingSourceCode);
            bookingSourceCode.Disable = false;
            CurrentPage.As<BookingSourceCodePageActions>().UpdateBookingSourceCode(bookingSourceCode);
            CurrentPage.As<BookingSourceCodePageActions>().VerifyBookingSourceCode(bookingSourceCode);
            CurrentPage.As<BookingSourceCodePageActions>().DeleteBookingSourceCode(bookingSourceCode);
            CurrentPage.As<BookingSourceCodePageActions>().VerifyDeleteBookingSourceCode(bookingSourceCode);
        }
    }
}
