﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Booking
{
    [TestFixture]
    internal class CustomerTypesCodesTest : Hooks
    {
        [TestCase("CustomerTypeCodesTestData.json", "CustomerTypeCode", TestName = "QA770_QA773_Create_Delete_CustomerTypesCodes",
            Description = "M5-Booking-Customer Type Codes-Create and delete new Customer Type Code"),Order(1)]
        public void QA770_QA773_Create_Delete_CustomerTypesCodes(object[] testParameter)
        {
            CustomerTypeCode CustomerTypeData = CommonUtil.DataObjectForKey("QA_770CreateCustomerType").ToObject<CustomerTypeCode>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCustomerTypeCodesPage();
            CustomerTypeData.CustomerType = CurrentPage.As<CustomerTypeCodesPageActions>().CreateCustomerTypeCode(CustomerTypeData);
            CurrentPage.As<CustomerTypeCodesPageActions>().VerifyCustomerTypeCode(CustomerTypeData);
            Settings.Logger.Info("QA770 Create Booking Type Code Executed Successfully");
            CurrentPage.As<CustomerTypeCodesPageActions>().DeleteCustomerTypeCodes(CustomerTypeData);
            CurrentPage.As<CustomerTypeCodesPageActions>().VerifyDeletedCustomerCode(CustomerTypeData);
            CommonUtil.AddPassedTestCase("QA773");
            Settings.Logger.Info("QA773 Delete Booking Type Code Executed Successfully");

        }

        [Test, Description("M5-Deleting and Verifying Customer Type Code")]       
        public void QA773_DeletingCustomerTypeCode()
        {
            CommonUtil.VerifyPassedTestCase("QA773");
        }

        [TestCase("CustomerTypeCodesTestData.json", "CustomerTypeCode", TestName = "QA771_QA772_CreateEnableCustomerTypesCodesDisableCheckbox",
            Description = "M5-Booking-Create Customer Type Codes and Enable Customer Type Code"),Order(1)]
        public void QA771_QA772_CreateEnableCustomerTypesCodesDisableCheckbox(object[] testParameter)
        {
            CustomerTypeCode CustomerTypeData = CommonUtil.DataObjectForKey("CreateCustomerType").ToObject<CustomerTypeCode>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCustomerTypeCodesPage();
            CustomerTypeData.CustomerType = CurrentPage.As<CustomerTypeCodesPageActions>().CreateCustomerTypeCode(CustomerTypeData);
            CurrentPage.As<CustomerTypeCodesPageActions>().VerifyCustomerTypeCode(CustomerTypeData);
            Settings.Logger.Info("--------Execution completed for test ' QA771 Create and Disable Customer Type Codes' ------");
            CustomerTypeData.Disable = false;
            CurrentPage.As<CustomerTypeCodesPageActions>().EditCustomerTypeCode(CustomerTypeData);
            CurrentPage.As<CustomerTypeCodesPageActions>().VerifyCustomerTypeCode(CustomerTypeData);
            CommonUtil.AddPassedTestCase("QA772");
            Settings.Logger.Info("--------Execution completed for test ' QA772 Enable Customer Type Codes' ------");
        }

        [Test, Description("Enable Customer Type Code Merged with ,QA771_QA772_CreateEnableCustomerTypesCodesDisableCheckbox")]
        public void QA772_EnableCustomerTypeCode()
        {
            CommonUtil.VerifyPassedTestCase("QA772");
        }

    }
}
