﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.FuelProduct
{
    [TestFixture]
    internal class FuelProductTest : Hooks
    {
        [TestCase("FuelProductsTestData.json", "CreateProductMain", TestName = "QA691_CreateProductMain",
           Description = "M5-FuelProducts-CreateProductMain(no address)")]
        public void QA691_CreateProductMain(object[] testParameter)
        {
            FuelProducts fuelProducts = CommonUtil.DataObjectForKey("FuelProducts").ToObject<FuelProducts>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToFuelProductsMain();
            fuelProducts.productNumber = CurrentPage.As<FuelProductPageActions>().CreateFuelProduct(fuelProducts);
            CurrentPage.As<FuelProductPageActions>().VerifyFuelProduct(fuelProducts);
        }

        [TestCase("FuelProductsTestData.json", "CreateProductMain", TestName = "QA1133_CreateProductMainForAlternateFuel",
          Description = "M5-FuelProducts-CreateProductMainForAlternateFuel(no address)")]
        public void QA1133_CreateProductMainForAlternateFuel(object[] testParameter)
        {
            FuelProducts fuelProducts = CommonUtil.DataObjectForKey("AlternateFuelProducts").ToObject<FuelProducts>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToFuelProductsMain();
            fuelProducts.productNumber = CurrentPage.As<FuelProductPageActions>().CreateFuelProduct(fuelProducts);
            CurrentPage.As<FuelProductPageActions>().VerifyFuelProduct(fuelProducts);
        }

        [TestCase("ProductSetupTankTestData.json", "QA1277_ProductTank", TestName = "QA1277_QA1278_CreateUpdateDeleteProductTanks",
          Description = "M5-FuelProducts-Create product tanks")]
        public void QA1277_CreateProductTanks(object[] testParameter)
        {
            ProductTank DataObject = CommonUtil.DataObjectForKey("ProductTank").ToObject<ProductTank>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToProductSetupTanksPage();
            CurrentPage.As<ProductSetupTanksPageActions>().CreateProductTank(DataObject);
            CurrentPage.As<ProductSetupTanksPageActions>().VerifyCreatedProductTank(DataObject);

            CurrentPage.As<ProductSetupTanksPageActions>().UpdateAndDeleteProductTank(DataObject);
            CurrentPage.As<ProductSetupTanksPageActions>().VerifyDeletedProductTank(DataObject);
            Settings.Logger.Info("QA1278 Updated and Deleted ProductTank successfully");
            CommonUtil.AddPassedTestCase("QA1278");
        }

        [TestCase(
         TestName = "QA1278_UpdateDeleteProductTanks",
         Description = "M5-FuelProducts-Update & Delete product tanks, Merged with QA1277_CreateProductTanks")]
        public void QA1278_UpdateDeleteProductTanks()
        {
            CommonUtil.VerifyPassedTestCase("QA1278");
        }

        [TestCase("ProductSetUpLocation.json", "SetUpLocation", 
         TestName = "QA1298_QA1299_ProductSetUpLocation",
         Description = "M5-Product-Craete Product Setup Locations "),Order(1)]
        public void QA1298_QA1299_ProductSetUpLocation(object[] testParameter)
        {
            Settings.Logger.Info("Started QA1298_ProductSetUpLocation");
            ProductLocation DataObject = CommonUtil.DataObjectForKey("QA1298_ProductSetUpLocation").ToObject<ProductLocation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToProductSetupLocationPage();
            CurrentPage.As<ProductSetUpLocationPageActions>().CreateProductLocation(DataObject.ProductSetUpLocation);
            CurrentPage.As<ProductSetUpLocationPageActions>().VerifyProductLocation(DataObject.ProductSetUpLocation);
            Settings.Logger.Info("Ended QA1298_ProductSetUpLocation");
            Settings.Logger.Info("Started QA1299_UpdateProductSetUpLocation");
            DataObject = CommonUtil.DataObjectForKey("QA1299_UpdateProductSetUpLocation").ToObject<ProductLocation>();
            CurrentPage.As<ProductSetUpLocationPageActions>().UpdateProductLocation(DataObject.ProductSetUpLocation);
            CurrentPage.As<ProductSetUpLocationPageActions>().VerifyProductLocation(DataObject.ProductSetUpLocation);
            Settings.Logger.Info("Ended QA1299_UpdateProductSetUpLocation");
            CommonUtil.AddPassedTestCase("QA1299");
        }

        [TestCase(
       TestName = "QA1299_UpdateProductSetUpLocation",
       Description = "M5-Product-Update Product Setup Location , Merged with QA1298_ProductSetUpLocation")]
        public void QA1299_UpdateProductSetUpLocation()
        {
            CommonUtil.VerifyPassedTestCase("QA1299");
        }


        [TestCase("ProductSetUpEmployees.json", "ProductEmployeeSetUp", 
        TestName = "QA1316_QA1317_ProductSetUpEmployess",
        Description = "M5-Product-Create Product Setup Employee"),Order(1)]
        public void QA1316_QA1317_ProductSetUpEmployess(object[] testParameter)
        {
            Settings.Logger.Info("Started QA1316_ProductSetUpEmployess");
            EmployeeSetup DataObject = CommonUtil.DataObjectForKey("QA1316_ProductSetUpEmployees").ToObject<EmployeeSetup>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToProductSetUpEmployee();
            CurrentPage.As<ProductSetupEmployee>().CleanUpData(DataObject.productSetUpEmployees);
            CurrentPage.As<ProductSetupEmployee>().CreateProductEmployee(DataObject.productSetUpEmployees.SetUpEmployeeDetails);
            CurrentPage.As<ProductSetupEmployee>().VerifyEmployeeSetUp(DataObject.productSetUpEmployees);
            Settings.Logger.Info("Ended QA1316_ProductSetUpEmployess");
            Settings.Logger.Info("Started QA1317_UpdateDeleteProductEmployees");
            DataObject = CommonUtil.DataObjectForKey("QA1317_UpdateProductSetUpEmployees").ToObject<EmployeeSetup>();
            CurrentPage.As<ProductSetupEmployee>().UpdateProductEmployee(DataObject.productSetUpEmployees);
            CurrentPage.As<ProductSetupEmployee>().VerifyEmployeeSetUp(DataObject.productSetUpEmployees);
            CommonUtil.AddPassedTestCase("QA1317");
            Settings.Logger.Info("Ended QA1317_UpdateDeleteProductEmployees");
        }

        [TestCase(
        TestName = "QA1317_UpdateDeleteProductEmployees",
        Description = "M5-Product-Update-Delete Product Setup Employee")]
        public void QA1317_UpdateDeleteProductEmployees()
        {
            Settings.Logger.Info("Code is Merged with QA1316_ProductSetUpEmployess");
            CommonUtil.VerifyPassedTestCase("QA1317");
        }
    }
}
