﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Labor;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Labor
{
    [TestFixture]
    internal class LaborTest : Hooks
    {      

        [TestCase("LaborTestData.json", "QA936_EmployeeLaborWedge",
            TestName = "QA936_AddandRemoveEmployeeLaborWedge", Description = "M5-Labor-Labor Wedge-Employee Labor (Unit Work Order)")]
        public void QA936_AddandRemoveEmployeeLaborWedge(object[] testParameter)
        {
            EmpLaborWedge Wedge = CommonUtil.DataObjectForKey("LaborWedge").ToObject<EmpLaborWedge>();
            EmpLaborWedge WedgeR = CommonUtil.DataObjectForKey("RemoveWedge").ToObject<EmpLaborWedge>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToLaborWedgePage();
            CurrentPage.As<LaborWedgePageActions>().AddEmployeeLaborWedge(Wedge);
            CurrentPage.As<LaborWedgePageActions>().VerifyAddedLaborWedge(Wedge);
            CurrentPage.As<LaborWedgePageActions>().RemoveEmployeeLaborWedge(WedgeR);
        }
    }
}
