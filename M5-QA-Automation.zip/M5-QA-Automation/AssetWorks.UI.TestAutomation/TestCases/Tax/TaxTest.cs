﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Tax
{
    /// <summary>
    /// Test scenarios for Tax
    /// </summary>
    [TestFixture]
    internal class TaxTest : Hooks
    {

        [TestCase("TaxTypeTestData.json", "CreateTaxType", Description = "M5-Create, Edit and Delete Tax Type")]
        public void QA986_CreateUpdateDeleteTaxType(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTaxTypePage();
            TaxTypeMainPage.TaxClass = CurrentPage.As<TaxTypePageActions>().CreateTaxType("AddTaxTypeRecord");
            CurrentPage.As<TaxTypePageActions>().VerifyTaxRecord("AddTaxTypeRecord", TaxTypeMainPage.TaxClass);
            CurrentPage.As<TaxTypePageActions>().EditTaxRecord("EditTaxTypeRecord", TaxTypeMainPage.TaxClass);
            CurrentPage.As<TaxTypePageActions>().VerifyTaxRecord("EditTaxTypeRecord", TaxTypeMainPage.TaxClass);
            CurrentPage.As<TaxTypePageActions>().DeleteTaxType(TaxTypeMainPage.TaxClass);
            CurrentPage.As<TaxTypePageActions>().VerifyDeletedTaxType(TaxTypeMainPage.TaxClass);
        }

        [TestCase("TaxSchemeTestData.json", "QA987_CreateTaxScheme", Description = "M5-Create Tax Scheme-Parts Receive,Parts Issue,Labor")]
        public void QA987_CreateTaxScheme(object[] testParameter)
        {
            TaxScheme createTaxSchemeObject = CommonUtil.DataObjectForKey("TaxScheme").ToObject<TaxScheme>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTaxSchemePage();
            bool flagCancel = true;
            for (int i = 0; i < createTaxSchemeObject.CreateTaxScheme.AppliedTo.Count; i++)
            {
                string TaxSchemeID = CurrentPage.As<TaxSchemePageActions>().CreateTaxScheme(createTaxSchemeObject.CreateTaxScheme.AppliedTo[i], createTaxSchemeObject, flagCancel);
                CurrentPage.As<TaxSchemePageActions>().VerifyTaxScheme(TaxSchemeID, createTaxSchemeObject.CreateTaxScheme.AppliedTo[i], createTaxSchemeObject.CreateTaxScheme);
                flagCancel = false;                
            }

        }

        [TestCase("TaxSchemeTestData.json", "QA1008_EditTaxScheme", Description = "M5-Create,Edit Tax Scheme(Gasoline and Diesel)")]
        public void QA1008_EditTaxScheme(object[] testParameter)
        {
            TaxScheme createTaxSchemeObject = CommonUtil.DataObjectForKey("TaxScheme").ToObject<TaxScheme>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTaxSchemePage();

            for (int i = 0; i < createTaxSchemeObject.CreateTaxScheme.AppliedTo.Count; i++)
            {
                string TaxSchemeID = CurrentPage.As<TaxSchemePageActions>().CreateTaxScheme(createTaxSchemeObject.CreateTaxScheme.AppliedTo[i], createTaxSchemeObject);
                CurrentPage.As<TaxSchemePageActions>().VerifyTaxScheme(TaxSchemeID, createTaxSchemeObject.CreateTaxScheme.AppliedTo[i], createTaxSchemeObject.CreateTaxScheme);
                CurrentPage.As<TaxSchemePageActions>().UpdateTaxScheme(TaxSchemeID, createTaxSchemeObject, null);
                CurrentPage.As<TaxSchemePageActions>().VerifyTaxScheme(TaxSchemeID, createTaxSchemeObject.CreateTaxScheme.AppliedTo[i], createTaxSchemeObject.UpdateTaxScheme);               
            }

        }
        [TestCase("TaxSchemeTestData.json", "QA1008_EditTaxScheme", Description = "M5-Delete Tax Scheme(Gasoline and Diesel)")]
        public void QA1009_DeleteTaxScheme(object[] testParameter)
        {
            TaxScheme createTaxSchemeObject = CommonUtil.DataObjectForKey("TaxScheme").ToObject<TaxScheme>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTaxSchemePage();
            for (int i = 0; i < createTaxSchemeObject.CreateTaxScheme.AppliedTo.Count; i++)
            {
                string TaxSchemeID = CurrentPage.As<TaxSchemePageActions>().CreateTaxScheme(createTaxSchemeObject.CreateTaxScheme.AppliedTo[i], createTaxSchemeObject);
                CurrentPage.As<TaxSchemePageActions>().DeleteTaxScheme(TaxSchemeID);
                CurrentPage.As<TaxSchemePageActions>().VerifyDeletion(TaxSchemeID);
            }
        }

    }
}
