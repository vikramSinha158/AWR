﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.SystemAdmin
{
    [TestFixture]
    internal class ApplicationUserMaintenanceTest : Hooks
    {
        [TestCase("AppUserMaintenanceTestData.json", "ApplicationUserMaintenance", Description = "M5-System Admin-Create, Edit and Delete Application User"),Order(1)]
        public void QA794_QA795_CreateEditDeleteApplicationUser(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToApplicationUserMaintenancePage();
            AppUserMaintenanceMainPage.ApplicationUser = CurrentPage.As<AppUserMaintenancePageActions>().CreateApplicationUser("AddApplicationUser");
            CurrentPage.As<AppUserMaintenancePageActions>().VerifyApplicationUserMaintenanceDetail(AppUserMaintenanceMainPage.ApplicationUser);
            CurrentPage.As<AppUserMaintenancePageActions>().EditApplicationUserDetail("EditApplicationUser", AppUserMaintenanceMainPage.ApplicationUser);
            CurrentPage.As<AppUserMaintenancePageActions>().VerifyApplicationUserMaintenanceDetail(AppUserMaintenanceMainPage.ApplicationUser);
            CommonUtil.AddPassedTestCase("QA795");
            Settings.Logger.Info("QA795 - Edit Application User completed successfully.!");
            CurrentPage.As<AppUserMaintenancePageActions>().VerifyApplicationUserDeletion(AppUserMaintenanceMainPage.ApplicationUser);
            Settings.Logger.Info("QA794 - Create,Delete Application User completed successfully.!");
        }

        [Test, Description("M5-Edit Application User")]
        public void QA795_EditApplicationUser()
        {
            CommonUtil.VerifyPassedTestCase("QA795");
        }

        [TestCase("AppUserMaintenanceTestData.json", "ApplicationUserMaintenance", Description =
            "M5-Basic User Functionality-Copying an existing Application User Profile")]
        public void QA750_CopyApplicationUser(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToApplicationUserMaintenancePage();
            AppUserMaintenanceMainPage.ApplicationUser = CurrentPage.As<AppUserMaintenancePageActions>().CreateApplicationUser("AddApplicationUser");
            HomePageActions homepage = new HomePageActions(Driver);
            CurrentPage = homepage.NavigateToApplicationUserCopyPage();
            CurrentPage.As<AppUserCopyPageActions>().CopyApplicationUser("CopyApplicationUser", AppUserMaintenanceMainPage.ApplicationUser);
            CurrentPage = new AppUserMaintenancePageActions(Driver);
            CurrentPage.As<AppUserMaintenancePageActions>().VerifyApplicationUserMaintenanceDetail(AppUserMaintenanceMainPage.NewUserID);
            CurrentPage.As<AppUserMaintenancePageActions>().VerifyApplicationUserDeletion(AppUserMaintenanceMainPage.NewUserID);
        }

    }
}
