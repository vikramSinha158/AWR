﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.SystemAdmin
{
    [TestFixture]
    internal class SystemAdminTest : Hooks
    {
        private HomePageActions _homePage => new HomePageActions(Driver);

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin-Creating a new Role "),Order(2)]
        public void QA743_QA759_QA744_QA746_SystemAdminCreateEditAndDeletewMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.AddRoleMaintenance);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRoleMaintenanceDetail(SystemAdminObjects.AddRoleMaintenance, SystemAdminObjects.MaintenanceRole);
            CommonUtil.AddPassedTestCase("QA759");
            Settings.Logger.Info("------------Finishing executing test ' QA743 Create System Admin ' -------------------");
            CurrentPage.As<RoleMaintenancePageActions>().EditRoleMaintenanceDetail(SystemAdminObjects.EditRoleMaintenance);       
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRoleMaintenanceDetail(SystemAdminObjects.EditRoleMaintenance, SystemAdminObjects.MaintenanceRole);
            Settings.Logger.Info("------------Finishing executing test 'QA744 Add System Admin' -------------------");
            CommonUtil.AddPassedTestCase("QA744");
            CurrentPage.As<RoleMaintenancePageActions>().VerifyMaintenanceRoleDeletion();
            CommonUtil.AddPassedTestCase("QA746");
            Settings.Logger.Info("------------Finishing executing test ' QA759 Add System Admin' -------------------");
        }

        [Test, Description("M5-Verifying SystemAdmin Edit MaintenanceRole")]
        public void QA744_EditMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA744");
        }

        [Test, Description("M5-Verifying SystemAdmin Edit MaintenanceRole")]
        public void QA746_DeletewMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA746");
        }

        [Test, Description("M5-Verifying Adding General Information to an existing Role")]
        public void QA759_AddingGeneralInformation()
        {
            CommonUtil.VerifyPassedTestCase("QA759");
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin-Locations Operational "), Order(2)]
        public void QA761_QA775_AddingAndRemovingLocationsOperationalMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.LocationsOperational);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyLocationsOperational(SystemAdminObjects.MaintenanceRole);
            Settings.Logger.Info("------------Finishing executing test ' QA761 Adding Locations Operational MaintenanceRole' -------------------");
            CurrentPage.As<RoleMaintenancePageActions>().MoveLocationsOperationalLeft();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRemovingLocationsOperational(SystemAdminObjects.MaintenanceRole);
            CommonUtil.AddPassedTestCase("QA775");
            Settings.Logger.Info("------------Finishing executing test ' QA775  Removing Locations Operational MaintenanceRole' -------------------");
        }

        [Test, Description("M5-Verifying Removing Locations Operational Maintenance Role")]
        public void QA775_RemovingLocationsOperationalMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA775");
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin Adding and Removing Menus or KPIs "), Order(2)]
        public void QA762_QA776_AddingAndRemovingMenusorKPIsMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.MenusKpi);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyMenusKPI(SystemAdminObjects.MaintenanceRole);
            Settings.Logger.Info("------------Finishing executing test ' QA762  Adding MenusorKPIsMaintenanceRole' -------------------");
            CurrentPage.As<RoleMaintenancePageActions>().MoveAuthorizedMenusAndKPIToLeft();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRemovingMenusKPI(SystemAdminObjects.MaintenanceRole);
            CommonUtil.AddPassedTestCase("QA776");
            Settings.Logger.Info("------------Finishing executing test ' QA776  Removing MenusorKPIsMaintenanceRole' -------------------");
        }

        [Test, Description("M5-Verifying Removing Menus Maintenance Role")]
        public void QA776_RemovingMenusMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA776");
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin Adding and Removing Privileges ") ,Order(2)]
        public void QA763_QA778_AddingAndRemovingPrivilegesMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.Privileges);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyPrivileges(SystemAdminObjects.MaintenanceRole);
            Settings.Logger.Info("------------Finishing executing test ' QA763 Adding PrivilegesMaintenanceRole' -------------------");
            CurrentPage.As<RoleMaintenancePageActions>().MoveAuthorizedPrivilegesLeft();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRemovingPrivileges(SystemAdminObjects.MaintenanceRole);
            CommonUtil.AddPassedTestCase("QA778");
            Settings.Logger.Info("------------Finishing executing test ' QA778  Removing PrivilegesMaintenanceRole' -------------------");
        }

        [Test, Description("M5-Verifying Removing Privileges Maintenance Role")]
        public void QA778_RemovingPrivilegesMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA778");
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin Adding and Removing Reporting In MaintenanceRole"), Order(2)]
        public void QA764_QA780_AddingAndRemovingReportingInMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.Reporting);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyReporting(SystemAdminObjects.MaintenanceRole);
            Settings.Logger.Info("------------Finishing executing test ' QA764  Adding ReportingInMaintenanceRole' -------------------");
            CurrentPage.As<RoleMaintenancePageActions>().MoveAllAuthorizedReportingGroupsToLeft();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRemovingReportingGroupsList(SystemAdminObjects.MaintenanceRole);
            CommonUtil.AddPassedTestCase("QA780");
            Settings.Logger.Info("------------Finishing executing test ' QA780  Removing ReportingInMaintenanceRole' -------------------");
        }

        [Test, Description("M5-Verifying Removing Reporting Maintenance Role")]
        public void QA780_RemovingReportingIMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA780");
        }  

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin Adding and Removing Departments And Chat Grp In MaintenanceRole"), Order(2)]
        public void QA765_QA781_AddingAndRemovingDepartmentsAndChatGroup(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.DepartmentsAndChatGrp);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyDepartmentsAndChatGroup(SystemAdminObjects.MaintenanceRole);
            Settings.Logger.Info("------------Finishing executing test ' QA765  Adding DepartmentsAndChatGroup' -------------------");
            CurrentPage.As<RoleMaintenancePageActions>().MoveAuthorizedDepartmentsAndChatToLeft();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRemovingDepartmentsAndChat(SystemAdminObjects.MaintenanceRole);
            CommonUtil.AddPassedTestCase("QA781");
            Settings.Logger.Info("------------Finishing executing test ' QA781  Removing DepartmentsAndChatGroup' -------------------");
        }

        [Test, Description("M5-Verifying Removing Departments And ChatGroup"), Order(4)]
        public void QA781_RemovingDepartmentsAndChatGroup()
        {
            CommonUtil.VerifyPassedTestCase("QA781");
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin-Adding and Removing Vendor Gateway ")]
        public void QA783_AddingAndRemovingVendorGatewayInMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.vGState);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyvGState(SystemAdminObjects.MaintenanceRole);
            CurrentPage.As<RoleMaintenancePageActions>().MoveAuthorizedvGStateListLeft();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRemovingvGState(SystemAdminObjects.MaintenanceRole);
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin- IndiractAccounts "), Order(2)]
        public void QA784_QA768_AddingAndRemovingIndiractAccountsInMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            SystemAdminObjects.MaintenanceRole = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.IndiractAccounts);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyIndiractAccounts(SystemAdminObjects.MaintenanceRole);
            Settings.Logger.Info("------------Finishing executing test ' QA784  Adding AccountsInMaintenanceRol' -------------------");
            CurrentPage.As<RoleMaintenancePageActions>().MoveAuthorizedIndiractAccountsListLeft();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyRemovingIndiractAccounts(SystemAdminObjects.MaintenanceRole);
            CommonUtil.AddPassedTestCase("QA768");
            Settings.Logger.Info("------------Finishing executing test ' QA768  Removing AccountsInMaintenanceRol' -------------------");
        }

        [Test, Description("M5-Verifying Removing Departments And ChatGroup"), Order(4)]
        public void QA768_RemovingIndiractAccountsInMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA768");
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Admin Adding and Removing Departments And Chat Grp In MaintenanceRole"), Order(1)]
        public void QA988_ChatGroupAndValidationRoleMaintenancescreen(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToChatGroupMaintenancePage();
            CurrentPage.As<ChatGroupMaintenancePageActions>().AddChatgroup(2);
            CurrentPage.As<ChatGroupMaintenancePageActions>().VerifyAddedChatGroup();
            CurrentPage.As<ChatGroupMaintenancePageActions>().DeleteChatGroup();
            CurrentPage.As<ChatGroupMaintenancePageActions>().VerifyDeletionChatGroup();
            CurrentPage.As<ChatGroupMaintenancePageActions>().AddChatgroup(4);
            CurrentPage.As<ChatGroupMaintenancePageActions>().VerifyAddedChatGroup();
            CurrentPage.As<ChatGroupMaintenancePageActions>().DeleteChatGroup();
        }

        [TestCase("RoleMaintenanceTestData.json", "SystemAdmin", Description = "M5-Verifying System Adding Vendor Gateway Maintenance Role "), Order(2)]
        public void QA767_QA793_AddingVendorGatewayAndCopyingExistingMaintenanceRole(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToRoleMaintenancePage();
            string RoleName = CurrentPage.As<RoleMaintenancePageActions>().CreateMaintenanceRole(SystemAdminObjects.vGState);
            CurrentPage.As<RoleMaintenancePageActions>().VerifyvGState(RoleName);
            Settings.Logger.Info("------------Finishing executing test ' QA767 Adding Vendor Gateway' -------------------");          
            CurrentPage =_homePage.NavigateToRoleCopyPage();
            string NewRoleName =CurrentPage.As<RoleCopyPageActions>().CopyExistingRoleMaintenance(RoleName);
            CurrentPage = _homePage.NavigateToRoleMaintenancePage();
            CurrentPage.As<RoleMaintenancePageActions>().VerifyCopyRoleMaintenance(SystemAdminObjects.vGState,NewRoleName);
            CommonUtil.AddPassedTestCase("QA793");
            Settings.Logger.Info("------------Finishing executing test ' QA793 Copyin gExisting Maintenance Role' -------------------");
        }

        [Test, Description("M5-Verifying Copying Existing Maintenance Role")]
        public void QA793_CopyingExistingMaintenanceRole()
        {
            CommonUtil.VerifyPassedTestCase("QA793");
        }
    }
}
